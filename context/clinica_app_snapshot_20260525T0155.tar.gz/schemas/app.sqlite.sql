PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS source_registry (
  id TEXT PRIMARY KEY,
  source_type TEXT NOT NULL CHECK (source_type IN ('official_normative','official_judicial','official_doctrine','internal_rulebook','manual_upload')),
  authority_name TEXT NOT NULL,
  title TEXT NOT NULL,
  jurisdiction TEXT NOT NULL CHECK (jurisdiction IN ('nacional','provincia_buenos_aires','caba','federal','otras')),
  official_url TEXT NOT NULL,
  alternate_url TEXT,
  source_hash TEXT NOT NULL,
  publication_date TEXT NOT NULL,
  effective_date TEXT,
  control_date TEXT NOT NULL,
  vigencia_status TEXT NOT NULL CHECK (vigencia_status IN ('vigente','derogada','modificada','dudosa','pendiente_control')),
  publication_state TEXT NOT NULL DEFAULT 'draft' CHECK (publication_state IN ('draft','pending_review','approved','active','retired')),
  review_status TEXT NOT NULL CHECK (review_status IN ('raw','importado','clasificacion_pendiente','clasificado','verificado_humano','aprobado_codex','rechazado')),
  is_official_source INTEGER NOT NULL DEFAULT 1 CHECK (is_official_source IN (0,1)),
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  retired_at TEXT,
  CHECK (publication_state != 'active' OR review_status IN ('verificado_humano','aprobado_codex')),
  CHECK (official_url <> ''),
  CHECK (source_hash <> ''),
  CHECK (publication_date <> ''),
  CHECK (control_date <> '')
);

CREATE TABLE IF NOT EXISTS raw_documents (
  id TEXT PRIMARY KEY,
  source_id TEXT NOT NULL,
  document_kind TEXT NOT NULL CHECK (document_kind IN ('norma','jurisprudencia','doctrina','guia','regla_interna','historia_clinica','parte_quirurgico','consentimiento_informado','anexo')),
  file_name TEXT NOT NULL,
  mime_type TEXT,
  storage_path TEXT NOT NULL,
  binary_hash TEXT NOT NULL,
  text_hash TEXT,
  ingestion_method TEXT NOT NULL CHECK (ingestion_method IN ('manual_upload','crawler_detect_only','email_import','filesystem_sync')),
  immutable_status TEXT NOT NULL DEFAULT 'immutable' CHECK (immutable_status = 'immutable'),
  detected_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  ingested_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  created_by TEXT,
  notes TEXT,
  FOREIGN KEY(source_id) REFERENCES source_registry(id)
);

CREATE TABLE IF NOT EXISTS norm_index (
  id TEXT PRIMARY KEY,
  source_id TEXT NOT NULL,
  raw_document_id TEXT NOT NULL,
  corpus TEXT NOT NULL CHECK (corpus IN ('normativo','jurisprudencia','doctrina','clinico','interno')),
  title TEXT NOT NULL,
  short_citation TEXT,
  pathology_code TEXT,
  procedure_code TEXT,
  specialty TEXT,
  publication_state TEXT NOT NULL DEFAULT 'draft' CHECK (publication_state IN ('draft','pending_review','approved','active','retired')),
  vigencia_status TEXT NOT NULL CHECK (vigencia_status IN ('vigente','derogada','modificada','dudosa','pendiente_control')),
  review_status TEXT NOT NULL CHECK (review_status IN ('raw','importado','clasificacion_pendiente','clasificado','verificado_humano','aprobado_codex','rechazado')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(source_id) REFERENCES source_registry(id),
  FOREIGN KEY(raw_document_id) REFERENCES raw_documents(id),
  CHECK (publication_state != 'active' OR review_status IN ('verificado_humano','aprobado_codex'))
);

CREATE TABLE IF NOT EXISTS evidence_fragments (
  id TEXT PRIMARY KEY,
  norm_index_id TEXT NOT NULL,
  raw_document_id TEXT NOT NULL,
  fragment_type TEXT NOT NULL CHECK (fragment_type IN ('textual_quote','summary','table_extract','metadata','rule_basis')),
  page_label TEXT,
  section_label TEXT,
  excerpt TEXT NOT NULL,
  excerpt_hash TEXT NOT NULL,
  proposition TEXT,
  citation_locator TEXT,
  review_status TEXT NOT NULL CHECK (review_status IN ('raw','importado','clasificacion_pendiente','clasificado','verificado_humano','aprobado_codex','rechazado')),
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(norm_index_id) REFERENCES norm_index(id),
  FOREIGN KEY(raw_document_id) REFERENCES raw_documents(id)
);

CREATE TABLE IF NOT EXISTS internal_rules (
  id TEXT PRIMARY KEY,
  norm_index_id TEXT,
  rule_code TEXT NOT NULL UNIQUE,
  rule_title TEXT NOT NULL,
  rule_text TEXT NOT NULL,
  scope_type TEXT NOT NULL CHECK (scope_type IN ('global','especialidad','patologia','procedimiento','documento')),
  pathology_code TEXT,
  procedure_code TEXT,
  trigger_type TEXT NOT NULL CHECK (trigger_type IN ('drafting','validation','warning','template_selection','review_gate')),
  publication_state TEXT NOT NULL DEFAULT 'draft' CHECK (publication_state IN ('draft','pending_review','approved','active','retired')),
  review_status TEXT NOT NULL CHECK (review_status IN ('raw','importado','clasificacion_pendiente','clasificado','verificado_humano','aprobado_codex','rechazado')),
  source_priority INTEGER NOT NULL DEFAULT 100,
  approved_by TEXT,
  approved_at TEXT,
  retired_at TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY(norm_index_id) REFERENCES norm_index(id),
  CHECK (publication_state != 'active' OR approved_at IS NOT NULL),
  CHECK (publication_state != 'active' OR review_status IN ('verificado_humano','aprobado_codex'))
);

CREATE TABLE IF NOT EXISTS review_queue (
  id TEXT PRIMARY KEY,
  entity_type TEXT NOT NULL CHECK (entity_type IN ('source_registry','raw_documents','norm_index','evidence_fragments','internal_rules','change_candidates')),
  entity_id TEXT NOT NULL,
  queue_reason TEXT NOT NULL,
  severity TEXT NOT NULL CHECK (severity IN ('low','medium','high','critical')),
  requested_publication_state TEXT NOT NULL CHECK (requested_publication_state IN ('draft','pending_review','approved','active','retired')),
  current_publication_state TEXT NOT NULL CHECK (current_publication_state IN ('draft','pending_review','approved','active','retired')),
  status TEXT NOT NULL DEFAULT 'pending_review' CHECK (status IN ('pending_review','in_review','approved','rejected','implemented')),
  requested_by TEXT,
  reviewer TEXT,
  requested_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reviewed_at TEXT,
  notes TEXT,
  CHECK (requested_publication_state != 'active')
);

CREATE TABLE IF NOT EXISTS change_candidates (
  id TEXT PRIMARY KEY,
  source_id TEXT NOT NULL,
  raw_document_id TEXT,
  candidate_type TEXT NOT NULL CHECK (candidate_type IN ('new_source','vigencia_change','text_change','new_rule_proposal','retirement_proposal')),
  detection_method TEXT NOT NULL CHECK (detection_method IN ('crawler_detect_only','manual_review','diff_against_source','email_alert')),
  detected_change_summary TEXT NOT NULL,
  old_hash TEXT,
  new_hash TEXT,
  detected_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  publication_state TEXT NOT NULL DEFAULT 'pending_review' CHECK (publication_state IN ('draft','pending_review','approved','active','retired')),
  review_status TEXT NOT NULL DEFAULT 'clasificacion_pendiente' CHECK (review_status IN ('raw','importado','clasificacion_pendiente','clasificado','verificado_humano','aprobado_codex','rechazado')),
  automation_mode TEXT NOT NULL DEFAULT 'detect_only' CHECK (automation_mode = 'detect_only'),
  notes TEXT,
  FOREIGN KEY(source_id) REFERENCES source_registry(id),
  FOREIGN KEY(raw_document_id) REFERENCES raw_documents(id),
  CHECK (publication_state != 'active')
);

CREATE TABLE IF NOT EXISTS publication_registry (
  id TEXT PRIMARY KEY,
  entity_type TEXT NOT NULL CHECK (entity_type IN ('source_registry','norm_index','internal_rules')),
  entity_id TEXT NOT NULL,
  publication_state TEXT NOT NULL CHECK (publication_state IN ('draft','pending_review','approved','active','retired')),
  effective_from TEXT,
  effective_to TEXT,
  approved_by TEXT,
  approved_at TEXT,
  change_ticket_id TEXT,
  notes TEXT,
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CHECK (publication_state != 'active' OR approved_at IS NOT NULL)
);

CREATE TABLE IF NOT EXISTS audit_log (
  id TEXT PRIMARY KEY,
  actor_type TEXT NOT NULL CHECK (actor_type IN ('human','system','codex_guard','crawler')),
  actor_id TEXT,
  entity_type TEXT NOT NULL,
  entity_id TEXT NOT NULL,
  action_type TEXT NOT NULL CHECK (action_type IN ('ingest','classify','queue_review','approve','activate','retire','detect_change','reject','note')),
  previous_state TEXT,
  new_state TEXT,
  artifact_path TEXT,
  evidence_hash TEXT,
  event_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
  notes TEXT
);

CREATE INDEX IF NOT EXISTS idx_raw_documents_source_id ON raw_documents(source_id);
CREATE INDEX IF NOT EXISTS idx_norm_index_source_id ON norm_index(source_id);
CREATE INDEX IF NOT EXISTS idx_norm_index_publication_state ON norm_index(publication_state);
CREATE INDEX IF NOT EXISTS idx_internal_rules_publication_state ON internal_rules(publication_state);
CREATE INDEX IF NOT EXISTS idx_review_queue_status ON review_queue(status, severity);
CREATE INDEX IF NOT EXISTS idx_change_candidates_publication_state ON change_candidates(publication_state, detected_at);
CREATE INDEX IF NOT EXISTS idx_publication_registry_entity ON publication_registry(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_log_entity ON audit_log(entity_type, entity_id, event_at);
