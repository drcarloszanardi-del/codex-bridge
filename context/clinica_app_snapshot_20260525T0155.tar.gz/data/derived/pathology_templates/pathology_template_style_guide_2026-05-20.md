# Banco de plantillas por patología neuroquirúrgica

Generado: 2026-05-20T03:22:12.508Z

Modo de privacidad: plantillas derivadas, conteos y hashes cortos; sin textos completos, nombres de pacientes ni nombres de archivos.

Documentos candidatos: 3635
Muestras extraídas: 883
Familias con plantilla: 40

## Reglas transversales incorporadas

- No usar y/o, radiculalgia, si corresponde, cuando corresponda, si aplica ni posibles hallazgos no declarados.
- El documento visible debe ser clínico y sobrio; las reglas de auditoría quedan fuera del texto del paciente.
- Si el dato existe en el relato, se redacta como hecho afirmativo; si falta, queda como observación del tamiz, no como frase abierta.
- No agregar déficit motor, reflejos o complicaciones no informadas por el médico.
- No copiar textos reales de pacientes ni usar nombres de archivos como contenido clínico.

## Familias

### Otros procedimientos neuroquirúrgicos

ID: `otros_neurocirugia` · Categoría: Otros · Candidatos: 504 · Muestra: 28
Términos de clasificación: neurocirugía, procedimiento neuroquirúrgico
Señales detectadas: identificacion (28), incidentes_destino (27), clinica (19), estudios (15), tecnica (12), anestesia_posicion (3), examen (1), implantes (1)
Motivo/indicación madre: cuadro neuroquirúrgico con indicación fundada por clínica, examen e imágenes.
Procedimiento madre: procedimiento neuroquirúrgico indicado

### Cifoplastia

ID: `columna_cifoplastia` · Categoría: Columna · Candidatos: 354 · Muestra: 28
Términos de clasificación: cifoplastia, balón, fractura vertebral
Señales detectadas: identificacion (26), tecnica (25), incidentes_destino (25), anestesia_posicion (24), antisepsia (24), hemostasia_cierre (24), clinica (23), control_imagenes (23)
Motivo/indicación madre: dolor axial focal por fractura vertebral con colapso, con indicación de restauración parcial de altura y cementación.
Procedimiento madre: cifoplastia percutánea del nivel indicado

### Hernia de disco lumbar / microdiscectomía

ID: `columna_lumbar_hernia_disco` · Categoría: Columna · Candidatos: 333 · Muestra: 28
Términos de clasificación: hernia de disco lumbar, microdiscectomía, discectomía, tubular, extrusión discal, hdl
Señales detectadas: identificacion (28), incidentes_destino (27), estudios (17), clinica (16), tecnica (10), anestesia_posicion (10), antisepsia (9), hemostasia_cierre (9)
Motivo/indicación madre: lumbalgia con dolor radicular persistente con correlación clínico-radiológica por hernia discal y respuesta insuficiente al tratamiento conservador.
Procedimiento madre: microdiscectomía lumbar con descompresión radicular del nivel afectado

### Trauma craneal / hematomas / hundimiento

ID: `trauma_craneal` · Categoría: Trauma · Candidatos: 307 · Muestra: 28
Términos de clasificación: hematoma subdural, hematoma extradural, hundimiento, trauma craneal, craniectomía descompresiva
Señales detectadas: identificacion (28), incidentes_destino (28), clinica (19), hemostasia_cierre (19), anestesia_posicion (18), antisepsia (18), tecnica (16), implantes (13)
Motivo/indicación madre: trauma craneal con hematoma, hundimiento, efecto de masa o deterioro neurológico con indicación quirúrgica.
Procedimiento madre: craneotomía/craniectomía, evacuación de hematoma, toilette o reparación de hundimiento según lesión

### Fijación transpedicular lumbar

ID: `columna_lumbar_fijacion_transpedicular` · Categoría: Columna · Candidatos: 284 · Muestra: 28
Términos de clasificación: fijación transpedicular, artrodesis lumbar, instrumentación lumbar, tornillos pediculares
Señales detectadas: incidentes_destino (28), identificacion (27), clinica (22), tecnica (22), estudios (21), implantes (20), anestesia_posicion (17), antisepsia (17)
Motivo/indicación madre: dolor lumbar mecánico y dolor radicular por inestabilidad asociada a patología degenerativa, con correlación clínico-radiológica e indicación de descompresión y estabilización.
Procedimiento madre: descompresión, artrodesis e instrumentación transpedicular del segmento indicado

### Canal estrecho lumbar / recalibraje

ID: `columna_lumbar_canal_estrecho` · Categoría: Columna · Candidatos: 137 · Muestra: 28
Términos de clasificación: canal estrecho lumbar, estenosis lumbar, recalibraje, claudicación neurógena
Señales detectadas: identificacion (28), incidentes_destino (26), clinica (20), tecnica (16), estudios (13), anestesia_posicion (8), hemostasia_cierre (8), control_imagenes (7)
Motivo/indicación madre: dolor lumbar y claudicación neurógena con limitación funcional por estenosis de canal lumbar, con correlación clínica e imagenológica.
Procedimiento madre: descompresión/recalibraje microquirúrgico del canal lumbar en el nivel indicado

### Hidrocefalia / válvulas / DVP-DVE

ID: `otros_valvulas_hidrocefalia` · Categoría: Hidrocefalia · Candidatos: 130 · Muestra: 28
Términos de clasificación: válvula, dvp, dve, hidrocefalia, derivación
Señales detectadas: identificacion (26), implantes (26), incidentes_destino (24), antisepsia (22), anestesia_posicion (21), hemostasia_cierre (21), tecnica (20), estudios (16)
Motivo/indicación madre: hidrocefalia con indicación de derivación, revisión valvular o drenaje ventricular por clínica e imágenes.
Procedimiento madre: colocación, revisión o retiro de derivación ventricular según indicación

### Discectomía cervical anterior y fusión

ID: `columna_cervical_disco_fusion` · Categoría: Columna · Candidatos: 127 · Muestra: 28
Términos de clasificación: disco cervical, acdf, artrodesis cervical, cage cervical, celda cervical
Señales detectadas: identificacion (28), incidentes_destino (27), anestesia_posicion (27), antisepsia (27), control_imagenes (27), implantes (27), hemostasia_cierre (27), estudios (26)
Motivo/indicación madre: cervicobraquialgia o mielorradiculopatía por hernia discal o estenosis cervical, con correlación clínica e imagenológica.
Procedimiento madre: discectomía cervical anterior, descompresión y artrodesis intersomática del nivel indicado

### Tumores de columna

ID: `columna_tumor` · Categoría: Columna · Candidatos: 116 · Muestra: 28
Términos de clasificación: tumor medular, tumor vertebral, lesión intradural, metástasis vertebral
Señales detectadas: identificacion (28), incidentes_destino (27), anestesia_posicion (27), antisepsia (27), hemostasia_cierre (26), tecnica (25), clinica (22), control_imagenes (22)
Motivo/indicación madre: lesión tumoral vertebral, intradural o extradural con dolor, compromiso neurológico o necesidad diagnóstica/terapéutica.
Procedimiento madre: abordaje, descompresión, biopsia o resección de lesión tumoral de columna según localización

### TVT / MAV / lesión vascular compleja

ID: `vascular_tvt_mav` · Categoría: Vascular · Candidatos: 112 · Muestra: 28
Términos de clasificación: tvt, mav, malformación arteriovenosa, lesión vascular
Señales detectadas: identificacion (28), incidentes_destino (28), clinica (27), anestesia_posicion (27), antisepsia (27), tecnica (27), hemostasia_cierre (27), examen (26)
Motivo/indicación madre: lesión vascular neuroquirúrgica con indicación de tratamiento por riesgo hemorrágico, efecto clínico o estrategia diagnóstica.
Procedimiento madre: tratamiento microquirúrgico, endovascular o combinado según anatomía y planificación

### Dispositivo interespinoso / Coflex / DIAM

ID: `columna_interespinoso_coflex_diam` · Categoría: Columna · Candidatos: 96 · Muestra: 28
Términos de clasificación: coflex, diam, interespinoso
Señales detectadas: identificacion (27), incidentes_destino (26), clinica (26), examen (23), estudios (23), consentimiento (22), anestesia_posicion (22), antisepsia (22)
Motivo/indicación madre: estenosis lumbar o inestabilidad dinámica con indicación de descompresión y estabilización interespinosa.
Procedimiento madre: descompresión lumbar y colocación de dispositivo interespinoso en el nivel indicado

### Aneurisma cerebral

ID: `vascular_aneurisma` · Categoría: Vascular · Candidatos: 92 · Muestra: 28
Términos de clasificación: aneurisma, clipado, hemorragia subaracnoidea
Señales detectadas: identificacion (28), tecnica (27), anestesia_posicion (26), hemostasia_cierre (26), antisepsia (25), estudios (23), clinica (22), control_imagenes (21)
Motivo/indicación madre: aneurisma cerebral roto o no roto con indicación de tratamiento según riesgo hemorrágico, anatomía vascular y estado clínico.
Procedimiento madre: clipado microquirúrgico o tratamiento vascular según estrategia definida

### Glioma / tumor intraaxial

ID: `tumor_glioma` · Categoría: Cráneo tumoral · Candidatos: 88 · Muestra: 28
Términos de clasificación: glioma, astrocitoma, glioblastoma, tumor intraaxial
Señales detectadas: identificacion (28), tecnica (28), hemostasia_cierre (28), incidentes_destino (27), anestesia_posicion (27), antisepsia (27), estudios (24), clinica (21)
Motivo/indicación madre: lesión intraaxial compatible con glioma, con indicación de resección, citorreducción o biopsia por clínica, imágenes y estrategia oncológica.
Procedimiento madre: craneotomía y resección/biopsia de tumor intraaxial según localización y elocuencia

### Meningioma intracraneal

ID: `tumor_meningioma` · Categoría: Cráneo tumoral · Candidatos: 82 · Muestra: 28
Términos de clasificación: meningioma, base de cráneo, convexidad
Señales detectadas: identificacion (28), incidentes_destino (28), clinica (25), tecnica (25), estudios (24), anestesia_posicion (24), antisepsia (23), hemostasia_cierre (23)
Motivo/indicación madre: lesión extraaxial compatible con meningioma, sintomática o con crecimiento/efecto de masa, con indicación de resección.
Procedimiento madre: craneotomía y resección microquirúrgica de meningioma

### Craneoplastia

ID: `otros_craneoplastia` · Categoría: Reconstructiva · Candidatos: 80 · Muestra: 28
Términos de clasificación: craneoplastia, defecto óseo, plaqueta, craneal
Señales detectadas: identificacion (28), incidentes_destino (28), clinica (21), anestesia_posicion (21), antisepsia (21), hemostasia_cierre (21), implantes (19), examen (16)
Motivo/indicación madre: defecto óseo craneal con indicación reconstructiva por protección cerebral, estética o síndrome del trepanado.
Procedimiento madre: craneoplastia con material autólogo o protésico según disponibilidad

### Biopsia vertebral

ID: `columna_biopsia_vertebral` · Categoría: Columna · Candidatos: 72 · Muestra: 28
Términos de clasificación: biopsia vertebral, punción biopsia, lesión vertebral
Señales detectadas: identificacion (28), anestesia_posicion (28), antisepsia (28), incidentes_destino (28), tecnica (25), hemostasia_cierre (23), estudios (20), control_imagenes (16)
Motivo/indicación madre: lesión vertebral con necesidad de diagnóstico histológico o microbiológico.
Procedimiento madre: biopsia vertebral percutánea guiada por imágenes del nivel indicado

### Canal estrecho cervical / laminoplastia

ID: `columna_cervical_laminoplastia` · Categoría: Columna · Candidatos: 71 · Muestra: 28
Términos de clasificación: laminoplastia, mielopatía cervical, canal estrecho cervical
Señales detectadas: identificacion (28), estudios (28), incidentes_destino (28), clinica (27), tecnica (24), anestesia_posicion (23), examen (22), consentimiento (22)
Motivo/indicación madre: mielopatía cervical por estenosis de canal con correlación clínica e imagenológica.
Procedimiento madre: laminoplastia cervical expansiva descompresiva

### Metástasis cerebral

ID: `tumor_metastasis` · Categoría: Cráneo tumoral · Candidatos: 70 · Muestra: 28
Términos de clasificación: metástasis, mts, lesión secundaria
Señales detectadas: identificacion (28), incidentes_destino (27), clinica (24), hemostasia_cierre (24), tecnica (24), estudios (23), anestesia_posicion (21), antisepsia (21)
Motivo/indicación madre: lesión cerebral compatible con metástasis con indicación de resección o biopsia por efecto de masa, diagnóstico o control oncológico.
Procedimiento madre: craneotomía y resección/biopsia de lesión metastásica cerebral

### Túnel carpiano / nervio periférico

ID: `otros_tunel_carpiano_periferico` · Categoría: Sistema nervioso periférico · Candidatos: 69 · Muestra: 28
Términos de clasificación: túnel carpiano, nervio periférico, neurolysis
Señales detectadas: identificacion (28), clinica (28), estudios (28), incidentes_destino (28), examen (26), consentimiento (26), anestesia_posicion (26), antisepsia (26)
Motivo/indicación madre: síndrome de túnel carpiano o compresión de nervio periférico refractaria, con correlación clínica y electromiográfica si fue realizada.
Procedimiento madre: liberación quirúrgica del nervio afectado

### Vertebroplastia

ID: `columna_vertebroplastia` · Categoría: Columna · Candidatos: 68 · Muestra: 28
Términos de clasificación: vertebroplastia, cementación, pmma
Señales detectadas: identificacion (28), tecnica (28), incidentes_destino (28), anestesia_posicion (26), antisepsia (24), hemostasia_cierre (24), estudios (21), control_imagenes (21)
Motivo/indicación madre: dolor axial focal por fractura vertebral con edema o colapso del cuerpo vertebral, refractario al tratamiento conservador.
Procedimiento madre: vertebroplastia percutánea del nivel indicado

### Artrodesis lumbar circunferencial / 360

ID: `columna_lumbar_360_circunferencial` · Categoría: Columna · Candidatos: 58 · Muestra: 28
Términos de clasificación: 360, circunferencial, plif, tlif, caja intersomática, celda
Señales detectadas: identificacion (28), clinica (28), anestesia_posicion (28), antisepsia (28), implantes (28), hemostasia_cierre (28), incidentes_destino (27), tecnica (27)
Motivo/indicación madre: dolor lumbar mecánico y dolor radicular por patología degenerativa con inestabilidad y necesidad de estabilización circunferencial.
Procedimiento madre: descompresión, instrumentación transpedicular y artrodesis intersomática del nivel indicado

### Infección de columna / desbridamiento / retiro

ID: `columna_infeccion_desbridamiento_retiro` · Categoría: Columna · Candidatos: 58 · Muestra: 28
Términos de clasificación: infección de columna, desbridamiento, retiro de material, discitis, espondilodiscitis
Señales detectadas: identificacion (28), anestesia_posicion (27), hemostasia_cierre (27), antisepsia (26), incidentes_destino (24), tecnica (18), clinica (17), estudios (13)
Motivo/indicación madre: infección de herida, implante o columna con indicación de toilette, desbridamiento, toma de muestras o retiro de material.
Procedimiento madre: toilette quirúrgica, desbridamiento, toma de muestras y retiro/revisión de material según el caso

### Tumor de fosa posterior

ID: `tumor_fosa_posterior` · Categoría: Cráneo tumoral · Candidatos: 54 · Muestra: 28
Términos de clasificación: fosa posterior, cerebelo, cuarto ventrículo
Señales detectadas: identificacion (28), tecnica (27), incidentes_destino (26), hemostasia_cierre (23), estudios (22), clinica (21), anestesia_posicion (21), antisepsia (21)
Motivo/indicación madre: lesión de fosa posterior con síntomas cerebelosos, hidrocefalia, efecto de masa o necesidad diagnóstica/terapéutica.
Procedimiento madre: craneotomía/craniectomía suboccipital y resección o biopsia de lesión de fosa posterior

### Artroplastia cervical

ID: `columna_cervical_artroplastia` · Categoría: Columna · Candidatos: 43 · Muestra: 28
Términos de clasificación: artroplastia cervical, prótesis discal cervical
Señales detectadas: identificacion (28), incidentes_destino (28), clinica (26), estudios (25), examen (24), consentimiento (24), anestesia_posicion (24), antisepsia (24)
Motivo/indicación madre: cervicobraquialgia por patología discal cervical con indicación de descompresión y preservación de movilidad segmentaria.
Procedimiento madre: discectomía cervical anterior y colocación de prótesis discal cervical

### Biopsia estereotáxica

ID: `tumor_estereotaxia_biopsia` · Categoría: Cráneo tumoral · Candidatos: 37 · Muestra: 28
Términos de clasificación: estereotaxia, biopsia estereotáxica
Señales detectadas: identificacion (28), incidentes_destino (28), estudios (27), anestesia_posicion (27), antisepsia (27), tecnica (27), hemostasia_cierre (27), clinica (20)
Motivo/indicación madre: lesión intracraneal profunda, múltiple o de riesgo elocuente con necesidad de diagnóstico histológico por biopsia estereotáxica.
Procedimiento madre: biopsia estereotáxica de lesión intracraneal

### Hipófisis y endoscopía de base

ID: `tumor_hipofisis_base_craneo` · Categoría: Cráneo tumoral · Candidatos: 37 · Muestra: 28
Términos de clasificación: hipófisis, hipofisario, endoscopía de base, transesfenoidal
Señales detectadas: identificacion (28), tecnica (27), incidentes_destino (26), anestesia_posicion (26), hemostasia_cierre (26), estudios (25), clinica (24), examen (23)
Motivo/indicación madre: lesión selar o de base de cráneo con indicación de abordaje endoscópico por compromiso hormonal, visual, crecimiento o necesidad diagnóstica.
Procedimiento madre: abordaje endoscópico endonasal/transesfenoidal y resección/biopsia de lesión

### Malformación de Chiari

ID: `malformacion_chiari` · Categoría: Malformaciones · Candidatos: 29 · Muestra: 28
Términos de clasificación: chiari, descompresión fosa posterior, siringomielia
Señales detectadas: identificacion (28), estudios (28), incidentes_destino (28), clinica (27), tecnica (27), hemostasia_cierre (25), anestesia_posicion (25), examen (24)
Motivo/indicación madre: malformación de Chiari sintomática, con cefalea occipital, síntomas por Valsalva o siringomielia/compromiso neurológico documentado.
Procedimiento madre: descompresión de fosa posterior y unión cráneo-cervical, con duroplastia si fue indicada

### Quiste facetario lumbar

ID: `columna_quiste_facetario` · Categoría: Columna · Candidatos: 25 · Muestra: 25
Términos de clasificación: quiste facetario, quiste sinovial, quiste artrosinovial
Señales detectadas: identificacion (25), clinica (25), anestesia_posicion (25), antisepsia (24), examen (23), consentimiento (23), control_imagenes (23), tecnica (15)
Motivo/indicación madre: dolor radicular por quiste facetario lumbar con compresión neural y correlación clínica e imagenológica.
Procedimiento madre: resección microquirúrgica de quiste facetario y descompresión radicular

### Bloqueo sacroilíaco

ID: `otros_bloqueo_sacroiliaco` · Categoría: Dolor · Candidatos: 17 · Muestra: 17
Términos de clasificación: sacroilíaco, bloqueo sacroiliaco
Señales detectadas: identificacion (17), clinica (17), examen (17), consentimiento (17), anestesia_posicion (17), antisepsia (17), control_imagenes (17), implantes (1)
Motivo/indicación madre: dolor sacroilíaco con indicación de bloqueo diagnóstico/terapéutico.
Procedimiento madre: bloqueo sacroilíaco guiado por imágenes

### Ángulo pontocerebeloso

ID: `tumor_angulo_pontocerebeloso` · Categoría: Cráneo tumoral · Candidatos: 15 · Muestra: 15
Términos de clasificación: ángulo pontocerebeloso, schwannoma, neurinoma, apc
Señales detectadas: identificacion (14), tecnica (14), antisepsia (13), clinica (12), hemostasia_cierre (12), estudios (11), consentimiento (11), anestesia_posicion (11)
Motivo/indicación madre: lesión del ángulo pontocerebeloso con síntomas auditivos, vestibulares, compresión neural o crecimiento documentado.
Procedimiento madre: abordaje microquirúrgico y resección/biopsia de lesión del ángulo pontocerebeloso

### Neuralgia del trigémino

ID: `otros_neuralgia_trigemino` · Categoría: Otros · Candidatos: 15 · Muestra: 15
Términos de clasificación: trigémino, neuralgia trigeminal, termocoagulación, microdescompresión
Señales detectadas: identificacion (15), incidentes_destino (15), clinica (13), anestesia_posicion (13), antisepsia (13), estudios (12), consentimiento (11), examen (10)
Motivo/indicación madre: neuralgia trigeminal refractaria a tratamiento médico, con dolor paroxístico en territorio trigeminal.
Procedimiento madre: procedimiento percutáneo o microquirúrgico para neuralgia trigeminal según estrategia

### Mielomeningocele pediátrico

ID: `pediatria_mielomeningocele` · Categoría: Pediatría · Candidatos: 10 · Muestra: 10
Términos de clasificación: mielomeningocele, mmc, disrafismo
Señales detectadas: identificacion (10), implantes (10), hemostasia_cierre (10), incidentes_destino (10), tecnica (9), anestesia_posicion (9), antisepsia (9), estudios (1)
Motivo/indicación madre: disrafismo espinal abierto con indicación de reparación, cierre neural y cobertura de partes blandas.
Procedimiento madre: reparación quirúrgica de mielomeningocele con cierre por planos

### Quiste coloide

ID: `tumor_quiste_coloide` · Categoría: Cráneo tumoral · Candidatos: 8 · Muestra: 8
Términos de clasificación: quiste coloide, tercer ventrículo
Señales detectadas: identificacion (8), estudios (8), tecnica (8), incidentes_destino (8), anestesia_posicion (7), antisepsia (7), hemostasia_cierre (7), clinica (6)
Motivo/indicación madre: quiste coloide del tercer ventrículo con riesgo obstructivo, hidrocefalia o síntomas compatibles.
Procedimiento madre: resección endoscópica o microquirúrgica de quiste coloide según estrategia definida

### Absceso cerebral

ID: `otros_absceso_cerebral` · Categoría: Infecciones · Candidatos: 8 · Muestra: 8
Términos de clasificación: absceso cerebral, drenaje de absceso
Señales detectadas: identificacion (8), anestesia_posicion (8), antisepsia (8), hemostasia_cierre (8), incidentes_destino (8), tecnica (7), estudios (6), examen (5)
Motivo/indicación madre: absceso cerebral con indicación de drenaje, toma de muestra o evacuación por clínica, imágenes y riesgo infeccioso.
Procedimiento madre: drenaje, aspiración o evacuación quirúrgica de absceso cerebral

### Espondilolistesis lumbar

ID: `columna_lumbar_espondilolistesis` · Categoría: Columna · Candidatos: 7 · Muestra: 7
Términos de clasificación: espondilolistesis, listesis, inestabilidad segmentaria
Señales detectadas: identificacion (6), incidentes_destino (6), clinica (5), tecnica (5), estudios (4), consentimiento (1), implantes (1)
Motivo/indicación madre: dolor lumbar mecánico y dolor radicular por espondilolistesis lumbar, con inestabilidad segmentaria y correlación clínico-radiológica.
Procedimiento madre: descompresión, reducción/estabilización y artrodesis instrumentada del nivel indicado

### Bloqueo epidural

ID: `otros_bloqueo_epidural` · Categoría: Dolor · Candidatos: 7 · Muestra: 7
Términos de clasificación: bloqueo epidural, infiltración epidural
Señales detectadas: identificacion (7), examen (7), anestesia_posicion (7), antisepsia (7), clinica (6), consentimiento (6), estudios (2), incidentes_destino (2)
Motivo/indicación madre: dolor lumbar o radicular con indicación de bloqueo epidural diagnóstico/terapéutico.
Procedimiento madre: bloqueo epidural del nivel indicado guiado por imágenes

### Fístula de LCR

ID: `otros_fistula_lcr` · Categoría: Otros · Candidatos: 6 · Muestra: 6
Términos de clasificación: fístula de lcr, rinorraquia, licuorrea
Señales detectadas: identificacion (6), hemostasia_cierre (6), incidentes_destino (6), clinica (5), anestesia_posicion (5), antisepsia (5), tecnica (5), estudios (4)
Motivo/indicación madre: fístula de líquido cefalorraquídeo con indicación de reparación por pérdida persistente o riesgo infeccioso.
Procedimiento madre: reparación quirúrgica de fístula de LCR según localización

### Neurofisiología / monitorización

ID: `neurofisiologia_monitorizacion` · Categoría: Neurofisiología · Candidatos: 4 · Muestra: 4
Términos de clasificación: neurofisiología, monitorización, potenciales evocados
Señales detectadas: identificacion (2), implantes (2), tecnica (2), clinica (1), examen (1), estudios (1), consentimiento (1), anestesia_posicion (1)
Motivo/indicación madre: procedimiento neuroquirúrgico con necesidad de monitorización neurofisiológica o implante funcional según patología.
Procedimiento madre: monitorización neurofisiológica o procedimiento funcional indicado

### Monitoreo de presión intracraneana

ID: `otros_monitoreo_pic` · Categoría: UCI/Trauma · Candidatos: 3 · Muestra: 3
Términos de clasificación: monitoreo de pic, presión intracraneana, catéter pic
Señales detectadas: identificacion (2), clinica (2), estudios (2), consentimiento (2), anestesia_posicion (2), antisepsia (2), tecnica (2), hemostasia_cierre (2)
Motivo/indicación madre: necesidad de monitorización de presión intracraneana por trauma, edema, hidrocefalia o patología intracraneana grave.
Procedimiento madre: colocación de sensor/catéter de presión intracraneana

### Quiste aracnoideo

ID: `malformacion_quiste_aracnoideo` · Categoría: Malformaciones · Candidatos: 2 · Muestra: 2
Términos de clasificación: quiste aracnoideo, fenestración
Señales detectadas: identificacion (2), clinica (2), examen (2), estudios (2), consentimiento (2), anestesia_posicion (2), antisepsia (2), tecnica (2)
Motivo/indicación madre: quiste aracnoideo sintomático o con efecto de masa, con indicación de fenestración, derivación o tratamiento según localización.
Procedimiento madre: fenestración, marsupialización o derivación de quiste aracnoideo según localización

## Tamiz médico-legal común

- Identificación completa: paciente, edad, fecha, institución, cirujano, ayudantes y horarios cuando el documento sea quirúrgico.
- Correlación clínica, examen útil, estudios y diagnóstico deben justificar la indicación.
- Consentimiento informado: diagnóstico, procedimiento, riesgos, beneficios, alternativas, no tratamiento, preguntas y revocación.
- Parte quirúrgico: técnica secuencial reconstruible, hallazgos, controles críticos, hemostasia, cierre, incidentes y destino.
- Implantes permanentes: material utilizado y trazabilidad cuando se prepare documento final; no inventar marca, lote ni medidas.
- Eventos excepcionales: consignar solo si ocurrieron o fueron informados; no incorporarlos a plantillas convencionales.
- Salida: APTO_PARA_ENVIO, APTO_CON_OBSERVACIONES o BLOQUEADO_NO_ENVIAR según el tamiz flexible obligatorio.
