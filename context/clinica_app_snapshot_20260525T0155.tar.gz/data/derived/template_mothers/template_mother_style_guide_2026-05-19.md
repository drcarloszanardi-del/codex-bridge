# Plantillas madre derivadas del corpus local

Generado: 2026-05-19T18:12:53.074Z

Modo: estructura derivada sin volcar texto completo ni datos personales.

Candidatos Historia + Parte: 3149
Extraidos para analisis: 52

## Regla de producto

La app debe comportarse como un generador/revisor documental clinico: recibe relato del medico, detecta familia, carga una plantilla madre, completa con datos disponibles, marca faltantes sensibles y aplica correcciones del medico al documento. No debe responder como chat ni entregar PDFs sueltos fuera del flujo.

## Familias

### otros_neurocirugia
Candidatos: 351. Muestra extraida: 4.
Secciones dominantes: antecedentes_y_clinica (3), firma (3), identificacion (3), tecnica_quirurgica (3), otros (1).
Subarboles: NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna; NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/COFLEX.

### biopsia_infeccion_revision
Candidatos: 188. Muestra extraida: 4.
Secciones dominantes: otros (9), firma (6), antecedentes_y_clinica (4), tecnica_quirurgica (3), evolucion (3), diagnosticos (1).
Subarboles: NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Biopsia vertebral.

### columna_disco_lumbar
Candidatos: 164. Muestra extraida: 4.
Secciones dominantes: antecedentes_y_clinica (2), identificacion (2), tecnica_quirurgica (2), evolucion (2), otros (1).
Subarboles: NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Biopsia vertebral; NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Canal estrecho.

### tumores_intracraneales
Candidatos: 519. Muestra extraida: 4.
Secciones dominantes: antecedentes_y_clinica (6), tecnica_quirurgica (4), identificacion (3), evolucion (3), otros (3), firma (1), fechas_y_contexto (1).
Subarboles: NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Biopsia vertebral; NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Infecciones, desbridamientos y retiros; NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Tumores.

### columna_canal_estrecho_laminoplastia
Candidatos: 167. Muestra extraida: 4.
Secciones dominantes: antecedentes_y_clinica (6), tecnica_quirurgica (4), evolucion (4), identificacion (3), fechas_y_contexto (1).
Subarboles: NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Canal estrecho.

### columna_fijacion_transpedicular
Candidatos: 342. Muestra extraida: 4.
Secciones dominantes: antecedentes_y_clinica (4), tecnica_quirurgica (4), evolucion (4), identificacion (2), otros (1), fechas_y_contexto (1).
Subarboles: NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Canal estrecho.

### columna_microdiscectomia_tubular
Candidatos: 171. Muestra extraida: 4.
Secciones dominantes: antecedentes_y_clinica (4), identificacion (4), tecnica_quirurgica (4), evolucion (4), otros (1).
Subarboles: NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Canal estrecho.

### columna_disco_cervical
Candidatos: 165. Muestra extraida: 4.
Secciones dominantes: antecedentes_y_clinica (4), tecnica_quirurgica (4), firma (3), identificacion (3), evolucion (1).
Subarboles: NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Disco Cervical.

### trauma_craneal_columna
Candidatos: 299. Muestra extraida: 4.
Secciones dominantes: otros (5), antecedentes_y_clinica (4), tecnica_quirurgica (4), firma (3), evolucion (1), identificacion (1).
Subarboles: NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna.

### columna_vertebroplastia_cifoplastia
Candidatos: 406. Muestra extraida: 4.
Secciones dominantes: otros (4), antecedentes_y_clinica (2), tecnica_quirurgica (2), evolucion (2), firma (1), identificacion (1).
Subarboles: NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna; NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Transpedicular; NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Tumores.

### chiari_malformaciones
Candidatos: 28. Muestra extraida: 4.
Secciones dominantes: antecedentes_y_clinica (4), identificacion (4), tecnica_quirurgica (4), firma (3), evolucion (1), otros (1).
Subarboles: NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Malformaciones/Malformación de Chiari.

### hidrocefalia_valvulas_dvp
Candidatos: 149. Muestra extraida: 4.
Secciones dominantes: antecedentes_y_clinica (3), evolucion (3), tecnica_quirurgica (3), otros (3), indicacion_y_consentimiento (1), identificacion (1).
Subarboles: NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Otros/Craneoplastia; NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Otros/Valvulas.

### vascular_aneurismas_tvt
Candidatos: 200. Muestra extraida: 4.
Secciones dominantes: otros (5), antecedentes_y_clinica (4), identificacion (4), tecnica_quirurgica (4), evolucion (3), indicaciones_alta (3), firma (1).
Subarboles: NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Otros/Trigéminos.

## Tamiz medico legal comun

- Identificacion y fechas completas antes de uso real.
- Diagnostico e indicacion vinculados a clinica, estudios y lateralidad/nivel.
- Consentimiento/informacion previa mencionado como control documental, sin inventar.
- Tecnica quirurgica con abordaje, nivel/lado, hallazgos, maniobras principales, implantes/materiales si corresponde.
- Complicaciones: consignar solo dato real; si falta, marcar faltante sensible, no afirmar.
- Evolucion y destino postoperatorio separados del parte tecnico.
- Pautas de alarma/control y firma/sello como cierre documental.

## Prohibiciones operativas

- No copiar pacientes reales al producto final de prueba.
- No afirmar ausencia de complicaciones, consentimiento, lateralidad, implantes o evolucion si el dato no fue dado.
- No mezclar citas legales dentro del texto clinico final; el tamiz debe quedar como control lateral o validacion interna.
- No enviar PDF final hasta tener candidato de app validado y APTO_PARA_ENTREGAR.