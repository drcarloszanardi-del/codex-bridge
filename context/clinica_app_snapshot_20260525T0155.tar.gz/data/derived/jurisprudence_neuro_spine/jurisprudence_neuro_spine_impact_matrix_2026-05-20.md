# Corpus jurisprudencial neurocirugia/columna Argentina

Estado: `review_only_detect_only`  
Fecha de corte: 2026-05-20T15:26:08.201Z

Este es un primer corte trazable para reforzar el tamiz medico-legal de la app. No se presenta como exhaustividad absoluta de toda la jurisprudencia argentina: separa fuente oficial, sumario oficial, fuente secundaria publica y alerta pendiente, y deja queries para actualizacion.

## Politica de confiabilidad
- `official_judiciary_full_text`: fuente judicial oficial con texto completo.
- `official_saij_summary`: sumario/ficha oficial SAIJ; util para tamiz, pendiente de texto completo si se va a citar hacia afuera.
- `secondary_full_text_pending_official_copy`: fuente publica secundaria con tribunal/fecha/partes; usar solo como candidato hasta obtener copia oficial.
- `official_pending_merits_non_precedential`: alerta oficial sin sentencia de fondo; no se usa como precedente material.

## Reglas de impacto para la app
### NJ-TAMIZ-001 - Indicacion neuro/columna con correlacion y alternativas
- Aplica a: historia_clinica, consentimiento_informado
- Regla: Toda indicacion neuroquirurgica o de columna programada debe mostrar clinica, examen, estudios, diagnostico y razon de la conducta elegida, incluyendo fracaso o descarte de alternativas cuando no sea urgencia.
- Fuentes: NSJ-001, NSJ-002, NSJ-005, NSJ-006, NSJ-010, NSJ-017

### NJ-TAMIZ-002 - Nivel, lateralidad, raiz y control por imagen en columna
- Aplica a: historia_clinica, parte_quirurgico
- Regla: Columna exige nivel/lateralidad, raiz comprometida cuando aplique, estudio concordante y control radioscopico/rayos en procedimientos donde define nivel o implantes.
- Fuentes: NSJ-005, NSJ-006, NSJ-008, NSJ-009, NSJ-010

### NJ-TAMIZ-003 - Parte quirurgico con respuesta ante incidentes
- Aplica a: parte_quirurgico, evolucion
- Regla: El parte debe permitir reconstruir posicion, proteccion, abordaje, hallazgo, maniobra, control, hemostasia, recuento, incidente si existio, respuesta y destino.
- Fuentes: NSJ-003, NSJ-004, NSJ-007, NSJ-010, NSJ-014, NSJ-016, NSJ-017, NSJ-018

### NJ-TAMIZ-004 - Consentimiento neuroquirurgico material y especifico
- Aplica a: consentimiento_informado
- Regla: Consentimiento no sale si no identifica patologia, procedimiento, beneficios, riesgos propios, alternativas, no tratamiento, revocacion, fecha/firma y oportunidad de preguntas.
- Fuentes: NSJ-005, NSJ-006, NSJ-007, NSJ-009, NSJ-011, NSJ-013, NSJ-017, NSD-001

### NJ-TAMIZ-005 - Urgencia neurologica con tiempos y derivacion
- Aplica a: historia_clinica, evolucion
- Regla: En urgencia neurologica se registran horarios, examen, medidas, comunicaciones, criterio de derivacion y condicion de traslado o imposibilidad de consentimiento ordinario.
- Fuentes: NSJ-012, NSJ-013, NSJ-014

### NJ-TAMIZ-006 - Integridad y recuperabilidad de historia clinica neuro/institucional
- Aplica a: historia_clinica, evolucion, epicrisis
- Regla: La historia clinica, evolucion y epicrisis deben permitir reconstruir dias/horas relevantes, estudios, medicacion, profesional responsable y addendas sin enmiendas silenciosas.
- Fuentes: NSJ-015, NSJ-019


## Jurisprudencia cargada
### NSJ-001 - Batista Walter Jose y otros c/ Sanatorio Quintana S.A. y otro
- Tribunal: Camara Nacional de Apelaciones en lo Civil y Comercial Federal, Sala III
- Fecha: 2005-09-06
- Jurisdiccion: Nacional - Capital Federal
- Fuente: https://www.saij.gob.ar/docs-f/dossier-f/mala_praxis_medica.pdf
- Localizador: SAIJ N0015875, dossier Mala Praxis Medica, paginas 16-17
- Confiabilidad: `official_saij_summary`
- Dominio clinico: neurocirugia, nervio_periferico, diagnostico_diferencial
- Criterio operativo: Cuando el cuadro deja de encajar en el diagnostico inicial, el especialista debe documentar reevaluacion y estudios razonables antes de sostener o repetir una conducta.
- Impacto documental: historia_clinica, consentimiento_informado
- Tamiz:
  - Historia clinica: si hay sintomas neurologicos persistentes o cambiantes, documentar reevaluacion, diagnostico diferencial y estudios pedidos.
  - Historia clinica: no anclar la indicacion quirurgica a un diagnostico previo si el relato clinico exige nueva correlacion.
  - Consentimiento: explicar objetivo real y limite esperable del procedimiento cuando hay secuelas o diagnostico incierto.

### NSJ-002 - Hernandez Jose Luis c/ OSECAC y otros
- Tribunal: Camara Nacional de Apelaciones en lo Civil y Comercial Federal, Sala III
- Fecha: 2009-03-03
- Jurisdiccion: Nacional - Capital Federal
- Fuente: https://www.saij.gob.ar/docs-f/dossier-f/mala_praxis_medica.pdf
- Localizador: SAIJ N0015877, dossier Mala Praxis Medica, pagina 148
- Confiabilidad: `official_saij_summary`
- Dominio clinico: neurocirugia, diagnostico_neurologico
- Criterio operativo: La defensa mejora cuando la historia muestra por que se pidieron o no se pidieron estudios, con base en sintomas y examen.
- Impacto documental: historia_clinica, parte_quirurgico
- Tamiz:
  - Historia clinica: incluir sintomas cardinales, examen neurologico util y estudio que sostiene la conducta.
  - Historia clinica: si el caso es programado, dejar explicitado por que no se espera o por que no se elige alternativa menos invasiva.
  - Parte quirurgico: sostener hallazgos y secuencia para que la pericia futura pueda reconstruir lex artis.

### NSJ-003 - Hernandez Jose Luis c/ OSECAC y otros - riesgo quirurgico y negligencia
- Tribunal: Camara Nacional de Apelaciones en lo Civil y Comercial Federal, Sala III
- Fecha: 2009-03-03
- Jurisdiccion: Nacional - Capital Federal
- Fuente: https://www.saij.gob.ar/docs-f/dossier-f/mala_praxis_medica.pdf
- Localizador: SAIJ D0134737, dossier Mala Praxis Medica, paginas 146-147
- Confiabilidad: `official_saij_summary`
- Dominio clinico: neurocirugia, acto_quirurgico
- Criterio operativo: Ante un evento intraoperatorio o postoperatorio, la documentacion debe mostrar mecanismo, control, medidas adoptadas y estado final.
- Impacto documental: parte_quirurgico, evolucion
- Tamiz:
  - Parte quirurgico: no usar formulas genericas para incidentes; si hubo desvio, narrar mecanismo, control y respuesta.
  - Parte quirurgico: si no hubo incidentes evidentes, cerrar con hemostasia, recuento, control final y destino.
  - Evolucion: ante infeccion, sangrado, deficit o LCR, documentar deteccion, conducta y seguimiento.

### NSJ-004 - Hernandez Jose Luis c/ OSECAC y otros - rol de cirujano y ayudante
- Tribunal: Camara Nacional de Apelaciones en lo Civil y Comercial Federal, Sala III
- Fecha: 2009-03-03
- Jurisdiccion: Nacional - Capital Federal
- Fuente: https://www.saij.gob.ar/docs-f/dossier-f/mala_praxis_medica.pdf
- Localizador: SAIJ D0134739, dossier Mala Praxis Medica, paginas 146-147
- Confiabilidad: `official_saij_summary`
- Dominio clinico: neurocirugia, acto_quirurgico
- Criterio operativo: El parte debe identificar equipo y roles sin diluir la direccion tecnica del acto.
- Impacto documental: parte_quirurgico, consentimiento_informado
- Tamiz:
  - Parte quirurgico: consignar cirujano, ayudantes y rol operativo sin usar formulas ambiguas.
  - Parte quirurgico: el cirujano principal debe quedar identificado como responsable de indicacion tecnica y secuencia operatoria.
  - Consentimiento: autorizacion dirigida al profesional/equipo identificado, no solo a la institucion.

### NSJ-005 - V. L. M. N. y otros c/ E. R. J. y otro
- Tribunal: Camara Nacional de Apelaciones en lo Civil, Sala H
- Fecha: 2018-10-17
- Jurisdiccion: Nacional - Capital Federal
- Fuente: https://aldiaargentina.microjuris.com/2018/12/17/responsabilidad-del-medico-demandado-al-practicar-una-cirugia-que-no-era-recomendable-por-no-tratarse-de-una-situacion-de-urgencia/
- Localizador: Microjuris MJJ115305, fallo publico, lineas 62-82 y 207-215 relevadas
- Confiabilidad: `secondary_full_text_pending_official_copy`
- Dominio clinico: columna_lumbar, lumbociatalgia, artrodesis
- Criterio operativo: La historia debe justificar con precision por que la cirugia es necesaria y por que las alternativas conservadoras no alcanzan o no aplican al caso.
- Impacto documental: historia_clinica, parte_quirurgico, consentimiento_informado
- Tamiz:
  - Historia clinica: en cirugia programada de columna, documentar fracaso del tratamiento conservador o motivo concreto de indicacion directa.
  - Consentimiento: incluir alternativas razonables, no tratamiento y riesgos propios de columna: lesion radicular, lesion dural/LCR, deficit neurologico, dolor residual y reintervencion.
  - Parte quirurgico: si ocurre durotomia, LCR o lesion radicular, describir reparacion, interconsulta o conducta concreta.

### NSJ-006 - R. C. c/ Fundacion para la Lucha contra Enfermedades Neurologicas y otros
- Tribunal: Camara Nacional de Apelaciones en lo Civil, Sala J
- Fecha: 2019-05-09
- Jurisdiccion: Nacional - Capital Federal
- Fuente: https://www.infojudicial.com.ar/areas/jurisprudencia/jurisprudencia-2019/danos-y-perjuicios-mala-praxis-medica-intervencion-qururgica-infeccion-ausencia-de-culpa-medica/130393/
- Localizador: Infojudicial, fallo publico, lineas 100-116 y 140-141 relevadas
- Confiabilidad: `secondary_full_text_pending_official_copy`
- Dominio clinico: columna_lumbar, hernia_disco, infeccion_sitio_quirurgico
- Criterio operativo: Los eventos adversos de columna se valoran con historia, signos, imagenes, consentimiento especifico y conducta de seguimiento, no solo por el resultado.
- Impacto documental: historia_clinica, parte_quirurgico, consentimiento_informado, evolucion
- Tamiz:
  - Historia clinica: describir signos y sintomas presentes sin inventar deficit; si hay deficit motor, consignarlo solo si fue informado.
  - Consentimiento: para hernia discal debe incluir recidiva, infeccion, dolor residual, fibrosis, lesion dural/LCR y reintervencion.
  - Parte quirurgico/evolucion: ante infeccion, toilette o recidiva, documentar hallazgo, cultivo/tratamiento si existe y razon de reintervencion.

### NSJ-007 - M. G. L. c/ Asociacion Civil Hospital Aleman
- Tribunal: Camara Nacional de Apelaciones en lo Civil, Sala C
- Fecha: 2022-04-13
- Jurisdiccion: Nacional - Capital Federal
- Fuente: https://aldiaargentina.microjuris.com/2022/05/20/fallos-mala-praxis-lesiones-en-la-arteria-carotida-de-una-paciente-durante-una-practica-quirurgica/
- Localizador: Microjuris MJJ136905, fallo publico, lineas 62-90 y 245-253 relevadas
- Confiabilidad: `secondary_full_text_pending_official_copy`
- Dominio clinico: neurocirugia_craneal, hipofisis, lesion_vascular
- Criterio operativo: En neurocirugia craneal, el consentimiento debe ser personal y especifico; si hay incidente vascular, el parte debe describir deteccion, control, equipos convocados y estado final.
- Impacto documental: parte_quirurgico, consentimiento_informado, evolucion
- Tamiz:
  - Consentimiento: incluir riesgos severos materiales de la patologia y procedimiento, aun cuando no prometa listar cada contingencia infrecuente.
  - Parte quirurgico: ante sangrado vascular o incidente mayor, narrar control, hemostaticos/packing si fueron usados, interconsulta y procedimiento complementario.
  - Evolucion: documentar estado neurologico, terapia/recuperacion, estudios y plan posterior.

### NSJ-008 - Q. C. B. c/ A. E. y otros
- Tribunal: Suprema Corte de Justicia de Mendoza, Sala I
- Fecha: 2017-06-14
- Jurisdiccion: Mendoza
- Fuente: https://aldiaargentina.microjuris.com/2017/07/31/no-existe-mala-praxis-por-parte-de-un-medico-cirujano-y-un-hospital/
- Localizador: Microjuris MJJ105305, fallo publico, lineas 72-77 relevadas
- Confiabilidad: `secondary_full_text_pending_official_copy`
- Dominio clinico: columna_lumbar, implantes, control_radiologico
- Criterio operativo: El parte de columna con implantes gana fuerza si registra control de rayos/radioscopia y chequeo del montaje.
- Impacto documental: parte_quirurgico, historia_clinica, consentimiento_informado
- Tamiz:
  - Parte quirurgico: en procedimientos de columna con implantes, documentar control radioscopico y chequeo del material.
  - Historia clinica: dejar constancia de estudios previos y derivacion/consulta especializada cuando sostienen la decision.
  - Consentimiento: registrar procedimiento, riesgos, alternativas y oportunidad de preguntas.

### NSJ-009 - Villacura Carlos c/ Pilafis Salvador y Clinica Roca S.A.
- Tribunal: Juzgado Civil, Comercial, Mineria y Sucesiones N. 1 - General Roca
- Fecha: 2021-10-06
- Jurisdiccion: Rio Negro
- Fuente: https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=22651551-3d3a-4cde-a2e2-c4ef831189e2&option_text=0&usarSearch=1
- Localizador: Poder Judicial de Rio Negro, sentencia 35/2021, lineas 245-263 relevadas
- Confiabilidad: `official_judiciary_full_text`
- Dominio clinico: columna_lumbar, hernia_foraminal, postoperatorio
- Criterio operativo: El consentimiento de hernia lumbar debe ser especifico de patologia/procedimiento y el seguimiento posoperatorio debe quedar trazado.
- Impacto documental: consentimiento_informado, evolucion, historia_clinica
- Tamiz:
  - Consentimiento: hernia lumbar debe explicar naturaleza de hernia, finalidad de cirugia, riesgos, alternativas y revocacion.
  - Evolucion: registrar controles posoperatorios, movilidad, dolor, herida y pautas de alarma.
  - Historia clinica: no transformar el consentimiento en texto administrativo; debe estar unido a indicacion clinica.

### NSJ-010 - Marchan Susana Ester c/ Gomez, Labat y Sanatorio Juan XXIII
- Tribunal: Juzgado Civil, Comercial, Mineria y Sucesiones N. 9 - General Roca
- Fecha: 2023-11-30
- Jurisdiccion: Rio Negro
- Fuente: https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=826c19cc-0054-43d5-8a73-caa89eb1c0b0&option_text=0&usarSearch=1
- Localizador: Poder Judicial de Rio Negro, fallo completo, lineas 213-233 y 242-255 relevadas
- Confiabilidad: `official_judiciary_full_text`
- Dominio clinico: columna_lumbar, hernia_disco, pericia_medica
- Criterio operativo: La documentacion debe ser lo bastante completa para que una pericia futura reconstruya indicacion, tecnica, eventos y seguimiento.
- Impacto documental: historia_clinica, parte_quirurgico, evolucion
- Tamiz:
  - Historia clinica: unir sintomas, examen, estudios y razon de indicacion quirurgica.
  - Parte quirurgico: registrar hallazgos, liberacion neural, controles y cierre con precision.
  - Evolucion: consignar estado neurologico y seguimiento inmediato.

### NSJ-011 - Olivares Anselmo Eduardo c/ Sanatorio Juan XXIII y otros
- Tribunal: Juzgado Civil, Comercial, Mineria y Sucesiones N. 9 - General Roca
- Fecha: 2017-12-15
- Jurisdiccion: Rio Negro
- Fuente: https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=03651b40-774a-4e75-bdde-7011bfc10081&option_text=0&usarSearch=1
- Localizador: Poder Judicial de Rio Negro, sentencia 68/2017, lineas 76-100 y 191-199 relevadas
- Confiabilidad: `official_judiciary_full_text`
- Dominio clinico: columna_lumbar, bloqueo_peridural, canal_estrecho
- Criterio operativo: Tambien los procedimientos percutaneos o no quirurgicos de columna exigen indicacion, consentimiento, tecnica y evolucion documentadas.
- Impacto documental: historia_clinica, consentimiento_informado, evolucion
- Tamiz:
  - Historia clinica: para bloqueos/infiltraciones consignar diagnostico, nivel, objetivo y razon de no cirugia.
  - Consentimiento: incluir riesgos del procedimiento peridural/infiltrativo, alternativas y revocacion.
  - Evolucion: si aparece evento neurologico, registrar cronologia, examen, conducta y respuesta.

### NSJ-012 - Gomez Franco Maximiliano - emergencia por hemorragia cerebral
- Tribunal: Juzgado Civil, Comercial y Sucesiones N. 31 - Choele Choel
- Fecha: 2016-02-26
- Jurisdiccion: Rio Negro
- Fuente: https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/descargar-archivo-pdf?id_protocolo=87d3795e-accd-4940-acfa-0453c48c63c5
- Localizador: Poder Judicial de Rio Negro, PDF fallo completo, paginas 2-5 y 18-20 relevadas
- Confiabilidad: `official_judiciary_full_text`
- Dominio clinico: neuroemergencia, hemorragia_cerebral, derivacion
- Criterio operativo: En urgencias neurologicas, la defensa documental depende de horarios, examen inicial, medidas, llamadas, derivaciones y razon de cada traslado.
- Impacto documental: historia_clinica, evolucion, consentimiento_informado
- Tamiz:
  - Historia/evolucion: urgencias neuro deben incluir hora de inicio/atencion, estado neurologico, medidas iniciales y criterio de derivacion.
  - Evolucion: registrar comunicaciones, destino y condicion durante traslado.
  - Consentimiento: en urgencia, diferenciar consentimiento posible, representante o imposibilidad razonada.

### NSJ-014 - Echenique Silva Beatriz c/ Pardal Carlos y otros
- Tribunal: Camara Nacional de Apelaciones en lo Civil, Capital Federal
- Fecha: 2010-09-24
- Jurisdiccion: Nacional - Capital Federal
- Fuente: https://www.saij.gob.ar/docs-f/dossier-f/mala_praxis_medica.pdf
- Localizador: SAIJ C0408007/C0403565, dossier Mala Praxis Medica, pagina 144
- Confiabilidad: `official_saij_summary`
- Dominio clinico: neurocirugia_craneal, aneurisma, hemorragia_subaracnoidea
- Criterio operativo: En neurocirugia craneal urgente, la documentacion debe reconstruir oportunidad diagnostica, indicacion, pasos esenciales, controles y razon tecnica sin exigir inventario superfluo que no cambie el resultado.
- Impacto documental: historia_clinica, parte_quirurgico, evolucion, consentimiento_informado
- Tamiz:
  - Historia/evolucion: en HSA/aneurisma, registrar horario, estado neurologico, estudios, causa identificada y oportunidad quirurgica.
  - Parte quirurgico craneal: describir abordaje y pasos esenciales, clipado/tratamiento, control y cierre; no inventar marcas/lotes si no son necesarios para la defensa del caso.
  - Consentimiento/urgencia: si la opcion tecnica era unica o vital, dejar clara la urgencia, riesgos inevitables y el modo de informacion posible.

### NSJ-015 - Gonzalez Roberto Oscar c/ F.L.E.N.I.
- Tribunal: Camara Nacional de Apelaciones en lo Civil, Sala C
- Fecha: 2007-02-08
- Jurisdiccion: Nacional - Capital Federal
- Fuente: https://www.saij.gob.ar/docs-f/dossier-f/mala_praxis_medica.pdf
- Localizador: SAIJ C0402692/C0402693/C0401680, dossier Mala Praxis Medica, paginas 58-59
- Confiabilidad: `official_saij_summary`
- Dominio clinico: institucion_neurologica, infeccion_intrahospitalaria, historia_clinica
- Criterio operativo: La historia clinica y la epicrisis deben ser recuperables, consistentes y firmadas; las diferencias entre copias u originales agravan la discusion probatoria.
- Impacto documental: historia_clinica, evolucion, epicrisis
- Tamiz:
  - Historia clinica/evolucion: consignar dias u horas relevantes, estudios, medicacion, evolucion y profesional responsable.
  - Correcciones: toda modificacion posterior debe ser addenda fechada, sin reemplazar silenciosamente el texto previo.
  - Infeccion o evento intrahospitalario: documentar medidas, deteccion, tratamiento y seguimiento sin agregar afirmaciones retrospectivas no verificables.

### NSJ-016 - Fantini Carlos c/ Clinica Roca S.A. y otros
- Tribunal: Camara de Apelaciones en lo Civil, Comercial, Familia y Mineria - General Roca
- Fecha: 2009-04-22
- Jurisdiccion: Rio Negro
- Fuente: https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=de7c9a44-365f-4678-a950-3f370afb4256&option_text=0&usarSearch=1
- Localizador: Poder Judicial de Rio Negro, sentencia 37/2009, lineas 16-20 y 28 relevadas
- Confiabilidad: `official_judiciary_full_text`
- Dominio clinico: columna, anestesia, complicacion_via_aerea
- Criterio operativo: Aunque el parte quirurgico sea del cirujano, la documentacion de columna debe dejar claro el marco anestesico, posicionamiento, proteccion y transicion para reconstruir la cadena quirurgica.
- Impacto documental: parte_quirurgico, evolucion
- Tamiz:
  - Parte quirurgico: consignar anestesia, posicionamiento, proteccion ocular, acolchado y destino posoperatorio.
  - Parte/evolucion: si hubo evento de via aerea u otra complicacion anestesica conocida por el equipo quirurgico, dejar trazada la comunicacion y conducta coordinada.
  - No usar formulas vagas sobre anestesia para cubrir hechos que pertenecen al registro anestesico; el parte quirurgico debe limitarse a lo observado/realizado por el equipo.

### NSJ-013 - C. P. c/ P. S. R. y otros - dictamen de competencia
- Tribunal: Procuracion General de la Nacion
- Fecha: 2025-08-01
- Jurisdiccion: Federal
- Fuente: https://www.mpf.gob.ar/dictamenes/2025/VAbramovich/agosto/C_P_CIV_2343_2025_CS1.pdf
- Localizador: MPF CIV 2343/2025/CS1, paginas 1-2 relevadas
- Confiabilidad: `official_pending_merits_non_precedential`
- Dominio clinico: neurocirugia, consentimiento_informado, contexto_aspo
- Criterio operativo: No es precedente de fondo, pero sirve como alerta de busqueda futura: neurocirugia programada, consentimiento y alternativas siguen siendo focos litigiosos.
- Impacto documental: historia_clinica, consentimiento_informado
- Tamiz:
  - Consentimiento: no permitir salida si falta procedimiento, riesgos, alternativas, no tratamiento y firmas/fecha.
  - Historia clinica: en procedimiento no urgente, documentar por que se programa y por que no se posterga.
  - Updater: mantener este caso en cola hasta sentencia de fondo o fallo de competencia CSJN.

### NSJ-017 - Avendaño Jorge Osvaldo c/ Gomez Oscar Joaquin, Sanatorio Juan XXIII S.A. y OSPEDYC
- Tribunal: Juzgado Civil, Comercial, Mineria y Sucesiones N. 1 - General Roca
- Fecha: 2021-11-15
- Jurisdiccion: Rio Negro
- Fuente: https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=e71e6494-30d0-4d45-abf9-b2bbf6e72a17&option_text=0&usarSearch=1
- Localizador: Poder Judicial de Rio Negro, sentencia 44/2021, fallo completo oficial
- Confiabilidad: `official_judiciary_full_text`
- Dominio clinico: columna_cervical, laminoplastia, mielopatia
- Criterio operativo: En canal estrecho cervical/laminoplastia, la documentacion debe dejar clinica basal, indicacion, procedimiento efectivamente indicado, consentimiento especifico y evolucion neurologica posoperatoria.
- Impacto documental: historia_clinica, parte_quirurgico, consentimiento_informado, evolucion
- Tamiz:
  - Historia clinica cervical: iniciar por sintomas reales como trastorno de la marcha, torpeza manual, parestesias o deficit informado, sin formulas alternativas genericas.
  - Consentimiento: para laminoplastia/canal cervical, consignar mielopatia o compromiso neurologico concreto, objetivo de descompresion y riesgos neurologicos/materiales.
  - Parte/evolucion: registrar niveles, tecnica de laminoplastia, estado neurologico inmediato y seguimiento.

### NSJ-018 - I., A. S. c/ Clinica y Maternidad Maria Auxiliadora y otro/a
- Tribunal: Camara Civil y Comercial de Azul, Sala II
- Fecha: 2021-03-31
- Jurisdiccion: Provincia de Buenos Aires
- Fuente: https://juba.scba.gov.ar/VerTextoCompleto.aspx?idFallo=180817
- Localizador: SCBA/JUBA idFallo 180817, texto completo oficial
- Confiabilidad: `official_judiciary_full_text`
- Dominio clinico: lesion_raquimedular, anestesia_raquidea, alta
- Criterio operativo: Cuando el evento involucra eje raquimedular o anestesia, la cadena documental debe distinguir acto quirurgico, registro anestesico, estado neurologico y decision de alta/seguimiento.
- Impacto documental: parte_quirurgico, evolucion, historia_clinica
- Tamiz:
  - Parte quirurgico: no cubrir hechos anestesicos que pertenecen al registro anestesico, pero si consignar posicionamiento, proteccion y transicion observada.
  - Evolucion/alta: ante sintomas neurologicos o dolor no habitual, documentar examen, conducta, responsable y pauta de reconsulta.
  - Historia clinica: evitar alta o cierre sin estado neurologico y condiciones de seguimiento si hubo evento raquimedular.

### NSJ-019 - M., E. y otros c/ Hospital Municipal Vicente Lopez y otros
- Tribunal: Suprema Corte de Justicia de la Provincia de Buenos Aires
- Fecha: 2013-05-02
- Jurisdiccion: Provincia de Buenos Aires
- Fuente: https://juba.scba.gov.ar/VerTextoCompleto.aspx?idFallo=30512
- Localizador: SCBA/JUBA idFallo 30512, texto completo oficial
- Confiabilidad: `official_judiciary_full_text`
- Dominio clinico: neurotrauma, infeccion, historia_clinica
- Criterio operativo: En neurocirugia con infeccion o reintervencion, la documentacion debe dejar cronologia, cultivos/tratamiento cuando existen, evolucion y razonamiento de la conducta.
- Impacto documental: historia_clinica, parte_quirurgico, evolucion
- Tamiz:
  - Evolucion: ante fiebre, herida, coleccion o sospecha infecciosa, registrar hallazgo, estudio/cultivo si se solicita y plan antibiotico/quirurgico.
  - Historia clinica/parte: si hay reintervencion, dejar causa, hallazgo, muestra/cultivo si corresponde y estado final.
  - Tamiz institucional: diferenciar complicacion posible de omision de control o tratamiento documentable.


## Doctrina de especialidad separada
### NSD-001 - Consentimiento medico informado escrito en neurocirugia
- Fuente: https://aanc.org.ar/ranc/items/show/759
- Confiabilidad: `doctrine_specialty_argentina`
  - El consentimiento neuroquirurgico debe ser personalizado y elaborado como proceso, no como tramite administrativo.
  - Debe cubrir naturaleza del procedimiento, beneficios, riesgos tipicos, riesgos personalizados, alternativas incluida no intervencion, preguntas y firmas.
  - En cirugia programada conviene entregarlo con tiempo de lectura y dejar constancia en historia clinica.


## Queries para proximo actualizador
- `site:saij.gob.ar neurocirugia mala praxis responsabilidad medica`
- `site:saij.gob.ar neurocirujano responsabilidad medica mala praxis`
- `site:saij.gob.ar cirugia columna mala praxis responsabilidad medica`
- `site:saij.gob.ar hernia disco cirugia mala praxis danos perjuicios`
- `site:fallos.jusrionegro.gov.ar cirugia de columna mala praxis`
- `"neurocirugia" "consentimiento informado" "mala praxis" Argentina fallo`
- `"cirugia de columna" "consentimiento informado" "danos y perjuicios" Argentina`
- `"hernia de disco" "mala praxis" "danos y perjuicios" Argentina`
- `"hipofisectomia" "carotida" "danos y perjuicios" Argentina`
- `"neurocirujano" "OSECAC" "responsabilidad medica"`
- `"Echenique" "Pardal" aneurisma mala praxis`
- `"craneotomia" "responsabilidad medica" "SAIJ"`
- `"Gonzalez" "F.L.E.N.I." "historia clinica"`
- `"Fantini" "Clinica Roca" columna intubacion`
