# Referencia primaria oficial detectada para Ley 27.706

- Fecha de intento: 2026-05-18T19:33:30Z
- Objetivo: incorporar una ruta normativa primaria estable para Ley 27.706 dentro del corpus medicolegal detect-only.
- URL oficial detectada: https://servicios.infoleg.gob.ar/infolegInternet/verNorma.do?id=386179
- Evidencia positiva: una consulta HEAD devolvio HTTP 200 OK, content-type text/html;charset=iso-8859-1 y content-length 4533.
- Evidencia negativa: la descarga GET del cuerpo completo por curl en este microciclo vencio por timeout sin bytes utiles y web_fetch devolvio 403.
- Estado operativo: blocked_source_body_fetch_pending
- Impacto: la existencia de una ruta primaria oficial ya queda preservada en el source registry detect-only, separada del puente secundario argentina.gob.ar sobre Ley 27.706 y Decreto 393/2023.
- Siguiente intento sugerido: reintentar GET estructurado desde InfoLEG con otra ruta o ventana fuera de este microciclo, sin activar ninguna regla nueva.
