# Campos Obligatorios — Parte Quirúrgico
ultima_actualizacion: 2026-05-18
base_legal: Decreto 1089/2012 Art. 40 + Ley 26.529

## CHECKLIST DE CAMPOS — USO DE JARVIS

Para cada parte generado, verificar TODOS estos campos.
Un campo vacío sin justificación = ALERTA ROJA.

---

### BLOQUE 1 — IDENTIFICACIÓN (obligatorio total)
- [ ] Apellido y nombre completo del paciente
- [ ] Número de DNI
- [ ] Número de Historia Clínica
- [ ] Fecha de nacimiento / edad
- [ ] Fecha del acto quirúrgico (dd/mm/aaaa)
- [ ] Hora de inicio del acto quirúrgico (hh:mm)
- [ ] Hora de finalización del acto quirúrgico (hh:mm)
- [ ] Nombre del establecimiento
- [ ] Número o identificación del quirófano

### BLOQUE 2 — EQUIPO (obligatorio total, con matrícula)
- [ ] Cirujano principal — nombre completo + matrícula provincial
- [ ] Primer ayudante (si hubo) — nombre + matrícula
- [ ] Anestesiólogo — nombre completo + matrícula provincial
      NOTA: el anestesiólogo tiene su propio parte separado
- [ ] Instrumentadora — nombre completo
- [ ] Circulante (si hubo)

### BLOQUE 3 — DIAGNÓSTICO (obligatorio total)
- [ ] Diagnóstico preoperatorio
      → Debe incluir localización específica
      → Debe incluir lateralidad cuando aplique
      → Debe ser coherente con la indicación quirúrgica
- [ ] Diagnóstico postoperatorio
      → Debe ser coherente con el preoperatorio
      → Si difiere significativamente: nota explicativa obligatoria

### BLOQUE 4 — TÉCNICA (obligatorio total)
- [ ] Posición del paciente en la mesa quirúrgica
- [ ] Tipo de anestesia (referencia al parte de anestesia)
- [ ] Vía de abordaje / acceso quirúrgico
- [ ] Descripción paso a paso del procedimiento
      → Sin expresiones vagas (ver frases-prohibidas.md)
      → Con descripción de cada tiempo quirúrgico
- [ ] Materiales e implantes utilizados
      → Si hay implantes: marca + lote + número de serie
      → Si hay suturas: tipo y calibre
      → Si hay drenajes: tipo y ubicación
- [ ] Técnica de cierre
      → Por planos
      → Material de sutura por plano

### BLOQUE 5 — HALLAZGOS (obligatorio siempre)
- [ ] Hallazgos intraoperatorios
      → NUNCA dejar vacío
      → Si no hay hallazgos patológicos: escribir
        "Hallazgos intraoperatorios concordantes con
         el diagnóstico preoperatorio. Sin hallazgos
         patológicos adicionales."
      → En columna: descripción del disco/canal/raíces
      → En abdomen: descripción de órganos visualizados

### BLOQUE 6 — COMPLICACIONES (obligatorio siempre)
- [ ] Incidentes y complicaciones intraoperatorias
      → NUNCA dejar vacío
      → Si no hubo: escribir
        "Sin complicaciones intraoperatorias registradas."
      → Si hubo: descripción completa + conducta adoptada

### BLOQUE 7 — ESPECÍFICO COLUMNA (obligatorio en neuro)
- [ ] Verificación de nivel quirúrgico
      → "Se verifica nivel quirúrgico mediante control
         radioscópico intraoperatorio confirmando [nivel]"
      → CRÍTICO según jurisprudencia CNCiv Sala K 2019
- [ ] Estado de la raíz / médula al finalizar
      → "Se constata raíz [X] libre y móvil"
      → "Sin evidencia de lesión neurológica"
- [ ] Uso de microscopio / lupas / endoscopio si aplica
- [ ] Si se usó parche de duramadre:
      → Marca comercial
      → Número de lote
      → Número de serie
      → Indicación de uso
- [ ] Si se usó hemostático:
      → Nombre del producto
      → Número de lote
      → Cantidad utilizada

### BLOQUE 8 — CIERRE (obligatorio total)
- [ ] Material enviado a anatomía patológica
      → Si se envió: descripción + rotulado
      → Si no se envió: "No se envía material a
         anatomía patológica en este procedimiento."
- [ ] Destino del paciente al finalizar
      → Sala de recuperación / UTI / sala general
- [ ] Pérdida hemática estimada (opcional pero recomendado)
- [ ] Firma del cirujano principal
- [ ] Aclaración (nombre completo)
- [ ] Número de matrícula provincial
- [ ] Fecha y hora de confección del parte

---

## NIVELES DE ALERTA PARA JARVIS

### ROJO — No generar el parte sin resolver
- Falta nombre del paciente
- Falta diagnóstico preoperatorio
- Falta descripción de técnica
- Falta firma / matrícula del cirujano

### AMARILLO — Generar con advertencia
- Falta hora exacta de inicio o fin
- Hallazgos intraoperatorios vagos o incompletos
- Material de implante sin lote/serie (si aplica)
- Verificación radioscópica no mencionada (en columna)

### VERDE — Completo
Todos los campos de los 8 bloques cubiertos
con información específica y no vaga
