# Lenguaje Médico-Legal — Frases Prohibidas y Correctas
ultima_actualizacion: 2026-05-18
uso: Jarvis debe evitar TODAS las frases prohibidas
     y reemplazarlas por las correctas o equivalentes

---

## FRASES PROHIBIDAS — NUNCA usar

### Por vaguedad técnica (riesgo legal alto)

❌ "Se realizó el procedimiento habitual"
   → No describe qué se hizo. Indefendible en juicio.

❌ "Cirugía sin inconvenientes"
   → No especifica nada. ¿Sin qué inconvenientes?

❌ "Técnica estándar"
   → No existe técnica estándar en términos legales.

❌ "Procedimiento de rutina"
   → Ningún acto quirúrgico es de rutina legalmente.

❌ "Sin novedades"
   → Inaceptable en documentación médico-legal.

❌ "Evolución favorable"
   → Sin descripción es insuficiente.

❌ "Se realizó según protocolo"
   → ¿Cuál protocolo? No es descriptivo.

❌ "Todo bien"
   → Absolutamente inaceptable en HC o parte.

### Por omisión de lateralidad o nivel

❌ "Hernia de disco" (sin nivel ni lado)
   → Debe decir: "Hernia de disco L4/5 paralateal derecha"

❌ "Raíz comprometida" (sin especificar cuál)
   → Debe decir: "Raíz L5 derecha"

❌ "Se operó el nivel afectado"
   → Debe decir: "Se abordó el espacio intervertebral L4/5"

### Por omisión de verificación

❌ No mencionar la verificación radioscópica en columna
   → SIEMPRE incluir la confirmación del nivel

❌ "Se utilizó implante" sin especificar cuál
   → Debe incluir marca, lote y número de serie

### Por ambigüedad en complicaciones

❌ Dejar el campo "complicaciones" vacío
   → Siempre escribir algo, aunque sea que no hubo

❌ "Sin complicaciones" (muy escueto)
   → Preferir: "Sin complicaciones intraoperatorias
      registradas. Hemostasia correcta."

---

## FRASES CORRECTAS — Usar estas o equivalentes

### Para técnica quirúrgica en columna lumbar

✅ "Bajo anestesia general, en posición prona sobre
    caballete de Wilson con protección de puntos de apoyo.
    Asepsia y antisepsia de región lumbar."

✅ "Se verifica nivel quirúrgico mediante control
    radioscópico intraoperatorio, confirmando abordaje
    en espacio intervertebral [L4/5]."

✅ "Abordaje mediante sistema de retractores tubulares
    de [X] mm de diámetro bajo control radioscópico
    con correcto posicionamiento confirmado."

✅ "Identificación y protección de raíz [L5] derecha.
    Discectomía del fragmento herniado con pinza de
    Kerrison y cucharillas. Se comprueba raíz libre
    y móvil al finalizar la discectomía."

✅ "Hemostasia con agente hemostático [nombre/marca/lote].
    Parche de duramadre [marca/lote/serie] aplicado
    sobre [indicación específica]."

✅ "Cierre por planos anatómicos con Vicryl [calibre]
    en fascia, Vicryl [calibre] en tejido subcutáneo,
    Monocryl [calibre] en piel con puntos intradérmicos."

### Para hallazgos intraoperatorios en columna

✅ "Hallazgos: fragmento discal herniado de características
    [blandas/fibrosadas/calcificadas], de aproximadamente
    [tamaño estimado], con compresión de raíz [L5] derecha
    confirmada. El espacio discal presenta [descripción].
    Sin otros hallazgos patológicos."

✅ "Se constata compresión radicular de raíz [L5] derecha
    por fragmento discal paralateal. Canal medular permeable.
    Sin evidencia de inestabilidad segmentaria."

### Para cuando no hay hallazgos adicionales

✅ "Hallazgos intraoperatorios concordantes con el
    diagnóstico preoperatorio. No se evidencian
    hallazgos patológicos adicionales."

### Para complicaciones

✅ "Sin complicaciones intraoperatorias registradas.
    Hemostasia prolija. Sangrado intraoperatorio
    estimado: [X] ml."

✅ "Durante el procedimiento se produjo [descripción
    precisa de la complicación]. Se adoptó la siguiente
    conducta: [descripción de lo realizado]."

### Para anatomía patológica

✅ "Se envía a anatomía patológica: fragmento de núcleo
    pulposo L4/5 rotulado como 'Disco L4/5 Dr. Zanardi
    [fecha]'. Número de muestra: [X]."

✅ "No se envía material a anatomía patológica en este
    procedimiento dado que [razón si corresponde / o
    simplemente: 'No aplica para este tipo de intervención']."

### Para destino del paciente

✅ "Paciente tolera el procedimiento sin incidentes.
    Egresa a sala de recuperación post-anestésica en
    condiciones estables."

✅ "Paciente trasladado a sala general en condiciones
    hemodinámicamente estables, con [Glasgow / estado
    neurológico] preservado."

---

## NOTA PARA JARVIS
Cuando el médico use en su descripción coloquial
alguna de las frases prohibidas o equivalentes,
reemplazarlas automáticamente por la versión correcta
y marcar el cambio con alerta AMARILLA para que el
médico confirme que la versión técnica es correcta.
