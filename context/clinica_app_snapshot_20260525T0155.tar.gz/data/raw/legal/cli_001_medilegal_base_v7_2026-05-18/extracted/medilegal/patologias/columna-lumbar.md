# Cirugía de Columna Lumbar — Base de Conocimiento
ultima_actualizacion: 2026-05-18
especialidad: Neurocirugía / Cirugía de Columna
relevancia: ALTA para Dr. Zanardi

---

## PATOLOGÍAS FRECUENTES Y SU DOCUMENTACIÓN

### 1. Hernia de Núcleo Pulposo (HNP)

#### Diagnósticos preoperatorios correctos
- "Hernia de núcleo pulposo [L3/4 / L4/5 / L5/S1]
   [central / paracentral / paralateal / foraminal / extraforaminal]
   [derecha / izquierda]
   con [radiculopatía / síndrome ciático] [L4/L5/S1] [derecha/izquierda]"

#### Síntomas que sustentan la indicación (deben figurar en HC)
- Lumbalgia con irradiación a miembro inferior en territorio radicular
- Duración del cuadro (fundamental para justificar indicación)
- Fracaso del tratamiento conservador previo (obligatorio documentar)
- Hallazgos del examen físico: Lasègue, déficit motor/sensitivo/reflejos
- Estudios de imagen: RMN confirmatoria (fecha y hallazgos)

#### Técnicas habituales y su descripción
- Microdiscectomía abierta
- Microdiscectomía tubular (con retractores tubulares)
- Discectomía endoscópica

#### Campos críticos específicos HNP
- Verificación radioscópica del nivel: OBLIGATORIO
- Descripción de la raíz: estado pre y post descompresión
- Descripción del fragmento herniado: consistencia, tamaño estimado
- Si hay desgarro dural: descripción y reparación
- Si se usa parche de duramadre: marca, lote, serie, indicación

---

### 2. Estenosis de Canal

#### Diagnósticos preoperatorios correctos
- "Estenosis de canal lumbar [nivel/es]
   [central / foraminal bilateral / foraminal derecha|izquierda]
   con [claudicación neurógena / radiculopatía bilateral / mielopatía]"

#### Campos críticos específicos
- Número de niveles abordados
- Técnica de descompresión: laminectomía / hemilaminectomía / laminotomía
- Estado del canal pre y post descompresión
- Preservación de elementos de estabilidad (cápsulas articulares)
- Si se realiza artrodesis: descripción completa del sistema utilizado

---

### 3. Espondilolistesis

#### Diagnósticos preoperatorios correctos
- "Espondilolistesis [ístmica/degenerativa] [L4/L5 / L5/S1]
   grado [I/II/III/IV] de Meyerding
   con [inestabilidad segmentaria / radiculopatía / claudicación]"

#### Campos críticos
- Grado de deslizamiento pre y postoperatorio
- Sistema de fijación: descripción completa
  → Marca, referencia, número de lote de cada implante
  → Tornillos pediculares: diámetro, longitud, nivel, lado
  → Caja intersomática (TLIF/PLIF): marca, lote, serie, tamaño
  → Barras: diámetro, longitud, material
- Injerto óseo: tipo, origen, cantidad
- Control radioscópico de posición de implantes: OBLIGATORIO

---

### 4. Sección / Reparación Dural (complicación)

Si durante la cirugía se produce un desgarro dural:

#### Descripción obligatoria
- Localización exacta del desgarro
- Tamaño aproximado
- Técnica de reparación utilizada
- Material de sutura: tipo, calibre, marca
- Uso de parche de duramadre: marca, lote, serie
- Uso de sellante dural si aplica: marca, lote
- Maniobra de Valsalva al finalizar: resultado
- Posición postoperatoria indicada: [decúbito/tiempo]

#### Implicancia legal
La lesión dural no es mala praxis per se si está
documentada y manejada correctamente.
La NO documentación de una lesión dural que luego
genera complicaciones SÍ puede constituir mala praxis.

---

## INDICACIÓN QUIRÚRGICA — DOCUMENTAR SIEMPRE

Para que el parte sea médico-legalmente sólido,
la HC debe contener antes de la cirugía:

1. Diagnóstico confirmado por imagen (RMN/TAC con fecha)
2. Tiempo de evolución de los síntomas
3. Tratamiento conservador previo y su resultado
   (si aplica: "Fracaso del tratamiento conservador
   con [fisioterapia / bloqueos / medicación] durante
   [X semanas/meses]")
4. Consentimiento informado firmado con riesgos específicos:
   - Lesión neurológica (radicular/medular según nivel)
   - Infección superficial/profunda/discitis
   - Recidiva herniaria
   - Síndrome post-laminectomía / dolor residual
   - Complicaciones anestésicas
   - En instrumentadas: falla de implante, pseudoartrosis

---

## PLANTILLA BASE PARA JARVIS

Cuando el Dr. Zanardi describa una cirugía de columna
lumbar, usar esta estructura como base y completar
con la información específica del caso:

```
DIAGNÓSTICO PREOPERATORIO:
[patología] [nivel] [localización] [lado]
con [síntoma/síndrome] [lado/bilateral]

TÉCNICA QUIRÚRGICA:
Bajo anestesia general, en posición prona sobre
caballete de Wilson con protección de puntos de apoyo.
Asepsia y antisepsia de región [lumbar/lumbosacra].
Se verifica nivel quirúrgico mediante control radioscópico
intraoperatorio, confirmando abordaje en espacio [nivel].
[Descripción del abordaje según técnica]
[Descripción de los tiempos quirúrgicos principales]
[Descripción de materiales utilizados con datos de trazabilidad]
Hemostasia [con/sin hemostático (nombre/lote)].
[Si aplica: parche de duramadre (marca/lote/serie)]
Cierre por planos con [materiales de sutura por plano].

HALLAZGOS INTRAOPERATORIOS:
[Descripción de hallazgos concordantes con diagnóstico]
[Estado de raíz/médula pre y post descompresión]
[Sin/Con hallazgos patológicos adicionales]

COMPLICACIONES:
Sin complicaciones intraoperatorias registradas. /
[Descripción de complicación y conducta adoptada]

DIAGNÓSTICO POSTOPERATORIO:
[patología] operada. [Descripción del resultado].
Evolución postoperatoria inmediata sin particularidades. /
[o descripción si hubo algo relevante]

MATERIAL PARA ANATOMÍA PATOLÓGICA:
[Descripción del material enviado o "No aplica"]

DESTINO:
Paciente tolera el procedimiento. Egresa a
[sala de recuperación/sala general] en condiciones
[hemodinámicamente estables / descripción].
```
