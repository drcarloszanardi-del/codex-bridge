# Código Civil y Comercial — Responsabilidad Médica
ultima_actualizacion: 2026-05-18
fuente: SAIJ / InfoLEG
estado: vigente (desde agosto 2015)

## Marco general de responsabilidad

### Art. 1710 — Deber de prevención
"Toda persona tiene el deber de evitar causar un daño
no justificado y de adoptar medidas razonables para
evitar que se produzca o que no se agrave."

→ Implicancia: la documentación completa ES una medida
  razonable de prevención. Su omisión puede verse como
  incumplimiento de este deber.

### Art. 1724 — Culpa
"La omisión de la diligencia debida según la naturaleza
de la obligación y las circunstancias de personas, tiempo
y lugar. Comprende la imprudencia, la negligencia y la
impericia en el arte o profesión."

→ La documentación deficiente puede constituir negligencia
  en sí misma, independientemente del resultado clínico.

### Art. 1725 — Valoración de la conducta
"Cuanto mayor sea el deber de obrar con prudencia y pleno
conocimiento de las cosas, mayor es la diligencia exigible."

→ El cirujano especialista tiene un estándar más alto
  de diligencia exigida, incluyendo en documentación.

### Art. 1734 — Prueba de los factores de atribución
"Incumbe al actor probar el nexo de causalidad entre
la acción u omisión y el daño."

→ PERO: la HC incompleta invierte esta carga.
  Ver jurisprudencia en /jurisprudencia/fallos-hc.md

### Art. 1735 — Carga dinámica de la prueba
"El juez puede distribuir la carga de la prueba de la
culpa o de haber actuado con la diligencia debida,
ponderando cuál de las partes se halla en mejor
situación para aportarla."

→ Si la HC está incompleta, el juez puede presumir
  que el médico estaba en mejor posición para probar
  y no lo hizo. Esto opera en su contra.

### Arts. 1737-1748 — Daño resarcible
Incluye:
- Daño emergente
- Lucro cesante
- Pérdida de chance
- Daño extrapatrimonial (moral)
- Daño a la integridad psicofísica
- Consecuencias no patrimoniales

## Naturaleza de la obligación médica

### Obligación de medios (regla general)
El médico se compromete a actuar con diligencia,
no a garantizar resultados. Para acreditar cumplimiento:
→ La documentación es la prueba principal de la diligencia.

### Obligación de resultado (excepción)
En procedimientos estéticos, algunos implantes, y cirugías
donde el resultado fue prometido explícitamente.
→ El consentimiento informado debe ser cuidadoso en no
  prometer resultados que no se pueden garantizar.

## Prescripción de la acción

### Art. 2562 inc. a
"Prescriben a los tres años las acciones por agresión
sexual, daños derivados de la responsabilidad civil."

→ El médico debe conservar documentación por al menos
  10 años (Ley 26.529 art. 16) considerando plazos
  de prescripción y sus eventuales interrupciones.
