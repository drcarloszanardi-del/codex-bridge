# Estilo y Referencias — Dr. Carlos Zanardi
# CIRUGÍAS DE REVISIÓN — CASOS COMPLEJOS
ultima_actualizacion: 2026-05-18
basado_en: 20 casos reales analizados
criterio: Este archivo cubre revisiones complejas.
          Las simples (extensión de fijación a nivel adyacente) quedan
          integradas en estilo-zanardi-fijacion.md

---

## QUÉ ES UNA REVISIÓN COMPLEJA vs SIMPLE

### Simple → integrada en fijacion.md
- Extensión de fijación a nivel adyacente por síndrome adyacente
- Re-tightening de tornillos con buen sustrato óseo
- La técnica es idéntica a fijación primaria con el paso adicional de retirar material

### Compleja → este archivo
- Falla de implante por mala calidad (causa identificable en el material)
- Cirugía fallida de otro cirujano (flat back, cifosis, descompresión incompleta)
- Revisión cervical o dorsal por tumor/fractura patológica
- Corrección de implante mal colocado que comprime nervio
- Fijación larga por deformidad sagital (T11 o más cefálico)
- Discitis/infección sobre implante previo

---

## ELEMENTO CRÍTICO #1 — DOCUMENTAR EL ESTADO PREVIO

En toda revisión, la HC debe describir explícitamente:

```
Antecedentes quirúrgicos:
  → Quién operó (aunque sea "equipo tratante anterior" si no hay datos)
  → Cuándo
  → Qué procedimiento se realizó
  → Cómo evolucionó
  → Por qué falla ahora

Ejemplos reales del Dr. Zanardi:

"Antecedentes de cirugía para fijación L4/5 que evolucionó con
aflojamiento del implante." (Premio)

"Material provisto por Ortopedia Villalba de pésima calidad.
Se le explica a la familia sobre la necesidad de cirugía de revisión
porque se extruyo la caja (PLIF)." (Ruiz)

"Antecedentes de dos cirugías donde se realizó recalibraje parcial y
fijación L3/S1. Canal estrecho residual. Flat back. Cirugía fallida."
(Cervini)

"Fue operada en otra institución donde se realizó la colocación de un ALIF
en L5/S1 y un OLIF L4/5 stand alone. Evolucionó con dolor radicular
asociado a compresión foraminal L4/5 y pseudoartrosis." (Linardi)
```

→ Esta documentación preoperatoria es la que separa tu responsabilidad
  de la del cirujano anterior. Sin ella, el estado previo queda sin acreditar.

---

## ELEMENTO CRÍTICO #2 — FALLA DE IMPLANTE POR CALIDAD

Cuando la causa de la revisión es falla del material y no error técnico:

### Lo que hace el Dr. Zanardi (documentar así):

```
EN LA HC:
"Material provisto por [proveedor] de pésima calidad."
"Tornillos que han perdido amarre en el contexto de osteoporosis severa."
"Extrusión de PLIF de titanio asociada a aflojamiento de tornillos
pediculares en contexto de mal sustrato óseo."

EN EL PARTE:
"La tulipa del tornillo trabada (mala calidad del implante).
Se retira el tornillo y se cambia por otro de mayor diámetro,
que sigue otro trayecto."

AL FINAL DEL PARTE (CRÍTICO):
"El tornillo extraído se entrega al familiar del paciente y se le explica
la condición que motivó la falla del material."
```

→ **Entregar el implante fallado a la familia y documentarlo es una de las
  mejores prácticas médico-legales que existe en revisiones.**
  Preserva la evidencia. Muestra transparencia. Traslada la responsabilidad
  al fabricante si corresponde.

Jarvis debe preguntar siempre: "¿Conservaste el implante retirado?
¿Se lo entregaste a la familia o al paciente?"

---

## ELEMENTO CRÍTICO #3 — COMPLICACIÓN INTRAOPERATORIA / POSTOPERATORIA

Cuando ocurre algo adverso, documentarlo honestamente protege más que ocultarlo.

### Modelo del Dr. Zanardi (Ríos Marta):

```
EN LA EVOLUCIÓN:
"Refiere paresia leve en la flexión de la cadera que se interpreta como
consecuencia de la neuroapraxia durante las maniobras de colocación de
la caja. Se le explica a la paciente y la familia."
```

Tres elementos que siempre deben estar:
1. Descripción precisa del déficit
2. Interpretación clínica (neuroapraxia, no lesión definitiva)
3. Comunicación documentada con paciente y familia

Jarvis debe preguntar siempre en revisiones: "¿Hubo alguna incidencia
intraoperatoria o en el postoperatorio inmediato que registrar?"

---

## TIPOS DE REVISIÓN Y SU DOCUMENTACIÓN

### TIPO 1 — Falla de implante (aflojamiento + extrusión de PLIF)

**Diagnóstico:**
"Extrusión de caja intersomática (PLIF) y aflojamiento de tornillos pediculares [nivel]."
"Aflojamiento de implantes lumbares. Inestabilidad segmentaria."

**Operación:**
"Cirugía de revisión lumbar. Recolocación de caja intersomática y revisión de tornillos."
"Cirugía de revisión. Extracción y reimpactación de PLIF. Recolocación de tornillos
pediculares de revisión."

**Texto del parte:**
```
Decúbito prono. Asepsia y antisepsia. Se utilizan las incisiones previas como
guía para el abordaje. Apertura de incisiones previas. Disección por planos.
Colocación de retractores autoestáticos.
Se identifican barras y tulipas de los tornillos bilateralmente.
Se retiran los inners. [Descripción del estado de cada tornillo].
[Si tornillo flojo: "El tornillo de [nivel/lado] se encuentra totalmente flojo.
Se retira y se cambia por otro de mayor diámetro [X] mm, previo procedimiento
de aumentación con sistema de cifoplastia/PMMA."]
[Si PLIF extruida: "La caja se encuentra retropulsada. Se diseca cuidadosamente
de la raíz saliente. Se trabaja el espacio intersomático y se reimpacta,
llevándola a posición más anterior / [dirección] del espacio discal."]
Control radioscópico de posición. Hemostasia completa. Lavado profuso de
la logia operatoria. Cierre por planos. Procedimiento sin complicaciones.
[Si implante fallado: "El/los tornillo/s extraído/s se entrega/n al familiar
del paciente. Se explica la condición que motivó la falla del material."]
```

---

### TIPO 2 — Cirugía fallida de otro cirujano (flat back / descompresión incompleta)

**Diagnóstico:**
"Canal estrecho lumbar residual. Cirugía lumbar fallida."
"Canal estrecho lumbar residual. Flat back. Cirugía lumbar fallida.
Cifosis de la unión proximal."

**Operación:**
"Recalibraje microquirúrgico y fijación [niveles]. Recolocación de tornillos."
"Recalibraje microquirúrgico y fijación [niveles]. Recolocación de tornillos.
Aumentación vertebral. Alineación espinal."

**Texto del parte:**
```
Decúbito prono. Antisepsia rigurosa. Infiltración de celular con xilocaína
con epinefrina. Incisión medial siguiendo cicatriz previa [y resecando
el tercio inferior donde había cerrado por segunda intención].
Disección subperióstica bilateral.
Corroboración radioscópica del nivel.
Se exponen tornillos pediculares y barras bilateralmente.
Se procede a sacar los tornillos y colocar tornillos de revisión
(se usa sistema de [marca]).
[Si aumentación: "Se aumenta [nivel] para mejor amarre utilizando set de
VTP y cánulas."]
Se comienza la laminectomía con drill y kerrison entre [niveles].
El canal está muy estrechado. Se libera el saco dural desde [nivel] hasta [nivel].
Hemostasia completa. Chips de hueso para artrodesis intertransversa.
[Si lordosis corregida: "Se cierra el sistema en lordosis."]
[Si drenaje: "Se coloca drenaje que se exterioriza por contrabertura."]
Cierre de aponeurosis, celular y piel por planos.
Cura plana oclusiva y compresiva.
Procedimiento bien tolerado, sin complicaciones.
```

---

### TIPO 3 — Extensión de fijación con retirada parcial de material previo

**Diagnóstico:**
"Listesis degenerativa inestable [nivel]. [Nivel] cefálica a fijación previa."
"Inestabilidad [nivel] cefálica a fijación [niveles] realizada en cirugía previa."

**Lo diferencial respecto a fijación primaria:**
```
"Siguiendo cicatrices quirúrgicas previas..."
"Por vía intermuscular se exponen los tornillos y barras del sistema previo."
"Se sacan los inners. Se retiran las barras."
"Se retiran tornillos de [niveles que se extraen]."
"Se constata buen amarre en tornillos de [niveles que quedan]."
"Se colocan tornillos nuevos en [niveles que se agregan] bilateralmente."
```
→ El resto del parte es idéntico a fijación primaria.

---

### TIPO 4 — Implante de otro cirujano que comprime nervio

**Diagnóstico:**
"Compresión radicular [raíz] por tornillo pedicular mal colocado."
"Compresión radicular [raíz] por caja [tipo] colocada en posición foraminal."

**Texto del parte:**
```
[...abordaje estándar...]
Se identifica [tornillo/caja] en posición [descripción] comprimiendo
la raíz [X] [lado].
Con drill de alta velocidad se realiza el drilado de la [caja/tornillo]
para liberar la raíz [pasante/saliente].
Liberación radicular completa confirmada.
[Si parche dural: "Se coloca parche dural en topografía de axila radicular
para evitar fístula de LCR."]
```

---

### TIPO 5 — Revisión por discitis/infección sobre implante previo

**Siempre incluir:**
```
"Se envían muestras de tejido para cultivo microbiológico
(aerobios, anaerobios, hongos)."
"Lavado profuso de la logia operatoria."
```
→ Ver también estilo-zanardi-especiales.md (Variante D: discitis)

---

## CONSENTIMIENTO INFORMADO — REVISIÓN (diferencias clave)

El CI de revisión del Dr. Zanardi es más explícito que el de cirugía primaria en:

1. **Expectativas reducidas:**
   "Después de tantas cirugías, la posibilidad de mejoría se reduce mucho."

2. **Posibilidad de nueva reoperación:**
   "En caso de evolucionar con inestabilidad del segmento, el Doctor me explicó
   la potencialidad de necesitar una fijación de ese sector de la columna."

3. **Atribución del problema:**
   "Los Doctores me han explicado que ese tipo de cirugía que le realizaron
   suele asociarse a complicaciones y que ellos intentarán solucionar el conflicto."

4. **Riesgo de cicatriz compresiva:**
   "En el largo plazo la cicatriz puede por sí misma comprimir al nervio
   y ser causa de dolor."

5. **Sin alternativas conservadoras válidas:**
   "El Doctor nos ha explicado que no existen alternativas actuales válidas
   de tratamiento."

---

## INSTRUCCIONES PARA JARVIS

### Preguntar SIEMPRE en revisión:

1. "¿Quién realizó la cirugía previa? ¿Cuándo? ¿En qué institución?"
   → Para documentar atribución correctamente

2. "¿La causa de la falla es identificable? (mala calidad del implante,
   osteoporosis, técnica del cirujano anterior, progresión de la enfermedad)"
   → Cambia el texto del parte y del CI

3. "¿Retiraste implantes? ¿Los conservaste?"
   → Si sí: "¿Se los entregaste al paciente/familia?"
   → Documentar siempre

4. "¿Hubo alguna complicación intraoperatoria o en el postoperatorio inmediato?"
   → Si sí: documentar con descripción + interpretación + comunicación familia

5. "¿El campo quirúrgico tenía adherencias significativas?"
   → Siempre documentar en revisión de terceros

### Frase que no puede faltar en revisiones de implante fallado:
"El/los implante/s retirado/s se entrega/n al paciente/familiar con
explicación de la causa de falla."

### Diferenciador clave HC de revisión vs primaria:
La HC de revisión SIEMPRE empieza con la historia quirúrgica previa,
antes de la enfermedad actual. Sin eso el expediente no tiene sentido.
