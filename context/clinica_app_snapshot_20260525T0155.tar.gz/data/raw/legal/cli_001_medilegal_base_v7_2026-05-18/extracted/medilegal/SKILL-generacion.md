# SKILL: Generación de HC y Parte Quirúrgico
# Para OpenClaw / Jarvis
ultima_actualizacion: 2026-05-18

## CUÁNDO ACTIVAR ESTA SKILL
Cuando el Dr. Zanardi mande un mensaje que contenga
cualquier combinación de:
- Nombre de paciente + patología + descripción de procedimiento
- "operé", "cirugía", "intervine", "parte de"
- Descripción de técnica quirúrgica en cualquier formato

## FLUJO OBLIGATORIO

### PASO 1 — Extraer datos del mensaje

Del mensaje del Dr. Zanardi extraer:

DATOS_PACIENTE:
  nombre: (si lo menciona)
  patologia: (diagnóstico en sus palabras)
  
DATOS_CIRUGIA:
  hora_inicio: (si la menciona)
  hora_fin: (si la menciona)
  tecnica: (descripción coloquial)
  materiales: (lo que mencione)
  complicaciones: (si menciona "sin complicaciones" o describe alguna)
  destino: (sala general, UTI, etc.)

### PASO 2 — Cargar base de conocimiento

Leer OBLIGATORIAMENTE antes de generar:
1. /knowledge/campos-obligatorios/parte-campos.md
2. /knowledge/validacion/frases-prohibidas.md
3. /knowledge/patologias/[patologia-correspondiente].md
4. Si hay referencias del Dr. Zanardi de casos similares:
   cargar los 3 más recientes como referencia de estilo

### PASO 3 — Consultar a Codex Guard

Enviar a Codex Guard el siguiente prompt:

"""
CONTEXTO: Sos asistente médico-legal especializado
en cirugía de columna / neurocirugía argentina.

NORMATIVA APLICABLE:
[contenido de campos-obligatorios/parte-campos.md]

ESTILO DE REFERENCIA:
[partes anteriores del Dr. Zanardi si existen]

FRASES PROHIBIDAS:
[contenido de frases-prohibidas.md]

PLANTILLA BASE:
[contenido de patologias/columna-lumbar.md u otra]

DESCRIPCIÓN DEL MÉDICO:
[mensaje textual del Dr. Zanardi]

TAREA:
Generar en JSON:
{
  "hc_evolucion": "nota de evolución preoperatoria",
  "diagnostico_preoperatorio": "texto formal",
  "tecnica_quirurgica": "descripción técnica completa",
  "hallazgos_intraoperatorios": "descripción",
  "complicaciones": "texto",
  "diagnostico_postoperatorio": "texto",
  "material_ap": "texto o null",
  "destino": "texto",
  "campos_faltantes": ["lista de campos que el médico no mencionó"],
  "alertas": [{"campo":"x","tipo":"warning|error","mensaje":"x"}],
  "semaforo": "verde|amarillo|rojo"
}
"""

### PASO 4 — Procesar respuesta

Si semaforo == "rojo":
  Enviar por Telegram:
  "🔴 Faltan datos críticos antes de generar el parte:
   [lista de campos_faltantes]
   ¿Me los podés dar?"
  → Esperar respuesta del médico antes de continuar

Si semaforo == "amarillo":
  Generar el parte con los datos disponibles
  Marcar con [REVISAR] los campos con alertas

Si semaforo == "verde":
  Generar el parte completo

### PASO 5 — Enviar para revisión

Enviar por Telegram al Dr. Zanardi:
"[semáforo emoji] Parte listo para [nombre paciente]

DIAGNÓSTICO PRE: [resumen en 1 línea]
TÉCNICA: [resumen en 1 línea]
HALLAZGOS: [resumen en 1 línea]
COMPLICACIONES: [texto]

[lista de alertas si las hay]

¿Aprobás? Respondé:
✅ Aprobar → genero PDF
✏️ Corregir → decime qué cambiar
❌ Descartar"

### PASO 6 — Según respuesta del médico

Si "✅" o "Aprobar" o "sí":
  - Generar PDF con formato formal
  - Guardarlo en /Users/jarvis/medilegal/partes/
    con nombre: Parte_[Apellido]_[fecha].pdf
  - Enviar el PDF por Telegram
  - Avisar: "PDF generado. Adjuntalo a Nexup."

Si "✏️" o corrección:
  - Aplicar la corrección que indica el médico
  - Regenerar y volver al Paso 5

Si "❌":
  - Descartar y confirmar: "Parte descartado."

## COMPORTAMIENTO ANTE DATOS FALTANTES

El médico puede no dar todos los datos en un solo mensaje.
Jarvis puede completar con [COMPLETAR] cuando:
- No se mencionó el nombre del paciente
- No se mencionó el horario exacto
- No se mencionaron datos del equipo

Jarvis NO puede inventar:
- Diagnósticos
- Hallazgos intraoperatorios
- Complicaciones
- Materiales utilizados

Si el médico no los menciona → PREGUNTAR antes de generar.

## MEMORIA

Después de cada parte aprobado, guardar en memoria:
- Patología operada
- Técnica utilizada
- Materiales habituales del médico
- Estilo de redacción aprobado

Esto mejora cada generación futura.
