# Estilo y Referencias — Dr. Carlos Zanardi
# HDL — Hernia de Disco Lumbar — Microdiscectomía Tubular
ultima_actualizacion: 2026-05-18
basado_en: 8 documentos reales analizados
uso: Jarvis usa este archivo para generar documentos en el estilo exacto del Dr. Zanardi

---

## CONTEXTO INSTITUCIONAL

El Dr. Zanardi opera en dos clínicas:
- Clínica Centro (Junín) — abreviada "CMP" en encabezados
- Clínica La Pequeña Familia (Junín)

Servicio: Neurocirugía y Cirugía de Columna
Cirujano: Dr. Carlos Zanardi
Ayudantes habituales: Dr. Maximiliano Giménez / Dr. Gabriel Ordoñez / Dr. Matias Diaz

---

## ESTRUCTURA DE LA HISTORIA CLÍNICA — ESTILO ZANARDI

### Encabezado
[Nombre de la Clínica]
Servicio de Neurocirugía y Cirugía de Columna
HISTORIA CLINICA (o INGRESO Y EVOLUCIÓN)

PACIENTE: [Apellido Nombre]     FECHA: [DD de mes de AAAA]

### Campos en orden
1. MOTIVO DE INGRESO
2. ENFERMEDAD ACTUAL
3. EXAMEN FISICO
4. RMN (hallazgos de imagen)
5. EXAMENES PREOPERATORIOS
6. IMPRESION DIAGNOSTICA
7. PLAN TERAPEUTICO
8. Consentimiento informado (referencia)
9. Firma: Dr. Carlos Zanardi

### Frases características del Dr. Zanardi en HC

MOTIVO DE INGRESO (plantilla):
"[Patología] [nivel] [localización], asociada a ciática [lado] invalidante
que no ha mejorado con tratamiento médico/conservador."

ENFERMEDAD ACTUAL (plantilla):
"Ciática [lado] invalidante. Adormecimiento de la región [raíz] homónima.
Muy dolorido/dolorida."

EXAMEN FISICO (plantilla):
"Dolor ciático [lado] invalidante y deficitario."

RMN (plantilla):
"Extrusión discal [nivel] [localización]"

EXAMENES PREOPERATORIOS (frase fija):
"en rango quirúrgico (laboratorio, Rx tórax, ECG)."

IMPRESION DIAGNOSTICA (plantilla):
"Extrusión discal asociada a dolor invalidante. Refractario al tratamiento médico."

PLAN TERAPEUTICO (plantilla):
"microdiscectomía tubular"

CONSENTIMIENTO (frase fija):
"Se informaron al paciente sobre los objetivos y riesgos del procedimiento.
Se firmaron consentimientos."

---

## ESTRUCTURA DEL PARTE QUIRÚRGICO — ESTILO ZANARDI

### Encabezado
[Nombre de la Clínica]
Servicio de Neurocirugía y Cirugía de Columna (CMP)
PARTE QUIRURGICO

PACIENTE: [Apellido Nombre]     FECHA: [DD de mes de AAAA]
CIRUJANO: Carlos Zanardi.       AYUDANTE: [Nombre Apellido]

DIAGNOSTICO: [Patología específica con nivel y localización]
OPERACIÓN: microdiscectomia tubular

### Descripción técnica — TEXTO COMPLETO HABITUAL

**Versión 1 — Clínica Centro 2022-2024 (más detallada):**
"Decúbito prono, soportes bajo tórax, crestas ilíacas y tobillos.
Se constatan pulsos pedios. Antisepsia rigurosa y campos.
Incisión paramediana [derecha/izquierda]. Se introduce el sistema tubular
y se constata la posición con radioscopia del nivel [nivel].
Se comienza la descompresión bajo microscopio óptico a través de tubo
(22mm de diámetro X 5 cm de largo). Se utiliza drill de alta velocidad NSK.
Facetectomia [nivel] mínima. Se identifica el hombro de [raíz] y se descomprime
completamente resecando el disco extruido muy voluminoso.
Hemostasia completa con bipolar, hemostático y sellador dural.
Las raíces saliente y pasante, quedaron muy libres y pulsátiles.
Cierre de músculo, aponeurosis, celular y piel por planos.
Cura plana oclusiva y compresiva.
Procedimiento bien tolerado, sin complicaciones."

**Versión 2 — Clínica Centro/LPF 2026 (más compacta):**
"Decúbito prono bajo anestesia general. Asepsia y antisepsia de región lumbar.
Colocación de campos estériles. Marcación radioscópica del nivel a tratar [nivel].
Incisión lineal de 3 cm. Colocación de sistema de dilatación progresiva hasta colocar
tubo definitivo de 10cm de largo por 18 mm de diámetro, que se fija a camilla con
brazo articulado. Se coloca el microscopio quirúrgico.
Se aborda el espacio interlaminar [nivel] [lado].
Con drill de alta velocidad se realiza osteotomía de hemilamina inferior de [vértebra superior]
[lado], flavectomia homónima y se exponen las estructuras nerviosas.
Se identifica el hombro de [raíz], que se retrae a medial.
Se expone voluminoso fragmento de disco herniado que se diseca y se extrae el fragmento extruido.
El saco queda pulsátil y liberado.
Se coloca parche dural sintético para evitar adherencias con el músculo.
Hemostasia completa con hemostáticos. Se retiran los retractores. Cierre por planos.
Procedimiento sin complicaciones."

---

## ESTRUCTURA DE EVOLUCIÓN — ESTILO ZANARDI

**Evolución inmediata (día 0):**
"Postoperatorio de Discectomía [nivel]. Evoluciona favorablemente sin
complicaciones operatorias. Curaciones secas."
Dr. Carlos Zanardi

**Alta (día 1):**
"[DD de mes de AAAA]. Nc. Evoluciona favorablemente. Se levanta de la cama
y deambula mejor. En condiciones de externación por neurocirugía.
Pautas de alarma y control por consultorios externos."
Dr. Carlos Zanardi

---

## CONSENTIMIENTO INFORMADO — ESTILO ZANARDI

El consentimiento del Dr. Zanardi es muy completo y específico.
Incluye todos los elementos de validez legal:
- Objetivo del procedimiento en lenguaje accesible
- Riesgos específicos de columna (no genéricos)
- Riesgo de recidiva y reoperación
- Riesgo de LCR
- Riesgo neurológico (sensitivo y motor)
- Riesgo vascular mayor
- Alternativas terapéuticas
- Firma del paciente y aclaración
- Fecha (siempre anterior a la cirugía)
- Frase característica: "En cirugía de columna no existe el 'cero kilómetro'."

---

## ANÁLISIS MÉDICO-LEGAL — FORTALEZAS Y GAPS

### ✅ LO QUE HACE BIEN (mantener siempre)

1. VERIFICACIÓN RADIOSCÓPICA DEL NIVEL — siempre presente
   "se constata la posición con radioscopia del nivel [X]"
   "Marcación radioscópica del nivel a tratar [X]"
   → Crítico para defensa en columna. Nunca omitir.

2. LATERALIDAD — siempre especificada en diagnóstico y técnica

3. IDENTIFICACIÓN DE LA RAÍZ — siempre nombrada
   "Se identifica el hombro de [raíz]"

4. ESTADO POST-DESCOMPRESIÓN — siempre documentado
   "El saco queda pulsátil y liberado"
   "Las raíces saliente y pasante, quedaron muy libres y pulsátiles"
   → Esto es excelente. Demuestra que verificó la descompresión.

5. PULSOS PEDIOS — verificados en versión 2022
   "Se constatan pulsos pedios"
   → Recomendado mantener siempre.

6. CONSENTIMIENTO INFORMADO — muy completo y específico
   → Es uno de los mejores elementos defensivos del Dr. Zanardi.

7. AYUDANTE — siempre identificado con nombre

---

### ⚠️ GAPS DETECTADOS — AGREGAR EN DOCUMENTOS FUTUROS

**GAP 1 — HORA DE INICIO Y FIN (CAMPO OBLIGATORIO)**
Ningún parte tiene hora de inicio ni de fin del procedimiento.
→ Dec. 1089/2012 Art. 40: campo obligatorio.
→ Jarvis debe preguntar siempre la hora y agregarla.
→ Formato: "Hora de inicio: [HH:MM] / Hora de finalización: [HH:MM]"

**GAP 2 — MATRÍCULA PROVINCIAL (CAMPO OBLIGATORIO)**
Los partes no incluyen la matrícula provincial del cirujano.
→ Dec. 1089/2012: obligatorio en todo parte quirúrgico.
→ Agregar bajo la firma: "Mat. Prov. [número]"

**GAP 3 — PARCHE DURAL SIN MARCA/LOTE**
"Se coloca parche dural sintético" sin identificación del producto.
→ Jurisprudencia SCBA 2023: implantes deben tener marca, lote y serie.
→ Agregar: "Se coloca parche dural sintético [marca] (Lote: [X] / Serie: [X])"
→ Jarvis debe preguntar siempre marca y lote del parche dural.

**GAP 4 — HEMOSTÁTICO SIN MARCA/LOTE**
"Hemostasia completa con hemostáticos" sin identificación.
→ Mismo criterio que parche dural.
→ Agregar: "[Nombre del hemostático] (Lote: [X])"

**GAP 5 — EXAMEN FÍSICO MUY ESCUETO**
"Dolor ciático izquierdo invalidante y deficitario"
→ Para sostener la indicación quirúrgica es preferible agregar:
  - Signo de Lasègue: positivo a [X] grados
  - Reflejos: [osteotendinosos en miembro afectado]
  - Fuerza motora: [si hay déficit]
  - Sensibilidad: [territorio afectado]
→ No es obligatorio pero fortalece la indicación quirúrgica.

**GAP 6 — DESTINO POST-QUIRÚRGICO NO SIEMPRE CLARO**
Algunos partes no especifican destino al finalizar (sala, recuperación).
→ Agregar: "Paciente trasladado/a a sala de recuperación post-anestésica
   en condiciones estables."

**GAP 7 — NÚMERO DE HC NO SIEMPRE PRESENTE**
→ Dec. 1089/2012: número de HC obligatorio en el parte.
→ Jarvis debe solicitarlo siempre.

---

## INSTRUCCIONES PARA JARVIS

### Al generar una HC de HDL:
1. Usar estructura Zanardi exacta (arriba)
2. Completar [nivel], [localización], [lado], [raíz] con los datos del caso
3. Si el médico no dio examen físico detallado: dejar campo con
   "[COMPLETAR: Lasègue, reflejos, fuerza]" y alertar en amarillo
4. Siempre incluir referencia al consentimiento informado

### Al generar un parte quirúrgico de HDL:
1. Usar la Versión 2 (2026) como base — es la más reciente
2. Completar todos los campos variables
3. SIEMPRE preguntar:
   - Hora de inicio y fin → campo obligatorio
   - Marca y lote del parche dural → si se usó
   - Marca y lote del hemostático
   - Número de matrícula → si no está en memoria
4. Agregar hora y matrícula aunque el médico no las haya mencionado
5. Si el médico dice "parche dural": preguntar "¿Qué parche usaste? (marca y lote)"

### Frase de cierre del parte (mantener siempre):
"Procedimiento bien tolerado, sin complicaciones." (versión 2022)
O: "Procedimiento sin complicaciones." (versión 2026)
→ Usar la que el médico prefiera. Si hubo complicación: describir.

---

## VARIABLES POR CASO

Para cada cirugía de HDL, Jarvis debe completar:

NIVEL: L3/4 / L4/5 / L5/S1
LOCALIZACIÓN: posterolateral / paralateal / foraminal / central
LADO: derecha / izquierda
RAÍZ COMPROMETIDA: L4 / L5 / S1
HOMBRO IDENTIFICADO: L4 / L5 / S1
VÉRTEBRA SUPERIOR (para osteotomía): L3 / L4 / L5
ESPACIO INTERLAMINAR: L3/4 / L4/5 / L5/S1
AYUDANTE: [nombre según quién estaba ese día]
HORA INICIO: [HH:MM]
HORA FIN: [HH:MM]
PARCHE DURAL: [marca/lote/serie] o "no se utilizó"
HEMOSTÁTICO: [nombre/lote] — NSK drill siempre presente
CLÍNICA: Centro / La Pequeña Familia
