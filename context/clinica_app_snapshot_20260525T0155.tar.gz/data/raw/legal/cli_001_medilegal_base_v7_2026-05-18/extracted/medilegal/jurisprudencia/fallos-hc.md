# Jurisprudencia Verificada — Historia Clínica y Parte Quirúrgico
ultima_actualizacion: 2026-05-18
proxima_revision: 2026-08-18
fuentes: Microjuris, elDial, SAIJ
estado: VERIFICADO — todos los fallos son reales y citables

---

## PRINCIPIO RECTOR — DOCTRINA CONSOLIDADA

La historia clínica incompleta, deficiente o contradictoria
genera presunción en contra del médico y puede invertir
la carga de la prueba. Consolidado en CSJN y todas las Cámaras Civiles.

---

## FALLO 1 — Historia Clínica Incompleta como Presunción

CNCiv, Sala D — "R. C. M. c/ S. D. R. y otros s/ daños y perjuicios"
Fecha: 26/10/2018 | Cita: MJ-JU-M-115587-AR | Fuente: Microjuris

Doctrina:
"Las constancias de la historia clínica son un elemento valioso
en los juicios que se debate la responsabilidad del galeno o del
nosocomio, y sus imprecisiones y omisiones no deben redundar en
perjuicio del paciente."

"Las inconsistencias constituyen una presunción en contra del
propósito eximitorio perseguido por los accionados; la prueba
fehaciente de su falta de responsabilidad recae sobre los demandados."

Aplicación: Toda imprecisión u omisión en la HC opera contra el médico.

---

## FALLO 2 — CSJN — Principio base de inversión de carga

CSJN — Fallos 322:726
Citado reiteradamente por todos los tribunales inferiores.

Doctrina:
"El carácter incompleto y por tanto irregular de una historia clínica,
constituye presunción en contra de una pretensión eximitoria de la
responsabilidad médica, pues de otro modo el damnificado carecería
de la documentación necesaria para concurrir al proceso en igualdad
de posibilidades probatorias."

Aplicación: Fallo de la Corte Suprema. Citable directamente en cualquier proceso.

---

## FALLO 3 — Parte Quirúrgico. Omisiones críticas

CNCiv, Sala H — "N., V. A. S c/ Casa Hospital San Juan de Dios"
Expediente: 52.881/2016 | Fecha: 09/09/2022 | Fuente: elDial.com

Doctrina:
"Las graves omisiones en el parte quirúrgico y anestésico que no
permiten reconstruir los hechos tal como habrían acontecido, ni las
causas concretas, no pueden beneficiar a los accionados."

"El parte quirúrgico es el documento donde deben asentarse los
distintos actos médicos realizados para el tipo de intervención.
El médico que confeccionó un parte omisivo no puede luego
invocarlo en su defensa."

Aplicación: El parte debe permitir reconstruir el acto completo.
Si no puede reconstruirse, perjudica al médico.

---

## FALLO 4 — Cirugía de Columna — El parte como prueba central

CNCiv, Sala H — "V. L. M. N. y otros c/ E. R. J. s/ daños y perjuicios"
Fecha: 17/10/2018 | Fuente: Microjuris

Relevancia especial: involucró cirugía de columna lumbosacra.

Doctrina:
"El médico se encuentra en mejor posición para aportar
la prueba de su diligencia. Corresponde al médico demandado
acreditar que actuó correctamente cuando la documentación
médica que estaba a su cargo resulta incompleta."

El tribunal valoró el parte quirúrgico como elemento central
para reconstruir el acto operatorio. El parte completo fue
el elemento defensivo principal del médico demandado.

Aplicación: En cirugía de columna el parte completo es
la prueba principal de la diligencia del cirujano.

---

## FALLO 5 — Responsabilidad del Jefe de Equipo

CNCiv, Sala J — "V. M. C. c/ C. J. M. s/ daños y perjuicios"
Fecha: 10/10/2017 | Cita: MJ-JU-M-107976-AR | Fuente: Microjuris

Doctrina:
"El cirujano como jefe del equipo responde por la conducta
de sus componentes, cuyas actividades en aquel acto orienta
y coordina. Su deber no se limita a la actividad propia."

Aplicación: La firma del cirujano implica responsabilidad total
sobre todo lo que figura en el parte y todo lo ocurrido en quirófano.

---

## FALLO 6 — Consentimiento Informado Insuficiente

CNCiv, Sala M — "B. R. A. c/ B. J. P. y otros s/ daños y perjuicios"
Fecha: 28/06/2012 | Cita: MJ-JU-M-73881-AR | Fuente: Microjuris

Doctrina:
"La omisión del médico del deber de dar adecuada información
genera daño moral directo en tanto impidió al paciente adoptar
una decisión contando con información suficiente."

La omisión de información es daño autónomo, independiente del resultado.

Aplicación: En columna informar específicamente: lesión neurológica,
infección, recidiva, dolor residual. El consentimiento genérico no alcanza.

---

## FALLO 7 — Carga Dinámica de la Prueba. Fuente académica

SAIJ — Dossier Mala Praxis Médica, octubre 2022
Disponible: saij.gob.ar/docs-f/dossier-f/mala_praxis_medica.pdf

Doctrina:
"Cuando no existen elementos completos o suficientes la carga de
la prueba se coloca en cabeza de la parte que se encuentre en
mejores condiciones para producirla. El paciente puede tropezar
con dificultades para acceder a la verdad."

Aplicación: Si el parte está incompleto, el médico debe explicar
qué ocurrió. No es el paciente quien debe probar que algo salió mal.

---

## RESUMEN PARA JARVIS — 6 PRINCIPIOS VERIFICADOS

PRINCIPIO 1 — COMPLETITUD (CSJN Fallos 322:726)
  "Si no está escrito, no ocurrió."
  Todo campo vacío opera como presunción en contra.

PRINCIPIO 2 — RECONSTRUCCIÓN (CNCiv Sala H, 2022)
  El parte debe permitir reconstruir el acto completo.

PRINCIPIO 3 — NO BENEFICIO DE LA OMISIÓN (CNCiv Sala H, 2022)
  El parte omisivo no puede usarse como defensa posterior.

PRINCIPIO 4 — RESPONSABILIDAD DEL JEFE (CNCiv Sala J, 2017)
  La firma implica responsabilidad total del equipo y el parte.

PRINCIPIO 5 — CARGA DINÁMICA (SAIJ Dossier 2022)
  HC incompleta = médico debe probar su diligencia, no el paciente.

PRINCIPIO 6 — CONSENTIMIENTO AUTÓNOMO (CNCiv Sala M, 2012)
  La omisión de información es daño independiente del resultado.

---

NOTA DE ACTUALIZACIÓN
Archivo verificado en Microjuris, elDial y SAIJ al 18/05/2026.
Jarvis busca mensualmente en estas fuentes. Toda incorporación
nueva requiere aprobación del Dr. Zanardi antes de quedar activa.
