# Estilo y Referencias — Dr. Carlos Zanardi
# CIRUGÍAS ESPECIALES: CERVICAL / DORSAL / TUMORAL / NEUROVASCULAR
ultima_actualizacion: 2026-05-18
basado_en: 20 documentos reales analizados
cubre: Fijación cervical posterior, fijación dorsal, descompresión multinivel,
       cirugía tumoral/metastásica, descompresión neurovascular, fractura traumática

---

## CATEGORÍA 1 — FIJACIÓN CERVICAL POSTERIOR + DESCOMPRESIÓN MEDULAR

### Diagnósticos habituales
- "Canal estrecho cervical severo C[X/Y]. Mielopatía."
- "Canal estrecho cervical severo C[X/Y]. Mielomalacia."
- "Canal estrecho cervical C[X/Y] con compresión medular"

### Operación
- "Fijación C[X/Y] con tornillos de masa lateral. Descompresión medular."
- "Laminectomía descompresiva. Fijación C[X/Y]. Monitoreo electrofisiológico intraoperatorio."

### Texto del parte — Fijación cervical posterior

```
Decúbito prono bajo anestesia general. Protección de los puntos de apoyo.
Asepsia y antisepsia de región cervical posterior. Colocación de campos estériles.
Electrofisiólogo corrobora la indemnidad medular, que se conserva durante el
posicionamiento del paciente.
Incisión lineal de línea media [C2/7 o según niveles].
Colocación de retractores autoestáticos.
Con uso de monopolar y siguiendo el plano avascular del ligamento nucal,
se realiza la disección subperióstica de los músculos cervicales posteriores.
Se reposicionan los retractores. Hemostasia completa.
Se exponen las masas laterales desde C[X] a C[Y] bilateralmente.
Con uso de drill de alta velocidad, se colocan tornillos de masa lateral,
bilateralmente en esos niveles.
Se conserva la inserción muscular en la espinosa de C2.
Se fija con una barra unilateralmente, para comenzar con laminectomía y
descompresión medular amplia.
Durante todo el procedimiento no se observan descensos de los potenciales
sensitivos ni motores.
Luego de la laminectomía se coloca la barra del otro lado.
La médula queda pulsátil.
Se colocan los chips de hueso con agregado de sustituto para artrodesis vertebral.
Hemostasia completa con hemostáticos.
Cierre por planos. Procedimiento sin complicaciones.
```

### ✅ Elemento crítico — MONITOREO ELECTROFISIOLÓGICO
SIEMPRE documentar en cirugía cervical y dorsal:
"Durante todo el procedimiento no se observan descensos de los potenciales
sensitivos ni motores."
O si hubo cambios: descripción detallada y conducta adoptada.

→ Jurisprudencia: la ausencia de monitoreo o su falta de documentación
  en cirugía con riesgo medular es punto crítico en litigios por déficit neurológico.

### Consentimiento informado cervical — específico
El CI cervical del Dr. Zanardi menciona expresamente:
- Empeoramiento neurológico (parálisis de 4 miembros)
- Parálisis de hombros y flexión de brazos (C5 palsy): "incidencia de 3 en 100 casos"
- Inestabilidad en niveles adyacentes
- Riesgo de muerte
- Frase honesta: "No se puede asegurar que va a mejorar neurológicamente"
→ Mantener este nivel de especificidad.

---

## CATEGORÍA 2 — FIJACIÓN DORSAL + DESCOMPRESIÓN MEDULAR (fracturas patológicas)

### Contexto habitual
Fractura patológica por metástasis (CA mama, colorectal, otras).
Niveles más frecuentes: T10 (más común en tus casos).

### Diagnósticos
- "Fractura patológica [T10] con compresión medular severa"
- "Inestabilidad [T10] por fractura patológica. Compresión medular."

### Operación
- "Descompresión medular y fijación quirúrgica con técnica MISS"
- "Fijación T[X/Y] mínimamente invasiva. Descompresión medular."

### Texto del parte — Fijación dorsal MISS

```
Decúbito prono bajo anestesia general. Protección de los puntos de apoyo.
Asepsia y antisepsia de región dorsal. Colocación de campos estériles.
Marcación radioscópica del nivel a tratar [T8/9 y T11/12 o según caso].
Incisiones parasagitales bilaterales de 3 cm.
Disección por planos para colocar el sistema de retracción autoestático tubular.
Con el uso de monopolar se disecan los sitios de ingreso de tornillos pediculares
en [niveles] bilateralmente.
[Si nivel comprometido por tumor: "En [nivel], dado que el cuerpo estaba invadido
por tumor, no se colocan tornillos pediculares en ese nivel."]
[Si mal amarre: "En [nivel] no se logra buen amarre; luego de colocados se decide
retirarlos."]
En [nivel fracturado], se aborda hacia medial desde la faceta [X/Y] del lado derecho.
Con drill de alta velocidad, se comienza la laminectomía de [nivel] para descomprimir
la médula [y tomar muestras para anatomía patológica].
[Pediculectomía si aplica: "Pediculectomía [nivel] derecha."]
Con técnica "over the top" se libera también el saco hacia el lado contralateral.
El saco dural queda libre y pulsátil.
Hemostasia completa con bipolar y hemostático.
Se colocan las barras [en ligera cifosis/en lordosis] acorde a la anatomía de la región.
Chips de hueso y sustituto que se colocan laterales a las barras.
Cierre por planos. Procedimiento sin complicaciones.
```

### Elementos críticos — Cirugía tumoral/metastásica

1. SIEMPRE enviar muestras a anatomía patológica
   "Se toman muestras que se envían para anatomía patológica."

2. Si hay cultivos (discitis u origen infeccioso):
   "Muestras enviadas a bacteriología para cultivos aerobios, anaerobios y micológico."

3. Documentar lo que NO se pudo hacer y por qué:
   "En T8 no se logra buen amarre; se decide retirar los tornillos."
   "Se intenta cifoplastia en [nivel], que se suspende por fuga de cemento."
   → Estas frases son defensivas, no incriminatorias.

4. Comunicación con oncología en postoperatorio:
   "Se interconsulta con servicio de oncología para seguimiento conjunto postoperatorio."

5. Objetivos del CI deben ser realistas y específicos:
   "Se informa sobre los objetivos mecánicos de la cirugía (fijación y descompresión
   radicular) y la necesidad de continuar con el tratamiento oncológico."

---

## CATEGORÍA 3 — DESCOMPRESIÓN MULTINIVEL SIN FIJACIÓN (Recalibraje puro)

### Cuándo se usa
Canal estrecho multinivel estable (sin inestabilidad mecánica).
El Dr. Zanardi documenta explícitamente la decisión:
"No tiene clínica de inestabilidad mecánica. Se explica la eventualidad de evolución
con inestabilidad y necesidad de fijación posterior."
→ Esta frase es excelente: protege ante eventual reoperación por fijación tardía.

### Texto del parte — Recalibraje multinivel

```
Decúbito prono bajo anestesia general. Asepsia y antisepsia de región lumbar.
Colocación de campos estériles. Marcación radioscópica del nivel a tratar
[L2/3, L3/4 y L4/5].
Incisión lineal de [7] cm. Colocación de sistema de dilatación progresiva hasta
colocar tubo definitivo de 10 cm de largo por 18 mm de diámetro, que se fija a
camilla con brazo articulado. Se coloca el microscopio quirúrgico.
Flavectomía [niveles], con hemilaminotomía inferior.
Desde el lado derecho se liberan ambos recesos laterales con técnica "over the top",
logrando una satisfactoria liberación del saco lumbar y las raíces.
Hemostasia completa con hemostáticos. Cierre por planos. Procedimiento sin complicaciones.
```

---

## CATEGORÍA 4 — FIJACIÓN + DESCOMPRESIÓN POR FRACTURA TRAUMÁTICA

### Diferencias con fractura patológica
- Paciente generalmente más joven
- Antecedente traumático documentado
- Puede requerir gesto anterior diferido (documentar en CI)

### Elemento crítico — Planificación diferida
En Zambelli, el Dr. Zanardi documenta:
"Se le explica la potencial necesidad de un gesto anterior en caso de evolución cifótica.
Se planifica colocación de tornillos cortos para no tener dificultad técnica ante la
eventualidad de una corpectomía diferida."
→ Esta anticipación en el CI y en la HC es excelente práctica médico-legal.

### Texto del parte — Fijación por fractura traumática
Similar a fijación MISS estándar con estas diferencias:
- Documentar el fragmento en canal y su manejo
- Verificar y documentar descompresión radicular específica
- "El saco y las raíces pasantes y salientes quedan pulsátiles y libres"
- TAC control postoperatorio → documentar en evolución

---

## CATEGORÍA 5 — DESCOMPRESIÓN NEUROVASCULAR (Neuralgia del Trigémino)

### Diagnóstico habitual
"Neuralgia del trigémino [derecha/izquierda]. Distribución [V2/V3 o V1/2]."
"Conflicto neurovascular con [arteria cerebelosa superior/PICA]."

### Operación
"Descompresión neurovascular microquirúrgica [derecha/izquierda]"

### Texto del parte — Descompresión neurovascular

```
Paciente en decúbito lateral [izquierdo/derecho] con la mastoides al cenit.
Asepsia y antisepsia de piel en la región craneal.
Asepsia y antisepsia de región lumbar para colocación de drenaje lumbar continuo
que permita la evacuación de LCR y descomprimir la fosa posterior.
Colocación de campos estériles.
Incisión en herradura centrada en el Asterión del lado [derecho/izquierdo].
Colgajo miocutáneo. Craneotomía de [20] mm de diámetro usando drill de alta velocidad.
Exposición parcial de los senos transverso y sigmoideo.
La duramadre está relajada. Se abre.
El cerebelo permite acceder sin usar espátulas.
Se sigue el tentorio hasta localizar la vena petrosa superior.
Anterior a ella, se observa el trigémino.
Conflictuado por [arteria cerebelosa superior/PICA/etc.].
Se diseca con maniobras microquirúrgicas. Se liberan las adherencias aracnoidales.
Se separa el nervio de la arteria.
Se coloca una pieza de teflón entre ambos para mantener la separación.
Hemostasia completa.
Se cierra la duramadre y se reponen los chips de hueso para la plástica de cráneo.
Cierre del colgajo miocutáneo por planos.
Procedimiento sin complicaciones. Se retira el drenaje lumbar.
```

---

## CATEGORÍA 6 — EPICRISIS (nuevo formato detectado)

El Dr. Zanardi usa también una Epicrisis en lugar de HC completa en algunos casos.
Formato tabla detectado en caso Baccarini:

Campos de la epicrisis:
- Nombre y apellido / Edad / Obra social
- Fecha de ingreso y egreso
- Diagnóstico principal
- Antecedentes personales
- RMN/estudios
- Tratamiento realizado
- Evolución
- Complicaciones (Sí/No)
- Indicaciones al alta
- Datos de contacto del equipo

→ Jarvis debe reconocer este formato y poder generarlo cuando se indique.

---

## NOTAS SOBRE ROLES VARIABLES

En algunos casos el Dr. Zanardi figura como AYUDANTE (no como cirujano principal):
- Zambelli: CIRUJANO Maximiliano Gimenez / AYUDANTE Carlos Zanardi
- Zibana: CIRUJANO Nelson Picard / AYUDANTE Carlos Zanardi

Jarvis debe preguntar siempre:
"¿Fuiste cirujano principal o ayudante en esta cirugía?"

---

## GAPS CRÍTICOS — CERVICAL Y DORSAL

**GAP 1 — TORNILLOS DE MASA LATERAL SIN TRAZABILIDAD**
"Se colocan tornillos de masa lateral bilateralmente" sin marca/lote/dimensiones.
→ Mismo problema que tornillos pediculares lumbares.
→ Solución: [marca] / modelo / longitud [X] mm / diámetro / Lote [X]

**GAP 2 — TAC POST-OP NO SIEMPRE DOCUMENTADO**
Torres: "TAC control para verificar la correcta colocación del implante" → bien.
Otros casos cervicales: no se documenta control radiológico.
→ En cirugía cervical e instrumental dorsal, TAC post-op debería quedar registrado
  siempre en la evolución.

**GAP 3 — PROVEEDOR DE IMPLANTES SOLO EN UN CASO**
Alarcon: "Sistema de artrodesis provisto por Ortopedia Alemana" → bien.
Resto: sin identificación del proveedor.
→ El proveedor + número de catálogo permite localizar el lote ante recall.

**GAP 4 — TEFLÓN SIN IDENTIFICACIÓN (descompresión neurovascular)**
"Se coloca una pieza de teflón" sin especificación del producto.
→ Agregar: "[marca del teflón microquirúrgico] / referencia del producto"

---

## INSTRUCCIONES ESPECIALES PARA JARVIS

### Cervical: preguntar SIEMPRE
"¿Se realizó monitoreo electrofisiológico?
 Si sí: ¿los potenciales se mantuvieron estables durante todo el procedimiento?"

### Dorsal/tumoral: preguntar SIEMPRE
"¿Se enviaron muestras a anatomía patológica?
 ¿Se envió material a cultivo microbiológico?"

### Neurovascular: preguntar SIEMPRE
"¿Se usó drenaje lumbar? ¿Cuándo se retiró?
 ¿Qué material se usó para la descompresión (teflón/esponja/etc.)?"

### Epicrisis vs HC completa:
Si el médico dice "haceme una epicrisis" → usar formato tabla Baccarini.
Si dice "haceme la HC" → usar formato HC estándar.
