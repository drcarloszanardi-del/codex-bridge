# Base Médico-Legal — MediLegal Assistant
ultima_actualizacion: 2026-05-18
version: 1.0
responsable: Dr. Zanardi
estado: activo

## Propósito
Base de conocimiento médico-legal para generación y validación
de historias clínicas y partes quirúrgicos en Argentina.
Todo documento generado con esta base es responsabilidad
final del médico firmante.

## Estructura

### /leyes
- ley-17132.md          → Ejercicio de la medicina
- ley-26529.md          → Derechos del Paciente / HC
- decreto-1089-2012.md  → Reglamentación Ley 26.529
- ley-25326.md          → Protección de datos personales
- ley-25506.md          → Firma digital
- ccyc-responsabilidad.md → Código Civil y Comercial
- codigo-penal.md       → Arts. relevantes mala praxis

### /jurisprudencia
- fallos-hc.md          → Fallos sobre historia clínica
- fallos-parte.md       → Fallos sobre parte quirúrgico
- fallos-columna.md     → Fallos específicos neurocirugía
- fallos-consentimiento.md → Consentimiento informado

### /campos-obligatorios
- hc-campos.md          → Campos obligatorios historia clínica
- parte-campos.md       → Campos obligatorios parte quirúrgico
- anestesia-campos.md   → Campos obligatorios parte anestesia

### /validacion
- checklist-hc.md       → Checklist validación HC
- checklist-parte.md    → Checklist validación parte
- frases-prohibidas.md  → Lenguaje vago con riesgo legal
- frases-correctas.md   → Lenguaje técnico-legal correcto

### /patologias
- columna-lumbar.md     → Específico cirugía columna lumbar
- columna-cervical.md   → Específico cirugía columna cervical

## Instrucción para Jarvis
Antes de generar cualquier HC o parte quirúrgico:
1. Leer campos-obligatorios/ según tipo de documento
2. Leer patologias/ según la intervención específica
3. Leer frases-prohibidas.md y evitarlas
4. Al finalizar, validar contra checklist correspondiente
5. Nunca cerrar un documento con campos [COMPLETAR] sin alertar al médico
