# Estilo y Referencias — Dr. Carlos Zanardi
# LAMINOPLASTIA CERVICAL EXPANSIVA
ultima_actualizacion: 2026-05-18
basado_en: 8 casos clínicos + capítulo académico de autoría del Dr. Zanardi
            (Mazza Elizalde D, Zanardi C. "Laminoplastia cervical expansiva.
             Indicaciones, técnica y complicaciones.")
tecnica_preferida: Open-door (Hirabayashi)

---

## DIAGNÓSTICOS HABITUALES

- "Canal estrecho cervical sintomático. Mielopatía."
- "Canal estrecho cervical severo C[X/Y]. Mielomalacia."
- "Canal estrecho cervical C[X/Y] con compresión medular y radicular."
- "Canal estrecho cervical multisegmentario. Mielopatía degenerativa."

---

## OPERACIÓN — NOMENCLATURA

- "Laminoplastia cervical expansiva."
- "Laminoplastia C[X/Y] con técnica open door."
- "Laminoplastia cervical expansiva. Monitoreo electrofisiológico intraoperatorio."

---

## TEXTO DEL PARTE — VERSIÓN COMPLETA (formato actual 2024-2026)

```
Decúbito prono bajo anestesia general. Cabeza posicionada sobre cabezal blando
con globos oculares libres de presión. Asepsia y antisepsia de región cervical posterior.
Colocación de campos estériles.
[Si monitoreo: "Electrofisiólogo registra potenciales basales con el paciente en
decúbito supino previo al posicionamiento. Se obtiene segundo registro una vez
posicionado en decúbito ventral, sin modificaciones de los potenciales."]
Marcación radioscópica del nivel a tratar C[X]/C[Y].
Incisión lineal de [8] cm de línea media posterior.
Disección por planos. Colocación de retractores autoestáticos.
Legrado subperióstico de los músculos paraespinales.
Exposición de las láminas desde C[X] a C[Y],
preservando las inserciones musculares en C2 y C7.
Se identifican los espacios a tratar mediante control radioscópico.
Se comienza la osteotomía en la unión facelominar del lado [derecho/izquierdo]
desde C[X] a C[Y] con kerrison de 2 mm.
Del lado [izquierdo/derecho] se realiza una canaleta en tallo verde con drill
de alta velocidad (NSK), que actúa como bisagra.
[Si usando distractor: "Con asistencia de distractor de Cloward se realiza
la apertura controlada de la lámina hasta lograr expansión adecuada del canal."]
Se mantiene la apertura del conducto raquídeo con miniplacas de titanio
[5 orificios / configuración en Z] moldeadas, que se fijan en las láminas y las facetas
con tornillos autoperforantes y autoroscantes.
La médula queda libre y pulsátil.
[Si monitoreo: "Los potenciales evocados no sufren modificaciones durante
el procedimiento quirúrgico."]
Hemostasia completa con hemostáticos.
Se retiran los retractores. Cierre por planos.
Procedimiento sin complicaciones.
```

---

## VERSIÓN ABREVIADA (formato antiguo 2021-2022 — mantener actualizado)

```
Paciente en decúbito ventral. Intubado en ARM. Marcación radioscópica del nivel
a tratar. Asepsia y antisepsia de piel. Colocación de campos estériles.
Incisión cervical posterior medial. Disección por planos.
Se identifican los espacios a tratar radioscópicamente.
Osteotomía en la unión facelominar del lado derecho desde C[X] a C[Y]
con kerrison de 2 mm.
Del lado izquierdo se realiza canaleta en tallo verde con drill de alta velocidad (NSK).
Se visualiza la duramadre, libre y pulsátil. Hemostasia completa con hemostático.
Se mantiene la apertura del conducto raquídeo con miniplacas de 5 orificios moldeadas
que se fijan en las láminas y las facetas.
Hemostasia completa. Cierre por planos. Procedimiento sin complicaciones.
```

---

## EVOLUCIÓN — ESTILO ZANARDI

**Día 0 (inmediato):**
"Postoperatorio de laminoplastia cervical expansiva.
[Mejoro mucho lo neurológico. Movilidad de los brazos y las piernas.] /
[Mueve los 4 miembros. Pasa a sala general para control postoperatorio.]
Se dejan indicaciones. Control evolutivo."

**Día 1 (alta):**
"[DD de mes de AAAA]. Nc. Paciente que evoluciona favorablemente.
RX/TAC control sin complicaciones.
En condiciones de externación por neurocirugía.
Pautas de alarma y control por consultorios externos, mañana a las 8 hs."

---

## CONOCIMIENTO TÉCNICO PROPIO DEL DR. ZANARDI
(extraído del capítulo académico de su autoría)

### Elección del lado de apertura
"El sitio de apertura se elige según la lateralización de los síntomas y suele
corresponder al hemicuerpo más sintomático. Si la sintomatología es simétrica,
se prefiere realizar la apertura del lado no dominante (en pacientes diestros:
lado izquierdo), dado que una eventual parálisis de C5, más frecuente del lado
de mayor desplazamiento medular, no comprometa el miembro superior más funcional."

Aplicación para Jarvis: cuando el médico no indique el lado, preguntar:
"¿La sintomatología es lateralizada? ¿Cuál es el lado dominante del paciente?"

### Preservación de C2 y C7
"Preservar las inserciones musculares en C2 (músculo semiespinoso) y C7 es
fundamental para prevenir cifotización postoperatoria y dolor axial."
→ Siempre documentar en el parte: "preservando las inserciones musculares en C2 y C7"

### Monitoreo electrofisiológico
El Dr. Zanardi utiliza monitoreo multimodal de rutina:
- Potenciales evocados somatosensitivos y motores
- Registro basal PREVIO al posicionamiento (decúbito supino)
- Segundo registro TRAS el posicionamiento (decúbito ventral)
  → En mielomalacia significativa el posicionamiento puede modificar los potenciales
- Monitoreo continuo durante todo el procedimiento

Frases para el parte:
"Electrofisiólogo registra potenciales basales previo al posicionamiento.
Se obtiene segundo registro tras posicionamiento, sin modificaciones de los potenciales."
"Los potenciales evocados no sufren modificaciones durante el procedimiento quirúrgico."
Si hubo cambio: "Durante el [tiempo/maniobra], se observó [descripción del cambio].
Se adoptó la siguiente conducta: [descripción]. Los potenciales se recuperaron a [valor]."

### Complicación C5 palsy — documentar en CI
"La parálisis de C5 tiene una incidencia del 5 al 17%. Generalmente es transitoria
(recuperación en promedio 4,1 meses). Es más frecuente del lado de apertura completa."
→ Debe figurar en el CI: "Parálisis o debilidad del hombro y flexión de brazos
(C5): incidencia de 3-5 en 100 casos, habitualmente transitoria."

---

## ANÁLISIS MÉDICO-LEGAL — FORTALEZAS Y GAPS

### ✅ LO QUE HACE BIEN

1. MONITOREO ELECTROFISIOLÓGICO — presente en casos recientes (Frediano 2026, Massa 2025)
   → Protección fundamental en cirugía con riesgo medular

2. VERIFICACIÓN RADIOSCÓPICA DEL NIVEL — siempre presente
   → Evita el error de nivel quirúrgico

3. ESTADO DE LA MÉDULA AL FINALIZAR — siempre documentado
   "La médula queda libre y pulsátil"
   → Verifica que la descompresión fue efectiva

4. EVOLUCIÓN NEUROLÓGICA DOCUMENTADA — siempre
   "Mejoro mucho lo neurológico. Movilidad de los brazos y las piernas."
   "Mueve los 4 miembros."

5. TAC/RX CONTROL — mencionado en casos recientes (Massa 2025)
   → Verificación objetiva de implantes

---

### ⚠️ GAPS DETECTADOS

**GAP CRÍTICO 1 — MINIPLACAS SIN IDENTIFICACIÓN**
Todos los partes: "miniplacas de 5 orificios moldeadas" sin marca, dimensiones, lote.
→ Las miniplacas son implantes metálicos permanentes → misma obligación de
  trazabilidad que tornillos y PLIF.
→ Agregar: "[marca] / modelo / tamaño / Lote [X] — [X] miniplacas colocadas"

**GAP CRÍTICO 2 — TORNILLOS AUTOPERFORANTES SIN ESPECIFICACIÓN**
"tornillos autoperforantes y autoroscantes" sin dimensiones ni lote.
→ Agregar: "[marca] / diámetro [X] mm / longitud [X] mm / Lote [X]"

**GAP 3 — PROVEEDOR SOLO COMO NOTA AL PIE (no integrado)**
Los casos 2021-2022 anotan "#Ortopedia: Medical Implant" o "#Ortopedia: Química Mar"
como comentario al margen, no dentro del cuerpo del parte.
→ El proveedor debe integrarse en el texto del parte con lote verificable.

**GAP 4 — MONITOREO AUSENTE EN CASOS ANTERIORES (2021-2022)**
Contardi, Portilla, Actis, Nolt, Pereyra: sin mención de monitoreo.
→ En casos nuevos siempre documentar.

**GAP 5 — HORA DE INICIO Y FIN**
Ningún parte de laminoplastia tiene horario.
→ Campo obligatorio Dec. 1089/2012.

**GAP 6 — MATRÍCULA PROVINCIAL**
Sin matrícula en ningún parte.

**GAP 7 — EN MIELOMALACIA: POTENCIALES CON EL POSICIONAMIENTO**
El capítulo propio del Dr. Zanardi indica que en mielomalacia significativa
el posicionamiento puede modificar los potenciales. Esto nunca está documentado
en el parte aunque es clínicamente relevante.
→ Agregar: "Se obtiene registro tras posicionamiento sin modificaciones" o
  con descripción si las hubo.

---

## INSTRUCCIONES PARA JARVIS

### Preguntar SIEMPRE en laminoplastia:
1. "¿La sintomatología era lateralizada? ¿Cuál fue el lado de apertura completa?"
2. "¿Se realizó monitoreo electrofisiológico? ¿Los potenciales se mantuvieron estables?"
3. "¿El posicionamiento generó cambios en los potenciales?"
4. "¿Qué miniplacas usaste? (marca, modelo, tamaño, lote)"
5. "¿Qué tornillos usaste? (marca, dimensiones, lote)"
6. Hora de inicio y fin
7. Nombre del instrumentador/a (aparece en algunos partes: Laura, Eugenia)

### Variables por caso:
NIVELES: C3/7 (más frecuente) / C3/6 / C4/7 / según caso
LADO APERTURA COMPLETA: derecho (sintomático habitual) / izquierdo (no dominante)
LADO BISAGRA: opuesto al de apertura
MINIPLACAS: [marca] / [modelo] / [tamaño] / Lote [X]
TORNILLOS: [marca] / [diámetro] / [longitud] / Lote [X]
MONITOREO: realizado/no realizado + resultado
CLINICA: Centro / La Pequeña Familia / Hospital Interzonal Junín

### Frase que no puede faltar:
"La médula queda libre y pulsátil."
"Los potenciales evocados no sufren modificaciones durante el procedimiento quirúrgico."
