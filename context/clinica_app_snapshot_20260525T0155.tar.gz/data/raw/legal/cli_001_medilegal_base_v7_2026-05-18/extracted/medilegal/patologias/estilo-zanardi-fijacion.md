# Estilo y Referencias — Dr. Carlos Zanardi
# FIJACIÓN LUMBAR CIRCUNFERENCIAL MISS
ultima_actualizacion: 2026-05-18
basado_en: 20 documentos reales analizados
procedimiento: Fijación/artrodesis lumbar por vía mínimamente invasiva (MISS)

---

## VARIANTES DE LA OPERACIÓN — NOMENCLATURA HABITUAL

Según el caso, el Dr. Zanardi usa estas denominaciones:

- "Fijación circunferencial [niveles] MISS (mínimamente invasiva)"
- "Discectomía y fijación circunferencial [nivel]"
- "Fijación y descompresión indirecta [niveles] MISS"
- "Recalibraje y fijación lumbar MISS [niveles] circunferencial"
- "Cirugía de revisión. Extracción del material protésico y fijación [nivel]"
- "Toilette del espacio discal + fijación circunferencial" (caso de discitis)

---

## DIAGNÓSTICOS HABITUALES — FIJACIÓN

Más frecuentes en tus casos:

1. "Canal estrecho [nivel] por listesis degenerativa inestable"
2. "Inestabilidad degenerativa [nivel]"
3. "Canal estrecho [nivel] asociado a listesis degenerativa inestable"
4. "Inestabilidad lumbar [nivel] degenerativa"
5. "Canal estrecho [nivel] inestable asociado a listesis lítica de alto grado"
6. "Inestabilidad lumbosacra" (post-laminectomía)
7. "Canal estrecho [nivel] inestable complicado con discitis hematógena" (caso especial)

---

## TEXTO DEL PARTE — VERSIÓN ESTÁNDAR MISS (más frecuente)

Base extraída de tus casos más recientes (2024-2026):

```
Decúbito prono bajo anestesia general. Asepsia y antisepsia de región lumbar.
Colocación de campos estériles. Marcación radioscópica del nivel a tratar [nivel]
en [una / dos] incisiones parasagitales de [3 / 4 / 5] cm [cada una / bilateral].
Incisiones lineales. Colocación de sistema de dilatación progresiva hasta colocar
tubo definitivo de [10 cm de largo por 18 mm / 10 cm por 22 mm / 8 cm por 20 mm]
de diámetro, que se fija a camilla con brazo articulado.
Por vía intermuscular se colocan tornillos en [vértebras] bilateralmente.
[Si osteoporosis: Tornillos canulados y fenestrados a través de los cuales se
inyecta polimetilmetacrilato para realizar aumentación de los mismos.]
Por el triángulo de Kambin, desde el lado [derecho/izquierdo], con mínima
osteotomía de la faceta articular superior de [vértebra inferior] [lado],
se aborda el disco [nivel]. Discectomía completa y luego colocación de
[PLIF / caja PLIF] de titanio trabecular de [8/10/12] mm de alto, relleno con
injerto de hueso y sustituto óseo.
Se logra una correcta descompresión [indirecta / directa e indirecta].
Las raíces pasantes y salientes del segmento quedan libres y pulsátiles.
[Si parche dural: Se coloca parche dural [indicación específica].]
Hemostasia completa con hemostáticos. Se retiran los retractores.
Cierre por planos. Procedimiento sin complicaciones.
```

---

## VARIANTES TÉCNICAS DETECTADAS

### Variante A — Descompresión directa adicional (recalibraje)
Cuando además de la fijación hay descompresión directa del canal:

```
Se reposiciona el tubo y se aborda el espacio [nivel] desde [lado].
Se realiza, bajo microscopio quirúrgico, la flavectomia completa del segmento [nivel],
para visualizar los nervios pasantes y salientes, usando técnica "over the top".
Identificación de las raíces pasantes y salientes del segmento vertebral,
homo y contralaterales. Se reseca fragmento de faceta del lado [lado] que
comprimía severamente el nervio pasante. Liberación radicular completa.
```

### Variante B — Tornillos con cementación (osteoporosis)
```
Tornillos canulados y fenestrados a través de los cuales se inyecta
polimetilmetacrilato para realizar aumentación de los mismos.
[Si hubo fuga: Procedimiento de aumentación que se suspende por fuga del PMMA
por fuera del cuerpo vertebral. Se continúa con la técnica habitual.]
```

### Variante C — Cirugía de revisión (extracción de material previo)
```
Por vía intermuscular se retiran los tornillos colocados en [nivel] bilateralmente
y los de [nivel], previo retiro de las barras. Se colocan tornillos nuevos en
[nivel] bilateralmente. [Justificación si no se coloca nueva caja: "Dado que las
facetas están artrodesadas no se coloca una caja PLIF adicional en el espacio [nivel],
ya que tiene colocada una caja en la cirugía nativa."]
```

### Variante D — Discitis / Infección (caso especial — Tello)
```
Se aborda el triángulo de Kambin y se realiza discectomía completa,
con envío de material a bacteriología para cultivos y también para anatomía patológica.
Lavado profuso de la logia operatoria.
[NOTA: en estos casos SIEMPRE enviar muestras a cultivo bacteriológico y micológico]
```

### Variante E — Multilevel (dos o más niveles)
```
Marcación radioscópica de [nivel1] y [nivel2] en [dos] incisiones parasagitales
de [X] cm cada una. [...]
Colocación de PLIF de [X] mm de alto en [nivel1] y de [Y] mm de alto en [nivel2].
Se logra una correcta alineación sagital y coronal.
Las cajas se implantan bien anterior en el espacio discal para maximizar la lordosis.
```

---

## ANÁLISIS MÉDICO-LEGAL — FORTALEZAS Y GAPS

### ✅ LO QUE HACE BIEN

1. GUÍA RADIOSCÓPICA — siempre presente para colocación de tornillos y verificación del nivel

2. RAÍCES NERVIOSAS — siempre verificadas al finalizar
   "Las raíces pasantes y salientes del segmento quedan libres y pulsátiles"
   → Esto es fundamental. Demuestra verificación de la descompresión.

3. DOCUMENTACIÓN DE COMPLICACIONES INTRAOPERATORIAS HONESTAS
   Gonzalez Nelba: "Procedimiento muy dificultoso. Se intentó realizar procedimiento
   de aumentación que se suspende por fuga del PMMA por fuera del cuerpo vertebral."
   → MUY BIEN. Documentar lo que ocurrió, aunque sea adverso, es la mejor defensa.

4. JUSTIFICACIÓN DE DECISIONES TÉCNICAS
   Fernandez: "Dado que las facetas están artrodesadas no se coloca una caja PLIF más"
   → La explicación de por qué NO se hizo algo es tan importante como lo que sí se hizo.

5. CULTIVOS EN CASO DE INFECCIÓN (Tello)
   → Excelente. Muestras a bacteriología y anatomía patológica documentadas.

---

### 🔴 GAPS CRÍTICOS — FIJACIÓN (más graves que en HDL)

**GAP CRÍTICO 1 — IMPLANTES SIN IDENTIFICACIÓN COMPLETA**
Este es el gap más importante de toda la fijación.

Encontrado en tus partes:
- "Se colocan tornillos en L4 y L5" → SIN marca, modelo, diámetro, longitud, lote
- "Se coloca PLIF de titanio trabecular de 10 mm de alto" → SIN marca, lote, serie
- "Se colocan las barras" → SIN especificación alguna

Lo que DEBE decir (por ANMAT y jurisprudencia):
```
Tornillos pediculares: [marca] / modelo [X] / diámetro [6.5] mm / longitud [45] mm /
Lote: [número] — 4 unidades en L4 y L5 bilateralmente.

Caja intersomática PLIF: [marca] / modelo [X] / altura [10] mm / ancho [X] mm /
longitud [X] mm / Lote: [número] / Serie: [número] — 1 unidad en espacio [nivel].

Barras: [marca] / diámetro [5.5] mm / longitud [X] mm / material: titanio /
Lote: [número] — 2 unidades.

Conectores (inners/tulipas): incluidos en el sistema [marca].
```

ANMAT Disposición 2318/02 y modificatorias exigen trazabilidad completa
de todo implante ortopédico/neuroquirúrgico. El lote permite rastrear
el implante ante falla del material, infección por contaminación
o recall del fabricante.

**GAP CRÍTICO 2 — HORA DE INICIO Y FIN (obligatorio)**
Ningún parte de fijación tiene horario.
→ Especialmente importante en cirugías largas: un tiempo quirúrgico de 4 horas
sin registro puede generar preguntas sobre anestesia y complicaciones.

**GAP 3 — PARCHE DURAL SIN MARCA/LOTE**
Presente en varios casos (Caballero, Aquilano, Martin, Romero).
Mismo problema que en HDL.

**GAP 4 — MATRÍCULA PROVINCIAL**
No figura en ningún parte.

**GAP 5 — PÉRDIDA HEMÁTICA**
En cirugías de fijación la pérdida puede ser significativa.
Recomendado: "Pérdida hemática estimada: [X] ml."

---

## INSTRUCCIONES PARA JARVIS

### Al generar un parte de FIJACIÓN:

PASO 1 — Identificar variante:
¿Es MISS estándar / con descompresión adicional / revisión / discitis / multilevel?

PASO 2 — Completar variables obligatorias:
- Nivel(es) operado(s)
- Lado de abordaje (triángulo de Kambin)
- Si hay osteoporosis: ¿tornillos fenestrados con PMMA?
- Si hay descompresión directa adicional: ¿qué nivel?
- Si es revisión: ¿qué material se retira?

PASO 3 — PREGUNTAR SIEMPRE (implantes):
"Para completar correctamente el parte con trazabilidad de implantes:
 ¿Qué tornillos usaste? (marca, modelo, diámetro y longitud)
 ¿Qué PLIF? (marca, altura, lote y serie)
 ¿Qué barras? (marca, diámetro)
 ¿Usaste parche dural? (marca y lote)
 ¿Qué hemostático? (nombre y lote)"

PASO 4 — Hora de inicio y fin → SIEMPRE preguntar

PASO 5 — Verificar que incluya:
□ Guía radioscópica confirmada
□ Raíces verificadas libres y pulsátiles
□ Si hubo evento adverso: documentado honestamente
□ Si no se hizo algo esperado: justificación escrita

### Frases que NUNCA deben faltar en fijación:
"Bajo guía radioscópica..."
"Las raíces pasantes y salientes del segmento quedan libres y pulsátiles."
"Procedimiento sin complicaciones." (o descripción honesta si las hubo)

---

## CASOS ESPECIALES — DOCUMENTACIÓN DIFERENCIAL

### Osteoporosis + PMMA
Agregar antes de la cirugía en HC:
"Paciente con diagnóstico de osteoporosis. En tratamiento endocrinológico/
con bifosfonatos. Densitometría: [resultado si disponible].
Se planifica aumentación de tornillos con PMMA para mejorar el amarre."

### Discitis / Infección
Siempre documentar:
- Envío de muestras a bacteriología (aerobios, anaerobios, micológico)
- Envío a anatomía patológica
- Lavado profuso de la logia operatoria
- Antibioticoterapia postoperatoria coordinada con infectología

### Reoperación
Siempre documentar estado del campo quirúrgico:
"Se encuentra tejido cicatrizal [leve/moderado/severo] en el campo operatorio.
Las adherencias se disecaron [sin/con] dificultad."
→ Esto protege ante eventual complicación neurológica postoperatoria.

---

## VARIABLES POR CASO — FIJACIÓN

NIVELES: L2/3 / L3/4 / L4/5 / L5/S1 (uno o múltiples)
LADO KAMBIN: derecho / izquierdo
VARIANTE: estándar / descompresión / revisión / discitis / multilevel
TORNILLOS: [marca] / [diámetro] mm / [longitud] mm / Lote [X]
PLIF: [marca] / [altura] mm / Lote [X] / Serie [X]
BARRAS: [marca] / [diámetro] mm / Lote [X]
PMMA: sí / no
PARCHE DURAL: [marca/lote] / no se utilizó
HEMOSTÁTICO: [nombre/lote]
HORA INICIO: [HH:MM]
HORA FIN: [HH:MM]
AYUDANTE: Dr. Maximiliano Giménez (habitual)
CLÍNICA: Centro / La Pequeña Familia / Hospital Interzonal Junín
