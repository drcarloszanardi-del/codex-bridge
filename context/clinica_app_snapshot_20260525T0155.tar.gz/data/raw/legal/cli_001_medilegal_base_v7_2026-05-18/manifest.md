# CLI-001 Ingesta raw medilegal-base-v7

- task: `CLI-001`
- source_message_id: `5757`
- origin_path: `/Users/jarvis/.openclaw/media/inbound/medilegal-base-v7---dca2e052-81d0-4212-82ad-4bf852f1552e.zip`
- snapshot_zip_path: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/raw/legal/cli_001_medilegal_base_v7_2026-05-18/medilegal-base-v7---dca2e052-81d0-4212-82ad-4bf852f1552e.zip`
- extract_dir: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/raw/legal/cli_001_medilegal_base_v7_2026-05-18/extracted`
- sha256: `b3a36a5fd362541411185d0044cf1d468d3dd0b9f8cf6f9a79b9698e76646ce6`
- size_bytes: `43956`

## Clasificación
### normativa_primaria
- `medilegal/leyes/ccyc-responsabilidad.md`
- `medilegal/leyes/decreto-1089-2012.md`
- `medilegal/leyes/ley-17132.md`
- `medilegal/leyes/ley-26529.md`

### jurisprudencia
- `medilegal/jurisprudencia/fallos-hc.md`

### campos_obligatorios
- `medilegal/campos-obligatorios/parte-campos.md`

### validacion
- `medilegal/validacion/frases-prohibidas.md`

### patologias
- `medilegal/patologias/columna-lumbar.md`
- `medilegal/patologias/estilo-zanardi-HDL.md`
- `medilegal/patologias/estilo-zanardi-especiales.md`
- `medilegal/patologias/estilo-zanardi-fijacion.md`
- `medilegal/patologias/estilo-zanardi-laminoplastia.md`
- `medilegal/patologias/estilo-zanardi-revisiones.md`

### instruccion_operativa
- `medilegal/INDEX.md`
- `medilegal/SKILL-generacion.md`

## Cobertura contra INDEX

### leyes
- present: `4`
- missing_vs_index: `ley-25326.md, ley-25506.md, codigo-penal.md`
- extra_vs_index: `ninguno`

### jurisprudencia
- present: `1`
- missing_vs_index: `fallos-parte.md, fallos-columna.md, fallos-consentimiento.md`
- extra_vs_index: `ninguno`

### campos-obligatorios
- present: `1`
- missing_vs_index: `hc-campos.md, anestesia-campos.md`
- extra_vs_index: `ninguno`

### validacion
- present: `1`
- missing_vs_index: `checklist-hc.md, checklist-parte.md, frases-correctas.md`
- extra_vs_index: `ninguno`

### patologias
- present: `6`
- missing_vs_index: `columna-cervical.md`
- extra_vs_index: `estilo-zanardi-HDL.md, estilo-zanardi-especiales.md, estilo-zanardi-fijacion.md, estilo-zanardi-laminoplastia.md, estilo-zanardi-revisiones.md`

## Matriz de impacto

### corpus_normativo_primario
- zip_inputs: `medilegal/leyes/ley-17132.md, medilegal/leyes/ley-26529.md, medilegal/leyes/decreto-1089-2012.md, medilegal/leyes/ccyc-responsabilidad.md`
- impact: Refuerza requisitos base de informacion, consentimiento, responsabilidad y ejercicio profesional.

### matriz_requisitos_obligatorios
- zip_inputs: `medilegal/campos-obligatorios/parte-campos.md, medilegal/validacion/frases-prohibidas.md, medilegal/INDEX.md`
- impact: Permite derivar checklist legal y detectar omisiones o lenguaje riesgoso en plantillas vigentes.

### auditoria_correccion_por_patologia
- zip_inputs: `medilegal/patologias/columna-lumbar.md, medilegal/patologias/estilo-zanardi-fijacion.md, medilegal/patologias/estilo-zanardi-HDL.md, medilegal/patologias/estilo-zanardi-laminoplastia.md, medilegal/patologias/estilo-zanardi-especiales.md, medilegal/patologias/estilo-zanardi-revisiones.md`
- impact: Aporta riesgos concretos, estilo redaccional y variantes por procedimiento para corregir bases no conformes.

### jurisprudencia_y_defensa_documental
- zip_inputs: `medilegal/jurisprudencia/fallos-hc.md`
- impact: Sirve como soporte interpretativo para trazabilidad, autenticidad y valor probatorio de consentimientos y registros.

## Gaps detectados

- Faltan en el ZIP varios archivos prometidos por INDEX: codigo-penal.md, fallos-parte.md, fallos-columna.md, fallos-consentimiento.md, hc-campos.md, anestesia-campos.md, checklist-hc.md, checklist-parte.md, frases-correctas.md y columna-cervical.md.
- El ZIP trae estilo-zanardi-* no listados en INDEX, utiles para correccion quirurgica pero requieren trazabilidad separada como extensiones de trabajo.
