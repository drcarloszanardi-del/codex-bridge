# Referencia estructurada secundaria, Ley 5669 CABA, historias clínicas electrónicas

- Origen de detección: página oficial Argentina.gob.ar `Mi historia clínica` ya capturada en el corpus.
- URL enlazada desde la fuente oficial: http://www.saij.gob.ar/5669-local-ciudad-autonoma-buenos-aires-creacion-sistema-integrador-historias-clinicas-electronicas-registro-historias-clinicas-electronicas-lpx0005669-2016-10-27/123456789-0abc-defg-966-5000xvorpyel
- Fecha de intento de captura estructurada: 2026-05-18T14:22:00Z
- Resultado: 403 Forbidden por ruta SAIJ pública desde fetch no autenticado.
- Valor operativo actual: la existencia de la referencia queda corroborada por la fuente oficial nacional ya guardada; el texto legal CABA sigue `pending_review` como norma secundaria útil para historia clínica electrónica, pero todavía no se promueve como fuente normativa primaria del corpus.
- Próxima ruta segura: reintentar con una vía oficial/estructurada accesible o una copia normativa pública confiable de la Ciudad, conservando esta evidencia de bloqueo para no perder trazabilidad.
