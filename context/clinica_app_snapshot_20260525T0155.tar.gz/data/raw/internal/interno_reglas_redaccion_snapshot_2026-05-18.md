# Reglas internas candidatas de redacción medicolegal

Estado global: `pending_review`
Fecha de corte: 2026-05-18T12:33:00Z
Uso permitido ahora: diseño, QA local y dry run. No `active` para documentos reales.

## Reglas candidatas

1. **CLI-R001 Identificación completa del acto**
   - Estado: `pending_review`
   - Fundamento: Ley 17.132 + Ley 26.529 arts. 12-15 + Dec. 1089/2012 arts. 12 y 15.
   - Regla: toda nota clínica y todo parte quirúrgico deben iniciar con paciente, fecha, hora, ámbito y autor del registro.

2. **CLI-R002 Consentimiento con contenido material**
   - Estado: `pending_review`
   - Fundamento: Ley 26.529 arts. 5-6 + CCCN art. 59 + Dec. 1089/2012 art. 5.
   - Regla: no basta mencionar "consentimiento firmado"; debe constar información sobre diagnóstico, objetivo, riesgos relevantes, alternativas y posibilidad de rechazo.

3. **CLI-R003 Correlación clínico-radiológica explícita**
   - Estado: `pending_review`
   - Fundamento: CCCN arts. 1724-1726 + criterio operativo derivado de responsabilidad médica.
   - Regla: cuando se decide conducta invasiva, unir clínica, examen físico y estudio complementario en una misma unidad narrativa.

4. **CLI-R004 Hallazgos y técnica no genéricos**
   - Estado: `pending_review`
   - Fundamento: Ley 26.529 art. 15 + CCCN arts. 1725-1726 + litigiosidad de partes quirúrgicos incompletos.
   - Regla: el parte debe describir hallazgo intraoperatorio, maniobra principal, implantes/materiales y cierre; evitar fórmulas vacías repetidas.

5. **CLI-R005 Complicaciones y no complicaciones declaradas**
   - Estado: `pending_review`
   - Fundamento: CCCN arts. 1710 y 1724 + completitud útil.
   - Regla: registrar complicaciones, incidentes, pérdidas hemáticas relevantes o, si no existieron, dejarlo dicho de forma sobria.

6. **CLI-R006 Addendas sin borrado**
   - Estado: `pending_review`
   - Fundamento: Ley 26.529 art. 13 + Dec. 1089/2012 art. 15 + autenticidad documental.
   - Regla: toda corrección posterior debe entrar como addenda fechada y firmada, nunca reemplazando silenciosamente el texto previo.

7. **CLI-R007 Mínima exposición de datos sensibles**
   - Estado: `pending_review`
   - Fundamento: Ley 25.326 + CP art. 156 + CCCN arts. 51-53.
   - Regla: incluir solo datos personales/sensibles útiles para el acto asistencial y la continuidad de cuidados; evitar juicios de valor o datos ajenos a la indicación.

8. **CLI-R008 Justificación clínica explícita en conductas invasivas**
   - Estado: `pending_review`
   - Fundamento: CCCN arts. 1710, 1724-1726 + SAIJ estándar de medios y error inexcusable.
   - Regla: toda indicación quirúrgica o invasiva debe enlazar síntomas, examen, estudios, objetivo del procedimiento y motivo por el que se elige esa conducta.

9. **CLI-R009 Control final verificable del acto quirúrgico**
   - Estado: `pending_review`
   - Fundamento: SAIJ sobre eventos quirúrgicos evitables + CP arts. 84 y 94.
   - Regla: el parte debe cerrar con control final suficiente, incluyendo incidentes, recuentos o verificación equivalente cuando corresponda, hemostasia y estado al finalizar.

10. **CLI-R010 Continuidad asistencial y alta sin zona gris**
   - Estado: `pending_review`
   - Fundamento: Ley 26.529 arts. 2 y 15 + CP art. 106.
   - Regla: toda alta o pase debe dejar indicaciones, signos de alarma, responsable de seguimiento y vía de reconsulta para evitar abandono documental del paciente.

11. **CLI-R011 Consentimiento con constancia de acceso/copia**
   - Estado: `pending_review`
   - Fundamento: Ley 26.529 arts. 2, 5 y 14 + Dec. 1089/2012 art. 5 + SAIJ acceso a consentimiento informado.
   - Regla: además del contenido material, dejar trazado si se entregó copia, si quedó disponible para consulta y si hubo oportunidad real de lectura/preguntas.

12. **CLI-R012 Cronología quirúrgica y respuesta ante desvíos**
   - Estado: `pending_review`
   - Fundamento: CCCN arts. 1710, 1724-1726 + CP arts. 84 y 94.
   - Regla: el parte operatorio debe narrar secuencia, controles, incidente si existió, respuesta aplicada y estado final; evitar cierres sin hilo temporal.

13. **CLI-R013 Imágenes y registros clínicos con finalidad explicitada**
   - Estado: `pending_review`
   - Fundamento: CCCN art. 53 + Ley 25.326 + CP art. 156.
   - Regla: toda foto, video o registro audiovisual vinculado al acto clínico debe identificar finalidad asistencial/auditoría/docencia, resguardo y límite de circulación.

## Gates de activación
- `pending_review`: estado actual obligatorio.
- `approved_for_dry_run`: solo después de revisar base normativa y ejemplos sintéticos.
- `active`: prohibido antes de revisión humana/Codex guard.
