# Fuentes de actualización medicolegal argentina, modo detect-only

Estado: `pending_review`
Fecha de corte: 2026-05-18T12:21:05Z
Modo operativo: `detect_only`. Ninguna fuente, cambio, regla o cita nueva se activa automáticamente sin revisión humana/Codex Guard.

## Objetivo
Monitorear fuentes oficiales o estructuradas que puedan cambiar cómo conviene redactar historias clínicas, consentimientos y partes quirúrgicos en Argentina.

## Principios del updater
1. Guardar raw inmutable con `sha256`, `fetched_at`, URL oficial y URL final.
2. Detectar cambios por hash o aparición de nueva fuente/candidato.
3. Encolar todo hallazgo en `change_candidates`/`review_queue` o resumen QA equivalente.
4. No publicar ni activar reglas automáticamente.
5. Separar cambios por capa: `normativo`, `jurisprudencia`, `doctrina`, `interno`.

## Fuentes priorizadas del lote actual

### Normativo oficial
- InfoLEG, Ley 26.529, Derechos del Paciente  
  URL: https://servicios.infoleg.gob.ar/infolegInternet/anexos/160000-164999/160432/norma.htm  
  Raw: `data/raw/legal/norm_ley_26529_infoleg.html`
- InfoLEG, Ley 17.132, ejercicio de la medicina  
  URL: https://servicios.infoleg.gob.ar/infolegInternet/anexos/15000-19999/19429/texact.htm  
  Raw: `data/raw/legal/norm_ley_17132_infoleg.html`
- InfoLEG, Ley 25.326, protección de datos personales  
  URL: https://servicios.infoleg.gob.ar/infolegInternet/anexos/60000-64999/64790/texact.htm  
  Raw: `data/raw/legal/norm_ley_25326_infoleg.html`
- InfoLEG, Ley 25.506, firma digital  
  URL: https://servicios.infoleg.gob.ar/infolegInternet/anexos/70000-74999/70749/norma.htm  
  Raw: `data/raw/legal/norm_ley_25506_firma_digital_infoleg.html`
- InfoLEG, Código Civil y Comercial de la Nación, Ley 26.994  
  URL: https://servicios.infoleg.gob.ar/infolegInternet/anexos/235000-239999/235975/norma.htm  
  Raw: `data/raw/legal/norm_cccn_ley_26994_infoleg.html`
- InfoLEG, Decreto 1089/2012 reglamentario de Ley 26.529  
  URL: https://servicios.infoleg.gob.ar/infolegInternet/anexos/195000-199999/199296/norma.htm  
  Raw: `data/raw/legal/norm_dec_1089_2012_infoleg.html`
- InfoLEG, Código Penal de la Nación Argentina, Ley 11.179  
  URL: https://servicios.infoleg.gob.ar/infolegInternet/anexos/15000-19999/16546/texact.htm  
  Raw: `data/raw/legal/norm_codigo_penal_ley_11179_infoleg.html`
- Argentina.gob.ar Derecho Fácil, derechos del paciente (apoyo interpretativo, no texto rector)  
  URL: https://www.argentina.gob.ar/justicia/derechofacil/leysimple/derechos-del-paciente  
  Raw: `data/raw/legal/norm_derechos_paciente_argentina_gob.html`

### Jurisprudencia estructurada
- SAIJ búsqueda `historia clinica prueba`  
  URL: https://www.saij.gob.ar/busqueda?o=0&f=Total%7CTipo+de+Documento/Jurisprudencia&q=historia+clinica+prueba  
  Raw: `data/raw/jurisprudence/jur_saij_historia_clinica_prueba.json`
- SAIJ búsqueda `responsabilidad medica consentimiento`  
  URL: https://www.saij.gob.ar/busqueda?o=0&f=Total%7CTipo+de+Documento/Jurisprudencia&q=responsabilidad+medica+consentimiento  
  Raw: `data/raw/jurisprudence/jur_saij_responsabilidad_medica_consentimiento.json`
- SAIJ búsqueda `consentimiento informado medico`  
  URL: https://www.saij.gob.ar/busqueda?o=0&f=Total%7CTipo+de+Documento/Jurisprudencia&q=consentimiento+informado+medico&format=json  
  Raw: `data/raw/jurisprudence/jur_saij_consentimiento_informado_medico.json`
- SAIJ búsqueda `operacion quirurgica negligencia medica`  
  URL: https://www.saij.gob.ar/busqueda?o=0&f=Total%7CTipo+de+Documento/Jurisprudencia&q=operacion%20quirurgica%20negligencia%20medica&format=json  
  Raw: `data/raw/jurisprudence/jur_saij_operacion_quirurgica_negligencia_medica.json`

## Próxima expansión prioritaria
- Complementarias adicionales de Ley 26.529 y normativa sectorial adicional de historia clínica electrónica, si aplica, sobre la base ya confirmada de Decreto 1089/2012 art. 13 + Ley 25.506.
- Mantener bajo seguimiento el bloque ya priorizado de artículos: Ley 26.529 arts. 2, 5, 6, 11-15; Dec. 1089/2012 arts. 2, 5, 12-15; CCCN arts. 51-59, 1710, 1716, 1724-1726, 1737; CP arts. 84, 94, 106 y 156.
- Fallos SAIJ con texto completo o sumario robusto sobre consentimiento informado, autenticidad de historia clínica y parte quirúrgico, incluyendo el nuevo bucket de `operacion_quirurgica_negligencia_medica`.
- Resolver por ruta oficial la referencia normativa complementaria de Decreto 1089/2012 sin incorporar URL inexistente al corpus.
- Si aparece fuente doctrinaria útil, tratarla como `pending_review`, nunca como norma.

## Salida esperada del updater
- Resumen JSON en `qa/approval_gates/medicolegal_update_detect_only_summary.json`
- `change_candidates` con `change_type`, `layer`, `sha256_before`, `sha256_after`, `final_url` y `review_bucket`
- Conteo de fuentes monitoreadas, capas cubiertas y brechas abiertas
- `pending_review_queue` con `artifact` real y prioridad
- Cola priorizada de revisión jurisprudencial separando `historia_clinica`, `consentimiento`, `seguridad_quirurgica`, `error_inexcusable` y `jurisprudencia_general`

## Criterio de seguridad
Si una fuente falla por 403/429 o cambia formato, registrar el bloqueo y conservar la última evidencia válida; no promover una inferencia del modelo como si fuera cita vigente.
