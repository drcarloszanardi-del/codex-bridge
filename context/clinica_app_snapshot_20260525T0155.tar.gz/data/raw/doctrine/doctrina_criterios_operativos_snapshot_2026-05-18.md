## Doctrina y criterios operativos, capa separada
Estado general: `pending_review`, derivada de normas y jurisprudencia estructurada del lote actual. No citar como si fuera norma.

1. **Principio de completitud útil**. Documentar lo necesario para reconstruir decisión, ejecución y seguimiento, evitando tanto vacíos críticos como relleno irrelevante.
2. **Principio de secuencia temporal**. Cada nota debe permitir reconstruir quién hizo qué, cuándo y con qué fundamento clínico.
3. **Principio de correlación clínico-radiológica**. En columna/neurocirugía no alcanza listar estudios; conviene unir síntoma, hallazgo físico, imagen y conducta.
4. **Principio de consentimiento material**. Debe quedar constancia de riesgos relevantes, alternativas razonables, posibilidad de rechazo y oportunidad temporal suficiente.
5. **Principio de preservación**. Toda enmienda posterior debe quedar visible como addenda fechada, sin borrar la versión previa.
6. **Principio de razonabilidad explícita**. Cuando la decisión es invasiva o riesgosa, el registro debe exponer por qué se eligió esa conducta y no otra.
7. **Principio de control final verificable**. El parte quirúrgico debe dejar asentados chequeos finales relevantes, incidentes y estado de cierre para reducir ambigüedad pericial.
