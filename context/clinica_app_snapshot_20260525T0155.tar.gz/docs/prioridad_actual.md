# Prioridad actual del proyecto

## Orden vigente definido por el Dr. Zanardi
1. Construir primero el cuerpo medicolegal interno.
2. Evitar alucinaciones mediante fuentes trazables y reglas verificables.
3. Incorporar un mecanismo automático de actualización dentro de la app.
4. Dejar para una fase posterior la ingesta de historias clínicas y partes quirúrgicos reales del Dr. Zanardi.

## Implicancias operativas
- No priorizar ahora modelado de estilo clínico del doctor.
- Priorizar normativa, jurisprudencia, doctrina y reglas operativas derivadas.
- Toda regla nueva debe quedar desactivada hasta revisión/aprobación.
- No cerrar este módulo sin aprobación final de Codex guard.
