# Ruta Unica Jarvis - App Clinica Medicolegal

Este documento es la referencia operativa obligatoria para Jarvis cuando el Dr. Carlos Zanardi pida por Telegram una historia clinica, protocolo quirurgico, consentimiento informado o evolucion postoperatoria.

Contrato operativo vigente:

`/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/docs/JARVIS_CONTRATO_OPERATIVO_CLINICA_2026-05-20.md`

Contrato legible por maquina:

`/Users/jarvis/.openclaw/workspace/state/clinica_medicolegal/jarvis_clinica_contract.json`

## Principio

Jarvis no redacta documentos clinicos por cuenta propia y no convierte PDF por metodos alternativos.

Antes de responder cualquier pedido del Dr. Zanardi sobre consentimiento, historia clinica, protocolo/parte quirurgico o evolucion, Jarvis debe clasificar el texto con la compuerta:

```bash
/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node \
  /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_request_guard.js \
  --request "<pedido textual completo>"
```

Si la compuerta devuelve `clinical_document_request=true`, queda prohibido responder con el documento en texto libre o escribir `.md`/`.pdf` manuales en `/Users/jarvis/.openclaw/workspace/clinica`. La unica salida valida es el wrapper unico, con `--request` o con argumentos explicitos:

```bash
/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_generar_y_enviar.sh \
  --request "<pedido textual completo>" \
  --chat-id "<CHAT_ID>" \
  --send
```

Jarvis debe llamar siempre al wrapper unico:

```bash
/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_generar_y_enviar.sh
```

Ese wrapper llama a la app, genera el documento, exporta PDF, corre el chequeo medico-legal y prepara el envio por Telegram.

Compuerta de salida adicional: aunque Jarvis intente usar el script crudo `/Users/jarvis/.openclaw/workspace/scripts/send_telegram_document.js`, ese script debe bloquear cualquier PDF clinico de `/clinica/` que no tenga manifiesto de app en `/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/`, estado apto y ausencia de datos QA/prueba. Esto existe para que no vuelva a ocurrir un envio manual por fuera de la app.

## Prohibido

Jarvis no debe:

- redactar libremente un consentimiento, historia clinica o protocolo;
- responder por Telegram con una historia clinica, protocolo/parte o consentimiento armado como texto directo;
- escribir documentos clinicos manuales en `/Users/jarvis/.openclaw/workspace/clinica/historia_clinica*.md`, `/Users/jarvis/.openclaw/workspace/clinica/partes_quirurgicos/` u otra carpeta paralela;
- copiar una respuesta de IA como si fuera documento final;
- convertir HTML a PDF con navegador, `wkhtmltopdf`, `weasyprint`, screenshots, impresoras virtuales u otro metodo;
- enviar PDFs clinicos con `send_telegram_document.js` sin manifiesto de app; el script debe fallar antes de tocar Telegram;
- enviar un documento si el manifiesto dice `BLOQUEADO_NO_ENVIAR`;
- cambiar logos, formato, matricula, texto medico-legal o plantilla madre por su cuenta;
- usar, deformar o reemplazar el logo HIGA fuera de la ruta canonica `clinica/logos/hospital_junin_logo_limpio.png`;
- omitir el chequeo medico-legal.

## Estados permitidos

Consentimiento:

- Solo enviar si `validation_status` es `APTO_PARA_ENVIO`.

Historia clinica, protocolo quirurgico y evolucion:

- Enviar si `validation_status` es `APTO_PARA_ENVIO`.
- Enviar si `validation_status` es `APTO_CON_OBSERVACIONES`, dejando las observaciones en el manifiesto.
- No enviar si `validation_status` es `BLOQUEADO_NO_ENVIAR`.

## Datos que Jarvis debe pedir o extraer

Minimos para consentimiento:

- tipo de consentimiento o patologia;
- fecha;
- institucion;
- nivel y lado cuando aplique;
- nombre del paciente y DNI solo si el Dr. Zanardi los informa;
- equipo o ayudantes solo si el Dr. Zanardi los informa.

Si el Dr. Zanardi no informa nombre del paciente o DNI, Jarvis no debe inventarlos. El consentimiento debe dejar una linea de puntos para completar a mano. Si no informa equipo/ayudantes, debe quedar `Dr. Zanardi y equipo`.

Minimos para historia clinica:

- relato clinico resumido;
- paciente;
- edad, si esta disponible;
- fecha;
- institucion;
- patologia/procedimiento;
- nivel y lado cuando aplique.

Minimos para protocolo quirurgico:

- relato de lo operado;
- paciente;
- edad, si esta disponible;
- fecha;
- hora de inicio;
- hora de fin;
- ayudantes;
- institucion;
- nivel y lado;
- procedimiento;
- eventos reales o excepciones si existieron.

Si faltan edad, hora o ayudantes, el sistema puede dejar `APTO_CON_OBSERVACIONES`. Si faltan nivel/lado criticos, aparecen placeholders o hay contradiccion clinica, debe bloquear.

## Comando base para consentimiento

```bash
/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_generar_y_enviar.sh \
  --type consent \
  --slug hernia_disco_lumbar \
  --date "20/05/2026" \
  --level "L4-L5 izquierda" \
  --institution clinica_centro \
  --chat-id "<CHAT_ID>" \
  --send
```

Slugs habituales:

- `hernia_disco_lumbar`
- `canal_estrecho_lumbar_con_fijacion`
- `canal_estrecho_lumbar_sin_fijacion`
- `laminoplastia_cervical`
- `artrodesis_cervical`
- `cifoplastia_vertebroplastia`
- `hidrocefalia_derivaciones`
- `chiari`
- `tunel_carpiano_y_neuropatias`

## Comando base para historia clinica

```bash
/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_generar_y_enviar.sh \
  --type hc \
  --family lumbar_hdl \
  --input "Paciente con hernia discal posterolateral L4-L5 izquierda y dolor radicular izquierdo. Microdiscectomia tubular L4-L5 izquierda." \
  --patient "Nombre Apellido" \
  --age "61" \
  --date "20/05/2026" \
  --level "L4-L5" \
  --side "izquierda" \
  --institution clinica_centro \
  --chat-id "<CHAT_ID>" \
  --send
```

## Comando base para protocolo quirurgico

```bash
/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_generar_y_enviar.sh \
  --type parte \
  --family lumbar_hdl \
  --input "Paciente con hernia discal posterolateral L4-L5 izquierda y dolor radicular izquierdo. Microdiscectomia tubular L4-L5 izquierda." \
  --patient "Nombre Apellido" \
  --age "61" \
  --date "20/05/2026" \
  --start-time "08:00" \
  --end-time "09:10" \
  --assistants "Ayudante" \
  --level "L4-L5" \
  --side "izquierda" \
  --institution clinica_centro \
  --chat-id "<CHAT_ID>" \
  --send
```

## Familias de app habituales

- `lumbar_hdl`: hernia de disco lumbar / microdiscectomia.
- `lumbar_fijacion`: canal estrecho lumbar, inestabilidad degenerativa, fijacion/artrodesis.
- `cervical`: canal estrecho cervical / laminoplastia cervical.
- `auto`: deteccion automatica por relato.

## Instituciones

- `clinica_centro`
- `la_pequena_familia`
- `higa_junin`
- `centro_medico_pellegrini`

## Criterios clinicos ya incorporados

Jarvis no debe volver a discutirlos:

- si no recibe paciente/DNI reales, dejar lineas de puntos; nunca completar con `Paciente QA`, `QA2`, `Paciente prueba`, `Paciente Wrapper` ni datos inventados;
- si no recibe equipo/ayudantes reales, usar `Dr. Zanardi y equipo`;
- usar `dolor radicular`, no `radiculalgia`;
- no usar `y/o`;
- no usar `si corresponde`, `cuando corresponda`, `si aplica`, `eventual`;
- no inventar deficit motor;
- no dejar placeholders visibles de nivel o lateralidad;
- no escribir explicaciones anatomicas tipo tratado dentro de la historia clinica;
- para hernia L4-L5 posterolateral/central habitual, la raiz es L5;
- para hernia extraforaminal cambia la raiz segun nivel;
- el protocolo debe incluir secuencia quirurgica real, no solo checklist;
- proteccion ocular, acolchado, antisepsia, profilaxis, control radioscopico, hemostasia, recuento, cierre, curacion, incidentes y destino se consignan como rutinas verdaderas cuando aplican;
- material/implantes se consignan cuando el caso los informa;
- parche dural, hemostaticos o sellador dural se consignan solo si ocurrieron o se usaron.

## Validaciones minimas de regresion

Antes de considerar estable el flujo Jarvis-app-Telegram deben pasar:

```bash
node scripts/qa/validate_clinical_handoff.js
node scripts/qa/validate_consent_handoff.js
node scripts/qa/validate_product_mode.js
node scripts/qa/validate_clinical_send_gate.js
```

`validate_clinical_send_gate.js` comprueba tres cosas criticas: un PDF clinico manual sin manifiesto queda bloqueado, un PDF generado por la app con manifiesto apto queda habilitado en dry-run, y un documento con valores `QA`/prueba queda bloqueado aunque exista PDF.

## Salida esperada

El wrapper devuelve JSON con:

- `ok`;
- `validation_status`;
- `file`;
- `manifest`;
- `status`;
- `warnings`, si existen.

El PDF final queda en:

`/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/`

El manifiesto queda en:

`/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/`

## Si algo falla

Jarvis debe informar exactamente:

- `validation_status`;
- blockers o warnings del manifiesto;
- ruta del manifiesto;
- ruta del PDF si se genero.

Jarvis no debe arreglar manualmente el documento. Debe volver a llamar al wrapper con datos corregidos.

## Validacion de salud

Para probar que el camino funciona:

```bash
/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node \
  /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/qa/validate_clinica_route_guard.js

/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node \
  /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/qa/validate_jarvis_wrapper.js
```

Para auditar que una sesion no haya salteado la app:

```bash
/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node \
  /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_request_guard.js \
  --session "<session.jsonl>" \
  --strict
```

Debe devolver `"ok": true`.

Para guardia ampliada de pedidos reales tipo Telegram:

```bash
cd /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal
node scripts/qa/validate_jarvis_overnight_requests.js
```

Debe devolver `"ok": true`, `requests_count: 24` y `failures_count: 0`.
