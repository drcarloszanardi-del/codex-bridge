# Release candidate app clínica médico-legal

Fecha: 2026-05-19
Estado: `LISTA_PARA_PRUEBA_LOCAL_MEDICA`

## Ruta de prueba

- App local: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/app/product.html`

## Qué queda cerrado en este candidato

1. Generación desde relato breve de:
   - historia clínica,
   - parte quirúrgico,
   - consentimiento informado,
   - evolución postoperatoria.
2. Familias principales activas:
   - hernia de disco lumbar / microdiscectomía,
   - fijación/descompresión lumbar degenerativa,
   - canal estrecho cervical / laminoplastia,
   - familias neuroquirúrgicas derivadas de la ingesta local.
3. Criterios permanentes incorporados:
   - no usar `radiculalgia`;
   - no usar `y/o` en historia clínica;
   - usar `dolor radicular`;
   - nivel lumbar -> raíz comprometida según hernia habitual o extraforaminal;
   - parte quirúrgico con técnica real y no solo checklist;
   - no usar `cuando corresponde` ni `salvo contraindicación` en rutinas que se consignan como realizadas.
4. Consentimientos:
   - cuerpo canónico recuperado desde Jarvis;
   - 16 consentimientos disponibles;
   - estado de aprobación preservado por documento;
   - exportador a HTML/DOCX/PDF con logo institucional.
5. Exportación desde la app:
   - `Copiar vista`;
   - `Descargar paquete` en HTML imprimible;
   - `Imprimir/PDF` desde navegador.

## Archivos clave

- App: `app/product.html`
- Cuerpo de consentimientos: `data/derived/consent_canonicals/consent_body_pack_2026-05-19.json`
- Exportador de consentimientos: `scripts/exports/export_consent_artifact.py`
- Criterios de estilo clínico: `docs/criterios_estilo_hc_zanardi_2026-05-19.md`
- Validación técnica: `scripts/qa/validate_product_mode.js`
- Manifiesto candidato: `qa/approval_gates/cli_app_candidate_manifest_2026-05-19.json`

## Estado prudente de uso

La app queda lista para prueba local médica. No se declara certificación legal ni cierre asistencial automático. El documento generado debe ser revisado por el médico antes de copiar, imprimir o incorporar a historia clínica real.

## Próxima prueba recomendada

1. Cargar un caso real breve.
2. Elegir familia quirúrgica si la detección automática no coincide.
3. Completar paciente, edad, fecha, hora y ayudantes.
4. Revisar HC, parte, consentimiento y evolución.
5. Usar `Descargar paquete` para generar HTML imprimible.
6. Usar `Imprimir/PDF` para guardar PDF desde el navegador.
