# Proyecto v1

## Prioridad inicial
Construir primero el cuerpo medicolegal interno y la estructura local de la app.

## Después
Cuando el Dr. Zanardi entregue archivos reales de historias clínicas y partes quirúrgicos, se procesarán para:
- clasificar por patología
- distinguir historia clínica vs parte quirúrgico
- modelar estilo de redacción
- extraer patrones recurrentes
- diseñar plantillas cerradas basadas en práctica real

## Condición de cierre
No cerrar entregables sustantivos sin aprobación final de Codex guard.
