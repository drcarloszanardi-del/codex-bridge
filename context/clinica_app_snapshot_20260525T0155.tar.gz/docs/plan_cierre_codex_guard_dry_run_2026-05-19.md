# Plan de cierre con Codex guard hacia `approved_for_dry_run`

Fecha de corte: 2026-05-19
Origen: microciclo interno para cierre técnico del frente historia clínica y partes quirúrgicos.
Estado: `EN_EJECUCION_LOCAL_PENDIENTE_DE_RESPUESTA_CODEX_GUARD`

## Objetivo
Mover el frente desde `BASE_AVANZADA_REVIEW_ONLY` a una condición prudente de `approved_for_dry_run`, sin afirmar cierre legal terminal ni cumplimiento integral.

## Cambios mínimos concretos a ejecutar
1. Consolidar reglas críticas hoy dispersas como gate formal de dry run:
   - identificación completa del acto,
   - consentimiento con contenido material,
   - parte quirúrgico completo y cronológico,
   - addendas sin borrado,
   - confidencialidad y acceso mínimo,
   - integridad/autenticidad/auditoría.
2. Congelar una definición operativa única de qué significa `approved_for_dry_run`.
3. Exigir validación trazable de un circuito documental completo, aunque sea sintético:
   - alta paciente,
   - historia clínica,
   - addenda,
   - parte quirúrgico,
   - resguardo de autor/fecha/hora,
   - preservación de original.
4. Mantener prohibición expresa de frases de sobrepromesa legal.

## Paso único verificable que se aplica ya
Se deja formalizado este criterio interno:

> El frente solo podrá pasar a `approved_for_dry_run` cuando exista evidencia documental local de un circuito sintético completo y trazable de historia clínica + addenda + parte quirúrgico, validado contra el gate de 6 controles.

## Gate interno de promoción
Para cambiar estado deberán coexistir estos 3 elementos:
- corpus y matriz en estado al menos `review_complete_for_dry_run`;
- reglas críticas promovidas desde `pending_review` a `approved_for_dry_run`;
- evidencia de circuito sintético completo archivada en `qa/`.

## Restricción vigente
Hasta entonces, el estado prudente sigue siendo `BASE_AVANZADA_REVIEW_ONLY`.
