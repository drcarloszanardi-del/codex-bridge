# Contrato de blindaje redaccional medico-legal

Fecha: 2026-05-24

## Regla permanente

Todo insumo del corpus medico-legal debe impactar la app como regla redaccional, plantilla o gate verificable antes de modificar historia clinica, parte quirurgico o consentimiento informado.

El documento clinico final no debe transformarse en un escrito legal ni rellenarse con citas. Debe quedar clinicamente limpio, pero cumplir las exigencias que surgen de leyes, normativa sanitaria, jurisprudencia oficial y doctrina tecnica curada.

## Capas fuente

1. Leyes y normativas argentinas oficiales.
   - Consentimiento informado.
   - Derechos del paciente.
   - Historia clinica.
   - Revocabilidad, informacion suficiente y copia.
   - Seguridad quirurgica, trazabilidad, implantes, recuento, tiempos, autor y custodia documental.

2. Jurisprudencia oficial.
   - Nacion: SAIJ, CSJN, CIJ y MPF cuando haya trazabilidad.
   - Provincia de Buenos Aires: JUBA, SCBA y fuentes oficiales del Poder Judicial.
   - Solo se promueve si hay tribunal, fecha, caratula o identificador, URL oficial y utilidad redaccional concreta.

3. Doctrina tecnica y medico-legal.
   - AANC/RANC, publicaciones forenses y doctrina de responsabilidad medica.
   - Entra como cola o apoyo de interpretacion.
   - No se convierte sola en regla de app sin revision Codex 5.5 y criterio medico/legal.

## Flujo operativo

Subagentes 5.3 pueden buscar, clasificar, extraer y proponer impacto. No modifican plantillas ni gates clinicos.

Codex integra el hallazgo, decide si corresponde cambio, y si corresponde lo traduce a:

- gate detectable;
- ajuste de plantilla;
- frase prohibida o reemplazo seguro;
- item de faltante critico;
- cola de revision si no alcanza trazabilidad.

## Reglas de redaccion ya endurecidas

- Diagnostico separado de indicacion y tecnica.
- No inventar hernia, deficit motor, implantes, parche dural, selladores ni material especial.
- Hernia extraforaminal con abordaje foraminal/extraforaminal, no interlaminar.
- Fijacion lumbar sin lateralizar artrodesis; nivel si, lado no.
- Descompresion directa solo si fue indicada o realizada.
- Hemostasia y recuento antes de cierre.
- Adjuntos durales antes del cierre si corresponden.
- Consentimiento con diagnostico, procedimiento, riesgos, alternativas, revocabilidad y ausencia de garantia de resultado.

## Limite

Esto es un tamiz medico-legal interno y reproducible. No declara certificacion legal terminal ni reemplaza revision medica/legal humana cuando el caso lo requiera.
