# Radar 5.3 de fuentes normativas y jurisprudenciales

Fecha: 2026-05-24

## Objetivo

Mantener un radar de bajo costo para leyes, normativas, jurisprudencia y doctrina que pueda fortalecer la app clinica medico-legal de neurocirugia y cirugia de columna.

## Fuentes evaluadas

| Fuente | Tipo | Utilidad | Regla de promocion |
| --- | --- | --- | --- |
| SAIJ | Oficial, legislacion, jurisprudencia, doctrina, dictamenes | Fuente primaria para leyes, fallos y doctrina argentina | Promover si hay texto oficial, identificador, fecha y utilidad redaccional concreta |
| CIJ / CSJN | Oficial judicial nacional | Noticias judiciales, comunicados y fallos vinculables | Fallo/PDF/decision a corpus; nota sin sentencia a cola |
| JUBA / SCBA | Oficial Provincia de Buenos Aires | Jurisprudencia local prioritaria para Junin/PBA | Promover con idFallo, tribunal, fecha y texto oficial |
| MPF | Oficial | Dictamenes y criterios de procuracion cuando incidan en responsabilidad/documentacion | Cola o corpus segun trazabilidad e impacto |
| AANC / RANC | Tecnica-cientifica | Estandar tecnico, lenguaje quirurgico, actualizacion neuroquirurgica | Cola doctrinal; requiere revision 5.5 antes de impactar gates |
| Cuadernos / doctrina medico-legal | Doctrina/forense | Taxonomia de responsabilidad, prueba y causalidad | Cola doctrinal; no reemplaza ley ni sentencia |

## Formato de reporte del subagente

Cada hallazgo debe traer:

- fuente;
- naturaleza: ley, norma, fallo, sumario, dictamen, doctrina, guia tecnica;
- caratula/autor/titulo;
- tribunal u organismo;
- fecha;
- URL oficial o trazable;
- texto completo disponible: si/no;
- tema: consentimiento, HC, parte, implantes, seguridad quirurgica, causalidad, seguimiento, urgencia;
- utilidad para HC/parte/consentimiento;
- riesgo que reduce;
- decision: promover al corpus, dejar en cola, requiere 5.5;
- cambio candidato: gate, plantilla, frase prohibida, faltante critico o sin cambio.

## Salida esperada

El subagente no toca la app. Deja hallazgos en reporte breve y propone impacto. Codex decide si se integra.
