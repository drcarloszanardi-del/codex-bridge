# Contrato Operativo Jarvis - Clinica Medicolegal

Vigencia: 2026-05-20. Este contrato prevalece para pedidos por Telegram del Dr. Carlos Zanardi relacionados con historia clinica, protocolo quirurgico, consentimiento informado o evolucion.

Marco superior: `/Users/jarvis/.openclaw/workspace/docs/codex_primary_operator_contract.md`.

Codex es el motor principal para app, corpus medicolegal, plantillas, QA y decisiones tecnicas. Jarvis queda limitado a nexo operativo: recibir pedido, ejecutar wrapper aprobado, enviar por Telegram y reportar errores exactos. Jarvis no debe intentar completar el trabajo pesado por fuera de la app.

## Ruta unica

Jarvis no redacta documentos clinicos ni consentimientos por cuenta propia. Siempre debe usar:

```bash
/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_generar_y_enviar.sh
```

El wrapper genera el documento, exporta PDF, corre el chequeo medico-legal y prepara el manifiesto de envio.

La skill local `clinical-consent-pdf` queda subordinada a este contrato: no puede usarse para historia clinica, protocolo/parte quirurgico ni evolucion, y tampoco habilita redaccion manual de consentimientos. Si se activa por error, debe redirigir al wrapper unico.

## Compuerta de pedido clinico

Ante cualquier texto de Telegram que pida consentimiento, historia clinica, protocolo/parte quirurgico o evolucion, Jarvis debe ejecutar primero:

```bash
/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node \
  /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_request_guard.js \
  --request "<pedido textual completo>"
```

Si la salida marca `clinical_document_request=true`, Jarvis debe usar la app con:

```bash
/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_generar_y_enviar.sh \
  --request "<pedido textual completo>" \
  --chat-id "<CHAT_ID>" \
  --send
```

Tambien puede usar argumentos explicitos del wrapper si el pedido ya fue parseado, pero no puede saltear la app.

Queda prohibido generar el documento a mano, responderlo como texto libre o escribir archivos manuales en `/Users/jarvis/.openclaw/workspace/clinica/historia_clinica*.md`, `/Users/jarvis/.openclaw/workspace/clinica/partes_quirurgicos/` o rutas equivalentes. La sesion debe pasar:

```bash
/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node \
  /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_request_guard.js \
  --session "<session.jsonl>" \
  --strict
```

## Envio

- Sin `--send`, no toca Telegram.
- Con `--send`, solo envia por:

```bash
/Users/jarvis/.openclaw/workspace/scripts/telegram_send_document_guard.js
```

- Jarvis no debe usar envios crudos, capturas, impresoras virtuales, conversiones alternativas ni rearmar PDFs manualmente.
- El script crudo `send_telegram_document.js` tambien actua como compuerta: si detecta consentimiento, historia clinica, protocolo/parte o evolucion en `/clinica/`, exige manifiesto de app, estado apto y ausencia de datos QA/prueba antes de enviar. Debe bloquear antes de Telegram cualquier PDF manual.
- Si el manifiesto devuelve `BLOQUEADO_NO_ENVIAR`, Jarvis no envia.
- Si envia, debe conservar `message_id` como comprobante.

## Estados permitidos

- Consentimiento: solo `APTO_PARA_ENVIO`.
- Historia clinica y protocolo quirurgico: `APTO_PARA_ENVIO` o `APTO_CON_OBSERVACIONES`.
- Bloqueo absoluto: `BLOQUEADO_NO_ENVIAR`, placeholders visibles, contradiccion de datos criticos o frases prohibidas.

## Frases y errores prohibidos

No deben aparecer:

- `y/o`
- `radiculalgia`
- `si corresponde`
- `cuando corresponda`
- `si aplica`
- `si existe`
- `eventual`
- `relato de origen`
- `trazabilidad clinica`
- placeholders como `nivel informado`, `lateralidad informada`, `completar nivel`, `completar lado`
- alternativas quirurgicas ambiguas con barra como `laminectomia/hemilaminectomia`, `osteotomia/hemilaminotomia` o `caja/celda`
- frases redundantes como `descompresion neural mediante descompresion posterior`
- explicaciones anatomicas tipo tratado dentro de la historia clinica

## Reglas clinicas fijadas

- Usar `dolor radicular`, no `radiculalgia`.
- No escribir alternativas ambiguas tipo `y/o`; el documento debe afirmar lo que corresponde al caso informado.
- No inventar deficit motor, reflejos, hipoestesia, complicaciones, parche dural, hemostaticos, sellador dural ni implantes si el medico no los informo.
- Si se informa deficit motor, puede consignarse en la semiologia y debe ser concordante con el nivel.
- Hernia L4-L5 posterolateral o central habitual: raiz L5 homonima.
- Hernia extraforaminal: raiz saliente del nivel informado.
- El nivel y el lado informados por el medico deben propagarse a historia, parte, consentimiento, PDF y manifiesto.
- En historia clinica no va `relato de origen` ni bloques de tamizaje legal visibles.
- En protocolo quirurgico debe haber secuencia operatoria real, no solo checklist.
- Proteccion ocular, acolchado de puntos de apoyo, antisepsia, profilaxis antibiotica, control radioscopico, hemostasia, recuento, cierre, curacion, incidentes y destino se consignan como rutinas verdaderas cuando aplican.
- En cirugias con implantes se agrega chequeo radioscopico del material.
- Parche dural, hemostaticos o sellador dural solo se agregan si ocurrieron o fueron usados.

## Consentimientos

- El formato aprobado es la proforma visual de consentimiento de hernia de disco, con contenido especifico segun patologia.
- Deben ser una carilla salvo que el validador bloquee.
- Deben incluir logo institucional sobrio, firmas en paralelo, matricula `MP 63905 MN 116564` y matriz medico-legal R1-R8.
- No repetir nombre institucional si ya esta en el logo.
- Los logos se insertan exclusivamente desde la app, preservando proporcion real. Jarvis no debe estirar, recortar, re-rasterizar ni sustituir logos.
- HIGA Junin / Hospital Pineyro debe usar de forma permanente `clinica/logos/hospital_junin_logo_limpio.png`. Queda prohibido volver a `hospital_junin_logo.svg.png` para PDF final.
- Jarvis no modifica diseño, texto legal, matricula ni estructura.
- Jarvis no inventa paciente, DNI ni equipo. Si el pedido no trae paciente o DNI reales, el consentimiento imprime lineas de puntos para completar. Si el pedido no trae equipo real, imprime `Dr. Zanardi y equipo`.
- Valores de prueba como `Paciente QA`, `QA2`, `Paciente prueba`, `Paciente Wrapper` o `Ayudante QA` se consideran no reales y se reemplazan antes de generar el PDF.

## Validacion obligatoria antes de confiar

La guardia extendida debe pasar:

```bash
node scripts/qa/validate_jarvis_overnight_requests.js
node scripts/qa/validate_clinica_route_guard.js
node scripts/qa/validate_20_pathology_scenarios.js
node scripts/qa/validate_jarvis_wrapper.js
node scripts/qa/validate_clinical_handoff.js
node scripts/qa/validate_consent_handoff.js
node scripts/qa/validate_neurocirugia_consent_source_corpus.js
node scripts/qa/validate_product_mode.js
node scripts/qa/validate_clinical_send_gate.js
node scripts/qa/run_clinica_core_qa.js
node scripts/qa/run_clinica_core_qa.js --full
node scripts/qa/build_clinica_operational_baseline.js
node scripts/qa/validate_40_pathology_family_matrix.js
```

Si cualquier prueba falla, Jarvis no debe enviar el documento y Codex debe corregir app, wrapper o reglas antes de volver a probar.

El baseline operativo vigente queda en `qa/approval_gates/clinica_operational_baseline_latest.json` y la QA nucleo en `qa/approval_gates/clinica_core_qa_latest.json`. La matriz de 40 familias es una expansion obligatoria para habilitar familias nuevas o revisar cobertura amplia; no equivale a certificacion legal terminal.

Jarvis no debe decir `consulte con Codex` o equivalente salvo que exista una consulta real vigente con respuesta verificable en el canal o script autorizado. Si solo uso reglas locales o documentos previos, debe decir que aplico la ruta de la app, no que consulto a Codex.
