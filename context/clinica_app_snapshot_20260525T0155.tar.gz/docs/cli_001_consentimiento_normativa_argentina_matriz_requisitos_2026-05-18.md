# CLI-001 Matriz normativa argentina para auditoría de consentimientos

Fecha de corte: 2026-05-18T18:55:00Z  
Task: `CLI-001-CONSENTIMIENTOS-AUDITORIA-NORMATIVA-ARG-20260518`

## Fuentes efectivamente relevadas en este ciclo
- `ingesta/raw/cli_001_medilegal_base_v7_2026-05-18/extracted/medilegal/leyes/ley-26529.md`
- `ingesta/raw/cli_001_medilegal_base_v7_2026-05-18/extracted/medilegal/leyes/decreto-1089-2012.md`
- `ingesta/raw/cli_001_medilegal_base_v7_2026-05-18/extracted/medilegal/leyes/ley-17132.md`
- `plantillas/consentimientos_manifest_multiinstitucion.json`
- Muestra visual/estructural: `plantillas/consentimiento_hernia_disco_lumbar_clinica_centro_master.html`

## Matriz mínima de requisitos obligatorios para consentimiento informado quirúrgico
| Requisito operativo | Fuente | Criterio de auditoría sobre plantilla |
|---|---|---|
| Identificación del paciente y fecha | Ley 26.529 + Decreto 1089/2012 | Debe existir lugar/fecha y campos para paciente/DNI o representante. |
| Procedimiento propuesto claramente descripto | Decreto 1089/2012 | La plantilla debe nombrar la cirugía o intervención concreta, no un acto genérico. |
| Diagnóstico o indicación clínica | Ley 26.529 | Debe constar el diagnóstico o motivo clínico que fundamenta la práctica. |
| Riesgos y complicaciones | Decreto 1089/2012 | Debe enumerar riesgos relevantes generales y específicos del procedimiento. |
| Alternativas terapéuticas | Decreto 1089/2012 | Debe informar alternativas razonables, no solo la cirugía propuesta. |
| Consecuencias de no tratar / no realizar | Ley 26.529 art. derecho a decidir + deber de información | Debe explicitar qué puede ocurrir si el paciente rechaza o posterga la práctica. |
| Anestesia y hemoderivados | Decreto 1089/2012 | Debe contemplar anestesia prevista y eventual necesidad de sangre/hemoderivados. |
| Posibilidad de preguntas y segunda opinión | Ley 26.529, deber de información comprensible | Debe dejar constancia de espacio para preguntas y/o derecho a segunda opinión. |
| Revocación del consentimiento antes del acto | Ley 26.529 | Debe afirmar que el consentimiento puede retirarse antes del procedimiento. |
| No garantía de resultado | Ley 17.132 | Debe evitar promesa de curación o resultado asegurado. |
| Firma del paciente y del médico con matrícula | Ley 26.529 + Decreto 1089/2012 | Deben existir bloques de firma y matrícula profesional. |
| Soporte trazable para HC | Ley 26.529 | El consentimiento debe poder integrarse a HC completa, fechada y firmada. |

## Hallazgos rápidos sobre plantillas vigentes
Chequeo textual rápido sobre `clinica/plantillas/consentimiento_*.html|md` buscando bloques mínimos.

### Plantillas con faltantes más notorios
| Archivo | Faltantes detectados |
|---|---|
| `consentimiento_canal_estrecho_lumbar_sin_instrumentacion_base_aprobada.md` | alternativas, consecuencias_no_tratar, revocacion, segunda_opinion, hemoderivados, anestesia, riesgos |
| `consentimiento_espondilodiscitis_dorsal_hospital_interzonal_aprobado.md` | alternativas, consecuencias_no_tratar, revocacion, segunda_opinion, hemoderivados, anestesia, riesgos |
| `consentimiento_fijacion_lumbar_degenerativa_base_aprobada.md` | alternativas, consecuencias_no_tratar, revocacion, segunda_opinion, hemoderivados, anestesia, riesgos |
| `consentimiento_hernia_disco_lumbar_base_aprobada.md` | alternativas, consecuencias_no_tratar, revocacion, segunda_opinion, hemoderivados, anestesia, riesgos |
| `consentimiento_hernia_disco_lumbar_clinica_centro_aprobado.md` | alternativas, consecuencias_no_tratar, revocacion, segunda_opinion, hemoderivados, anestesia, riesgos |

### Plantillas parcialmente alineadas pero con gap legal puntual
| Archivo | Gap puntual |
|---|---|
| `consentimiento_descompresion_dorsal_biopsia_fijacion_lpf_master.html` | falta bloque explícito de consecuencias de no tratar |
| `consentimiento_fractura_dorsal_reduccion_fijacion_clinica_centro_master.html` | falta bloque explícito de consecuencias de no tratar |
| `consentimiento_hernia_disco_lumbar_base.md` | falta consecuencias de no tratar y segunda opinión |
| `consentimiento_hernia_disco_lumbar_clinica_centro_master.html` | falta consecuencias de no tratar y segunda opinión |
| `consentimiento_laminoplastia_cervical_clinica_centro_master.html` | falta bloque explícito de consecuencias de no tratar |

### Plantillas que pasaron este chequeo textual mínimo
- `consentimiento_exeresis_quiste_facetario_lumbar_sin_fijacion_clinica_centro_master.html`
- `consentimiento_fijacion_descompresion_lumbar_degenerativa_clinica_centro_master.html`

## Lectura operativa del hallazgo
1. La ingesta raw ya permite pasar del inventario a la auditoría normativa real.
2. El gap dominante no es visual sino jurídico-textual: varias plantillas omiten alternativas, consecuencias de no tratar, revocación y segunda opinión.
3. Hay dos grupos de trabajo claros:
   - **grupo A, corrección profunda**: bases/aprobados viejos con 7 faltantes.
   - **grupo B, corrección puntual**: masters casi completos donde falta sobre todo el bloque de consecuencias de no tratar y, en algunos casos, segunda opinión.
4. El manifest multiinstitución ya reconoce bloques obligatorios (`alternativas`, `consecuencias_no_tratar`, `anestesia_hemoderivados`, `preguntas_segunda_opinion`, `aceptacion_rechazo_revocacion`), pero la auditoría muestra que todavía no están sincronizados en todas las plantillas reales.

## Próximo paso físico habilitado
Corregir primero los masters institucionales y bases con mayor reutilización, empezando por:
1. `consentimiento_hernia_disco_lumbar_clinica_centro_master.html`
2. `consentimiento_laminoplastia_cervical_clinica_centro_master.html`
3. `consentimiento_descompresion_dorsal_biopsia_fijacion_lpf_master.html`

Luego sincronizar las versiones `*_aprobado.md` que todavía quedaron con texto pre-auditoría.
