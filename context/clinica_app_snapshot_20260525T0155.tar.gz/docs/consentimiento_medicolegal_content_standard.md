# Estándar de contenido para consentimientos

ID: `consentimiento_medicolegal_arg_v1`  
Estado: operativo para generación y QA interno  
Base: matriz local `CLI-001` + corpus médico-legal argentino preservado en la app.

## Regla madre

Todo consentimiento exportado por la app debe respetar la proforma formal aprobada por el Dr. Zanardi, pero el contenido clínico-legal debe cambiar según la patología solicitada. Jarvis no puede reemplazar esta matriz por redacción libre.

## Bloques obligatorios R1-R8

1. **R1 Identificación del paciente y del acto.** Nombre, DNI, fecha, institución por logo o texto institucional, procedimiento propuesto, nivel o lateralidad cuando aplique.
2. **R2 Diagnóstico e indicación.** Diagnóstico concreto y motivo de indicación quirúrgica.
3. **R3 Procedimiento comprensible.** Qué se autoriza, con técnica y alcance razonablemente entendibles por el paciente.
4. **R4 Riesgos relevantes y específicos.** Riesgos generales y riesgos propios de la patología, nivel, lateralidad, descompresión, duramadre o instrumentación cuando aplique.
5. **R5 Beneficios, alternativas y no tratamiento.** Beneficio esperado, alternativas razonables, posibilidad de no operarse y consecuencias previsibles de no tratar.
6. **R6 Autonomía.** Oportunidad de preguntas, segunda opinión, aceptación, rechazo y revocación antes del procedimiento.
7. **R7 Firmas.** Firma del paciente o representante, aclaración, DNI/vínculo si corresponde, firma del médico, aclaración/sello y matrícula.
8. **R8 Trazabilidad documental.** Integración a historia clínica y disponibilidad de copia o acceso posterior.

## Prohibiciones

- No usar frases que aparenten eximir responsabilidad.
- No usar `si corresponde`, `cuando corresponda`, `eventual`, `técnica estándar` o explicaciones conversacionales dentro del documento final.
- No declarar datos clínicos o quirúrgicos no informados como si hubieran ocurrido.
- No cambiar la proforma visual ni el orden lógico sin aprobación.

## Control automático

`scripts/qa/validate_consent_handoff.js` debe fallar si el manifiesto no declara `content_standard_id=consentimiento_medicolegal_arg_v1` o si el PDF exportado no contiene los bloques R1-R8 mínimos.
