# App clínica medicolegal

Proyecto local para el Dr. Zanardi.

## Objetivo
Generar historias clínicas y partes quirúrgicos con plantillas cerradas, respetando el estilo real del Dr. Zanardi y aplicando un cuerpo medicolegal interno basado en normativa y jurisprudencia argentina, sin mostrar esa fundamentación en el documento final.

## Principios rectores
- uso personal
- almacenamiento local
- foco inicial en neurocirugía y cirugía de columna
- integración Word
- plantillas cerradas
- auditoría interna antes de emitir documento
- trazabilidad/versionado
- sin prometer riesgo legal cero
- sin citar base legal en el documento final

## Ejes de construcción
1. Cuerpo medicolegal interno
2. Ingesta y clasificación de documentos reales del Dr. Zanardi
3. Motor de plantillas cerradas
4. Validación clínico-medicolegal
5. Exportación Word
