# Criterios de estilo para historia clinica

Estado: criterio operativo incorporado por correccion directa del Dr. Zanardi.

## Alcance transversal

- Cada correccion marcada por el Dr. Zanardi se interpreta como criterio general del sistema, no como arreglo aislado del ejemplo visible.
- Aplicar la regla a todas las plantillas y familias documentales donde corresponda por patologia, tecnica o contexto operatorio.
- Si una regla depende de la tecnica, la app debe distinguir el contexto: por ejemplo, hernia/discectomia sin implantes vs. fijacion/artrodesis con implantes.
- No volver a introducir expresiones descartadas en nuevas plantillas, consentimientos, historias clinicas, partes quirurgicos o evoluciones.
- No imprimir en documentos clinicos visibles frases condicionales abiertas como `si corresponde`, `si corresponden`, `cuando corresponda`, `cuando correspondia`, `segun corresponda`, `si aplica`, `si existe` o `eventual`.
- Si el dato fue informado, redactarlo como hecho afirmativo. Si no fue informado, omitirlo del texto clinico visible o dejarlo como faltante lateral, pero no dentro de la historia, parte o consentimiento.

## Dolor lumbar y dolor radicular

- No usar `y/o` en historia clinica. La HC debe afirmar el dato clinico del caso, no dejar alternativas abiertas.
- No usar `radiculalgia` en la redaccion habitual.
- Usar `dolor radicular`.
- Para fijacion/descompresion lumbar por patologia degenerativa, la frase madre preferida es:
  - `dolor lumbar mecanico y dolor radicular por inestabilidad asociada a patologia degenerativa, con correlacion clinico-radiologica e indicacion de descompresion y estabilizacion.`

## Regla practica

Si el relato trae una formulacion ambigua como `dolor lumbar mecanico y/o radiculalgia por inestabilidad, estenosis o patologia degenerativa`, la app debe normalizarla a una frase afirmativa y clinicamente concreta antes de generar la historia clinica.

## Nivel discal y raiz comprometida

- En hernias lumbares habituales, usar la raiz pasante:
  - `L3-L4` -> raiz `L4`.
  - `L4-L5` -> raiz `L5`.
  - `L5-S1` -> raiz `S1`.
- Para hernia posterolateral habitual, redactar como radiculopatia de la raiz pasante homonima a la hernia:
  - `hernia discal posterolateral L4-L5 izquierda` -> `radiculopatia L5 izquierda homonima`.
  - No escribir `cuadro radicular concordante con L4-L5` como formulacion principal.
- En la historia clinica no explicar la anatomia ni el mecanismo. No usar parentesis tipo `raiz pasante`, `raiz saliente` o `hernia posterolateral/central habitual` en el texto visible.
- Redaccion preferida: `cuadro compatible con radiculopatia L5 izquierda por hernia discal posterolateral L4-L5 izquierda`.
- No usar `posible` para hallazgos semiologicos visibles en la HC. Si se incluye hipoestesia/debilidad/reflejo, redactarlo como hallazgo presente. Si no se sabe, no inventarlo o dejarlo como faltante sensible fuera del texto principal.
- No agregar deficit motor por patron esperado. Debilidad, paresia, pie caido, fuerza disminuida o alteracion de reflejos solo se consignan si el medico lo explicito en el relato del caso.
- Si no se explicita deficit motor, en examen fisico radicular usar dolor irradiado e hipoestesia/territorio sensitivo, sin fuerza ni reflejos.
- En hernias extraforaminales, usar la raiz saliente:
  - `L3-L4 extraforaminal` -> raiz `L3`.
  - `L4-L5 extraforaminal` -> raiz `L4`.
  - `L5-S1 extraforaminal` -> raiz `L5`.
- El examen fisico debe agregar signos y sintomas compatibles con la raiz interpretada cuando el nivel este disponible.

## Estudios por patologia lumbar

- En hernia de disco, usar:
  - `RM donde se evidencia extrusion discal [ubicacion] [nivel] [lateralidad], concordante con la clinica y la raiz comprometida.`
- El nivel y la lateralidad los informa el medico.
- Si el relato ya trae el nivel operado, incorporarlo tambien en el motivo de ingreso y no dejar `hernia discal` generico.
  - Ejemplo: `lumbalgia con dolor radicular persistente con correlacion clinico-radiologica por hernia discal L4-L5 y respuesta insuficiente al tratamiento conservador.`
- Si el relato trae lateralidad, incorporarla en motivo, enfermedad actual, estudios, parte y consentimiento. No dejar `miembro inferior` o `lateralidad informada por el medico` cuando el lado ya fue informado.
  - Ejemplo: `dolor radicular izquierdo`, `miembro inferior izquierdo`, `hernia discal L4-L5 izquierda`.
- En canal estrecho, no usar el relato de hernia/extrusion discal. Usar:
  - `RM donde se evidencia canal estrecho lumbar [nivel], con compromiso del canal y recesos laterales, concordante con la clinica y la indicacion quirurgica.`

## Parte quirurgico: verificaciones que siempre corresponden

- No escribir `cuando correspondia` para identidad, procedimiento, nivel, lateralidad o sitio quirurgico.
- En columna, consignar como verificado: identidad del paciente, procedimiento propuesto, nivel, lateralidad y sitio quirurgico.
- Consignar control radioscopico para identificacion del nivel.
- En cirugias con implantes, agregar chequeo del material.
- Si el medico menciona implantes especificos, la app debe incorporarlos al parte quirurgico: tornillos, barras, caja/celda PLIF-TLIF, miniplacas, dispositivo interespinoso, injerto, PMMA/cementacion u otro material indicado.
- No inventar marca, modelo, medida, lote ni serie. Si no fueron informados, deben quedar como faltante lateral de revision, no como texto ficticio dentro del parte.
- Para implantes permanentes de columna, conservar la necesidad medico-legal de trazabilidad cuando se prepare el documento final: marca/modelo/medidas/lote-serie segun sticker o rotulo disponible. Esta regla no se traslada a parche/sellador/hemostaticos salvo indicacion expresa del medico.
- No agregar `cuando corresponde` ni `cuando correspondia` al control radioscopico.
- No escribir `salvo contraindicacion` cuando se consigna una accion ya efectuada. Si hubo contraindicacion, esa accion no debe aparecer como realizada; si se realizo, debe documentarse de manera afirmativa.
- Para profilaxis antibiotica realizada, usar: `Se administro profilaxis antibiotica conforme protocolo institucional.`
- El parte quirurgico visible no debe incluir frases meta de auditoria como `Se consigna la secuencia operatoria...`.
- Antes de la descripcion tecnica solo deben ir verificaciones iniciales: identidad/sitio/nivel/lateralidad, posicionamiento, proteccion ocular, antisepsia, profilaxis y control radioscopico.
- Hemostasia, recuento, cierre/destino y ausencia de incidentes deben ubicarse al final de la tecnica, no antes del desarrollo quirurgico.
- Parche de duramadre, sellador dural y hemostaticos se consignan como uso tecnico local, sin lote, marca ni trazabilidad salvo que el medico lo pida expresamente.
- No forman parte del protocolo convencional. Solo deben aparecer si el medico los menciona expresamente en el caso.
- La tecnica base puede consignar `hemostasia completa con bipolar` o `hemostasia satisfactoria`, pero no debe agregar `hemostaticos locales` por defecto.
- Si el medico dice solo `use parche de duramadre, sellador dural y hemostaticos`, redactar:
  - `Se coloca parche de duramadre y sellador dural como refuerzo local sobre la zona dural expuesta. Se utilizan hemostaticos locales.`
- Si ademas el medico explicita durotomia, apertura dural o salida de LCR, redactar:
  - `Se cubre la zona dural con parche de duramadre y sellador dural. Se utilizan hemostaticos locales.`
- No inferir durotomia por el solo uso de parche o sellador dural.

## Parte quirurgico HDL / microdiscectomia

- El parte no debe quedarse en checklist. Luego del control radioscopico debe continuar con la tecnica quirurgica.
- Para microdiscectomia tubular, incluir:
  - decubito prono bajo anestesia general;
  - pulsos pedios;
  - antisepsia y campos;
  - marcacion radioscopica del nivel;
  - incision cutanea paramediana del lado indicado;
  - dilatacion progresiva y colocacion del sistema tubular;
  - microscopio quirurgico;
  - abordaje del espacio interlaminar;
  - drill/hemilaminotomia minima;
  - flavectomia homonima;
  - identificacion y proteccion de la raiz;
  - diseccion y extraccion del fragmento discal extruido;
  - constatacion de raiz liberada, saco dural pulsatil y ausencia de compresion residual evidente;
  - hemostasia, retiro del sistema tubular, cierre por planos y cura.
- Si el medico indica que no fue tubular, redactar abordaje abierto/convencional y no mencionar sistema tubular.

## Parte quirurgico fijacion/descompresion lumbar

- El parte de fijacion lumbar no debe quedarse en formula generica de `abordaje, tornillos y cierre`.
- Debe consignar una secuencia operatoria reconstruible:
  - decubito prono bajo anestesia general;
  - proteccion ocular y acolchado de puntos de apoyo;
  - pulsos pedios;
  - antisepsia y campos;
  - marcacion radioscopica del nivel;
  - abordaje posterior mediano o miniinvasivo segun dato del caso;
  - exposicion del arco posterior y puntos de entrada pedicular;
  - colocacion de tornillos transpediculares bajo reparos anatomicos y control radioscopico;
  - descompresion neural con laminectomia/hemilaminectomia, flavectomia, liberacion de recesos/foramenes;
  - identificacion y proteccion de saco dural y raiz comprometida;
  - si es circunferencial/TLIF/PLIF: facetectomia/descompresion lateral, discectomia, preparacion intersomatica, injerto y caja/celda;
  - colocacion de barras, reduccion/compresion si se realizo y chequeo radioscopico del material;
  - constatacion de liberacion neural, estabilidad del montaje, hemostasia y ausencia de compresion residual evidente;
  - injerto posterolateral si fue utilizado, cierre por planos y cura.
- Nivel, lateralidad, tipo de abordaje, implantes, lotes, drenaje y perdida hematica se completan con datos del caso.
- Cuando el nivel este informado en fijacion lumbar simple, no escribir `niveles planificados`: consignar los cuerpos vertebrales instrumentados si se pueden inferir del nivel, por ejemplo `L4 y L5 bilateralmente`.
- Si se informa caja/celda intersomatica, PLIF/TLIF, altura, material o PMMA, incorporarlo en la tecnica operatoria y no dejarlo como formula generica.

## Consentimientos

- No usar el consentimiento generico de la app como salida principal cuando exista consentimiento madre aprobado por Jarvis.
- La estructura formal del consentimiento de hernia de disco lumbar queda como molde maestro para el resto: titulo, lugar y fecha, identificacion del paciente, diagnostico, autorizacion del procedimiento, bloque `Se me informo especialmente`, alternativas/no tratamiento, transfusion/hemoderivados, anestesia, preguntas/segunda opinion/revocacion, ausencia de garantia de resultado, controles postoperatorios, uso documental y firmas.
- Para cada patologia cambia el contenido clinico-legal especifico, pero no el orden ni la logica del consentimiento.
- Fuente recuperada de Jarvis: `data/derived/consent_canonicals/consent_canonical_index_2026-05-19.json`.
- Cuerpo textual normalizado para la app: `data/derived/consent_canonicals/consent_body_pack_2026-05-19.json`.
- Ese indice distingue `approved_exact`, `approved_pathology` y `operational_derived`; la app no debe tratar como aprobado un consentimiento marcado como derivado operativo o pendiente de validacion.
- Los documentos `operational_derived` pueden usarse como cuerpo de trabajo interno, pero deben conservar su estado pendiente y no presentarse como consentimiento definitivo aprobado hasta validacion explicita.
- Para `hernia de disco lumbar`, usar el master aprobado de Clinica Centro y carpeta canonica Jarvis:
  - `plantillas/consentimiento_hernia_disco_lumbar_clinica_centro_master.html`
  - `canonicos/consentimientos/hernia_disco_lumbar`
- Para `canal estrecho lumbar con fijacion` o fijacion/descompresion lumbar degenerativa, usar el master aprobado de Clinica Centro y PDF/modelo enviado por el Dr. Zanardi el 19/05/2026:
  - `tmp/consentimiento_canal_estrecho_l4_l5_fijacion_clinica_centro_14052026_legal_master.html`
  - `plantillas/consentimiento_fijacion_descompresion_lumbar_degenerativa_clinica_centro_master.html`
  - `canonicos/consentimientos/canal_estrecho_lumbar_con_fijacion`
- Mantener en el consentimiento: diagnostico, procedimiento autorizado, finalidad, riesgos especificos, alternativas, consecuencias de no tratar, transfusion/hemoderivados, anestesia, ausencia de garantia de resultado, cuidados postoperatorios, uso documental, segunda opinion, revocacion y firmas.
- El consentimiento debe adaptarse por patologia y nivel/lateralidad, no redactarse como explicacion conversacional de IA.
- Todo consentimiento debe poder exportarse con logo institucional a HTML, Word o PDF desde el cuerpo canonico, sin depender de texto visible de auditoria dentro del documento del paciente.

## Cervical / laminoplastia

- En la historia clinica cervical no usar alternativas tipo `mielopatia o compromiso neurologico`.
- Si el caso es canal estrecho cervical con laminoplastia, la frase madre preferida es:
  - `mielopatia cervical por estenosis de canal con correlacion clinica e imagenologica.`
- La enfermedad actual no debe empezar con `cuadro clinico compatible con`. Debe arrancar directamente con el sintoma/signo principal:
  - `Trastorno de la marcha, torpeza manual, parestesias y signos de compromiso medular cervical...`
- Evitar `deficit motor o sensitivo` y `si corresponden` en la enfermedad actual visible. Redactar hallazgos concretos o signos de compromiso medular cervical.
- Si el medico indico laminoplastia, no ofrecer en la operacion visible `laminoplastia o laminectomia`.
- Redaccion preferida de operacion: `laminoplastia cervical expansiva descompresiva` o `laminoplastia cervical descompresiva` con niveles definitivos.
- Solo usar `laminectomia` si el medico la indico expresamente en el caso.

## Inicio de enfermedad actual

- Preferir `Paciente que presenta...`.
- Evitar arranques impersonales o redundantes como `el paciente presenta...` dentro de la historia clinica.
- No imprimir `Relato de origen` ni marcas internas del input en la historia clinica. El texto libre del medico sirve para interpretar el caso, no como bloque literal visible.
- No imprimir bloques de auditoria interna como `Trazabilidad clinica` dentro de la HC. Esa informacion puede estar en panel lateral o verificacion, pero no en el documento clinico visible.
