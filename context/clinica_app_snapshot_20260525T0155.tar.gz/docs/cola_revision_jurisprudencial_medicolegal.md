# Cola priorizada de revisión jurisprudencial medicolegal

Estado: `pending_review`
Fecha de corte: 2026-05-20T03:43:17Z
Origen estructurado: `data/processed/legal_corpus/jurisprudencia_candidates_2026-05-18.json`
Modo: `detect_only`. Ningún candidato activa reglas ni citas operativas sin revisión humana/Codex Guard.

## Objetivo
Traducir el lote detectado por SAIJ a una cola de lectura útil para fortalecer el corpus con precedentes más directamente vinculados a historia clínica, consentimiento informado y seguridad quirúrgica.

## Prioridad alta, lectura primero

| Bucket | Candidato | Fecha | Tribunal visible | Valor redaccional | Próxima ruta verificable |
|---|---|---:|---|---|---|
| historia_clinica | `recurso-extraordinario-responsabilidad-medica-mala-praxis-establecimientos-asistenciales-historia-clinica-falta-prueba-sua0061444` | 2002-09-19 | no visible en raw | Ayuda a fijar cómo pesa la historia clínica como prueba y qué pasa cuando falta o no puede recuperarse bien | Intentar ficha completa/sumario en SAIJ y, si no aparece texto completo, conservar friendly URL + resumen estructurado |
| historia_clinica | `camara-apelaciones-civil-comercial-local-entre-rios-lubo-ricardo-nicanor-publiese-canio-sumario-inc-impugnacion-autenticidad-historia-clinica-fa98080737-1998-03-03` | 1998-03-03 | Cámara de Apelaciones Civil Comercial | Directo para autenticidad, integridad y riesgo de correcciones silenciosas | Buscar sumario completo/ficha oficial y derivar reglas de addenda/versionado |
| consentimiento | `juzgado-civil-personas-familia-1ra-nominacion-local-salta-esteban-ivana-medida-autosatisfactiva-acceso-informacion-al-consentimiento-informado-fa21170005-2021-04-29` | 2021-04-29 | Juzgado Civil de Personas y Familia de 1ra Nominación | Útil para probar que acceso material a la información y al consentimiento también se litiga | Priorizar por actualidad y porque conecta con copia entregada, lectura y reconsulta |
| consentimiento | `responsabilidad-medica-obligaciones-medios-diagnostico-medico-medicos-analisis-clinicos-error-excusable-obligaciones-resultado-error-diagnostico-suw0003079` | 2020-09-02 | no visible en raw | Refuerza obligación de explicitar razonamiento clínico y estándar de medios | Buscar ficha/sumario más robusto y enlazarlo a reglas de indicación y correlación clínico-radiológica |
| consentimiento | `danos-perjuicios-responsabilidad-medica-responsabilidad-establecimientos-asistenciales-mala-praxis-oblito-quirurgico-error-material-presuncion-culpa-sun0007036` | 1996-06-06 | no visible en raw | Fuerte para recuentos, control final e incidentes intraoperatorios | Priorizar como precedente para parte quirúrgico y seguridad de cierre |
| seguridad_quirurgica | `camara-nacional-apelaciones-criminal-correccional-nacional-ciudad-autonoma-buenos-aires-adalid-enrique-lesiones-culposas-operacion-quirurgica-negligencia-medica-fa78060053-1978-04-25` | 1978-04-25 | CNCrim y Corr | Conecta parte quirúrgico con exposición penal por lesiones culposas | Buscar sumario/ficha y extraer controles, secuencia y respuesta ante desvíos |
| seguridad_quirurgica | `corte-suprema-justicia-nacion-federal-ciudad-autonoma-buenos-aires-silvia-carroza-shiroma-otro-hospital-italiano-otros-procedencia-recurso-extraordinario-sentencias-arbitrarias-valoracion-circunstancias-hecho-prueba-danos-perjuicios-responsabilidad-medica-negligencia-obras-sociales-fa86000102-1986-03-20` | 1986-03-20 | CSJN | Útil para valorar hechos, prueba y arbitrariedad en responsabilidad médica | Priorizar para bajar criterios de cronología y consistencia documental |
| seguridad_quirurgica | `responsabilidad-establecimientos-asistenciales-medico-anestesista-intervencion-quirurgica-traslado-paciente-muerte-valor-vida-indemnizacion-computo-intereses-tasa-activa-sun0008807` | 1999-11-04 | no visible en raw | Relevante para transición quirófano, anestesia y recuperación | Buscar texto/sumario y derivar regla de egreso de quirófano + receptor responsable |

## Prioridad media, mantener en cola
- `error-inexcusable-responsabilidad-medica-sul0006214`
- `responsabilidad-medica-error-inexcusable-suq0016682`
- `responsabilidad-establecimientos-asistenciales-muerte-traslado-paciente-medico-anestesista-intervencion-quirurgica-dano-moral-computo-intereses-tasa-activa-sun0008806`

## Prioridad alta neurocirugía/columna, ya cargada al tamiz

Artifact rector: `data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_corpus_latest.json`

| Bucket | ID | Caso/fuente | Confiabilidad | Valor redaccional | Próxima ruta verificable |
|---|---|---|---|---|---|
| indicacion_columna | `NSJ-005` | `V. L. M. N. c/ E. R. J.` | secundaria pública | Cirugía programada de columna exige indicación concreta y alternativas/fracaso conservador | Conseguir copia oficial o ficha judicial completa; mantener como candidato si no aparece |
| hernia_lumbar | `NSJ-006` | `R. C. c/ FLENI` | secundaria pública | Hernia, infección/recidiva y seguimiento: no alcanza el resultado; importan consentimiento, controles y evolución | Buscar expediente/fallo oficial Cámara Civil Sala J |
| control_implantes | `NSJ-008` | `Q. C. B. c/ A. E.` | secundaria pública | Para columna con implantes refuerza control de rayos/radioscopia y chequeo del material | Buscar copia oficial SCJ Mendoza |
| consentimiento_hernia | `NSJ-009` | `Villacura c/ Pilafis y Clínica Roca` | judicial oficial texto completo | Consentimiento específico de hernia lumbar y seguimiento posoperatorio | Mantener como fuente oficial; extraer próximos criterios de evolución |
| pericia_columna | `NSJ-010` | `Marchan c/ Gómez/Labat/Sanatorio Juan XXIII` | judicial oficial texto completo | Pericia futura reconstruye indicación, técnica, eventos y seguimiento | Mantener como fuente oficial; revisar si aporta lenguaje de parte quirúrgico |
| procedimientos_columna | `NSJ-011` | `Olivares c/ Sanatorio Juan XXIII` | judicial oficial texto completo | Bloqueos/peridurales también requieren indicación, consentimiento, técnica y evolución | Usar para plantillas de infiltración/bloqueos, no mezclar con cirugía abierta |
| neuroemergencia | `NSJ-012` | `Gómez Franco - hemorragia cerebral/derivación` | judicial oficial texto completo | Urgencias neuro: horarios, examen, medidas, comunicaciones, derivación | Mantener para evolución/guardia/traslado |
| neuro_craneal | `NSJ-007` | `M. G. L. c/ Hospital Alemán` | secundaria pública | Incidente vascular neuroquirúrgico: detección, control, equipos convocados y estado final | Buscar copia oficial Cámara Civil Sala C |
| neuro_craneal | `NSJ-014` | `Echenique c/ Pardal` | SAIJ sumario oficial | Aneurisma/HSA: oportunidad diagnóstica, cirugía temprana y pasos esenciales de craneotomía | Buscar texto completo si se va a citar fuera del tamiz |
| historia_clinica | `NSJ-015` | `González c/ F.L.E.N.I.` | SAIJ sumario oficial | Historia clínica/epicrisis por días y horas, sin enmiendas, firma/sello; infección institucional | Mantener como regla institucional e integridad documental |
| anestesia_columna | `NSJ-016` | `Fantini c/ Clínica Roca` | judicial oficial texto completo | Cirugía de columna + intubación: documentar marco anestésico, posición, protección y transición | Usar para no mezclar parte quirúrgico con registro anestésico, pero sí dejar cadena del acto |

## Reglas neuro/columna ya derivadas
1. En columna programada, la historia debe unir síntomas, examen, imagen, nivel/lateralidad/raíz e indicación.
2. En hernia y canal, no inventar déficit motor o reflejos; solo consignarlos si fueron informados.
3. En parte quirúrgico de columna, radioscopia para nivel; chequeo del material solo cuando hay implantes.
4. En consentimiento neuroquirúrgico, patología, procedimiento, beneficios, riesgos propios, alternativas, no tratamiento y revocación no pueden quedar como texto genérico.
5. En urgencia neurológica, horarios, comunicaciones, medidas y derivación pesan más que una fórmula administrativa.
6. En historia clínica/evolución/epicrisis, integridad, firma, hora y addenda visible son parte del tamiz, no un detalle administrativo.

## Excluidos por ahora
- `confirmacion-sentencia-medidas-cautelares-mercado-cambiario-dolares-intervencion-quirurgica-suk0030250`
  - Motivo: `out_of_scope_non_medicolegal_match`

## Reglas operativas para el siguiente lote
1. Si el texto completo no aparece, conservar friendly URL, fecha, tribunal visible, bucket y resumen estructurado como evidencia mínima trazable.
2. No promover ningún candidato a regla `active` solo por coincidencia de búsqueda.
3. Separar claramente candidatos de historia clínica, consentimiento y seguridad quirúrgica para no contaminar buckets.
4. Si una ruta oficial falla, registrar el bloqueo y mantener la evidencia estructurada ya capturada; no borrar candidatos útiles.
5. En neuro/columna, las fuentes secundarias solo alimentan tamiz interno y cola de búsqueda oficial; no se citan en documentos clínicos ni se muestran al paciente.

## Impacto inmediato sobre el corpus
- Refuerza la cola de revisión donde más pesa la futura redacción real del doctor: autenticidad de historia clínica, acceso al consentimiento, parte quirúrgico, recuentos, egreso de quirófano y cronología de incidentes.
- Reduce el riesgo de seguir agregando normativa sin bajar suficiente jurisprudencia práctica.
- Deja un orden verificable de lectura/adquisición para el próximo microciclo útil de CLI-001.
