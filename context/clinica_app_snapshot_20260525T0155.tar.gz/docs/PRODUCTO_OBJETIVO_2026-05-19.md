# Producto objetivo, app clínica médico-legal

## Norte del producto

La salida principal debe ser:
- historia clínica completa base,
- parte quirúrgico completo base,
- con tono y estructura cercanos a los modelos reales del Dr. Zanardi,
- y tamiz médico-legal embebido, sin estorbar el flujo.

## Flujo deseado

1. El médico envía audio o texto coloquial.
2. La app detecta la familia clínica/patología.
3. La app carga una plantilla madre robusta por familia y documento.
4. La app reemplaza lo variable del caso.
5. La app enriquece el texto con redacción estándar defensiva solo cuando exista fundamento médico-legal o documental.
6. La app marca solo los faltantes realmente sensibles para revisión final.
7. El médico revisa, corrige mínimo y usa el documento como punto de partida real.

## Regla de enriquecimiento

La app no debe inventar hechos del paciente.

Sí puede agregar:
- estructura narrativa estándar,
- puentes de redacción clínica,
- formulaciones prudentes de indicación, información brindada, correlación clínico-radiológica, evolución esperable y cierre del acto,
- recordatorios de contenido crítico cuando exista base normativa, jurisprudencial o documental suficiente.

## Regla de seguridad práctica

Clasificar cada pieza del texto en tres grupos:

### A. Dato confirmado del caso
Proviene del audio/texto, plantilla base ya validada o dato explícito ingresado.
Se redacta como hecho del paciente.

### B. Redacción estándar defensiva permitida
No afirma un hecho nuevo singular, pero mejora cobertura documental.
Se puede insertar automáticamente.
Ejemplos:
- objetivos, riesgos, beneficios y alternativas fueron explicados,
- evolución postoperatoria inmediata sin incidentes evidentes,
- conducta basada en cuadro clínico e imágenes concordantes,
- control evolutivo e indicaciones postoperatorias.

### C. Dato crítico no inventable
Debe quedar marcado para confirmar o completar.
Ejemplos:
- fecha y hora exactas,
- ayudantes,
- hallazgos intraoperatorios específicos,
- lotes/marcas/series de implantes,
- complicaciones reales,
- examen neurológico específico,
- destino, drenajes e indicaciones nominales.

## Objetivo UX

La app debe resolver casi todo y frenar solo en lo verdaderamente riesgoso.
No debe comportarse como auditoría académica ni como checklist molesto.
Debe parecerse más a una plantilla inteligente de Word que a un sistema restrictivo.

## Implementación mínima recomendada

### 1. Plantillas madre por familia clínica
- HC lumbar HDL
- HC fijación lumbar MISS/circunferencial
- HC cervical mielopatía/laminoplastia
- Parte quirúrgico por familia
- Evolución postoperatoria base por familia

### 2. Diccionario de variables por caso
- paciente
- edad
- diagnóstico
- nivel
- lateralidad
- síntomas
- estudios
- procedimiento
- institution/logo
- cirujano/equipo

### 3. Capa de enriquecimiento defensivo trazable
Cada agregado estándar debe tener:
- etiqueta interna de fundamento,
- referencia a ley/regla/criterio documental,
- posibilidad de auditoría interna posterior.

### 4. Modo salida simple
El médico no debe ver la complejidad interna.
Debe recibir principalmente:
- documento base,
- pocos resaltados sensibles,
- y si hace falta un mini resumen de qué completar.

## Criterio de éxito

Éxito = ahorrar tiempo real al médico, mantener tono cercano a sus modelos, elevar cobertura documental y reducir omisiones peligrosas sin complicar el uso.
