# Fuentes de actualización medicolegal argentina, modo detect-only

Estado: `pending_review`
Fecha de corte: 2026-05-20T15:20:48Z
Modo operativo: `detect_only`. Ninguna fuente, cambio, regla o cita nueva se activa automáticamente sin revisión humana/Codex Guard.

## Objetivo
Monitorear fuentes oficiales o estructuradas que puedan cambiar cómo conviene redactar historias clínicas, consentimientos y partes quirúrgicos en Argentina.

## Principios del updater
1. Guardar raw inmutable con `sha256`, `fetched_at`, URL oficial y URL final.
2. Detectar cambios por hash o aparición de nueva fuente/candidato.
3. Encolar todo hallazgo en `change_candidates`/`review_queue` o resumen QA equivalente.
4. No publicar ni activar reglas automáticamente.
5. Separar cambios por capa: `normativo`, `jurisprudencia`, `doctrina`, `interno`.

## Fuentes priorizadas del lote actual

### Normativo oficial
- InfoLEG, Ley 26.529, Derechos del Paciente  
  URL: https://servicios.infoleg.gob.ar/infolegInternet/anexos/160000-164999/160432/norma.htm  
  Raw: `data/raw/legal/norm_ley_26529_infoleg.html`
- InfoLEG, Ley 17.132, ejercicio de la medicina  
  URL: https://servicios.infoleg.gob.ar/infolegInternet/anexos/15000-19999/19429/texact.htm  
  Raw: `data/raw/legal/norm_ley_17132_infoleg.html`
- InfoLEG, Ley 25.326, protección de datos personales  
  URL: https://servicios.infoleg.gob.ar/infolegInternet/anexos/60000-64999/64790/texact.htm  
  Raw: `data/raw/legal/norm_ley_25326_infoleg.html`
- InfoLEG, Ley 25.506, firma digital  
  URL: https://servicios.infoleg.gob.ar/infolegInternet/anexos/70000-74999/70749/norma.htm  
  Raw: `data/raw/legal/norm_ley_25506_firma_digital_infoleg.html`
- InfoLEG, Código Civil y Comercial de la Nación, Ley 26.994  
  URL: https://servicios.infoleg.gob.ar/infolegInternet/anexos/235000-239999/235975/norma.htm  
  Raw: `data/raw/legal/norm_cccn_ley_26994_infoleg.html`
- InfoLEG, Decreto 1089/2012 reglamentario de Ley 26.529  
  URL: https://servicios.infoleg.gob.ar/infolegInternet/anexos/195000-199999/199296/norma.htm  
  Raw: `data/raw/legal/norm_dec_1089_2012_infoleg.html`
- InfoLEG, Código Penal de la Nación Argentina, Ley 11.179  
  URL: https://servicios.infoleg.gob.ar/infolegInternet/anexos/15000-19999/16546/texact.htm  
  Raw: `data/raw/legal/norm_codigo_penal_ley_11179_infoleg.html`
- Argentina.gob.ar Derecho Fácil, derechos del paciente (apoyo interpretativo, no texto rector)  
  URL: https://www.argentina.gob.ar/justicia/derechofacil/leysimple/derechos-del-paciente  
  Raw: `data/raw/legal/norm_derechos_paciente_argentina_gob.html`
- Argentina.gob.ar, reglamentación de Ley 27.706 y Decreto 393/2023 sobre sistema único de historias clínicas  
  URL: https://www.argentina.gob.ar/noticias/el-gobierno-nacional-reglamento-la-ley-que-crea-un-sistema-unico-de-informatizacion-de-las  
  Raw: `data/raw/legal/norm_ley_27706_decreto_393_2023_argentina_gob.html`
- InfoLEG, Ley 27.706, texto primario oficial capturado  
  URL: https://servicios.infoleg.gob.ar/infolegInternet/anexos/380000-384999/380710/norma.htm  
  Raw: `data/raw/legal/norm_ley_27706_infoleg.html`  
  Estado: `pending_review`, captura estructurada disponible. La vieja ruta `verNorma.do?id=386179` queda solo como evidencia bloqueada/histórica, no como fuente principal.
- InfoLEG, Decreto 393/2023 reglamentario de Ley 27.706  
  URL: https://servicios.infoleg.gob.ar/infolegInternet/anexos/385000-389999/387475/norma.htm  
  Raw: `data/raw/legal/norm_dec_393_2023_infoleg.html`
- Provincia de Buenos Aires, Ley 14.494 de historia clínica electrónica única  
  URL: https://normas.gba.gob.ar/ar-b/ley/2013/14494/11338  
  Raw: `data/raw/legal/norm_ley_14494_pba.html`
- Provincia de Buenos Aires, Decreto 1600/2024 reglamentario de Ley 14.494  
  URL: https://normas.gba.gob.ar/ar-b/decreto/2024/1600/451942  
  Raw: `data/raw/legal/norm_dec_1600_2024_pba.html`
- Argentina.gob.ar / InfoLEG, Decreto 182/2019 reglamentario de firma digital  
  URL: https://www.argentina.gob.ar/normativa/nacional/decreto-182-2019-320735/texto  
  Raw: `data/raw/legal/norm_dec_182_2019_firma_digital_argentina_gob.html`
- Argentina.gob.ar, Decreto 1558/2001 reglamentario de datos personales  
  URL: https://www.argentina.gob.ar/normativa/nacional/decreto-1558-2001-70368/texto  
  Raw: `data/raw/legal/norm_dec_1558_2001_datos_personales_argentina_gob.html`
- Argentina.gob.ar, Ley 27.553 sobre recetas electrónicas/digitales y teleasistencia  
  URL: https://www.argentina.gob.ar/normativa/nacional/ley-27553-340919/texto  
  Raw: `data/raw/legal/norm_ley_27553_receta_teleasistencia_argentina_gob.html`
- Argentina.gob.ar, `Mi historia clínica` con referencia operativa a soporte digital y pista de norma local CABA  
  URL: https://www.argentina.gob.ar/mi-historia-clinica  
  Raw: `data/raw/legal/norm_historia_clinica_mi_historia_clinica_argentina_gob.html`
- Referencia estructurada secundaria a Ley 5669 CABA detectada desde `Mi historia clínica`, con bloqueo 403 en SAIJ  
  URL detectada: http://www.saij.gob.ar/5669-local-ciudad-autonoma-buenos-aires-creacion-sistema-integrador-historias-clinicas-electronicas-registro-historias-clinicas-electronicas-lpx0005669-2016-10-27/123456789-0abc-defg-966-5000xvorpyel  
  Raw: `data/raw/legal/norm_ley_5669_caba_saij_reference_blocked_2026-05-18.md`

### Jurisprudencia estructurada
- SAIJ búsqueda `historia clinica prueba`  
  URL: https://www.saij.gob.ar/busqueda?o=0&f=Total%7CTipo+de+Documento/Jurisprudencia&q=historia+clinica+prueba  
  Raw: `data/raw/jurisprudence/jur_saij_historia_clinica_prueba.json`
- SAIJ búsqueda `responsabilidad medica consentimiento`  
  URL: https://www.saij.gob.ar/busqueda?o=0&f=Total%7CTipo+de+Documento/Jurisprudencia&q=responsabilidad+medica+consentimiento  
  Raw: `data/raw/jurisprudence/jur_saij_responsabilidad_medica_consentimiento.json`
- SAIJ búsqueda `consentimiento informado medico`  
  URL: https://www.saij.gob.ar/busqueda?o=0&f=Total%7CTipo+de+Documento/Jurisprudencia&q=consentimiento+informado+medico&format=json  
  Raw: `data/raw/jurisprudence/jur_saij_consentimiento_informado_medico.json`
- SAIJ búsqueda `operacion quirurgica negligencia medica`  
  URL: https://www.saij.gob.ar/busqueda?o=0&f=Total%7CTipo+de+Documento/Jurisprudencia&q=operacion%20quirurgica%20negligencia%20medica&format=json  
  Raw: `data/raw/jurisprudence/jur_saij_operacion_quirurgica_negligencia_medica.json`

### Jurisprudencia neurocirugía y cirugía de columna
- Corpus específico neuro/columna, con fuentes oficiales y secundarias separadas  
  Artifact: `data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_corpus_latest.json`  
  Matriz: `data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_impact_matrix_latest.md`  
  Estado: `review_only_detect_only`; primer corte trazable, no exhaustividad absoluta.
- SAIJ, dossier oficial de mala praxis médica, con sumarios sobre neurocirugía, diagnóstico, riesgo quirúrgico y rol del equipo  
  URL: https://www.saij.gob.ar/docs-f/dossier-f/mala_praxis_medica.pdf
- Poder Judicial de Río Negro, fallos oficiales de columna/neuroemergencia incorporados al primer corte  
  URLs: `Villacura c/ Pilafis`, `Marchan c/ Gómez`, `Olivares c/ Sanatorio Juan XXIII`, `Gómez Franco - emergencia neurológica`, `Fantini c/ Clínica Roca` y `Avendaño c/ Gómez/Sanatorio Juan XXIII` en `fallos.jusrionegro.gov.ar`
- SCBA/JUBA, textos completos oficiales incorporados como refuerzo bonaerense  
  URLs: `I., A. S. c/ Clínica y Maternidad María Auxiliadora` (`idFallo=180817`) y `M., E. y otros c/ Hospital Municipal Vicente López` (`idFallo=30512`) en `juba.scba.gov.ar`
- MPF, dictamen oficial `C.P. c/ P.S.R.` como alerta jurisdiccional/competencia, sin usarlo como precedente material de fondo  
  URL: https://www.mpf.gob.ar/dictamenes/2025/VAbramovich/agosto/C_P_CIV_2343_2025_CS1.pdf
- Fuentes secundarias públicas usadas solo como candidatos hasta obtener copia oficial: Microjuris/Al Día Argentina e Infojudicial para artrodesis lumbar, FLENI hernia/infección, Hospital Alemán hipófisis/carótida y SCJ Mendoza columna con implantes.
- Doctrina separada de jurisprudencia: Revista Argentina de Neurocirugía/AANC sobre consentimiento informado en neurocirugía. No se promueve como norma ni como fallo.

## Snapshots internos ya monitoreados
- Snapshot raw de doctrina y criterios operativos: `data/raw/doctrine/doctrina_criterios_operativos_snapshot_2026-05-18.md`
- Snapshot raw de reglas internas de redacción: `data/raw/internal/interno_reglas_redaccion_snapshot_2026-05-18.md`
- Snapshot raw de fuentes detect-only y colas de revisión: `data/raw/internal/interno_fuentes_detect_only_snapshot_2026-05-18.md`

## Próxima expansión prioritaria
- Mantener control de cambios de Ley 27.706 y Decreto 393/2023 desde las rutas oficiales ya capturadas; no volver a usar `verNorma.do?id=386179` como fuente principal.
- Mantener control de cambios de Ley PBA 14.494 y Decreto PBA 1600/2024 por impacto directo en HIGA Junín y prestadores bonaerenses.
- Reintentar por vía oficial/estructurada accesible la norma local citada por `Mi historia clínica` para CABA (Ley 5669 de historias clínicas electrónicas); ya quedó guardada la referencia detectada y el primer bloqueo 403 de SAIJ para no perder trazabilidad.
- Mantener bajo seguimiento el bloque ya priorizado de artículos: Ley 26.529 arts. 2, 5, 6, 11-15; Dec. 1089/2012 arts. 2, 5, 12-15; CCCN arts. 51-59, 1710, 1716, 1724-1726, 1737; CP arts. 84, 94, 106 y 156.
- Fallos SAIJ con texto completo o sumario robusto sobre consentimiento informado, autenticidad de historia clínica y parte quirúrgico, incluyendo el nuevo bucket de `operacion_quirurgica_negligencia_medica`.
- Fallos neurocirugía/columna: buscar copia oficial de los 4 candidatos hoy marcados `secondary_full_text_pending_official_copy` y ampliar por Cámara Civil, CSJN, SAIJ, CIJ, Microjuris como detector, bases provinciales y buscadores judiciales locales.
- Consultas de actualización neuro/columna ya preservadas en el corpus: `neurocirugía mala praxis`, `cirugía columna mala praxis`, `hernia de disco cirugía mala praxis`, `artrodesis lumbar responsabilidad médica`, `lesión dural cirugía columna`, `consentimiento informado neurocirugía`, `control radioscópico columna implantes`, `Echenique Pardal aneurisma`, `González FLENI historia clínica`, `Fantini Clínica Roca columna intubación`.
- Mantener en seguimiento Decreto 182/2019, Decreto 1558/2001 y Ley 27.553 como complementarias para firma, datos e indicaciones digitales.
- Si aparece fuente doctrinaria útil, tratarla como `pending_review`, nunca como norma.

## Salida esperada del updater
- Resumen JSON en `qa/approval_gates/medicolegal_update_detect_only_summary.json`
- Índices procesados en `data/processed/legal_corpus/index_latest.json` y `data/processed/legal_corpus/jurisprudencia_candidates_latest.json` (además de snapshots fechados).
- `change_candidates` con `change_type`, `layer`, `sha256_before`, `sha256_after`, `final_url` y `review_bucket`
- Conteo de fuentes monitoreadas, capas cubiertas y brechas abiertas
- `pending_review_queue` con `artifact` real y prioridad
- Cola priorizada de revisión jurisprudencial separando `historia_clinica`, `consentimiento`, `seguridad_quirurgica`, `error_inexcusable` y `jurisprudencia_general`
- `risk_delta` con conteos de riesgo pendientes por bucket crítico y filtro explícito de falsos positivos/out-of-scope
- `excluded_items` cuando una coincidencia estructurada no sea medicolegal sino ruido de búsqueda, para no contaminar reglas ni colas de revisión

## Criterio de seguridad
Si una fuente falla por 403/429 o cambia formato, registrar el bloqueo y conservar la última evidencia válida; no promover una inferencia del modelo como si fuera cita vigente.
