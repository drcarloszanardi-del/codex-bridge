# Matriz de impacto redaccional para historias clínicas y partes quirúrgicos

Estado: `BASE_AVANZADA_REVIEW_ONLY`
Fecha de corte: 2026-05-19T05:45:00Z

## Gate formal de 6 controles, corte 2026-05-19
- Estado operativo de la matriz: `BASE_AVANZADA_REVIEW_ONLY`.
- Uso permitido: checklist visible para tamiz prudente de HC y parte quirúrgico en modo `review_only`.
- Uso no permitido: cierre legal terminal, activación productiva o afirmaciones de cumplimiento integral.
- Cobertura mínima confirmada por esta matriz:
  1. identificación completa de paciente, episodio, fecha, hora y autor;
  2. consentimiento con contenido material y acceso/copia;
  3. parte quirúrgico con técnica, hallazgos, cronología, complicaciones/no complicaciones y control final;
  4. addendas sin borrado con autor, fecha y hora;
  5. confidencialidad y acceso mínimo a datos sensibles;
  6. integridad, autenticidad y auditoría del registro electrónico.

| Campo/documento afectado | Riesgo medicolegal | Fuente/fundamento | Regla de redacción | Ejemplo de frase segura | Alerta de omisión |
|---|---|---|---|---|---|
| Identificación del paciente y episodio | Confusión de autoría, paciente o episodio asistencial | Ley 26.529 arts. 12-15 + Dec. 1089/2012 arts. 12 y 15 | Abrir cada registro con identidad suficiente, fecha, hora y contexto asistencial | "Paciente identificado como ..., evaluado el 18/05/2026 a las 07:30 h en consultorio de columna" | Nota anónima o sin contexto temporal debilita valor probatorio |
| Profesional interviniente | Duda sobre autoría y responsabilidad del acto | Ley 17.132 + Dec. 1089/2012 art. 12 | Consignar nombre, especialidad/cargo y firma o equivalente trazable | "Evalúa Dr. ..., MN ..., especialista en neurocirugía" | Indicación sin autor identificable |
| Trato digno, intimidad y acceso a la información | Reclamo por trato inadecuado, ocultamiento o falta de acceso posterior | Ley 26.529 art. 2 + CCCN arts. 51-52 | Redactar en tono sobrio, clínico y verificable; dejar constancia de qué se informó y cómo puede acceder el paciente a su documentación | "Se explica evolución, conducta y plan; paciente comprende y se informa canal para solicitar copia de documentación" | Nota descalificadora, paternalista o sin registro de información brindada |
| Motivo de consulta y anamnesis | Dificultad para justificar conducta | Ley 26.529 arts. 12-15 + CCCN arts. 1724-1726 | Registrar síntoma principal, tiempo de evolución y antecedentes relevantes | "Consulta por lumbociatalgia derecha de 6 meses, refractaria a tratamiento conservador" | Evolución posterior sin punto de partida claro |
| Examen físico neurológico/columna | Alegación de evaluación incompleta | CCCN arts. 1710, 1724 y 1725 | Dejar hallazgos positivos y negativos útiles, no solo "sin particularidades" | "Fuerza EHL 4/5 derecha, Lasègue positivo a 40°, hipoestesia L5" | Imposible correlacionar clínica con indicación |
| Estudios complementarios | Cuestionamiento de correlación clínica | CCCN arts. 1725-1726 + criterio clínico-radiológico | Mencionar estudio, fecha y hallazgo relevante vinculado a la conducta | "RM 12/05/2026: hernia L4-L5 posterolateral derecha concordante con clínica" | Se cita cirugía sin soporte objetivo visible |
| Diagnóstico y justificación | Falta de racionalidad médica explicitada | CCCN arts. 1710, 1716 y 1725 | Separar diagnóstico presuntivo/confirmado y explicar por qué se indica conducta | "Se indica microdiscectomía por dolor radicular persistente, déficit y fracaso de manejo conservador" | Conducta parece arbitraria |
| Consentimiento informado | Falta de información suficiente | Ley 26.529 arts. 5-6 + CCCN art. 59 + Dec. 1089/2012 art. 5 | Dejar constancia de riesgos, beneficios, alternativas, preguntas y aceptación/rechazo | "Se informan beneficios, riesgo de infección, sangrado, lesión neural, reoperación y alternativas conservadoras" | Firma aislada sin contenido material |
| Consentimiento: entrega/acceso a copia | Conflicto sobre accesibilidad real del consentimiento y de la información brindada | Ley 26.529 arts. 2, 5 y 14 + Dec. 1089/2012 art. 5 + SAIJ acceso a consentimiento informado | Registrar si se entregó copia, si quedó disponible y si el paciente o su representante pudo leer/preguntar | "Se entrega copia del consentimiento y se ofrece nueva lectura previa al procedimiento" | Existe formulario firmado pero luego no puede probarse acceso material al documento |
| Parte quirúrgico: equipo y anestesia | Lagunas sobre ejecución del acto | Ley 26.529 art. 15 + Dec. 1089/2012 art. 15 | Identificar equipo, anestesia, posicionamiento y abordaje | "Bajo anestesia general, en decúbito prono, se realiza abordaje posterior paramediano" | No puede reconstruirse la técnica real |
| Parte quirúrgico: hallazgos y técnica | Debate sobre lex artis y nexo causal | Ley 26.529 art. 15 + CCCN arts. 1725-1726 + SAIJ | Describir hallazgos intraoperatorios, pasos críticos, implantes/materiales y controles | "Se constata compresión radicular L4-L5; se realiza descompresión y fijación con tornillos pediculares..." | Parte genérico que no explica qué se hizo |
| Parte quirúrgico: complicaciones y hemostasia | Sospecha de ocultamiento | CCCN arts. 1710 y 1724 + deber de completitud | Declarar si hubo o no incidentes, sangrado estimado y cómo se resolvieron | "Sin complicaciones intraoperatorias visibles; hemostasia satisfactoria" | Silencio frente a eventos relevantes |
| Parte quirúrgico: control final y recuentos | Presunción de falla ante evento evitable | SAIJ sobre oblito quirúrgico + CP art. 94 | Dejar constancia de chequeos finales, recuentos o verificación equivalente según técnica y material utilizado | "Recuento de material e instrumental informado como completo antes del cierre" | Parte operatorio no explica control final ni medidas de seguridad |
| Parte quirúrgico: cronología intra y postevento | Dificultad para reconstruir diligencia, prevención o respuesta ante desvíos | CCCN arts. 1710, 1724-1726 + CP arts. 84 y 94 | Ordenar el parte por secuencia: inicio, hallazgo, maniobra, control, incidente, respuesta y estado final | "Durante la exposición se identifica..., luego se realiza..., ante sangrado venoso se controla con..., cierre sin nuevo evento" | La pericia encuentra hechos sin secuencia ni respuesta documentada |
| Traslado, anestesia y recuperación inmediata | Zona gris de responsabilidad entre equipo quirúrgico, anestesia y establecimiento | SAIJ traslado/anestesista/intervención quirúrgica + CCCN arts. 1724-1726 | Documentar paso a recuperación o UTI, condición de egreso de quirófano, responsable que recibe y eventos inmediatos | "Egresa de quirófano hemodinámicamente estable, ventilando espontáneamente; recibe anestesia/recuperación con indicaciones consignadas" | El evento adverso aparece después pero no puede reconstruirse la transición asistencial |
| Razonamiento clínico de la indicación | Acusación de arbitrariedad o error inexcusable | CCCN arts. 1710, 1724-1726 + SAIJ estándar de medios | Explicar por qué se adoptó la conducta elegida y qué alternativas fueron descartadas | "Se indica fijación por inestabilidad y fracaso de manejo conservador, explicadas alternativas no quirúrgicas" | Conducta invasiva sin fundamento narrado |
| Evolución y alta | Falta de seguimiento o advertencias | Ley 26.529 arts. 2 y 15 + CP art. 106 | Registrar evolución, indicaciones, signos de alarma y plan de control | "Alta con analgesia, control en 7 días y consulta inmediata ante fiebre o déficit progresivo" | Paciente queda sin instrucciones trazables |
| Prevención del daño y reconsulta | Debilitamiento de la defensa por omitir medidas preventivas o alertas | CCCN art. 1710 + CP art. 106 | Cerrar cada alta o pase con medidas preventivas, signos de alarma y conducta ante empeoramiento clínico | "Se indica reconsulta urgente ante retención urinaria, fiebre, dolor descontrolado o déficit motor progresivo" | El documento describe el acto pero no deja plan preventivo verificable |
| Confidencialidad y circulación de datos | Exposición indebida de datos sensibles o secreto profesional vulnerado | Ley 25.326 + CP art. 156 + CCCN arts. 51-53 | Limitar difusión a lo asistencialmente necesario, registrar destinatarios cuando se comparte y evitar datos o imágenes ajenas al acto | "Se entrega copia autenticada al paciente; no se remiten imágenes identificables a terceros sin base válida" | Circulación informal de datos o imágenes sin causa documentada |
| Autoría digital, integridad y no repudio | Impugnación de autenticidad del registro electrónico o de la addenda | Ley 25.506 + Dec. 1089/2012 art. 13 + Ley 26.529 art. 13 | Separar borrador, revisión y emisión; conservar huella de autor, fecha, hora y addenda sin borrado | "Addenda emitida el 18/05/2026 19:20 por Dr. ..., firmada digitalmente sobre registro original conservado" | Corrección silenciosa o imposibilidad de probar quién emitió/cambió el registro |
| Imágenes, videos y registros audiovisuales | Uso impropio de imagen/voz o material clínico fuera de finalidad asistencial | CCCN art. 53 + Ley 25.326 + secreto profesional | Diferenciar uso asistencial, docente, auditoría o comunicación; documentar base y resguardo | "Fotografía intraoperatoria incorporada a registro asistencial para documentación técnica, sin difusión externa" | Foto o video clínico circula sin finalidad documentada |
| Correcciones/addendas | Impugnación de autenticidad | Ley 26.529 art. 13 + Dec. 1089/2012 art. 15 + SAIJ autenticidad de historia clínica | No borrar; agregar adenda fechada con motivo y autor | "Addenda 18/05/2026 19:20: se incorpora resultado diferido de anatomía patológica" | Modificación silenciosa del texto original |

## Checklist mínimo trazable por tipo de documento

### Historia clínica / evolución
1. Identificación suficiente de paciente, episodio, fecha, hora y autor.
2. Motivo de consulta y evolución temporal concreta.
3. Antecedentes relevantes para la decisión tomada.
4. Examen físico útil con hallazgos positivos y negativos clínicamente pertinentes.
5. Estudios citados con fecha y correlación explícita con la clínica.
6. Diagnóstico presuntivo o confirmado, separado de la conducta.
7. Razonamiento de la conducta: por qué se elige y qué alternativas se descartan.
8. Información brindada al paciente y constancia de comprensión y preguntas realizadas.
9. Indicación, seguimiento, signos de alarma y vía de reconsulta.
10. Si hay corrección posterior, addenda con fecha, hora, autor y motivo.

### Consentimiento informado
1. Procedimiento o conducta propuestos en términos concretos.
2. Objetivo esperado y beneficio buscado.
3. Riesgos materiales relevantes, no solo fórmula genérica.
4. Alternativas razonables, incluida la no intervención cuando fue ofrecida.
5. Posibilidad de rechazo o revocación.
6. Oportunidad real de lectura y preguntas.
7. Entrega de copia o constancia de disponibilidad de copia.
8. Fecha, hora, firmantes y nexo con el episodio clínico.

### Parte quirúrgico
1. Fecha, hora, paciente, procedimiento, cirujano y equipo.
2. Anestesia, posición y abordaje.
3. Hallazgos intraoperatorios concretos.
4. Maniobras principales y material/implantes utilizados.
5. Cronología de los pasos críticos.
6. Complicaciones o constancia expresa de ausencia de incidentes visibles.
7. Hemostasia, recuentos o verificación equivalente según técnica y material utilizado.
8. Estado de egreso de quirófano, destino inmediato y responsable que recibe.
9. Órdenes o indicaciones críticas del postoperatorio inmediato.

## Alertas de redacción insegura a bloquear en revisión
- "Sin particularidades" cuando existieron hallazgos que justifican conducta.
- "Consentimiento firmado" sin riesgos, alternativas ni acceso a copia.
- "Se realiza procedimiento habitual" sin técnica, hallazgos ni control final.
- Correcciones que reemplazan texto previo sin addenda trazable.
- Frases valorativas o descalificadoras sobre el paciente sin utilidad asistencial.
- Imágenes o videos clínicos mencionados sin finalidad, resguardo ni límite de circulación.
