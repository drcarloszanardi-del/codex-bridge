# Estandar visual de consentimientos

ID: `consentimiento_sobrio_institucional_v1`

Este estandar es obligatorio para todos los consentimientos generados por la app y enviados por Jarvis. Jarvis no debe improvisar diseno ni armar documentos por fuera del exportador.

## Concepto visual

Documento A4 sobrio, institucional, medico-legal y estable. Debe parecer un consentimiento clinico listo para imprimir, no una pieza de marketing ni una respuesta de IA.

## Reglas fijas

- Usar una sola marca institucional en cabecera.
- Si el logo ya contiene el nombre de la institucion, no repetir el nombre debajo.
- El logo debe verse integrado al blanco de la hoja, sin caja gris o fondo visible.
- Los logos deben insertarse preservando su proporcion real, dentro de una caja maxima; nunca forzar ancho y alto fijos que deformen la marca.
- HIGA Junin / Hospital Pineyro debe usar siempre `clinica/logos/hospital_junin_logo_limpio.png`. No volver a usar `hospital_junin_logo.svg.png` para PDF final porque es un lienzo cuadrado con aire y puede deformar la salida.
- El titulo del consentimiento va debajo del logo, centrado, en mayusculas, sin subtitulos decorativos.
- Cuerpo en tipografia simple y legible, justificado, con uso amplio del ancho disponible y sin comprimir de manera innecesaria.
- Color de texto negro o gris muy oscuro; no usar colores aleatorios, banners, tarjetas, etiquetas ni estados visibles.
- Firma del paciente y del medico al pie, en paralelo, con lineas simples.
- Mantener A4, margenes sobrios y jerarquia constante entre patologias.

## Prohibiciones

- No duplicar `Clinica Centro`, `Clinica La Pequena Familia` u otro nombre institucional si ya esta en el logo.
- No agregar frases operativas como `generado por`, `validacion`, `estado`, `proforma`, `slug`, `matriz`, `si corresponde`, `cuando corresponda` o `eventual`.
- No cambiar estilos segun quien lo pida por Telegram.
- No cambiar, re-rasterizar ni sustituir logos institucionales por cuenta de Jarvis.
- No entregar como PDF final una vista que parezca borrador o pantalla de app.

## Implementacion

- Exportador unico: `scripts/exports/export_consent_artifact.py`.
- Handoff Jarvis: `scripts/jarvis/consent_telegram_handoff.js`.
- QA obligatorio: `scripts/qa/validate_consent_handoff.js`.

El manifiesto de Jarvis debe declarar `visual_standard_id=consentimiento_sobrio_institucional_v1`. Si el QA no pasa, no debe enviarse como consentimiento final.
