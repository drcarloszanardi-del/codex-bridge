# CLI-001 Matriz de impacto del ZIP `medilegal-base-v7` sobre consentimientos y cuerpo médico-legal

Fecha de corte: 2026-05-18T18:29:00Z  
Task: `CLI-001-CONSENTIMIENTOS-AUDITORIA-NORMATIVA-ARG-20260518`

## Regla de lectura aplicada
El ZIP humano se trata como corpus fuente inmutable. Esta matriz no corrige plantillas todavía: identifica dónde impacta cada bloque del ZIP antes de la auditoría uno a uno.

## Matriz de impacto
| Fuente del ZIP | Tipo | Impacto en consentimientos | Impacto en cuerpo médico-legal más amplio | Acción siguiente |
|---|---|---|---|---|
| `medilegal/leyes/ley-26529.md` | normativa primaria | Define deber de información, consentimiento informado, acceso/copia y trazabilidad en HC. | Ordena archivo, integridad y disponibilidad documental. | Usar como base obligatoria R1-R8 en auditoría de cada plantilla. |
| `medilegal/leyes/decreto-1089-2012.md` | reglamentación | Baja a criterios operativos de información suficiente, representantes y soporte documental. | Refuerza requisitos de implementación concreta en formularios y procesos. | Verificar que las plantillas no queden solo en fórmulas genéricas. |
| `medilegal/leyes/ley-17132.md` | ejercicio profesional | Exige identificación y responsabilidad profesional. | Impacta firma, matrícula y rol del médico interviniente. | Controlar firma, aclaración y matrícula en todos los modelos. |
| `medilegal/leyes/ccyc-responsabilidad.md` | responsabilidad civil | Refuerza autonomía, información clara y cobertura de riesgos/alternativas. | Sostiene estándar de prueba ante litigio por información defectuosa. | Revisar omisiones de alternativas, rechazo y riesgos específicos. |
| `medilegal/jurisprudencia/fallos-hc.md` | jurisprudencia | Indirecto: fortalece necesidad de consentimiento legible, fechado y trazable dentro de HC. | Directo: historia clínica incompleta o deficiente debilita defensa médico-legal. | Alinear consentimiento con cronología y archivo en HC. |
| `medilegal/campos-obligatorios/parte-campos.md` | checklist estructural | Indirecto: obliga coherencia entre procedimiento consentido y procedimiento documentado. | Directo: conecta consentimiento con parte quirúrgico y consistencia perioperatoria. | Revisar que nombre del procedimiento, nivel y técnica coincidan con la documentación operatoria. |
| `medilegal/validacion/frases-prohibidas.md` | control de lenguaje | Directo: invalida frases vagas como “procedimiento habitual” o “técnica estándar”. | Mejora precisión defensiva en todo el set documental. | Marcar hallazgo rojo ante lenguaje vacío o no específico. |
| `medilegal/patologias/columna-lumbar.md` | guía patología | Directo: aporta riesgos, indicaciones y especificidad para cirugía lumbar. | Ayuda coherencia clínica entre consentimiento, HC y parte. | Auditar modelos de HDL, canal estrecho y fijación lumbar. |
| `medilegal/patologias/estilo-zanardi-HDL.md` | guía de estilo/procedimiento | Directo: adapta contenido a hernia de disco lumbar. | Sirve como patrón de redacción técnica clara. | Cruzar contra plantillas HDL aprobadas/master. |
| `medilegal/patologias/estilo-zanardi-fijacion.md` | guía de estilo/procedimiento | Directo: aporta riesgos y descripción para fijación/instrumentación. | Refuerza consistencia con implantes y reintervenciones. | Cruzar contra plantillas con artrodesis/fijación lumbar. |
| `medilegal/patologias/estilo-zanardi-laminoplastia.md` | guía de estilo/procedimiento | Directo: aporta especificidad para laminoplastia cervical. | Aporta base para futuras variantes cervicales. | Cruzar contra plantilla `consentimiento_laminoplastia_cervical_clinica_centro_master.html`. |
| `medilegal/patologias/estilo-zanardi-especiales.md` | guía de estilo/procedimiento | Directo: cubre escenarios complejos o no estándar. | Ayuda a evitar plantillas excesivamente genéricas. | Detectar si alguna plantilla compleja necesita adaptación especial. |
| `medilegal/patologias/estilo-zanardi-revisiones.md` | guía de estilo/procedimiento | Directo: relevante para reintervenciones/revisiones. | Refuerza deber de explicar cicatriz previa, fibrosis, mayor riesgo y límites de resultado. | Buscar modelos de revisión o cirugías complejas que hoy no tengan cobertura suficiente. |
| `medilegal/INDEX.md` | mapa del corpus | Indirecto: muestra qué normativa/checklists deberían existir para auditoría completa. | Detecta faltantes del corpus recibido. | Mantener trazados los gaps antes de declarar cierre. |
| `medilegal/SKILL-generacion.md` | instructivo operativo | Indirecto: define orden de uso del corpus para generar/validar documentos. | Alinea metodología de armado del cuerpo médico-legal. | Usarlo como guard metodológico, no como norma sustantiva. |

## Plantillas locales que quedan inmediatamente bajo auditoría
- `clinica/plantillas/consentimiento_hernia_disco_lumbar_base.md`
- `clinica/plantillas/consentimiento_hernia_disco_lumbar_base_aprobada.md`
- `clinica/plantillas/consentimiento_hernia_disco_lumbar_clinica_centro_aprobado.md`
- `clinica/plantillas/consentimiento_hernia_disco_lumbar_clinica_centro_master.html`
- `clinica/plantillas/consentimiento_canal_estrecho_lumbar_sin_instrumentacion_base_aprobada.md`
- `clinica/plantillas/consentimiento_fijacion_lumbar_degenerativa_base_aprobada.md`
- `clinica/plantillas/consentimiento_fijacion_descompresion_lumbar_degenerativa_clinica_centro_master.html`
- `clinica/plantillas/consentimiento_laminoplastia_cervical_clinica_centro_master.html`
- `clinica/plantillas/CONSENTIMIENTOS_SISTEMA_CANONICO_MULTIINSTITUCION.md`
- `clinica/plantillas/CONSENTIMIENTOS_CIERRE_FINAL_AUDITABLE.md`

## Conclusión operativa
La ingesta ya permite auditar de inmediato los consentimientos de columna lumbar, fijación y laminoplastia con base normativa y de lenguaje suficiente para detectar no conformidades materiales. El principal faltante del ZIP no impide empezar la auditoría de consentimientos, pero sí obliga a dejar trazados los vacíos del corpus antes del cierre final `APTO_PARA_ENTREGAR`.
