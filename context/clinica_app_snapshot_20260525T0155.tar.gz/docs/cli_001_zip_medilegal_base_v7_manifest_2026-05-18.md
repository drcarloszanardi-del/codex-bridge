# CLI-001 Ingesta raw del ZIP humano `medilegal-base-v7`

Fecha de corte: 2026-05-18T18:29:00Z  
Task: `CLI-001-CONSENTIMIENTOS-AUDITORIA-NORMATIVA-ARG-20260518`  
Origen: Telegram directo del señor Zanardi `message_id=5757`

## Fuente inmutable
- ZIP original: `/Users/jarvis/.openclaw/media/inbound/medilegal-base-v7---dca2e052-81d0-4212-82ad-4bf852f1552e.zip`
- SHA256: `b3a36a5fd362541411185d0044cf1d468d3dd0b9f8cf6f9a79b9698e76646ce6`
- Tamaño: `43956 bytes`
- Snapshot raw preservado: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/ingesta/raw/cli_001_medilegal_base_v7_2026-05-18/`
- Copia raw ZIP: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/ingesta/raw/cli_001_medilegal_base_v7_2026-05-18/source.zip`
- Extracción raw: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/ingesta/raw/cli_001_medilegal_base_v7_2026-05-18/extracted/`
- Política aplicada: snapshot preservado con permisos sin escritura (`chmod -R a-w`) para evitar mutación accidental durante la auditoría.

## Listado top-level del ZIP
- `medilegal/`

## Árbol operativo extraído
```text
medilegal/
  INDEX.md
  SKILL-generacion.md
  leyes/
    ley-17132.md
    ley-26529.md
    decreto-1089-2012.md
    ccyc-responsabilidad.md
  jurisprudencia/
    fallos-hc.md
  campos-obligatorios/
    parte-campos.md
  validacion/
    frases-prohibidas.md
  patologias/
    columna-lumbar.md
    estilo-zanardi-HDL.md
    estilo-zanardi-especiales.md
    estilo-zanardi-fijacion.md
    estilo-zanardi-laminoplastia.md
    estilo-zanardi-revisiones.md
```

## Clasificación del contenido presente
| Área | Archivos presentes | Uso inmediato en CLI-001 |
|---|---|---|
| Normativa primaria | `ley-17132.md`, `ley-26529.md`, `decreto-1089-2012.md`, `ccyc-responsabilidad.md` | Base para requisitos estructurales del consentimiento, deber de información y trazabilidad clínica. |
| Jurisprudencia | `fallos-hc.md` | Refuerza exigencias de integridad documental e historia clínica como soporte probatorio. |
| Campos obligatorios | `parte-campos.md` | Impacta cuerpo médico-legal general y consistencia con documentación perioperatoria, no solo consentimiento. |
| Validación de lenguaje | `frases-prohibidas.md` | Gate directo para detectar cláusulas vacías, genéricas o de riesgo legal. |
| Patologías / estilo clínico | `columna-lumbar.md`, serie `estilo-zanardi-*` | Aporta adaptación por patología/técnica, especialmente riesgos y descripción específica del procedimiento. |
| Instrucción de uso | `INDEX.md`, `SKILL-generacion.md` | Sirve para ordenar consumo del corpus y criterios de generación/validación. |

## Gaps detectados contra `INDEX.md`
El índice declara más corpus del que efectivamente llegó en este ZIP. Faltan, al menos:
- `ley-25326.md`
- `ley-25506.md`
- `codigo-penal.md`
- `fallos-parte.md`
- `fallos-columna.md`
- `fallos-consentimiento.md`
- `hc-campos.md`
- `anestesia-campos.md`
- `checklist-hc.md`
- `checklist-parte.md`
- `frases-correctas.md`
- `columna-cervical.md`

## Estado de la ingesta
- ZIP humano ingerido como raw inmutable: **OK**
- Hash y origen preservados: **OK**
- Listado top-level y árbol operativo: **OK**
- Clasificación inicial para auditoría normativa: **OK**
- Siguiente paso habilitado: cruzar este corpus con plantillas vigentes y marcar conformidad/no conformidad por plantilla.
