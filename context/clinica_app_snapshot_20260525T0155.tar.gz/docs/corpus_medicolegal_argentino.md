# Corpus medicolegal argentino base para historias clínicas y partes quirúrgicos

Fecha de corte: 2026-05-20T15:20:48Z
Estado: base estructurada y trazable, `BASE_AVANZADA_REVIEW_ONLY` para uso humano interno. No activar publicación ni reglas reales sin revisión final.

## Gate formal de 6 controles, corte 2026-05-19
- Estado operativo del corpus: `BASE_AVANZADA_REVIEW_ONLY`, no `APTO_PARA_ENTREGAR`.
- Dictamen prudente habilitado: base médico-legal avanzada para tamiz interno; el cierre formal sigue pendiente.
- Controles sostenidos por este corpus: identificación completa del acto, consentimiento con contenido material y acceso/copia, parte quirúrgico completo, addendas sin borrado, confidencialidad con acceso mínimo e integridad/autenticidad/auditoría del registro electrónico.
- Alcance permitido hoy: QA local, `review_only`, `detect-only` y redacción prudente interna.
- Alcance prohibido hoy: declarar cumplimiento legal total, certificación, firma digital probada o cierre definitivo del frente HC/partes.

## Cobertura inicial verificable de este lote
- Normativa trazada con raw inmutable y hash: Ley 26.529, Ley 17.132, Ley 25.326 y Decreto 1558/2001, Ley 25.506 y Decreto 182/2019, Código Civil y Comercial de la Nación (Ley 26.994), Decreto 1089/2012 reglamentario, Código Penal de la Nación Argentina (Ley 11.179), Ley 27.706 y Decreto 393/2023 sobre historia clínica electrónica, Ley 27.553 sobre recetas electrónicas/teleasistencia cuando el flujo emita indicaciones u órdenes, Ley PBA 14.494 y Decreto PBA 1600/2024 para el eje bonaerense/HIGA, y la página oficial `Mi historia clínica` como apoyo operativo sobre soporte digital.
- Jurisprudencia trazada por búsqueda estructurada SAIJ en JSON, ahora con 4 consultas dedicadas y 12 candidatos priorizados para historia clínica, autenticidad documental, consentimiento informado, estándar de medios, error inexcusable, pruebas periciales, negligencia en operación quirúrgica y eventos quirúrgicos evitables.
- Corpus neurocirugía/columna agregado el 2026-05-20: 19 registros jurisprudenciales y 1 fuente doctrinaria separada, con 15 registros de fuente oficial y 4 secundarios tratados como candidatos. Artifact: `data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_corpus_latest.json`.
- Registro persistente sincronizado el 2026-05-20: `data/db/medicolegal.sqlite` pasó a reflejar 28 fuentes, 28 raw documents y 28 índices normativos/jurisprudenciales en estado `pending_review`, evitando que la app dependa solo de los MD/JSON.
- Separación operativa preservada: `normativo`, `jurisprudencia`, `doctrina`, `interno`, `clinico`.

## Fuentes normativas incorporadas

### 1. Ley 26.529, Derechos del Paciente
- Tipo: norma nacional
- Fuente oficial: https://servicios.infoleg.gob.ar/infolegInternet/anexos/160000-164999/160432/norma.htm
- Raw: `data/raw/legal/norm_ley_26529_infoleg.html`
- Hash SHA-256: `593287851e8ff066900626da39d3e98a580b10cb04d88437e824bdff129f5253`
- Utilidad redaccional: base para consentimiento informado, acceso a historia clínica, confidencialidad, trato digno, derecho a información y directivas anticipadas.
- Riesgo si se omite: debilita trazabilidad del consentimiento, de la información brindada y del derecho del paciente a obtener copia/documentación.

### 2. Ley 17.132, ejercicio de la medicina
- Tipo: norma nacional
- Fuente oficial: https://servicios.infoleg.gob.ar/infolegInternet/anexos/15000-19999/19429/texact.htm
- Raw: `data/raw/legal/norm_ley_17132_infoleg.html`
- Hash SHA-256: `59fc8d0f4d21b355325a5bbe976c3fd8681642f0ab1517fd42cbcc68d3a9ec0c`
- Utilidad redaccional: marco de deberes profesionales, límites del ejercicio, incumbencias y estándar básico de actuación médica documentable.
- Riesgo si se omite: deja sin sustento operativo la identificación profesional, firma, indicación y responsabilidad del acto documentado.

### 3. Ley 25.326, protección de datos personales
- Tipo: norma nacional
- Fuente oficial: https://servicios.infoleg.gob.ar/infolegInternet/anexos/60000-64999/64790/texact.htm
- Raw: `data/raw/legal/norm_ley_25326_infoleg.html`
- Hash SHA-256: `61548a0fba22550e19a4189c101876238501cb6a9b5821cea5e36478708a3b61`
- Utilidad redaccional: restringe acceso, circulación y exposición de datos sensibles de salud; obliga a criterio de mínima exposición y trazabilidad de acceso.
- Riesgo si se omite: exposición indebida de datos sensibles, secreto profesional débil, copias o intercambios sin base mínima.

### 4. Código Civil y Comercial de la Nación, Ley 26.994
- Tipo: norma nacional de responsabilidad civil y consentimiento para actos médicos
- Fuente oficial: https://servicios.infoleg.gob.ar/infolegInternet/anexos/235000-239999/235975/norma.htm
- Raw: `data/raw/legal/norm_cccn_ley_26994_infoleg.html`
- Hash SHA-256: `cb0d963dd779b4f8ac44d049c3d1c449c250e7dc28a5ead280633115e9ba2967`
- Utilidad redaccional: agrega base general de consentimiento informado, responsabilidad civil, deber de prevención del daño y valor de la documentación clínica para reconstruir diligencia médica.
- Riesgo si se omite: el corpus queda sin puente explícito entre normas sanitarias y responsabilidad civil general aplicable al conflicto por praxis o documentación.

### 5. Decreto 1089/2012, reglamentación de la Ley 26.529
- Tipo: decreto reglamentario nacional
- Fuente oficial: https://servicios.infoleg.gob.ar/infolegInternet/anexos/195000-199999/199296/norma.htm
- Raw: `data/raw/legal/norm_dec_1089_2012_infoleg.html`
- Hash SHA-256: `0dff82bbd4866d75d14c4930e17c957b40a122e7aa84de4095c2b1f1e3292a2a`
- Utilidad redaccional: baja a reglas operativas la información sanitaria, el consentimiento, la historia clínica y la trazabilidad exigible en la relación asistencial.
- Riesgo si se omite: deja el corpus sin el puente reglamentario que aterriza deberes de la ley en criterios prácticos de documentación.

### 6. Código Penal de la Nación Argentina, Ley 11.179
- Tipo: norma penal nacional
- Fuente oficial: https://servicios.infoleg.gob.ar/infolegInternet/anexos/15000-19999/16546/texact.htm
- Raw: `data/raw/legal/norm_codigo_penal_ley_11179_infoleg.html`
- Hash SHA-256: `52575de7c849442282f2a8ff00a7464adb2a20a0c7d84d3f74ce50215bdfaa28`
- Utilidad redaccional: agrega el marco penal de lesiones culposas, homicidio culposo y secreto profesional que vuelve crítica la precisión, cronología y reserva de la documentación clínica.
- Riesgo si se omite: el corpus queda débil frente a escenarios donde la discusión supera la órbita civil y alcanza reproche penal por omisión, imprudencia o divulgación indebida.

### 7. Ley 25.506 de Firma Digital
- Tipo: norma nacional de soporte para autenticidad, integridad y firma de documentación electrónica
- Fuente oficial: https://servicios.infoleg.gob.ar/infolegInternet/anexos/70000-74999/70749/norma.htm
- Raw: `data/raw/legal/norm_ley_25506_firma_digital_infoleg.html`
- Hash SHA-256: `b2fc741b4ae4986db7c4ad2c7bd6466cde8ab7697ff08f46db67328a3ceb2974`
- Utilidad redaccional: fortalece el puente técnico-jurídico para historia clínica informatizada y documentación firmada digitalmente, en línea con la remisión del Decreto 1089/2012 art. 13.
- Riesgo si se omite: queda subdocumentado el fundamento de autenticidad, integridad y no repudio para historia clínica electrónica, addendas y registros firmados digitalmente.

### 8. Derecho Fácil, Derechos del paciente
- Tipo: fuente oficial divulgativa, no reemplaza texto legal
- Fuente oficial: https://www.argentina.gob.ar/justicia/derechofacil/leysimple/derechos-del-paciente
- Raw: `data/raw/legal/norm_derechos_paciente_argentina_gob.html`
- Hash SHA-256: `5bbdb2e5f3b5b6b11fe67059e85568e81c0888924d58b1a5dc56da056c814c08`
- Utilidad redaccional: resume en lenguaje operativo deber de información, consentimiento, acceso a historia clínica y plazo de entrega.
- Advertencia: usar solo como apoyo interpretativo y checklist; la fuerza principal sigue siendo la ley y reglamentación.

### 9. Programa Federal Único de Informatización y Digitalización de Historias Clínicas, Ley 27.706 y Decreto 393/2023
- Tipo: normas nacionales oficiales, útiles como capa sectorial de historia clínica electrónica
- Fuente oficial Ley 27.706: https://servicios.infoleg.gob.ar/infolegInternet/anexos/380000-384999/380710/norma.htm
- Raw Ley 27.706: `data/raw/legal/norm_ley_27706_infoleg.html`
- Hash SHA-256 Ley 27.706: `06c95d9d128a2f9097ce86cf1628db1ac5f2838647cb3156e4813c148f236b5c`
- Fuente oficial Decreto 393/2023: https://servicios.infoleg.gob.ar/infolegInternet/anexos/385000-389999/387475/norma.htm
- Raw Decreto 393/2023: `data/raw/legal/norm_dec_393_2023_infoleg.html`
- Hash SHA-256 Decreto 393/2023: `d0c075eb36855061f1994bd1ca82d55ccbd24f8ad86e25b60d537b93f263450b`
- Utilidad redaccional: confirma la capa posterior a Ley 26.529 para marca temporal, registro individualizado, integridad, trazabilidad, confidencialidad, acceso del paciente e interoperabilidad.
- Advertencia: queda en `pending_review` para reglas activas, pero ya no está bloqueada la captura primaria: el texto oficial fue incorporado localmente y reemplaza la antigua referencia equivocada/bloqueada `verNorma.do?id=386179` como fuente principal.

### 10. Argentina.gob.ar, “Mi historia clínica”
- Tipo: fuente oficial operativa/divulgativa con citas normativas y mención expresa de soporte digital
- Fuente oficial: https://www.argentina.gob.ar/mi-historia-clinica
- Raw: `data/raw/legal/norm_historia_clinica_mi_historia_clinica_argentina_gob.html`
- Hash SHA-256: `e0bfc698e2104994f4d2db60236f3741be1899403fadf555c0dc17a03f0cb1ec`
- Utilidad redaccional: baja a lenguaje operativo qué debe contener la historia clínica, reconoce soporte papel/digital y deja citados Decreto 1089/2012 arts. 12 y 13; además menciona como ruta estructurada secundaria la Ley 5669 CABA sobre historias clínicas electrónicas.
- Advertencia: sirve como apoyo operativo y como pista de norma local CABA a validar por vía estructurada adicional; no reemplaza al texto normativo primario. Ya quedó guardada una evidencia detect-only de la referencia enlazada a Ley 5669 CABA, con primer intento estructurado bloqueado por 403 en SAIJ (`data/raw/legal/norm_ley_5669_caba_saij_reference_blocked_2026-05-18.md`).

### 11. Provincia de Buenos Aires, Ley 14.494 y Decreto 1600/2024
- Tipo: normativa provincial sobre historia clínica electrónica única, especialmente relevante para HIGA Junín y prestadores bonaerenses.
- Fuente oficial Ley 14.494: https://normas.gba.gob.ar/ar-b/ley/2013/14494/11338
- Raw Ley 14.494: `data/raw/legal/norm_ley_14494_pba.html`
- Hash SHA-256 Ley 14.494: `deb10e741ed6da737b4af2c7c0cbf58f422d995db3789ccb65601838e8ceb66e`
- Fuente oficial Decreto 1600/2024: https://normas.gba.gob.ar/ar-b/decreto/2024/1600/451942
- Raw Decreto 1600/2024: `data/raw/legal/norm_dec_1600_2024_pba.html`
- Hash SHA-256 Decreto 1600/2024: `dc1568dde2d250e050d2040f9b60269fbac4bfcd6a32c3e39d66084277477f89`
- Utilidad redaccional: refuerza finalidad asistencial, veracidad, confidencialidad, accesibilidad restringida, titularidad, registro de procedimientos diagnósticos/terapéuticos y responsabilidades institucionales dentro de Buenos Aires.

### 12. Decretos complementarios de firma digital y datos personales
- Decreto 182/2019, firma digital: `data/raw/legal/norm_dec_182_2019_firma_digital_argentina_gob.html`, SHA-256 `d8e32e544382b744f65fe4673da0558a72804eb8dfbd85076f04c779bdfc2f78`.
- Decreto 1558/2001, datos personales: `data/raw/legal/norm_dec_1558_2001_datos_personales_argentina_gob.html`, SHA-256 `3be65569f2cfc86808892266f30e7d6ea027ce41c34afda16d8c622f6f091b69`.
- Utilidad redaccional: baja a soporte operativo la conservación de documentos digitales, firma electrónica/digital, acceso, control y resguardo de datos sensibles.

### 13. Ley 27.553, recetas electrónicas o digitales y teleasistencia
- Tipo: norma nacional complementaria, relevante solo si la app genera indicaciones, recetas, órdenes o teleasistencia.
- Fuente oficial: https://www.argentina.gob.ar/normativa/nacional/ley-27553-340919/texto
- Raw: `data/raw/legal/norm_ley_27553_receta_teleasistencia_argentina_gob.html`
- Hash SHA-256: `5d1427835c27c8b7f66a5b4c8b3f6adbf31f5c9c16151f040b45baaa11a8f816`
- Utilidad redaccional: evitar que una indicación electrónica salga como texto informal sin identificación profesional, soporte válido y trazabilidad suficiente.

## Hallazgos normativos operativos
1. La historia clínica debe pensarse como documento asistencial y probatorio, no como memoria informal.
2. El consentimiento informado no se agota en la firma; exige constancia verificable de información material, riesgos, beneficios, alternativas y posibilidad de rechazo.
3. Los datos de salud son sensibles; la redacción debe evitar difusión innecesaria y separar información clínica útil de juicios de valor superfluos.
4. La identificación de profesional, fecha, hora y secuencia del acto no es accesorio: sostiene trazabilidad, autoría y defensa posterior.
5. Ya no alcanza pensar historia clínica electrónica solo como “papel digitalizado”: la capa 27.706/393-2023 agrega interoperabilidad, acceso federal y exigencia de diseño técnico del registro.
6. La ruta oficial `Mi historia clínica` confirma que el soporte digital y la base de datos institucional son parte del modelo aceptado, y abre una línea local útil hacia Ley 5669 CABA como norma secundaria a validar. Esa referencia ya quedó preservada como candidato detect-only con bloqueo estructurado inicial documentado, en lugar de perderse como mención informal.

## Bloque de artículos priorizados para redacción y QA

### Ley 26.529 y Decreto 1089/2012
- **Ley 26.529 art. 2**: obliga a documentar trato digno, intimidad, confidencialidad y acceso del paciente a la información. Impacto directo: evitar juicios de valor, registrar qué se informó y sostener reserva de datos.
- **Ley 26.529 arts. 5 y 6 + Decreto 1089/2012 art. 5**: fijan el núcleo del consentimiento informado. Impacto directo: no alcanza la frase “consentimiento firmado”; hay que dejar objetivo, riesgos relevantes, beneficios, alternativas y posibilidad de rechazo, además de acceso real a copia.
- **Ley 26.529 arts. 11 a 15 + Decreto 1089/2012 arts. 12 a 15**: estructuran historia clínica, titularidad, autenticidad, integridad, guarda y soporte informatizado. Impacto directo: cada registro debe tener autor, fecha, hora, addendas trazables y preservación de la versión original.
- **Decreto 1089/2012 art. 13**: vincula historia clínica informatizada con firma digital/electrónica y mecanismos de autenticidad. Impacto directo: toda app debe separar borrador, revisión y registro emitido con trazabilidad de autoría.

### Código Civil y Comercial de la Nación
- **Arts. 51 a 53**: protegen dignidad, intimidad e imagen. Impacto directo: limitar circulación de fotos, videos y capturas clínicas a finalidad asistencial, auditoría o docencia autorizada/documentada.
- **Art. 59**: consolida consentimiento informado en actos médicos. Impacto directo: la app debe inducir redacciones que dejen documentada la decisión informada, no solo la aceptación final.
- **Art. 1716**: responsabilidad por daño injustificado. Impacto directo: la documentación debe explicar por qué la conducta fue razonable según el cuadro clínico.
- **Arts. 1724 a 1726**: culpa, diligencia y valoración de la conducta. Impacto directo: registrar razonamiento clínico, correlación con estudios, controles y respuesta frente a desvíos.

### Código Penal de la Nación
- **Arts. 84 y 94**: homicidio y lesiones culposas. Impacto directo: el parte quirúrgico debe poder reconstruir técnica, controles, cronología e incidentes para no dejar vacíos ante reproche por imprudencia o negligencia.
- **Art. 106**: abandono de persona o desatención relevante. Impacto directo: alta, pase y reconsulta deben quedar con indicaciones, signos de alarma y responsable de seguimiento.
- **Art. 156**: secreto profesional. Impacto directo: reforzar mínima exposición de datos sensibles, trazabilidad de entrega de copias y restricción de difusión no asistencial.

### Capa de historia clínica electrónica
- **Ley 25.506 + Decreto 1089/2012 art. 13**: sostienen autenticidad, integridad y no repudio del soporte digital.
- **Ley 27.706 + Decreto 393/2023**: agregan interoperabilidad y programa federal como capa de vigilancia detect-only, con texto primario oficial ya capturado localmente.
- **Ley PBA 14.494 + Decreto PBA 1600/2024**: agregan capa bonaerense para HIGA/prestadores de Buenos Aires, con finalidad, veracidad, confidencialidad, accesibilidad restringida y autoridad sanitaria provincial.
- **Ley 5669 CABA**: queda como referencia secundaria detectada desde fuente oficial, con bloqueo estructurado 403 ya preservado. No usar como regla activa hasta capturar ruta normativa primaria o alternativa estable.

## Jurisprudencia relevante, primer lote estructurado

### A. Historia clínica y carga probatoria
- Fuente estructurada: SAIJ búsqueda `historia clinica prueba`
- Raw: `data/raw/jurisprudence/jur_saij_historia_clinica_prueba.json`
- Candidato 1: Recurso extraordinario, responsabilidad médica, mala praxis, establecimientos asistenciales, historia clínica, falta de prueba
- Tribunal: CS
- Fecha: 2002-09-19
- Referencia estructurada: `recurso-extraordinario-responsabilidad-medica-mala-praxis-establecimientos-asistenciales-historia-clinica-falta-prueba-sua0061444`
- Síntesis propia: la ausencia o mal uso de la historia clínica en juicio no se lee de modo automático; importa cómo fue ofrecida y articulada como prueba. Operativamente obliga a documentar bien y además preservar recuperabilidad/autenticidad para que el documento sea utilizable.
- Confianza: structured_search_result_pending_full_text_review

### B. Autenticidad e integridad documental de la historia clínica
- Fuente estructurada: SAIJ búsqueda `historia clinica`
- Raw: `data/raw/jurisprudence/jur_saij_historia_clinica_prueba.json`
- Candidato 2: Sumario-Inc. de Impugnación de Autenticidad de Historia Clínica
- Tribunal: CAMARA DE APELACIONES CIVIL COMERCIAL
- Fecha: 1998-03-03
- Referencia estructurada: `camara-apelaciones-civil-comercial-local-entre-rios-lubo-ricardo-nicanor-publiese-canio-sumario-inc-impugnacion-autenticidad-historia-clinica-fa98080737-1998-03-03`
- Síntesis propia: aparecen controversias sobre autenticidad de historia clínica; por eso cualquier corrección o agregado debe quedar como addenda/versionado y nunca como sustitución silenciosa del registro previo.
- Confianza: structured_search_result_pending_full_text_review

### C. Responsabilidad médica y estándar de medios
- Fuente estructurada: SAIJ búsqueda `responsabilidad medica consentimiento`
- Raw: `data/raw/jurisprudence/jur_saij_responsabilidad_medica_consentimiento.json`
- Candidato 3: Responsabilidad médica, obligaciones de medios, diagnóstico médico, médicos, análisis clínicos, error excusable, obligaciones de resultado, error de diagnóstico
- Tribunal: CC
- Fecha: 2020-09-02
- Referencia estructurada: `responsabilidad-medica-obligaciones-medios-diagnostico-medico-medicos-analisis-clinicos-error-excusable-obligaciones-resultado-error-diagnostico-suw0003079`
- Síntesis propia: la litigiosidad médica se apoya en diagnóstico, indicación, medios empleados, error alegado y relación causal. Redaccionalmente eso exige dejar explícitos criterio clínico, correlación con estudios y racionalidad de la conducta elegida.
- Confianza: structured_search_result_pending_full_text_review

### D. Prueba pericial y consistencia del registro asistencial
- Fuente estructurada: SAIJ búsqueda `historia clinica prueba`
- Raw: `data/raw/jurisprudence/jur_saij_historia_clinica_prueba.json`
- Candidato 4: pericia médica, establecimientos asistenciales, obras sociales, responsabilidad solidaria, cuestiones de hecho, prueba, recurso de casación
- Tribunal: CS
- Fecha: 2004-04-04
- Referencia estructurada: `pericia-medica-establecimientos-asistenciales-obras-sociales-responsabilidad-solidaria-cuestiones-hecho-prueba-recurso-casacion-su10004542`
- Síntesis propia: cuando la discusión depende de pericia y prueba técnica, la historia clínica debe ser internamente consistente con indicaciones, estudios y evolución; si el registro es fragmentario, deja más espacio a reconstrucciones adversas.
- Confianza: structured_search_result_pending_full_text_review

### E. Eventos quirúrgicos evitables y presunción de falla
- Fuente estructurada: SAIJ búsqueda `responsabilidad medica consentimiento`
- Raw: `data/raw/jurisprudence/jur_saij_responsabilidad_medica_consentimiento.json`
- Candidato 5: daños y perjuicios, responsabilidad médica, establecimientos asistenciales, mala praxis, oblito quirúrgico, error material, presunción de culpa
- Tribunal: CO
- Fecha: 1996-06-06
- Referencia estructurada: `danos-perjuicios-responsabilidad-medica-responsabilidad-establecimientos-asistenciales-mala-praxis-oblito-quirurgico-error-material-presuncion-culpa-sun0007036`
- Síntesis propia: frente a eventos quirúrgicos evitables, un parte operatorio genérico o incompleto agrava la exposición. Operativamente conviene documentar recuentos, control final, hallazgos y ausencia/presencia de incidentes con lenguaje concreto.
- Confianza: structured_search_result_pending_full_text_review

### F. Error inexcusable y necesidad de razonar la conducta
- Fuente estructurada: SAIJ búsqueda `responsabilidad medica consentimiento`
- Raw: `data/raw/jurisprudence/jur_saij_responsabilidad_medica_consentimiento.json`
- Candidato 6: error inexcusable, responsabilidad médica
- Tribunal: CS
- Fecha: 2014-06-05
- Referencia estructurada: `error-inexcusable-responsabilidad-medica-sul0006214`
- Síntesis propia: no todo desenlace adverso equivale a mala praxis, pero la defensa empeora si la nota no explica por qué se eligió una conducta y qué controles se hicieron. La redacción debe mostrar juicio clínico y no solo conclusiones.
- Confianza: structured_search_result_pending_full_text_review

### G. Consentimiento informado y acceso a la información del paciente
- Fuente estructurada: SAIJ búsqueda `consentimiento informado medico`
- Raw: `data/raw/jurisprudence/jur_saij_consentimiento_informado_medico.json`
- Candidato 7: medida autosatisfactiva de acceso a la información y al consentimiento informado
- Tribunal: Juzgado Civil de Personas y Familia de 1ra Nominación, Salta
- Fecha: 2021-04-29
- Referencia estructurada: `juzgado-civil-personas-familia-1ra-nominacion-local-salta-esteban-ivana-medida-autosatisfactiva-acceso-informacion-al-consentimiento-informado-fa21170005-2021-04-29`
- Síntesis propia: la disputa judicial puede centrarse no solo en si existió consentimiento, sino en la accesibilidad real a la información y al documento. Operativamente conviene dejar constancia de entrega, explicación, oportunidad de lectura y disponibilidad posterior de copia.
- Confianza: structured_search_result_pending_full_text_review

### H. Negligencia médica en operación quirúrgica y reproche penal/civil
- Fuente estructurada: SAIJ búsqueda `operacion quirurgica negligencia medica`
- Raw: `data/raw/jurisprudence/jur_saij_operacion_quirurgica_negligencia_medica.json`
- Candidato 8: LESIONES CULPOSAS - OPERACION QUIRURGICA - NEGLIGENCIA MEDICA
- Tribunal: Cámara Nacional de Apelaciones en lo Criminal y Correccional
- Fecha: 1978-04-25
- Referencia estructurada: `camara-nacional-apelaciones-criminal-correccional-nacional-ciudad-autonoma-buenos-aires-adalid-enrique-lesiones-culposas-operacion-quirurgica-negligencia-medica-fa78060053-1978-04-25`
- Síntesis propia: agrega una vía de lectura más penal del acto quirúrgico. Para el parte operatorio y la evolución inmediata refuerza que la técnica, los controles intraoperatorios, la cronología y la conducta postevento no deben quedar implícitos.
- Confianza: structured_search_result_pending_full_text_review

### I. Arbitrariedad probatoria en negligencia médica con control de hechos y prueba
- Fuente estructurada: SAIJ búsqueda `operacion quirurgica negligencia medica`
- Raw: `data/raw/jurisprudence/jur_saij_operacion_quirurgica_negligencia_medica.json`
- Candidato 10: procedencia del recurso extraordinario, sentencias arbitrarias, daños y perjuicios, responsabilidad médica, negligencia, obras sociales
- Tribunal: Corte Suprema de Justicia de la Nación
- Fecha: 1986-03-20
- Referencia estructurada: `corte-suprema-justicia-nacion-federal-ciudad-autonoma-buenos-aires-silvia-carroza-shiroma-otro-hospital-italiano-otros-procedencia-recurso-extraordinario-sentencias-arbitrarias-valoracion-circunstancias-hecho-prueba-danos-perjuicios-responsabilidad-medica-negligencia-obras-sociales-fa86000102-1986-03-20`
- Síntesis propia: enfatiza que el litigio médico no se resuelve solo por desenlace, sino por cómo quedan fijados los hechos y la prueba. Redaccionalmente obliga a sostener secuencia verificable entre indicación, intervención, complicaciones, respuesta y seguimiento.
- Confianza: structured_search_result_pending_full_text_review

### J. Traslado, anestesia e intervención quirúrgica como cadena única de responsabilidad documentable
- Fuente estructurada: SAIJ búsqueda `operacion quirurgica negligencia medica`
- Raw: `data/raw/jurisprudence/jur_saij_operacion_quirurgica_negligencia_medica.json`
- Candidato 11: responsabilidad de establecimientos asistenciales, médico anestesista, intervención quirúrgica, traslado del paciente, muerte
- Tribunal: sin detalle visible en el resultado estructurado
- Fecha: 1999-11-04
- Referencia estructurada: `responsabilidad-establecimientos-asistenciales-medico-anestesista-intervencion-quirurgica-traslado-paciente-muerte-valor-vida-indemnizacion-computo-intereses-tasa-activa-sun0008807`
- Síntesis propia: refuerza que la defensa del acto quirúrgico no termina en la técnica. También deben quedar trazados traslado, anestesia, monitoreo, entrega a recuperación y condiciones del postoperatorio inmediato.
- Confianza: structured_search_result_pending_full_text_review

### K. Obligaciones de medios y error diagnóstico con necesidad de razonamiento explícito
- Fuente estructurada: SAIJ búsqueda `responsabilidad medica consentimiento`
- Raw: `data/raw/jurisprudence/jur_saij_responsabilidad_medica_consentimiento.json`
- Candidato 12: responsabilidad médica, obligaciones de medios, diagnóstico médico, error excusable e inexcusable
- Tribunal: sin detalle visible en el resultado estructurado
- Fecha: 2020-09-02
- Referencia estructurada: `responsabilidad-medica-obligaciones-medios-diagnostico-medico-medicos-analisis-clinicos-error-excusable-obligaciones-resultado-error-diagnostico-suw0003079`
- Síntesis propia: obliga a distinguir desenlace adverso de apartamiento culpable mediante documentación del juicio clínico. En la práctica conviene narrar hipótesis, incertidumbres, estudios pedidos y motivo del cambio o mantenimiento de conducta.
- Confianza: structured_search_result_pending_full_text_review

## Jurisprudencia neurocirugía/columna, primer corte específico 2026-05-20

Artifact rector: `data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_corpus_latest.json`  
Matriz de impacto: `data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_impact_matrix_latest.md`  
Estado: `review_only_detect_only`. No se presenta como exhaustividad absoluta de toda la jurisprudencia argentina; queda como primer corte trazable y ampliable.

### Fuentes oficiales incorporadas
- SAIJ, dossier de mala praxis médica: sumarios `Batista c/ Sanatorio Quintana`, `Hernández c/ OSECAC`, `Echenique c/ Pardal`, `González c/ F.L.E.N.I.` y criterios sobre neurocirugía, estudios, riesgo quirúrgico, historia clínica y roles del equipo.
- Poder Judicial de Río Negro: `Villacura c/ Pilafis`, `Marchan c/ Gómez/Labat/Sanatorio Juan XXIII`, `Olivares c/ Sanatorio Juan XXIII`, `Gómez Franco - emergencia por hemorragia cerebral` y `Fantini c/ Clínica Roca`.
- MPF, dictamen `C.P. c/ P.S.R.`: alerta oficial de competencia/jurisdicción; no se usa como precedente material de fondo.

### Fuentes secundarias en cola de oficialización
- `V. L. M. N. c/ E. R. J.` sobre indicación de cirugía de columna programada.
- `R. C. c/ FLENI` sobre hernia lumbar, infección/recidiva y seguimiento.
- `M. G. L. c/ Hospital Alemán` sobre neurocirugía craneal e incidente vascular.
- `Q. C. B. c/ A. E.` sobre columna con implantes y control radiológico.

### Impacto operativo ya incorporado al tamiz
1. Historia clínica neuro/columna: síntomas, examen, estudios, diagnóstico, nivel/lateralidad/raíz cuando aplique y motivo de indicación deben quedar unidos, sin transformar la nota en tratado anatómico.
2. Parte quirúrgico de columna: posición, protección ocular y puntos de apoyo, antisepsia, profilaxis, radioscopia para nivel, chequeo de material si hay implantes, abordaje, hallazgo, maniobra, hemostasia, recuento, cierre y destino.
3. Consentimiento neuroquirúrgico: patología y procedimiento concretos, beneficios esperables, riesgos propios, alternativas, no tratamiento, revocación, preguntas y firmas; formato visual único de la app.
4. Incidentes y desvíos: si existieron, se describen mecanismo, respuesta, control y estado final; si no existieron, se cierra con controles finales verdaderos sin frases condicionales.
5. Urgencia neurológica: horarios, examen, medidas, comunicaciones, criterio de derivación y condición de traslado son datos críticos.
6. Historia clínica/evolución/epicrisis: días u horas relevantes, estudios, medicación, evolución, firma/sello o autor identificable, y addendas visibles sin enmiendas silenciosas.

### Gates nuevos en el paquete de tamiz
- `CLI-NSJ001`: indicación neuro/columna con alternativas.
- `CLI-NSJ002`: nivel, lateralidad, raíz y control por imagen.
- `CLI-NSJ003`: seguridad intraoperatoria y respuesta a incidentes.
- `CLI-NSJ004`: consentimiento neuroquirúrgico específico.
- `CLI-NSJ005`: urgencia neurológica con tiempos y derivación.
- `NJ-TAMIZ-006`: integridad y recuperabilidad de historia clínica/evolución/epicrisis neuro/institucional, cubierto en el paquete operativo por los gates generales de addenda y trazabilidad documental.

## Señales jurisprudenciales operativas del lote actual
1. La autenticidad y recuperabilidad del registro valen casi tanto como su contenido.
2. En cirugía, parte operatorio y evolución inmediata deben cerrar el circuito entre indicación, ejecución y control final.
3. El consentimiento debe ser accesible y recuperable, no solo firmado; conviene documentar entrega de copia, explicación y posibilidad de consulta posterior.
4. La historia clínica y el consentimiento sirven mejor cuando permiten reconstruir razonamiento clínico, alternativas y riesgos discutidos.
5. La pericia futura se beneficia de una cronología completa, autor identificable y correlación entre estudios, hallazgos y conducta.
6. La exposición penal por lesiones culposas obliga a que el parte quirúrgico deje mejor documentados los controles, la técnica y la respuesta ante incidentes o desvíos.
7. Traslado, anestesia, recuperación y entrega posoperatoria deben quedar dentro del mismo hilo documental cuando inciden en el riesgo del paciente.
8. Cuando el caso gira sobre acceso posterior a consentimiento o historia clínica, sirve documentar no solo el contenido sino también la disponibilidad efectiva de copia y reconsulta.

## Bloque civil y penal priorizado, traducido a impacto redaccional

### Trazabilidad temporal y autoría
- **CCCN arts. 1710, 1724, 1725 y 1726** + **CP arts. 84 y 94**
- Traducción operativa: en decisiones invasivas o ante incidentes, la cronología tiene que permitir reconstruir prevención, diligencia, controles y nexo causal discutido.
- Impacto redaccional: fecha, hora, autor, motivo del acto, conducta adoptada y control posterior no pueden quedar implícitos ni delegados a "se realizó procedimiento".

### Consentimiento como proceso verificable
- **Ley 26.529 arts. 5 y 6** + **CCCN art. 59** + **Decreto 1089/2012 art. 5**
- Traducción operativa: el consentimiento útil para defensa no es solo firma, sino proceso material de explicación, alternativas, riesgos, posibilidad de rechazo y acceso posterior.
- Impacto redaccional: conviene dejar constancia de qué se explicó, cuándo, quién lo explicó, si hubo preguntas y si se ofreció/entregó copia.

### Historia clínica como documento auténtico y preservable
- **Ley 26.529 arts. 12 a 15** + **Ley 25.506 arts. 6, 7 y 8** + **SAIJ autenticidad de historia clínica**
- Traducción operativa: la historia clínica electrónica o híbrida debe sostener integridad, recuperabilidad y autoría; las correcciones deben ser visibles como addenda.
- Impacto redaccional: evitar sobrescrituras silenciosas, campos vagos sin autor y notas retrospectivas sin marca temporal explícita.

### Secreto profesional y mínima exposición
- **Ley 25.326** + **CP art. 156** + **CCCN arts. 51 a 53**
- Traducción operativa: la documentación debe contener solo datos sensibles útiles para el acto asistencial, con especial cautela en imágenes, audios, fotos y reenvíos.
- Impacto redaccional: describir finalidad asistencial, base de circulación y destinatario cuando se comparte documentación; evitar adjetivación innecesaria o estigmatizante.

### Continuidad asistencial y prevención de abandono documental
- **Ley 26.529 arts. 2 y 15** + **CP art. 106**
- Traducción operativa: alta, derivación o control deben dejar instrucciones, signos de alarma y vía de reconsulta verificables.
- Impacto redaccional: una nota de egreso breve pero completa protege mejor que un alta genérica sin advertencias ni responsable de seguimiento.

## Doctrina y criterios operativos, capa separada
Estado general: `pending_review`, derivada de normas y jurisprudencia estructurada del lote actual. No citar como si fuera norma.

1. **Principio de completitud útil**. Documentar lo necesario para reconstruir decisión, ejecución y seguimiento, evitando tanto vacíos críticos como relleno irrelevante.
2. **Principio de secuencia temporal**. Cada nota debe permitir reconstruir quién hizo qué, cuándo y con qué fundamento clínico.
3. **Principio de correlación clínico-radiológica**. En columna/neurocirugía no alcanza listar estudios; conviene unir síntoma, hallazgo físico, imagen y conducta.
4. **Principio de consentimiento material**. Debe quedar constancia de riesgos relevantes, alternativas razonables, posibilidad de rechazo y oportunidad temporal suficiente.
5. **Principio de preservación**. Toda enmienda posterior debe quedar visible como addenda fechada, sin borrar la versión previa.
6. **Principio de razonabilidad explícita**. Cuando la decisión es invasiva o riesgosa, el registro debe exponer por qué se eligió esa conducta y no otra.
7. **Principio de control final verificable**. El parte quirúrgico debe dejar asentados chequeos finales relevantes, incidentes y estado de cierre para reducir ambigüedad pericial.

## Mapa de artículos prioritarios ya bajados desde fuentes oficiales

### Ley 26.529
- **Art. 2**: fija derechos del paciente y sostiene trato digno, información suficiente y documentación clínica útil.
- **Art. 5**: define el contenido material mínimo del consentimiento informado.
- **Art. 6**: vuelve exigible el consentimiento previo como regla general de actuación médico-sanitaria.
- **Art. 11**: incorpora directivas anticipadas y obliga a no redactar notas incompatibles con esa autonomía.
- **Arts. 12 a 15**: convierten la historia clínica en documento obligatorio, cronológico, completo, con reglas de integridad, titularidad, acceso y asientos mínimos.

### Decreto 1089/2012
- **Art. 2**: aterriza deberes de asistencia y ejercicio efectivo de derechos del paciente dentro del sistema de salud.
- **Art. 5**: interpreta el consentimiento como proceso, no solo firma, incluyendo competencia, comprensión y plan diagnóstico/terapéutico/quirúrgico.
- **Art. 12**: exige en historia clínica escrita autor identificable, procesos aceptados/rechazados y conservación/recuperabilidad.
- **Art. 13**: vincula historia clínica informatizada con Ley 25.506 y preservación de documentación respaldatoria.

### Ley 25.506 de Firma Digital
- **Arts. 2 y 3**: distinguen firma digital y firma electrónica, útil para no mezclar evidencia fuerte con trazas informales.
- **Art. 6**: regla de documento digital y exigencia legal escrita, relevante para soporte electrónico de historia clínica y consentimientos.
- **Arts. 7 y 8**: presunciones de autoría e integridad cuando la firma digital es válida, clave para autenticidad de registros y addendas.
- **Art. 14**: refuerza acceso del paciente a copia autenticada dentro del plazo legal y acelera urgencias.
- **Art. 15**: agrega datos mínimos, fecha y hora inmediatas, redacción clara, prohibición de tachaduras/borrados y manejo formal de errores.

### Código Civil y Comercial de la Nación
- **Arts. 51 y 52**: dignidad e intimidad como base para evitar redacciones humillantes, estigmatizantes o innecesariamente invasivas.
- **Art. 53**: consentimiento para imagen/voz, útil para fotos clínicas, registros audiovisuales o material docente/promocional.
- **Arts. 55 y 56**: actos sobre derechos personalísimos y propio cuerpo, con consentimiento restrictivo, no presumido y revocable.
- **Art. 59**: consentimiento informado para actos médicos e investigaciones en salud con detalle material alineado al flujo clínico.
- **Arts. 1710 y 1716**: prevención del daño y deber de reparar, que vuelven prudente documentar advertencias, controles y medidas preventivas.
- **Arts. 1724, 1725 y 1726**: culpa, valoración de la conducta y nexo causal, claves para que la historia clínica muestre diligencia, previsibilidad y razonamiento clínico.
- **Art. 1737**: concepto de daño, útil para recordar que la documentación también protege frente a daños no patrimoniales y de persona.

### Código Penal de la Nación
- **Art. 84**: homicidio culposo por imprudencia, negligencia, impericia o inobservancia de deberes, con impacto directo en cómo se documentan controles y decisiones.
- **Art. 94**: lesiones culposas con misma lógica de reproche por imprudencia/negligencia/impericia.
- **Art. 106**: abandono o puesta en peligro de la vida/salud ajena, relevante para continuidad asistencial, derivaciones y constancias de indicaciones.
- **Art. 156**: secreto profesional, base penal para mínima exposición y control de acceso a datos sensibles.

## Vacíos pendientes del siguiente lote
- Otras normas complementarias de Ley 26.529 y normativa sectorial adicional de historia clínica electrónica/digital, si la fuente oficial específica se confirma más allá del puente ya trazado Decreto 1089/2012 art. 13 + Ley 25.506.
- Fallos con texto completo y más precedentes directamente vinculados a consentimiento informado/partes quirúrgicos/neurocirugía, priorizando el nuevo lote `operacion quirurgica negligencia medica` y las búsquedas específicas de neurocirugía/columna.
- Oficializar las cuatro fuentes secundarias neuro/columna o dejarlas como alerta si no aparece copia judicial primaria.
- Consolidar una cola de revisión priorizada para diferenciar precedentes de historia clínica, consentimiento y seguridad intraoperatoria.
