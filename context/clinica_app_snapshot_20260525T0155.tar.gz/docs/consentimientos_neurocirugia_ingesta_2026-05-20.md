# Ingesta Consentimientos Neurocirugia - 2026-05-20

Estado: OK.

Archivos revisados: 1339.
Textos únicos detectados: 952.
Consentimientos neuroquirúrgicos únicos filtrados: 934.
Familias incorporadas al corpus: 19.
Fallos de extracción: 3.

Privacidad: el corpus guarda rasgos derivados, hashes y conteos; no vuelca texto completo, nombres de pacientes ni rutas fuente completas.

## Familias principales

- tumor_intracraneal_absceso: 177 fuentes únicas; instituciones higa_junin, itaes_anexo, la_pequena_familia, no_determinada; riesgos convulsiones, deficit_neurologico, dolor_residual, esfinteres, implantes, infeccion, lcr_dural, muerte, reoperacion, sangrado_hematoma, valvula.
- vertebroplastia_cifoplastia: 110 fuentes únicas; instituciones clinica_centro, higa_junin, itaes_anexo, la_pequena_familia, no_determinada; riesgos cemento, convulsiones, deficit_neurologico, dolor_residual, esfinteres, implantes, infeccion, lcr_dural, muerte, reoperacion, sangrado_hematoma.
- hernia_disco_lumbar: 108 fuentes únicas; instituciones clinica_centro, higa_junin, la_pequena_familia, no_determinada; riesgos cemento, deficit_neurologico, dolor_residual, esfinteres, implantes, infeccion, lcr_dural, muerte, reoperacion, sangrado_hematoma, valvula.
- trauma_columna: 88 fuentes únicas; instituciones higa_junin, la_pequena_familia; riesgos cemento, convulsiones, deficit_neurologico, dolor_residual, esfinteres, implantes, infeccion, lcr_dural, muerte, reoperacion, sangrado_hematoma, valvula.
- neurocirugia_general_otras_patologias: 77 fuentes únicas; instituciones clinica_centro, higa_junin, la_pequena_familia, no_determinada; riesgos convulsiones, deficit_neurologico, dolor_residual, esfinteres, implantes, infeccion, lcr_dural, muerte, reoperacion, sangrado_hematoma.
- biopsia_vertebral_mts_infeccion: 61 fuentes únicas; instituciones higa_junin, la_pequena_familia, no_determinada; riesgos cemento, convulsiones, deficit_neurologico, dolor_residual, esfinteres, implantes, infeccion, lcr_dural, muerte, reoperacion, sangrado_hematoma, valvula.
- hidrocefalia_derivaciones: 55 fuentes únicas; instituciones higa_junin, itaes_anexo, la_pequena_familia, no_determinada; riesgos convulsiones, deficit_neurologico, dolor_residual, esfinteres, implantes, infeccion, lcr_dural, muerte, reoperacion, sangrado_hematoma, valvula.
- columna_cervical_anterior_artrodesis_artroplastia: 41 fuentes únicas; instituciones higa_junin, la_pequena_familia; riesgos deficit_neurologico, dolor_residual, esfinteres, implantes, infeccion, lcr_dural, muerte, reoperacion, sangrado_hematoma.
- vascular_neuroquirurgico: 36 fuentes únicas; instituciones la_pequena_familia; riesgos convulsiones, deficit_neurologico, dolor_residual, esfinteres, implantes, infeccion, lcr_dural, muerte, reoperacion, sangrado_hematoma.
- craneoplastia_hundimiento: 34 fuentes únicas; instituciones higa_junin, la_pequena_familia, no_determinada; riesgos deficit_neurologico, implantes, infeccion, lcr_dural, muerte, reoperacion, sangrado_hematoma, valvula.
- canal_estrecho_lumbar_sin_fijacion: 30 fuentes únicas; instituciones higa_junin, la_pequena_familia, no_determinada; riesgos deficit_neurologico, dolor_residual, esfinteres, implantes, infeccion, lcr_dural, muerte, reoperacion, sangrado_hematoma.
- hematoma_subdural_epidural: 26 fuentes únicas; instituciones higa_junin, la_pequena_familia; riesgos deficit_neurologico, dolor_residual, implantes, infeccion, lcr_dural, muerte, reoperacion, sangrado_hematoma.
- canal_estrecho_lumbar_con_fijacion: 24 fuentes únicas; instituciones higa_junin, la_pequena_familia; riesgos deficit_neurologico, dolor_residual, esfinteres, implantes, infeccion, lcr_dural, muerte, reoperacion, sangrado_hematoma, valvula.
- tunel_carpiano_cubital_periferico: 17 fuentes únicas; instituciones higa_junin, la_pequena_familia, no_determinada; riesgos deficit_neurologico, dolor_residual, infeccion, lcr_dural, sangrado_hematoma.
- chiari: 17 fuentes únicas; instituciones higa_junin, la_pequena_familia; riesgos convulsiones, deficit_neurologico, dolor_residual, implantes, infeccion, lcr_dural, muerte, reoperacion, sangrado_hematoma.
- laminoplastia_cervical_canal_cervical: 14 fuentes únicas; instituciones higa_junin, la_pequena_familia; riesgos deficit_neurologico, dolor_residual, esfinteres, implantes, infeccion, lcr_dural, muerte, reoperacion, sangrado_hematoma.
- tumor_medular_intrarraquideo: 12 fuentes únicas; instituciones higa_junin, la_pequena_familia; riesgos deficit_neurologico, dolor_residual, esfinteres, implantes, infeccion, lcr_dural, muerte, reoperacion, sangrado_hematoma.
- coflex_diam_interespinoso: 6 fuentes únicas; instituciones la_pequena_familia; riesgos deficit_neurologico, dolor_residual, esfinteres, implantes, infeccion, lcr_dural, muerte, reoperacion, sangrado_hematoma.
- mielomeningocele_pediatrico: 1 fuentes únicas; instituciones la_pequena_familia; riesgos infeccion, lcr_dural, reoperacion, sangrado_hematoma.

## Uso operativo

- El corpus fuente complementa `consent_body_pack_2026-05-19.json` como respaldo de variabilidad histórica.
- No habilita entrega automática de una nueva patología por sí solo: primero debe pasar matriz R1-R8 y formato visual aprobado.
- Sirve para enriquecer riesgos, alternativas y consecuencias de no tratar por familia, sin copiar formularios viejos de manera literal.
