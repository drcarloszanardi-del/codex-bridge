# Puente Jarvis-App Para Documentos Clinicos

La ruta operativa completa y obligatoria queda consolidada en:

`/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/docs/RUTA_UNICA_JARVIS_CLINICA.md`

Ese archivo prevalece ante dudas operativas de Jarvis.

## Objetivo

Jarvis no redacta historia clinica, protocolo quirurgico ni consentimiento por cuenta propia. Cuando el Dr. Zanardi pide un documento por Telegram, Jarvis debe llamar al wrapper unico:

```bash
/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_generar_y_enviar.sh \
  --type hc|parte|consent|evolucion \
  --input "relato del caso" \
  --patient "Nombre Apellido" \
  --date "20/05/2026" \
  --family lumbar_hdl|lumbar_fijacion|cervical|auto \
  --institution clinica_centro|la_pequena_familia|higa_junin|centro_medico_pellegrini
```

El puente genera el documento con `app/product.html`, exporta PDF/HTML y deja un manifiesto en:

`/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/`

## Regla anti-error de conversion

Jarvis no debe convertir HTML a PDF por su cuenta, no debe usar `wkhtmltopdf`, `weasyprint`, el navegador ni rutas relativas para esta tarea.

Debe ejecutar siempre:

`/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_generar_y_enviar.sh`

Ese wrapper deja seteado:

- Node fijo: `/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node`
- Python fijo: `/Users/jarvis/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3`
- `OPENCLAW_NODE`
- `CLINICA_PYTHON`
- `PATH`

La conversion a PDF ocurre dentro de la app mediante `scripts/exports/export_clinical_document_pdf.py` o, para consentimientos, `scripts/exports/export_consent_artifact.py`. Si la conversion falla, Jarvis debe reportar el error del wrapper y no improvisar otro PDF.

## Regla de seguridad

- Consentimiento: compuerta dura. Solo se envia si el validador devuelve `APTO_PARA_ENVIO`.
- Historia clinica y protocolo quirurgico: chequeo medico-legal obligatorio flexible.
- Si el estado es `APTO_PARA_ENVIO`, Jarvis puede enviar.
- Si el estado es `APTO_CON_OBSERVACIONES`, Jarvis puede enviar, dejando las observaciones en el manifiesto.
- Si el estado es `BLOQUEADO_NO_ENVIAR`, Jarvis no envia.

## Bloqueos rojos

El puente bloquea si detecta:

- frases prohibidas: `y/o`, `radiculalgia`, `si corresponde`, `cuando corresponda`, `si aplica`, `eventual`;
- placeholders visibles de nivel, lateralidad, fecha, paciente o datos criticos;
- contradiccion de nivel/lateralidad;
- deficit motor no declarado por el medico;
- historia clinica sin secciones basicas;
- protocolo quirurgico sin secuencia operatoria real;
- consentimiento que no pase matriz medico-legal R1-R8.

## Envio por Telegram

Sin `--send`, el puente no toca Telegram y devuelve `send_command` en el manifiesto.

Con `--send`, el puente llama a:

`/Users/jarvis/.openclaw/workspace/scripts/telegram_send_document_guard.js`

Esto conserva el canal y no modifica la configuracion de Telegram.

## Ejemplo de historia clinica

```bash
/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_generar_y_enviar.sh \
  --type hc \
  --family lumbar_hdl \
  --input "Paciente con hernia discal posterolateral L4-L5 izquierda y dolor radicular izquierdo. Microdiscectomia tubular L4-L5 izquierda." \
  --patient "Paciente Ejemplo" \
  --age 61 \
  --date "20/05/2026" \
  --level L4-L5 \
  --side izquierda \
  --institution clinica_centro
```

## Ejemplo de consentimiento

```bash
/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_generar_y_enviar.sh \
  --type consent \
  --slug hernia_disco_lumbar \
  --patient "Paciente Ejemplo" \
  --dni "11.111.111" \
  --date "20/05/2026" \
  --level "L4-L5 izquierda" \
  --team "Ayudante Ejemplo" \
  --institution clinica_centro
```
