# CLI-001 Matriz de requisitos obligatorios para consentimiento informado quirúrgico en Argentina

Fecha de corte: 2026-05-18T18:24:00Z  
Estado: borrador operativo trazable para auditoría y corrección de plantillas  
Task: `CLI-001-CONSENTIMIENTOS-AUDITORIA-NORMATIVA-ARG-20260518`

## Fuentes base usadas en esta matriz

### ZIP humano `message_id=5757`
- `medilegal/leyes/ley-26529.md`
- `medilegal/leyes/decreto-1089-2012.md`
- `medilegal/leyes/ley-17132.md`
- `medilegal/leyes/ccyc-responsabilidad.md`
- `medilegal/campos-obligatorios/parte-campos.md`
- `medilegal/validacion/frases-prohibidas.md`
- `medilegal/patologias/columna-lumbar.md`

### Corpus local ya preservado
- `clinica/app-clinica-medicolegal/docs/corpus_medicolegal_argentino.md`
- `clinica/plantillas/CONSENTIMIENTOS_SISTEMA_CANONICO_MULTIINSTITUCION.md`
- `clinica/plantillas/CONSENTIMIENTOS_CIERRE_FINAL_AUDITABLE.md`
- `clinica/plantillas/checklist_legal_y_visual.md`

## Regla de auditoría
Una plantilla de consentimiento se considera conforme solo si cubre los bloques R1 a R8 y no incurre en hallazgos rojos. Si falta un dato variable del paciente o procedimiento, el modelo puede quedar `completable`; si falta una cláusula estructural o legal, queda `no_conforme`.

## Matriz de requisitos

| ID | Requisito obligatorio | Base normativa o fuente | Impacto en plantillas |
|---|---|---|---|
| R1 | Identificación del paciente y del acto | Ley 26.529 arts. 12, 14, 19; Decreto 1089/2012; corpus local | Debe incluir nombre y apellido, DNI, fecha, institución y procedimiento propuesto. |
| R2 | Información suficiente sobre diagnóstico e indicación | Ley 26.529; CCCN art. 59; corpus local | Debe explicar diagnóstico, motivo de la cirugía e indicación concreta, no solo el nombre del procedimiento. |
| R3 | Descripción comprensible del procedimiento | Ley 26.529 arts. 5, 6; Decreto 1089/2012; sistema canónico | Debe describir qué se hará en lenguaje claro, evitando vaguedad y tecnicismo vacío. |
| R4 | Riesgos relevantes y específicos | Ley 26.529; CCCN art. 59; patología columna lumbar | Debe listar riesgos generales y riesgos propios del nivel, lateralidad, instrumentación o patología. |
| R5 | Beneficios esperados, alternativas y consecuencias de no tratar | Ley 26.529; Decreto 1089/2012; corpus local | Debe incluir beneficios probables, alternativas razonables y riesgo de rechazo/no tratamiento. |
| R6 | Voluntariedad, posibilidad de preguntas, rechazo y revocación | Ley 26.529; sistema canónico multiinstitución | Debe dejar constancia de comprensión, posibilidad de consultar, rechazar o revocar antes del acto. |
| R7 | Firmas, aclaraciones y rol de representante si corresponde | Ley 26.529 art. 14; Ley 17.132; sistema canónico | Debe contemplar firma del paciente o representante, firma del profesional, aclaración y matrícula. |
| R8 | Trazabilidad documental y copia | Ley 26.529 arts. 15, 18, 19; Decreto 1089/2012; corpus local | Debe poder archivarse en HC, con fecha previa al acto y disponibilidad de copia/acceso. |

## Subrequisitos operativos por bloque

### R1. Identificación mínima
- Paciente: nombre completo y DNI.
- Fecha del consentimiento.
- Institución.
- Procedimiento propuesto con nivel, segmento o lateralidad cuando aplique.
- Profesional actuante con matrícula.

### R2. Información clínica mínima
- Diagnóstico preoperatorio en términos comprensibles.
- Relación entre diagnóstico e indicación quirúrgica.
- Si es patología de columna, nivel y lado deben quedar expresos.

### R3. Descripción del procedimiento
- Descripción breve pero específica del acto propuesto.
- Si hay fijación, implantes o abordaje especial, debe mencionarse.
- Prohibido dejar fórmulas genéricas del tipo “cirugía habitual”, “técnica estándar” o equivalentes.

### R4. Riesgos relevantes
#### Riesgos transversales mínimos
- Sangrado.
- Infección.
- Lesión neurológica o funcional cuando corresponda.
- Dolor residual o falta de mejoría.
- Riesgos anestésicos.
- Necesidad de reintervención o complicaciones imprevistas.

#### Riesgos específicos columna lumbar
- Lesión radicular o dural.
- Recidiva herniaria.
- Persistencia del dolor.
- Inestabilidad segmentaria.
- Si hay instrumentación: falla de implante, pseudoartrosis, malposición.

### R5. Alternativas y no tratamiento
- Debe mencionar alternativas razonables, aunque sea tratamiento conservador.
- Debe dejar constancia de consecuencias probables de no tratar.
- No alcanza la sola frase “se explicaron alternativas” si no se individualiza al menos la categoría terapéutica.

### R6. Voluntariedad y comprensión
- Debe constar que el paciente pudo formular preguntas.
- Debe constar que comprendió la información brindada.
- Debe constar que presta consentimiento libremente.
- Debe contemplar rechazo o revocación previa al procedimiento.

### R7. Firma y representación
- Firma y aclaración del paciente.
- Si firma representante: vínculo, DNI y causa habilitante.
- Firma y aclaración del profesional con matrícula.
- Espacio para testigo solo si el modelo institucional lo exige, no como reemplazo de las firmas base.

### R8. Trazabilidad y soporte
- Fecha del consentimiento anterior o concurrente al acto, nunca posterior.
- Debe ser integrable a HC única, cronológica y completa.
- No debe admitir correcciones silenciosas sobre el documento firmado.
- Debe poder archivarse con copia para paciente o acceso posterior.

## Hallazgos rojos de no conformidad
- Falta de riesgos específicos del procedimiento.
- Falta de alternativas terapéuticas o de consecuencias de no tratar.
- Falta de identificación del procedimiento concreto.
- Falta de firma/matrícula del profesional.
- Modelo excesivamente genérico que no distingue diagnóstico, nivel o técnica.
- Cláusulas que aparenten eximir responsabilidad o sustituyan información por fórmulas vacías.

## Hallazgos amarillos corregibles
- Riesgos listados pero sin adaptación suficiente a la patología.
- Procedimiento descripto con terminología demasiado técnica para paciente.
- Alternativas mencionadas de modo escueto pero presentes.
- Espacios de identificación incompletos pero claramente previstos.

## Alertas de lenguaje
Tomar como gatillos de corrección las fórmulas del ZIP `frases-prohibidas.md`, especialmente:
- “procedimiento habitual”
- “técnica estándar”
- “sin novedades”
- descripciones sin nivel o lateralidad
- referencias vagas a implantes o complicaciones

## Relación con el sistema canónico actual
- La estructura protegida multiinstitución ya favorece R6 y R7.
- La auditoría debe concentrarse en verificar si cada plantilla cubre R2, R3, R4 y R5 con especificidad suficiente por patología e institución.
- Los consentimientos aprobados en HTML/MD deben clasificarse luego como `conforme`, `conforme_con_ajustes_menores` o `no_conforme` contra esta matriz.

## Gaps abiertos para la siguiente tanda
- Integrar al corpus operativo los faltantes del ZIP contra `INDEX.md`: `ley-25326.md`, `ley-25506.md`, `codigo-penal.md`, `fallos-parte.md`, `fallos-columna.md`, `fallos-consentimiento.md`, `hc-campos.md`, `anestesia-campos.md`, `checklist-hc.md`, `checklist-parte.md`, `frases-correctas.md`, `columna-cervical.md`.
- Auditar una por una las plantillas vigentes en `clinica/plantillas/` usando esta matriz como guard de conformidad.
