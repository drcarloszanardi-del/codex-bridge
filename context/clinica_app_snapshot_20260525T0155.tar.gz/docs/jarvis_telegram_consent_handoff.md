# Handoff Jarvis - Consentimiento PDF por Telegram

Objetivo: permitir que Jarvis reciba un pedido breve por Telegram, genere un consentimiento informado con logo institucional en PDF de una sola carilla y lo envie por Telegram respetando el formato aprobado.

## Regla de arquitectura

- La app clinica genera el documento final.
- Jarvis solo actua como mensajero y orquestador.
- La app no toca tokens, chats ni configuracion de Telegram.
- El envio real debe pasar por `telegram_send_document_guard.js`.
- `hernia_disco_lumbar` es la proforma de formato, no el contenido universal.
- El contenido medico-legal sale siempre del `--slug` solicitado: diagnostico, procedimiento, riesgos, alternativas y consecuencias de no tratar.
- El diseño visual no es variable de Jarvis: debe salir siempre con `visual_standard_id=consentimiento_sobrio_institucional_v1`.
- El contenido medico-legal no es variable de Jarvis: debe salir siempre con `content_standard_id=consentimiento_medicolegal_arg_v1`.

## Estandar visual fijo

- A4 sobrio, profesional y de lectura clinico-legal.
- Logo institucional unico en la cabecera, mas visible e integrado al blanco de la hoja. Si el logo ya contiene el nombre de la institucion, no repetir el texto institucional debajo.
- Los logos deben salir desde la app preservando proporcion real; Jarvis no debe estirarlos, recortarlos ni reinsertarlos manualmente.
- Para `higa_junin`, el unico logo valido para PDF final es `clinica/logos/hospital_junin_logo_limpio.png`.
- Titulo del consentimiento centrado debajo del logo, en mayusculas y sin decoracion innecesaria.
- Cuerpo justificado en tipografia simple, usando bien el ancho de hoja y sin comprimir de manera innecesaria.
- Firmas al pie en paralelo, paciente a la izquierda y medico a la derecha, con lineas simples.
- Jarvis no debe reconstruir ni redisenar el consentimiento: solo llama el exportador de la app y envia el PDF resultante.
- Jarvis no debe reescribir el contenido legal desde cero: solo selecciona el slug, completa datos variables y deja que el exportador aplique la proforma y la matriz R1-R8.
- Antes de entregar o enviar por Telegram, el manifiesto debe quedar con `validation.status=APTO_PARA_ENVIO`. Si la validacion falla, el script bloquea el envio.

## Comando de generacion sin envio

Jarvis debe llamar:

```bash
node /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/consent_telegram_handoff.js \
  --slug hernia_disco_lumbar \
  --institution clinica_centro \
  --patient "Nombre Apellido" \
  --dni "DNI" \
  --date "19/05/2026" \
  --level "L4-L5 izquierda" \
  --team "Ayudante"
```

Salida:

- PDF listo en `exports/telegram_ready/`.
- JSON de handoff en `/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/`.
- Estado `pending_telegram_send`.

## Comando de generacion y envio

Cuando Jarvis tenga el `chat_id` del mensaje humano:

```bash
node /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/consent_telegram_handoff.js \
  --slug hernia_disco_lumbar \
  --institution clinica_centro \
  --patient "Nombre Apellido" \
  --dni "DNI" \
  --date "19/05/2026" \
  --level "L4-L5 izquierda" \
  --team "Ayudante" \
  --chat-id "<chat_id>" \
  --caption "Consentimiento informado" \
  --send
```

El script invoca:

```bash
/Users/jarvis/.openclaw/workspace/scripts/telegram_send_document_guard.js
```

## Garantias del puente

- PDF en una sola carilla (`--one-page` obligatorio).
- Logo institucional desde `clinica/logos`.
- Logo HIGA permanente: `clinica/logos/hospital_junin_logo_limpio.png`; no usar `hospital_junin_logo.svg.png` en entregas finales.
- Estandar visual fijo `consentimiento_sobrio_institucional_v1`.
- Estandar de contenido fijo `consentimiento_medicolegal_arg_v1`.
- Formato basado en consentimiento de hernia de disco lumbar.
- Contenido basado en la patologia solicitada por `--slug`.
- Matriz R1-R8 obligatoria: identificacion, diagnostico, procedimiento, riesgos especificos, beneficios/alternativas/no tratamiento, autonomia, firmas con matricula e integracion a historia clinica con copia/acceso.
- Si el slug es `canal_estrecho_lumbar_con_fijacion`, el PDF debe hablar de canal estrecho/fijacion, no de hernia de disco.
- Sin frases abiertas tipo `si corresponde`, `cuando corresponda`, `eventual`.
- Sin tocar secretos ni configuracion de Telegram.
- Sin envio si falta contenido R1-R8, matricula `MP 63905 MN 116564`, nivel/lateralidad informado, o si quedan placeholders visibles.
- Si el PDF no entra en una carilla, el comando falla y no deja enviar una version no conforme.

## Slugs principales disponibles

- `hernia_disco_lumbar`
- `canal_estrecho_lumbar_con_fijacion`
- `canal_estrecho_lumbar_sin_fijacion`
- `laminoplastia_cervical`
- `artrodesis_cervical`
- `cifoplastia_vertebroplastia`
- `hidrocefalia_derivaciones`
- `chiari`
- `tunel_carpiano_y_neuropatias`

## Flujo operativo recomendado

1. El medico le pide a Jarvis: `mandame consentimiento de hernia L4-L5 izquierda Clinica Centro para Juan Perez`.
2. Jarvis interpreta slug, institucion, paciente, fecha, nivel/lado y ayudante.
3. Jarvis llama `consent_telegram_handoff.js`.
4. Si esta en el mismo chat de Telegram, Jarvis agrega `--chat-id` y `--send`.
5. Jarvis informa el `message_id` o, si no envio, deja el manifiesto pendiente.
