# Plan del cuerpo medicolegal interno

## Objetivo
Construir un cuerpo medicolegal interno, trazable y actualizable, que gobierne la futura redacción clínica y quirúrgica sin exponer la fundamentación jurídica en el documento final.

## Reglas rectoras
- fuentes trazables, no memoria libre del modelo
- raw inmutable
- fragmentos citables
- vigencia controlada
- nada nuevo entra en producción sin revisión/aprobación
- separación entre corpus legal y corpus clínico

## Componentes
1. repositorio de normas
2. repositorio de jurisprudencia
3. repositorio de doctrina/guías
4. citas y fragmentos verificables
5. reglas operativas derivadas
6. estado de revisión y vigencia
7. actualización automática controlada

## Próxima construcción
- inbox normativo
- pipeline de actualización automática
- esquema de activación/desactivación de reglas
- fuentes prioritarias argentinas
