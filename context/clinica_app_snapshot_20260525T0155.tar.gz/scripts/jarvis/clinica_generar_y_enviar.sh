#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal"
NODE="/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node"
PYTHON="/Users/jarvis/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3"
BRIDGE="${APP_ROOT}/scripts/jarvis/clinical_document_handoff.js"

export OPENCLAW_NODE="$NODE"
export CLINICA_PYTHON="$PYTHON"
export PATH="/Users/jarvis/.openclaw/tools/node-v22.22.0/bin:/Users/jarvis/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin:${PATH}"

if [[ ! -x "$NODE" ]]; then
  echo "{\"ok\":false,\"status\":\"RUNTIME_NODE_NO_DISPONIBLE\",\"error\":\"No existe Node fijo: $NODE\"}" >&2
  exit 70
fi

if [[ ! -x "$PYTHON" ]]; then
  echo "{\"ok\":false,\"status\":\"RUNTIME_PYTHON_NO_DISPONIBLE\",\"error\":\"No existe Python fijo: $PYTHON\"}" >&2
  exit 70
fi

if [[ ! -f "$BRIDGE" ]]; then
  echo "{\"ok\":false,\"status\":\"PUENTE_CLINICA_NO_DISPONIBLE\",\"error\":\"No existe bridge: $BRIDGE\"}" >&2
  exit 70
fi

"$PYTHON" - <<'PY' >/dev/null
import reportlab
import pypdf
try:
    import PIL
except Exception:
    pass
PY

exec "$NODE" "$BRIDGE" "$@"
