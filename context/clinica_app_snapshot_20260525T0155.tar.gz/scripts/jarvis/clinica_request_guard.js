#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const WORKSPACE = '/Users/jarvis/.openclaw/workspace';
const SESSIONS_DIR = '/Users/jarvis/.openclaw/agents/main/sessions';
const APP_ROOT = path.resolve(__dirname, '..', '..');
const WRAPPER = path.join(APP_ROOT, 'scripts', 'jarvis', 'clinica_generar_y_enviar.sh');
const ROUTE_DOC = path.join(APP_ROOT, 'docs', 'RUTA_UNICA_JARVIS_CLINICA.md');

function usage() {
  console.error(`usage:
  clinica_request_guard.js --request "texto humano"
  clinica_request_guard.js --session /abs/session.jsonl [--strict]
  clinica_request_guard.js --scan-recent [--hours 24] [--strict]

Detecta pedidos clinicos que Jarvis debe derivar a la app y audita respuestas/sesiones con redaccion manual.`);
  process.exit(2);
}

function parseArgs(argv) {
  const out = { hours: 24, strict: false };
  for (let i = 2; i < argv.length; i += 1) {
    const key = argv[i];
    const value = argv[i + 1];
    if (key === '--request' || key === '--text') { out.request = value; i += 1; continue; }
    if (key === '--session') { out.session = value; i += 1; continue; }
    if (key === '--scan-recent') { out.scanRecent = true; continue; }
    if (key === '--hours') { out.hours = Number(value || 24); i += 1; continue; }
    if (key === '--strict') { out.strict = true; continue; }
    usage();
  }
  if (!out.request && !out.session && !out.scanRecent) usage();
  return out;
}

function norm(value) {
  return String(value || '')
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function detectRequest(text) {
  const n = norm(text);
  const types = [];
  if (/\b(consentimiento|consentimiento informado|consent)\b/.test(n)) types.push('consent');
  if (/\b(historia clinica|\bhc\b)\b/.test(n)) types.push('hc');
  if (/\b(parte quirurgico|protocolo quirurgico|parte|protocolo)\b/.test(n)) types.push('parte');
  if (/\b(evolucion postoperatoria|evolucion|poi)\b/.test(n)) types.push('evolucion');
  const clinicalTerms = /\b(hernia|microdiscectomia|columna|laminoplastia|fijacion|artrodesis|canal estrecho|radicular|hematoma|lodge|toilette|reapertura|drenaje|evacuacion|coleccion|infeccion|l[1-5]\s*[-/]\s*l?[1-5]|c[1-7]\s*[-/]\s*c?[1-7])\b/.test(n);
  const mustUseApp = types.length > 0 || (clinicalTerms && /\b(redact\w*|hac\w*|gener\w*|mand\w*|envi\w*|prepar\w*|arm\w*|necesito|pasame|dame)\b/.test(n));
  return {
    clinical_document_request: mustUseApp,
    requested_types: [...new Set(types.length ? types : (mustUseApp ? ['clinical_document'] : []))],
    required_route: WRAPPER,
    route_doc: ROUTE_DOC,
    direct_answer_allowed: !mustUseApp,
    manual_workspace_write_allowed: false,
    telegram_send_requires_guard: true,
    rule: mustUseApp
      ? 'Jarvis debe llamar al wrapper de la app y responder con file/manifest/status; no puede redactar texto clinico libre.'
      : 'No parece pedido de documento clinico.',
  };
}

function readJsonLine(line) {
  try { return JSON.parse(line); } catch { return null; }
}

function contentText(item) {
  if (!item) return '';
  if (typeof item === 'string') return item;
  if (item.type === 'text' || item.type === 'thinking') return item.text || item.thinking || '';
  if (item.type === 'toolCall') return JSON.stringify(item);
  return JSON.stringify(item);
}

function isManualClinicalPath(filePath) {
  const p = String(filePath || '');
  if (!p.startsWith(WORKSPACE)) return false;
  if (p.includes('/clinica/app-clinica-medicolegal/exports/telegram_ready/')) return false;
  if (p.includes('/outbox/clinica_medicolegal/telegram_ready/')) return false;
  if (p.includes('/clinica/app-clinica-medicolegal/')) return false;
  return /\/clinica\/(?:historia_clinica|partes_quirurgicos\/.*(?:protocolo|parte)|.*(?:historia|protocolo|parte).*\.md$)/i.test(p);
}

function isClinicalTelegramSendText(text) {
  const normalized = norm(text);
  const rawSend = /send_telegram_document\.js/.test(text)
    && !/telegram_send_document_guard\.js/.test(text);
  const clinical = /\b(consentimiento|historia clinica|historia_clinica|protocolo quirurgico|protocolo_quirurgico|parte quirurgico|parte_quirurgico|evolucion postoperatoria|evolucion_postoperatoria)\b/.test(normalized);
  return rawSend && clinical && normalized.includes('/clinica/');
}

function auditSession(file) {
  const violations = [];
  const lines = fs.readFileSync(file, 'utf8').split(/\n/);
  lines.forEach((line, index) => {
    if (!line.trim()) return;
    const record = readJsonLine(line);
    const message = record?.message;
    if (!message || message.role !== 'assistant') return;
    const contents = Array.isArray(message.content) ? message.content : [];
    const text = contents.map(contentText).join('\n');

    for (const item of contents) {
      if (item?.type !== 'toolCall' || item.name !== 'write') continue;
      const target = item.arguments?.path || item.arguments?.file || '';
      if (isManualClinicalPath(target)) {
        violations.push({
          file,
          line: index + 1,
          kind: 'manual_clinical_file_write',
          target,
          message: 'Jarvis escribio un documento clinico fuera de la app/handoff.',
        });
      }
    }

    const normalized = norm(text);
    if (isClinicalTelegramSendText(text)) {
      violations.push({
        file,
        line: index + 1,
        kind: 'manual_clinical_telegram_send',
        message: 'Jarvis intento enviar un documento clinico por send_telegram_document.js sin pasar por el guard/manifiesto de app.',
      });
    }
    const looksLikeClinicalAnswer = /\b(historia clinica|protocolo quirurgico|parte quirurgico|consentimiento informado)\b/.test(normalized)
      && /\b(motivo de ingreso|enfermedad actual|descripcion quirurgica|procedimiento realizado|diagnostico preoperatorio|firma y sello)\b/.test(normalized);
    const hasApprovedRoute = /clinical_document_handoff|clinica_generar_y_enviar|app\.product\.html via clinical_document_handoff|outbox\/clinica_medicolegal\/telegram_ready/.test(text);
    if (looksLikeClinicalAnswer && !hasApprovedRoute) {
      violations.push({
        file,
        line: index + 1,
        kind: 'manual_clinical_reply',
        message: 'Jarvis respondio con documento clinico redactado libremente, sin manifiesto de app.',
      });
    }
    if (/redact[eé] directo en el workspace|directo en el workspace|no desde la app/i.test(text)) {
      violations.push({
        file,
        line: index + 1,
        kind: 'explicit_bypass_admission',
        message: 'Jarvis admitio haber evitado la app.',
      });
    }
  });
  return violations;
}

function recentSessions(hours) {
  const cutoff = Date.now() - Math.max(1, Number(hours || 24)) * 3600 * 1000;
  return fs.readdirSync(SESSIONS_DIR)
    .filter((name) => name.endsWith('.jsonl'))
    .map((name) => path.join(SESSIONS_DIR, name))
    .filter((file) => fs.statSync(file).mtimeMs >= cutoff);
}

function main() {
  const args = parseArgs(process.argv);
  if (args.request) {
    const result = detectRequest(args.request);
    console.log(JSON.stringify({ ok: true, ...result }, null, 2));
    return;
  }

  const files = args.scanRecent ? recentSessions(args.hours) : [args.session];
  const violations = files.flatMap((file) => auditSession(file));
  const result = {
    ok: violations.length === 0,
    audited_files: files.length,
    violations,
    required_route: WRAPPER,
    route_doc: ROUTE_DOC,
  };
  console.log(JSON.stringify(result, null, 2));
  if (args.strict && violations.length) process.exit(4);
}

main();
