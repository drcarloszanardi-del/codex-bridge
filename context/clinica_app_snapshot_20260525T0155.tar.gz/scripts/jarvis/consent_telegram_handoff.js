#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const APP_ROOT = path.resolve(__dirname, '..', '..');
const WORKSPACE = '/Users/jarvis/.openclaw/workspace';
const PYTHON = process.env.CLINICA_PYTHON || '/Users/jarvis/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3';
const NODE = process.env.OPENCLAW_NODE || '/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node';
const EXPORTER = path.join(APP_ROOT, 'scripts/exports/export_consent_artifact.py');
const SEND_GUARD = path.join(WORKSPACE, 'scripts/telegram_send_document_guard.js');
const READY_DIR = path.join(APP_ROOT, 'exports/telegram_ready');
const HANDOFF_DIR = path.join(WORKSPACE, 'outbox/clinica_medicolegal/telegram_ready');
const VISUAL_STANDARD_ID = 'consentimiento_sobrio_institucional_v1';
const VISUAL_STANDARD_RULE = 'A4 sobrio: logo institucional único agrandado y fundido al blanco, sin repetir nombre institucional si el logo ya lo contiene, título centrado, cuerpo justificado con uso amplio de hoja y firmas en paralelo. Jarvis no elige diseño.';
const CONTENT_STANDARD_ID = 'consentimiento_medicolegal_arg_v1';
const CONTENT_STANDARD_RULE = 'Matriz R1-R8 Argentina: identificación paciente/acto, diagnóstico/indicación, procedimiento comprensible, riesgos específicos, beneficios/alternativas/no tratamiento, autonomía/preguntas/revocación, firmas con matrícula e integración a historia clínica con copia/acceso.';
const SURGEON_LICENSE = 'MP 63905 MN 116564';

function usage() {
  console.error(`usage:
  consent_telegram_handoff.js --slug SLUG --institution clinica_centro [--patient NOMBRE] [--dni DNI] --date FECHA --level NIVEL [--team AYUDANTES]
    [--diagnosis TEXTO] [--procedure TEXTO] [--chat-id CHAT] [--thread-id TOPIC] [--caption TEXTO] [--send]

Genera un PDF de consentimiento en una sola carilla, con logo institucional, formato del consentimiento de hernia de disco y contenido de la patologia solicitada por --slug.
Sin --send no toca Telegram: deja un manifiesto para que Jarvis lo envie.`);
  process.exit(2);
}

function parseArgs(argv) {
  const out = { team: null, send: false };
  for (let i = 2; i < argv.length; i++) {
    const key = argv[i];
    const value = argv[i + 1];
    if (key === '--slug') { out.slug = value; i++; continue; }
    if (key === '--institution') { out.institution = value; i++; continue; }
    if (key === '--patient') { out.patient = value; i++; continue; }
    if (key === '--dni') { out.dni = value; i++; continue; }
    if (key === '--date') { out.date = value; i++; continue; }
    if (key === '--level') { out.level = value; i++; continue; }
    if (key === '--team') { out.team = value; i++; continue; }
    if (key === '--diagnosis') { out.diagnosis = value; i++; continue; }
    if (key === '--procedure') { out.procedure = value; i++; continue; }
    if (key === '--chat-id') { out.chatId = value; i++; continue; }
    if (key === '--thread-id') { out.threadId = value; i++; continue; }
    if (key === '--caption') { out.caption = value; i++; continue; }
    if (key === '--send') { out.send = true; continue; }
    usage();
  }
  for (const required of ['slug', 'institution', 'date', 'level']) {
    if (!out[required]) usage();
  }
  const normalized = normalizeDisplayArgs(out);
  Object.assign(out, normalized);
  if (out.send && !out.chatId) {
    throw new Error('--send requiere --chat-id');
  }
  return out;
}

const DOTTED_LINE = '........................................';
const DEFAULT_TEAM = 'Dr. Carlos Zanardi y equipo';

function isBlank(value) {
  return !String(value || '').trim();
}

function isTestOrPlaceholderPatient(value) {
  const raw = String(value || '').trim();
  if (!raw) return true;
  return /^(\[?paciente\]?|nombre apellido|nombre y apellido)$/i.test(raw)
    || /\b(QA|Wrapper|Bloqueo|Prueba)\b/i.test(raw)
    || /^paciente\s*(qa|prueba|wrapper|bloqueo)/i.test(raw);
}

function isTestOrPlaceholderDni(value) {
  const raw = String(value || '').trim();
  if (!raw) return true;
  return /^(\[?dni\]?|00\.?000\.?000|0+)$/i.test(raw)
    || /^QA[-_ ]?\d*/i.test(raw)
    || /\b(QA|Wrapper|Prueba)\b/i.test(raw);
}

function isTestOrPlaceholderTeam(value) {
  const raw = String(value || '').trim();
  if (!raw) return true;
  if (raw === DEFAULT_TEAM) return true;
  return /^\[?equipo.*\]?$/i.test(raw)
    || /ayudante\s*qa|equipo\s*qa|wrapper|prueba|a completar/i.test(raw);
}

function normalizeDisplayArgs(out) {
  const patientProvided = !isTestOrPlaceholderPatient(out.patient);
  const dniProvided = !isTestOrPlaceholderDni(out.dni);
  const teamProvided = !isTestOrPlaceholderTeam(out.team);
  return {
    patient: patientProvided ? String(out.patient).trim() : DOTTED_LINE,
    dni: dniProvided ? String(out.dni).trim() : DOTTED_LINE,
    team: teamProvided ? String(out.team).trim() : DEFAULT_TEAM,
    patient_data_provided: patientProvided,
    dni_data_provided: dniProvided,
    team_data_provided: teamProvided,
  };
}

function slugify(value) {
  return String(value || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/gi, '_')
    .replace(/^_+|_+$/g, '')
    .toLowerCase() || 'paciente';
}

function runJsonCommand(command, args, options = {}) {
  const raw = execFileSync(command, args, {
    cwd: options.cwd || APP_ROOT,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  }).trim();
  return raw ? JSON.parse(raw) : {};
}

function pdfInfo(file) {
  const raw = execFileSync(PYTHON, ['-c', `
from pypdf import PdfReader
import json, sys
r=PdfReader(sys.argv[1])
text="\\n".join((p.extract_text() or "") for p in r.pages)
print(json.dumps({"pages": len(r.pages), "text": text}, ensure_ascii=False))
  `, file], {
    cwd: APP_ROOT,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  }).trim();
  return JSON.parse(raw);
}

function matchesSlugContent(slug, text, compactText) {
  const rules = {
    hernia_disco_lumbar: /hernia (?:de disco|discal)|extrusi[oó]n discal|microdiscectom/i,
    canal_estrecho_lumbar_con_fijacion: /canal estrecho lumbar/i,
    canal_estrecho_lumbar_sin_fijacion: /canal estrecho lumbar/i,
    laminoplastia_cervical: /laminoplastia cervical|canal estrecho cervical|mielopat/i,
    artrodesis_cervical: /artrodesis cervical|discectom[ií]a cervical|fijaci[oó]n cervical/i,
    artroplastia_cervical: /artroplastia cervical|discectom[ií]a cervical|pr[oó]tesis cervical/i,
    cifoplastia_vertebroplastia: /cifoplastia|vertebroplastia|fractura vertebral/i,
    hidrocefalia_derivaciones: /hidrocefalia|derivaci[oó]n|v[aá]lvula/i,
    chiari: /chiari|fosa posterior|descompresi[oó]n cr[aá]neo cervical/i,
    tunel_carpiano_y_neuropatias: /t[uú]nel carpiano|neuropat[ií]a|liberaci[oó]n/i,
  };
  const rule = rules[slug];
  if (!rule) return true;
  return rule.test(text) || rule.test(compactText);
}

function validateConsentPdf(args, file) {
  const { pages, text } = pdfInfo(file);
  const compactText = text.replace(/\s+/g, ' ');
  const forbiddenVisible = /\b(si corresponde|cuando corresponda|cuando correspond[ií]a|seg[uú]n corresponda|si aplica|eventual(?:mente)?|t[eé]cnica est[aá]ndar)\b/i;
  const noTestPlaceholders = !/\b(Paciente\s+QA|QA[-_ ]?\d+|Ayudante\s+QA|Paciente\s+Wrapper|Ayudante\s+Wrapper|Paciente\s+Bloqueo)\b/i.test(compactText);
  const escapedPatient = String(args.patient).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const escapedDni = String(args.dni).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const patientPattern = args.patient_data_provided ? escapedPatient : '\\.{8,}';
  const dniPattern = args.dni_data_provided ? escapedDni : '\\.{8,}';
  const patientAndDni = new RegExp(`Yo,\\s*${patientPattern}\\s*,?\\s*DNI\\s*${dniPattern}`, 'i').test(compactText);
  const checks = {
    pdf_one_page: pages === 1,
    patient_and_dni: patientAndDni,
    no_test_placeholders: noTestPlaceholders,
    level_or_known_missing_absent: !/\[[^\]]+\]|Completar|nivel\/es y lado|nivel y lado/i.test(text),
    requested_slug_content: matchesSlugContent(args.slug, text, compactText),
    no_hernia_leak_for_other_slug: args.slug === 'hernia_disco_lumbar' || !/hernia de disco lumbar|hernia discal lumbar/i.test(compactText),
    no_forbidden_open_phrases: !forbiddenVisible.test(text),
    procedure_authorization: /Autorizo (?:a los Dres\.|al Dr\.)/i.test(text),
    diagnosis: /diagn[oó]stico de/i.test(text),
    alternatives_and_no_treatment: /alternativas terap[eé]uticas/i.test(compactText) && /si no realizo el tratamiento indicado/i.test(compactText),
    risks: /riesgo|riesgos|lesi[oó]n|infecci[oó]n|sangrado|hematoma|reintervenci[oó]n/i.test(text),
    autonomy: /preguntas.*segunda opini[oó]n.*rechazar.*revocar/i.test(compactText),
    blood_and_anesthesia: /hemoderivados/i.test(text) && /anestesia general/i.test(text),
    no_result_guarantee: /no se me ha garantizado un resultado determinado/i.test(compactText),
    hc_copy_access: /historia cl[ií]nica.*solicitar copia o acceso/i.test(compactText),
    signatures_and_license: /Firma del paciente\/representante/i.test(text) && /Firma del m[eé]dico/i.test(text) && compactText.includes(`Matrícula: ${SURGEON_LICENSE}`),
  };
  const failures = Object.entries(checks).filter(([, ok]) => !ok).map(([key]) => key);
  return {
    ok: failures.length === 0,
    status: failures.length === 0 ? 'APTO_PARA_ENVIO' : 'BLOQUEADO_NO_ENVIAR',
    standard_ids: {
      visual: VISUAL_STANDARD_ID,
      content: CONTENT_STANDARD_ID,
    },
    checks,
    failures,
  };
}

function main() {
  const args = parseArgs(process.argv);
  const now = new Date().toISOString();
  const stamp = now.replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z');
  fs.mkdirSync(READY_DIR, { recursive: true });
  fs.mkdirSync(HANDOFF_DIR, { recursive: true });

  const baseName = `consentimiento_${slugify(args.slug)}_${slugify(args.institution)}_${slugify(args.patient)}_${stamp}`;
  const pdfPath = path.join(READY_DIR, `${baseName}.pdf`);
  const caption = args.caption || `Consentimiento informado (${args.slug})`;

  const exportArgs = [
    EXPORTER,
    '--slug', args.slug,
    '--institution', args.institution,
    '--patient', args.patient,
    '--dni', args.dni,
    '--date', args.date,
    '--level', args.level,
    '--team', args.team,
    '--format', 'pdf',
    '--proforma', 'hernia',
    '--one-page',
    '--output', pdfPath,
  ];
  if (args.diagnosis) exportArgs.push('--diagnosis', args.diagnosis);
  if (args.procedure) exportArgs.push('--procedure', args.procedure);

  execFileSync(PYTHON, exportArgs, {
    cwd: APP_ROOT,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });

  const stat = fs.statSync(pdfPath);
  if (!stat.isFile() || stat.size <= 0) throw new Error(`PDF faltante o vacío: ${pdfPath}`);
  const validation = validateConsentPdf(args, pdfPath);

  const sendCommand = [
    NODE,
    SEND_GUARD,
    '--file', pdfPath,
    '--chat-id', args.chatId || '<chat_id_de_la_conversacion>',
    ...(args.threadId ? ['--thread-id', args.threadId] : []),
    '--caption', caption,
    '--task', `clinica-consent-${stamp}`,
    '--lane', 'clinica_medicolegal',
  ];

  const handoff = {
    created_at: now,
    status: validation.ok ? (args.send ? 'validated_ready_to_send' : 'validated_pending_telegram_send') : 'blocked_validation_failed',
    artifact_type: 'consentimiento_pdf_telegram_ready',
    visual_standard_id: VISUAL_STANDARD_ID,
    visual_standard_rule: VISUAL_STANDARD_RULE,
    content_standard_id: CONTENT_STANDARD_ID,
    content_standard_rule: CONTENT_STANDARD_RULE,
    format_proforma: 'formato_consentimiento_hernia_disco_lumbar',
    content_source_slug: args.slug,
    content_rule: 'Usar solo la estructura formal del consentimiento de hernia. El diagnostico, procedimiento, riesgos, alternativas y consecuencias corresponden al slug solicitado.',
    constraints: {
      pdf_one_page: true,
      institutional_logo: true,
      medico_legal_matrix_r1_r8: true,
      hard_validation_before_send: true,
      telegram_config_touched: false,
      delivery_requires_guard: true,
    },
    request: {
      slug: args.slug,
      institution: args.institution,
      patient: args.patient,
      dni: args.dni,
      patient_data_provided: args.patient_data_provided,
      dni_data_provided: args.dni_data_provided,
      date: args.date,
      level: args.level,
      team: args.team,
      team_data_provided: args.team_data_provided,
      diagnosis: args.diagnosis || null,
      procedure: args.procedure || null,
    },
    file: pdfPath,
    size: stat.size,
    caption,
    validation,
    send_command: sendCommand,
    delivery: null,
  };

  const manifestPath = path.join(HANDOFF_DIR, `${baseName}.json`);
  if (!validation.ok) {
    fs.writeFileSync(manifestPath, JSON.stringify(handoff, null, 2));
    throw new Error(`Consentimiento bloqueado por validacion: ${validation.failures.join(', ')}`);
  }

  fs.writeFileSync(manifestPath, JSON.stringify(handoff, null, 2));
  if (args.send) {
    handoff.delivery = runJsonCommand(NODE, sendCommand.slice(1), { cwd: WORKSPACE });
    handoff.status = handoff.delivery.dry_run ? 'dry_run_validated' : (handoff.delivery.ok ? 'sent' : 'send_failed');
    fs.writeFileSync(manifestPath, JSON.stringify(handoff, null, 2));
  }

  console.log(JSON.stringify({ ok: true, validated: true, validation_status: validation.status, manifest: manifestPath, file: pdfPath, status: handoff.status }, null, 2));
}

main();
