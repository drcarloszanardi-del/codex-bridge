#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { execFileSync } = require('child_process');

const APP_ROOT = path.resolve(__dirname, '..', '..');
const WORKSPACE = '/Users/jarvis/.openclaw/workspace';
const NODE = process.env.OPENCLAW_NODE || '/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node';
const PYTHON = process.env.CLINICA_PYTHON || '/Users/jarvis/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3';
const PRODUCT_HTML = path.join(APP_ROOT, 'app', 'product.html');
const CONSENT_HANDOFF = path.join(APP_ROOT, 'scripts', 'jarvis', 'consent_telegram_handoff.js');
const SEND_GUARD = path.join(WORKSPACE, 'scripts', 'telegram_send_document_guard.js');
const PDF_EXPORTER = path.join(APP_ROOT, 'scripts', 'exports', 'export_clinical_document_pdf.py');
const READY_DIR = path.join(APP_ROOT, 'exports', 'telegram_ready');
const HANDOFF_DIR = path.join(WORKSPACE, 'outbox', 'clinica_medicolegal', 'telegram_ready');
const MEDICO_LEGAL_STANDARD_ID = 'tamiz_medicolegal_flexible_obligatorio_v1';

class Element {
  constructor(id = '', tag = 'div') {
    this.id = id;
    this.tag = tag;
    this.value = '';
    this.dataset = {};
    this.children = [];
    this.options = [];
    this.listeners = {};
    this.href = '';
    this.download = '';
    this._innerHTML = '';
    this._textContent = '';
    this.classList = {
      values: new Set(),
      add: (...names) => names.forEach((name) => this.classList.values.add(name)),
      remove: (...names) => names.forEach((name) => this.classList.values.delete(name)),
      contains: (name) => this.classList.values.has(name),
    };
  }

  set innerHTML(value) {
    this._innerHTML = String(value || '');
    if (this.tag === 'select') {
      this.options = [...this._innerHTML.matchAll(/<option[^>]*value="([^"]*)"[^>]*>(.*?)<\/option>/g)]
        .map((match) => ({ value: unescapeHtml(match[1]), textContent: stripTags(match[2]) }));
      if (!this.options.some((option) => option.value === this.value)) {
        this.value = this.options[0]?.value || '';
      }
    }
  }

  get innerHTML() {
    return this._innerHTML;
  }

  set textContent(value) {
    this._textContent = String(value || '');
  }

  get textContent() {
    return this._textContent || stripTags(this._innerHTML);
  }

  get innerText() {
    return this.textContent;
  }

  addEventListener(type, handler) {
    this.listeners[type] = handler;
  }

  dispatch(type) {
    if (this.listeners[type]) this.listeners[type]({ target: this });
  }

  click() {
    this.dispatch('click');
  }

  remove() {}
}

function usage() {
  console.error(`usage:
  clinical_document_handoff.js --type hc|parte|evolucion|consent --input "caso" --patient NOMBRE --date FECHA [opciones]
  clinical_document_handoff.js --request "pedido textual de Telegram" [--chat-id CHAT] [--send]

Opciones comunes:
  --family auto|lumbar_hdl|lumbar_fijacion|cervical
  --institution clinica_centro|la_pequena_familia|higa_junin|centro_medico_pellegrini
  --age EDAD --start-time HH:MM --end-time HH:MM --assistants TEXTO --exceptions TEXTO
  --level NIVEL --side izquierda|derecha|bilateral --surgeon "Carlos Zanardi"
  --chat-id CHAT [--thread-id TOPIC] [--caption TEXTO] [--send]

Para consentimiento se delega en consent_telegram_handoff.js y requiere --slug, --dni, --level.`);
  process.exit(2);
}

function parseArgs(argv) {
  const out = {
    family: 'auto',
    institution: 'clinica_centro',
    surgeon: 'Carlos Zanardi',
    send: false,
    format: 'pdf',
  };
  for (let i = 2; i < argv.length; i += 1) {
    const key = argv[i];
    const value = argv[i + 1];
    if (key === '--request' || key === '--raw-request') { out.request = value; if (!out.input) out.input = value; i += 1; continue; }
    if (key === '--type') { out.type = normalizeType(value); i += 1; continue; }
    if (key === '--input' || key === '--case-summary') { out.input = value; i += 1; continue; }
    if (key === '--family') { out.family = normalizeFamily(value); i += 1; continue; }
    if (key === '--institution') { out.institution = normalizeInstitution(value); i += 1; continue; }
    if (key === '--patient') { out.patient = value; i += 1; continue; }
    if (key === '--age') { out.age = value; i += 1; continue; }
    if (key === '--date') { out.date = value; i += 1; continue; }
    if (key === '--start-time') { out.startTime = value; i += 1; continue; }
    if (key === '--end-time') { out.endTime = value; i += 1; continue; }
    if (key === '--assistants') { out.assistants = value; i += 1; continue; }
    if (key === '--exceptions') { out.exceptions = value; i += 1; continue; }
    if (key === '--level') { out.level = value; i += 1; continue; }
    if (key === '--side') { out.side = value; i += 1; continue; }
    if (key === '--surgeon') { out.surgeon = value; i += 1; continue; }
    if (key === '--slug') { out.slug = value; i += 1; continue; }
    if (key === '--dni') { out.dni = value; i += 1; continue; }
    if (key === '--team') { out.team = value; i += 1; continue; }
    if (key === '--diagnosis') { out.diagnosis = value; i += 1; continue; }
    if (key === '--procedure') { out.procedure = value; i += 1; continue; }
    if (key === '--format') { out.format = value; i += 1; continue; }
    if (key === '--chat-id') { out.chatId = value; i += 1; continue; }
    if (key === '--thread-id') { out.threadId = value; i += 1; continue; }
    if (key === '--caption') { out.caption = value; i += 1; continue; }
    if (key === '--send') { out.send = true; continue; }
    usage();
  }
  if (out.request) {
    Object.assign(out, inferArgsFromRequest(out.request, out));
  }
  if (!out.type) usage();
  if (out.type !== 'consent' && !out.input) usage();
  if (out.send && !out.chatId) throw new Error('--send requiere --chat-id');
  return out;
}

function todayArgentina() {
  const parts = new Intl.DateTimeFormat('es-AR', {
    timeZone: 'America/Argentina/Buenos_Aires',
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  }).formatToParts(new Date());
  const byType = Object.fromEntries(parts.map((part) => [part.type, part.value]));
  return `${byType.day}/${byType.month}/${byType.year}`;
}

function normalizeLevel(value) {
  const raw = String(value || '').trim().toUpperCase().replace(/\s+/g, '');
  const match = raw.match(/\b([CLDST])(\d)[-/]?([CLDST]?)(\d)\b/);
  if (!match) return raw;
  const [, firstLetter, firstNumber, secondLetter, secondNumber] = match;
  return `${firstLetter}${firstNumber}-${secondLetter || firstLetter}${secondNumber}`;
}

function normalizeTime(value) {
  const raw = String(value || '').trim();
  const match = raw.match(/\b(\d{1,2})(?:[:.](\d{2}))?\b/);
  if (!match) return raw;
  const hour = match[1].padStart(2, '0');
  const minute = match[2] || '00';
  return `${hour}:${minute}`;
}

function pickNameAfter(pattern, request) {
  const match = request.match(pattern);
  if (!match) return '';
  const raw = String(match[1] || '')
    .replace(/\b(dni|edad|fecha|l[1-5]|c[1-7]|hernia|canal|dolor|protocolo|parte|historia)\b.*$/i, '')
    .replace(/[.,;:].*$/, '')
    .trim();
  if (!raw || /^(con|que|de|para|por|sin|a completar)$/i.test(raw)) return '';
  const words = raw.split(/\s+/).slice(0, 4);
  if (!words.length) return '';
  return words.join(' ');
}

function inferRequestedTypesFromText(text) {
  const requestedTypes = [];
  if (/\b(consentimiento|consent)\b/.test(text)) requestedTypes.push('consent');
  if (/\b(historia clinica|historia clínica|\bhc\b)\b/.test(text)) requestedTypes.push('hc');
  if (/\b(parte quirurgico|parte quirúrgico|protocolo(?:\s+quirurgico|\s+quirúrgico)?|parte)\b/.test(text)) requestedTypes.push('parte');
  if (/\b(evolucion postoperatoria|evolución postoperatoria|\bevolucion\b|\bevolución\b|\bpoi\b)\b/.test(text)) requestedTypes.push('evolucion');
  return [...new Set(requestedTypes)];
}

function inferArgsFromRequest(request, current = {}) {
  const raw = String(request || '');
  const text = normalizedText(raw);
  const inferred = {};
  const requestedTypes = inferRequestedTypesFromText(text);

  if (requestedTypes.length) inferred.requestedTypes = requestedTypes;
  if (!current.type) {
    if (requestedTypes.length === 1) inferred.type = requestedTypes[0];
    else if (requestedTypes.includes('hc')) inferred.type = 'hc';
    else if (requestedTypes.length > 1) inferred.type = requestedTypes[0];
  }

  if (!current.family || current.family === 'auto') {
    if (isPostoperativeSpineWoundCase(text)) inferred.family = 'columna_infeccion_desbridamiento_retiro';
    else if (/\b(cervical|cervicobraquial|cervicobraquialgia|laminoplast|mielopat|canal estrecho cervical|estenosis cervical|artrodesis cervical|microdiscectomia cervical|discectomia cervical)\b/.test(text)) inferred.family = 'cervical';
    else if (/\b(fijacion|fijación|artrodesis|instrumentacion|instrumentación|canal estrecho lumbar|estenosis lumbar|listesis|espondilolistesis)\b/.test(text)) inferred.family = 'lumbar_fijacion';
    else if (/\b(hernia|microdiscect|discect|hdl)\b/.test(text)) inferred.family = 'lumbar_hdl';
  }

  if (!current.institution || current.institution === 'clinica_centro') {
    if (/\b(higa|piñeyro|pineyro|hospital)\b/.test(text)) inferred.institution = 'higa_junin';
    else if (/\b(lpf|pequeña familia|pequena familia)\b/.test(text)) inferred.institution = 'la_pequena_familia';
    else if (/\b(pellegrini|centro medico pellegrini|centro médico pellegrini)\b/.test(text)) inferred.institution = 'centro_medico_pellegrini';
  }

  if (!current.date) {
    const dateMatch = raw.match(/\b(\d{1,2}[/-]\d{1,2}[/-]\d{2,4})\b/);
    inferred.date = dateMatch ? dateMatch[1].replace(/-/g, '/') : todayArgentina();
  }
  if (!current.level) {
    const levelMatch = raw.match(/\b[CLDST]\s*\d\s*[-/]\s*[CLDST]?\s*\d\b/i);
    if (levelMatch) inferred.level = normalizeLevel(levelMatch[0]);
  }
  if (!current.side) {
    const sideMatch = text.match(/\b(izquierda|izquierdo|derecha|derecho|bilateral)\b/);
    if (sideMatch) inferred.side = sideMatch[1].replace('izquierdo', 'izquierda').replace('derecho', 'derecha');
  }
  if (!current.age) {
    const ageMatch = raw.match(/\b(\d{1,3})\s*(?:años|anos|a\.?)\b/i);
    if (ageMatch) inferred.age = ageMatch[1];
  }
  if (!current.startTime || !current.endTime) {
    const range = raw.match(/\b(?:de\s+)?(\d{1,2}(?::|\.|h)?\d{0,2})\s*(?:a|hasta|-)\s*(\d{1,2}(?::|\.|h)?\d{0,2})\b/i);
    if (range) {
      if (!current.startTime) inferred.startTime = normalizeTime(range[1].replace('h', ':'));
      if (!current.endTime) inferred.endTime = normalizeTime(range[2].replace('h', ':'));
    }
    const startMatch = raw.match(/\b(?:inicio|inici[oó]|empec[eé]|comenc[eé]|arranqu[eé])(?:\s+a\s+las|\s+|:)\s*(\d{1,2}(?::|\.|h)?\d{0,2})\b/i);
    const endMatch = raw.match(/\b(?:fin|finaliz[oó]|termin[eé]|cerr[eé])(?:\s+a\s+las|\s+|:)\s*(\d{1,2}(?::|\.|h)?\d{0,2})\b/i);
    const singleHourMatch = raw.match(/\bhora(?:\s+de\s+inicio)?\s*:?(?:\s+a\s+las)?\s*(\d{1,2}(?::|\.|h)\d{2}|\d{1,2})\b/i);
    if (startMatch && !current.startTime) inferred.startTime = normalizeTime(startMatch[1].replace('h', ':'));
    if (endMatch && !current.endTime) inferred.endTime = normalizeTime(endMatch[1].replace('h', ':'));
    if (singleHourMatch && !current.startTime) inferred.startTime = normalizeTime(singleHourMatch[1].replace('h', ':'));
  }
  if (!current.patient) {
    const patient = pickNameAfter(/\bpaciente\s+([A-ZÁÉÍÓÚÑ][\p{L}'´-]+(?:\s+[A-ZÁÉÍÓÚÑ][\p{L}'´-]+){0,3})/iu, raw)
      || pickNameAfter(/\bnombre(?:\s+del\s+paciente)?\s+([A-ZÁÉÍÓÚÑ][\p{L}'´-]+(?:\s+[A-ZÁÉÍÓÚÑ][\p{L}'´-]+){0,3})/iu, raw)
      || pickNameAfter(/\b(?:historia\s+clinica|historia|hc|parte\s+quirurgico|protocolo\s+quirurgico|protocolo|parte)(?:\s+completa)?(?:\s+base)?\s+de\s+([A-ZÁÉÍÓÚÑ][\p{L}'´-]+(?:\s+[A-ZÁÉÍÓÚÑ][\p{L}'´-]+){0,3})(?=\s*,|\s+\d{1,3}\s*a[nñ]os\b|\s+de\s+\d{1,3}\s*a[nñ]os\b|[.;:]|$)/iu, raw)
      || pickNameAfter(/\bde\s+([A-ZÁÉÍÓÚÑ][\p{L}'´-]+(?:\s+[A-ZÁÉÍÓÚÑ][\p{L}'´-]+){0,3})(?=\s*,\s*\d{1,3}\s*a[nñ]os\b|\s+de\s+\d{1,3}\s*a[nñ]os\b)/iu, raw)
      || pickNameAfter(/\bpara\s+([A-ZÁÉÍÓÚÑ][\p{L}'´-]+(?:\s+[A-ZÁÉÍÓÚÑ][\p{L}'´-]+){0,3})(?=\s+(?:por|con|sin|en)\b|[.,;:]|$)/iu, raw);
    if (patient) inferred.patient = patient;
  }
  if (!current.assistants && !current.team) {
    const assistantMatch = raw.match(/\b(?:ayudantes|ayudante|auudantes|auudante|asistentes|asistente|equipo)\s*:?\s*([^\n]+)/i);
    if (assistantMatch) {
      inferred.assistants = assistantMatch[1]
        .replace(/\b(?:evoluci[oó]n(?:\s+postoperatoria)?|sin enviar(?:\s+todav[ií]a)?|no enviar(?:\s+todav[ií]a)?|sin mandarlo(?:\s+todav[ií]a)?|sin enviarlo(?:\s+todav[ií]a)?|complicaciones?|cirujano|fecha|diagn[oó]stico|procedimiento)\b.*$/i, '')
        .replace(/[;,]\s*$/, '')
        .trim();
    }
  }

  if (!current.input) inferred.input = raw;
  return inferred;
}

function normalizeType(value) {
  const text = normalizeToken(value);
  if (['consentimiento', 'consent'].includes(text)) return 'consent';
  if (['historia', 'historia_clinica', 'hc'].includes(text)) return 'hc';
  if (['parte', 'parte_quirurgico', 'protocolo', 'protocolo_quirurgico'].includes(text)) return 'parte';
  if (['evolucion', 'evolucion_postoperatoria', 'poi'].includes(text)) return 'evolucion';
  return text;
}

function normalizeFamily(value) {
  const text = normalizeToken(value);
  const map = {
    auto: 'auto',
    hernia: 'lumbar_hdl',
    hernia_disco: 'lumbar_hdl',
    hdl: 'lumbar_hdl',
    microdiscectomia: 'lumbar_hdl',
    lumbar_hdl: 'lumbar_hdl',
    fijacion: 'lumbar_fijacion',
    artrodesis: 'lumbar_fijacion',
    canal_lumbar: 'lumbar_fijacion',
    lumbar_fijacion: 'lumbar_fijacion',
    cervical: 'cervical',
    laminoplastia: 'cervical',
    canal_cervical: 'cervical',
    hematoma_cervical: 'columna_infeccion_desbridamiento_retiro',
    hematoma_lodge: 'columna_infeccion_desbridamiento_retiro',
    lodge: 'columna_infeccion_desbridamiento_retiro',
    toilette: 'columna_infeccion_desbridamiento_retiro',
    revision: 'columna_infeccion_desbridamiento_retiro',
    reapertura: 'columna_infeccion_desbridamiento_retiro',
    infeccion: 'columna_infeccion_desbridamiento_retiro',
    infeccion_columna: 'columna_infeccion_desbridamiento_retiro',
    desbridamiento: 'columna_infeccion_desbridamiento_retiro',
    columna_infeccion_desbridamiento_retiro: 'columna_infeccion_desbridamiento_retiro',
  };
  return map[text] || text || 'auto';
}

function normalizeInstitution(value) {
  const text = normalizeToken(value);
  const map = {
    centro: 'clinica_centro',
    clinica_centro: 'clinica_centro',
    lpf: 'la_pequena_familia',
    pequena_familia: 'la_pequena_familia',
    la_pequena_familia: 'la_pequena_familia',
    higa: 'higa_junin',
    higa_junin: 'higa_junin',
    hospital: 'higa_junin',
    pellegrini: 'centro_medico_pellegrini',
    centro_medico_pellegrini: 'centro_medico_pellegrini',
  };
  return map[text] || value || 'clinica_centro';
}

function institutionLabel(key) {
  const map = {
    clinica_centro: 'Clínica Centro',
    la_pequena_familia: 'Clínica La Pequeña Familia',
    higa_junin: 'HIGA Dr. Abraham Piñeyro',
    centro_medico_pellegrini: 'Centro Médico Pellegrini',
  };
  return map[key] || key || 'Clínica Centro';
}

function stripTags(value) {
  return unescapeHtml(String(value || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim());
}

function unescapeHtml(value) {
  return String(value || '')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
}

function esc(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function normalizeToken(value) {
  return String(value || '')
    .trim()
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');
}

function slugify(value) {
  return normalizeToken(value) || 'documento';
}

function nowStamp() {
  return new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z');
}

function loadScript() {
  const html = fs.readFileSync(PRODUCT_HTML, 'utf8');
  const match = html.match(/<script>([\s\S]*?)<\/script>\s*<\/body>/);
  if (!match) throw new Error('No se encontró el script principal de product.html');
  return match[1];
}

function localFetch(url) {
  const clean = String(url).replace(/^\.\.\//, '');
  const filePath = path.join(APP_ROOT, clean);
  return Promise.resolve({
    ok: fs.existsSync(filePath),
    status: fs.existsSync(filePath) ? 200 : 404,
    json: async () => JSON.parse(fs.readFileSync(filePath, 'utf8')),
  });
}

function makeDocument() {
  const ids = [
    'input', 'familySelect', 'patient', 'age', 'dateInput', 'startTimeInput', 'endTimeInput',
    'assistants', 'exceptions', 'institution', 'surgeon', 'generate', 'copy', 'exportHtml',
    'printDoc', 'correctionTarget', 'correction', 'applyCorrection', 'brand', 'caseMeta',
    'docTitle', 'document', 'caseStatus', 'templateMother', 'colloquialMap', 'factBoundary',
    'missing', 'coverage', 'legalScore', 'legalGate', 'legalUpdatePolicy', 'legalSourceDocs',
    'matchedTemplateRules', 'reviewQueue', 'correctionLog', 'legalFoundations',
  ];
  const selectIds = new Set(['familySelect', 'institution', 'correctionTarget']);
  const elements = new Map(ids.map((id) => [id, new Element(id, selectIds.has(id) ? 'select' : 'div')]));
  const tabs = ['hc', 'parte', 'consent', 'evolucion', 'faltantes'].map((tab) => {
    const el = new Element(`tab-${tab}`, 'button');
    el.dataset.tab = tab;
    if (tab === 'hc') el.classList.add('active');
    return el;
  });

  elements.get('familySelect').innerHTML = '<option value="auto">Detectar automáticamente</option>';
  elements.get('familySelect').value = 'auto';
  elements.get('institution').innerHTML = [
    '<option value="Clínica Centro">Clínica Centro</option>',
    '<option value="Clínica La Pequeña Familia">Clínica La Pequeña Familia</option>',
    '<option value="HIGA Dr. Abraham Piñeyro">HIGA Dr. Abraham Piñeyro</option>',
    '<option value="Centro Médico Pellegrini">Centro Médico Pellegrini</option>',
  ].join('');
  elements.get('institution').value = 'Clínica Centro';
  elements.get('surgeon').value = 'Carlos Zanardi';
  elements.get('correctionTarget').innerHTML = '<option value="global">Todo el paquete</option><option value="hc">Historia clínica</option><option value="parte">Parte quirúrgico</option><option value="consent">Consentimiento</option><option value="evolucion">Evolución</option>';
  elements.get('correctionTarget').value = 'global';

  const body = {
    appendChild() {},
  };

  return {
    getElementById(id) {
      if (!elements.has(id)) elements.set(id, new Element(id));
      return elements.get(id);
    },
    querySelectorAll(selector) {
      return selector === '.tab' ? tabs : [];
    },
    createElement(tag) {
      return new Element('', tag);
    },
    body,
    _elements: elements,
    _tabs: tabs,
  };
}

function appendClinicalHints(input, args) {
  const hints = [];
  if (args.level && !new RegExp(args.level.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i').test(input)) {
    hints.push(`Nivel ${args.level}.`);
  }
  if (args.side && !new RegExp(args.side, 'i').test(input)) {
    hints.push(`Lado ${args.side}.`);
  }
  return [input, hints.join(' ')].filter(Boolean).join(' ');
}

async function renderFromApp(args) {
  const document = makeDocument();
  const context = {
    document,
    window: { print() {} },
    navigator: { clipboard: { writeText: async () => undefined } },
    fetch: localFetch,
    setTimeout: () => undefined,
    URL: { createObjectURL: () => 'blob:clinica', revokeObjectURL: () => undefined },
    Blob: class Blob {},
    console,
    Date,
    Error,
    String,
    Boolean,
    Number,
    RegExp,
  };
  vm.runInNewContext(loadScript(), context, { filename: PRODUCT_HTML });
  for (let i = 0; i < 8; i += 1) await Promise.resolve();

  const get = (id) => document.getElementById(id);
  get('input').value = appendClinicalHints(args.input || '', args);
  get('patient').value = args.patient || '';
  get('age').value = args.age || '';
  get('dateInput').value = args.date || '';
  get('startTimeInput').value = args.startTime || '';
  get('endTimeInput').value = args.endTime || '';
  get('assistants').value = args.assistants || '';
  get('exceptions').value = args.exceptions || '';
  get('institution').value = institutionLabel(args.institution);
  get('surgeon').value = args.surgeon || 'Carlos Zanardi';
  get('familySelect').value = args.family || 'auto';
  if (get('familySelect').listeners.change) get('familySelect').listeners.change({ target: get('familySelect') });
  const tab = document._tabs.find((item) => item.dataset.tab === args.type);
  if (tab) tab.click();
  for (let i = 0; i < 4; i += 1) await Promise.resolve();
  if (!String(args.patient || '').trim()) {
    get('patient').value = '';
  }

  let bodyHtml = finalizeClinicalHtml(get('document').innerHTML, args);
  if (shouldUsePostoperativeSpineWoundParteTemplate(args)) {
    bodyHtml = buildPostoperativeSpineWoundParteHtml(args);
  }
  const text = stripTags(bodyHtml);
  let familyLabel = shouldUsePostoperativeSpineWoundParteTemplate(args)
    ? 'Hematoma cervical posterior postoperatorio / toilette y drenaje'
    : stripTags(get('caseMeta').innerHTML).replace(/\s*Carlos Zanardi\s*$/, '').trim() || args.family;
  const subtype = lumbarFixationSubtype(args);
  if (subtype === 'inestabilidad_degenerativa') {
    const level = args.level || (args.input || '').match(/\bL\s*\d\s*[-/]\s*L?\s*\d\b/i)?.[0] || '';
    const levelText = level ? normalizeLevel(level) : 'segmento lumbar comprometido';
    familyLabel = lumbarFixationExactPhrases(args, levelText, normalizedText(args.input || '')).familyLabel;
  }
  return {
    bodyHtml,
    text,
    title: get('docTitle').textContent || titleForType(args.type),
    familyLabel,
    caseStatusHtml: get('caseStatus').innerHTML,
    missingHtml: get('missing').innerHTML,
    legalGateHtml: get('legalGate').innerHTML,
  };
}

function isPostoperativeSpineWoundCase(value) {
  const text = normalizedText(value);
  const spineOrWoundRegion = /\b(cervical|columna|lumbar|dorsal|lodge|lecho|herida|operatoria|quirurgica|quirurgico)\b/.test(text);
  const hematomaWound = /\bhematoma\b/.test(text)
    && /\b(lodge|lecho|herida|postoperator|posoperator|operatoria|quirurgic|cervical|columna)\b/.test(text);
  const revisionToilette = /\b(reapertura|toilette|lavado|drenaje|evacuacion|revision|desbridamiento|hemostasia)\b/.test(text)
    && /\b(cervical|columna|lodge|herida|lecho|operatoria|quirurgic)\b/.test(text);
  const infectedCollection = /\b(coleccion|infecciosa|infeccion)\b/.test(text)
    && /\b(cervical|columna|postoperator|posoperator|reapertura|toilette|drenaje|lodge|herida)\b/.test(text);
  return spineOrWoundRegion && (hematomaWound || revisionToilette || infectedCollection);
}

function shouldUsePostoperativeSpineWoundParteTemplate(args) {
  return args.type === 'parte' && isPostoperativeSpineWoundCase(`${args.family || ''} ${args.input || ''}`);
}

function detectSpineRange(value) {
  const raw = String(value || '');
  const match = raw.match(/\b([CLDST])\s*(\d)\s*(?:-|\/|a|hasta)\s*([CLDST])?\s*(\d)\b/i);
  if (!match) return '';
  const firstLetter = match[1].toUpperCase();
  const secondLetter = (match[3] || firstLetter).toUpperCase();
  return `${firstLetter}${match[2]}-${secondLetter}${match[4]}`;
}

function postoperativeSpineWoundLevel(args) {
  return detectSpineRange(args.level) || detectSpineRange(args.input) || String(args.level || '').trim();
}

function buildPostoperativeSpineWoundParteHtml(args) {
  const patient = args.patient || 'Paciente';
  const age = args.age || 'no informada';
  const date = args.date || todayArgentina();
  const start = args.startTime || 'no informado';
  const end = args.endTime || 'no informado';
  const assistants = args.assistants || args.team || 'no informados';
  const level = postoperativeSpineWoundLevel(args);
  const levelSuffix = level ? ` ${esc(level)}` : '';
  const levelPreposition = level ? ` desde ${esc(level)}` : '';
  const input = normalizedText(args.input || '');
  const antecedent = /\bcoleccion|infecciosa|infeccion\b/.test(input)
    ? ', con antecedente reciente de cirugía cervical posterior por colección infecciosa'
    : '';
  const materialSentence = /\b(cultivo|muestra|bacteriologia|anatomia patologica|patologia)\b/.test(input)
    ? '<p>Se toma muestra para estudio microbiológico/anatomopatológico según lo indicado en el acto quirúrgico.</p>'
    : '';
  return `
    <p><strong>Paciente:</strong> ${esc(patient)} · <strong>Edad:</strong> ${esc(age)} · <strong>Fecha:</strong> ${esc(date)} · <strong>Inicio:</strong> ${esc(start)} · <strong>Fin:</strong> ${esc(end)}</p>
    <p><strong>Cirujano:</strong> ${esc(args.surgeon || 'Carlos Zanardi')}. <strong>Ayudantes:</strong> ${esc(assistants)}</p>
    <p><strong>Diagnóstico:</strong> hematoma en lodge operatoria cervical posterior postoperatoria${esc(antecedent)}.</p>
    <p><strong>Operación:</strong> reapertura de herida cervical posterior${levelSuffix}, evacuación de hematoma de lodge operatoria, toilette quirúrgica amplia, revisión del lecho, hemostasia y colocación de drenaje.</p>
    <p>Se verificó identidad del paciente, procedimiento propuesto, nivel y sitio quirúrgico. Se realizó posicionamiento cuidadoso con acolchado de puntos de apoyo. Se colocó protección ocular durante el posicionamiento quirúrgico. Se efectuó antisepsia amplia y colocación de campos estériles. Se administró profilaxis antibiótica conforme protocolo institucional.</p>
    <p>Paciente en decúbito prono bajo anestesia general. Incisión sobre cicatriz previa y reapertura de herida cervical posterior${levelPreposition}. Apertura por planos hasta lodge operatoria. Se evacúa hematoma de lodge quirúrgica y se realiza toilette quirúrgica amplia con lavado profuso. Se revisa el lecho quirúrgico y se completa hemostasia meticulosa por planos. Se coloca drenaje aspirativo. Cierre por planos y curación plana, oclusiva y compresiva.</p>
    ${materialSentence}
    <p>Se efectuó recuento de gasas, agujas e instrumental conforme protocolo de quirófano.</p>
    <p><strong>Complicaciones:</strong> no se registraron incidentes intraoperatorios evidentes.</p>
  `;
}

function finalizeClinicalHtml(html, args) {
  let out = String(html || '');
  const levelText = args.level ? String(args.level).trim() : '';
  const sideText = args.side ? String(args.side).trim() : '';
  const strictSide = /^(izquierda|derecha|izquierdo|derecho)$/i.test(sideText);
  const locationText = [levelText, strictSide ? sideText : '']
    .filter(Boolean)
    .join(' ')
    .trim();
  const localNorm = (value) => String(value || '')
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ');
  const localCompact = (value) => localNorm(value).replace(/[^a-z0-9]/g, '');
  const appendToParagraph = (source, label, addition) => {
    if (!addition) return source;
    const rx = new RegExp(`(<p><strong>${label}:<\\/strong>\\s*)([\\s\\S]*?)(<\\/p>)`, 'i');
    return source.replace(rx, (match, start, body, end) => {
      if (localNorm(body).includes(localNorm(addition))) return match;
      const cleanBody = body.trim().replace(/\s*\.$/, '');
      return `${start}${cleanBody}, ${addition}.${end}`;
    });
  };
  out = out
    .replace(/&lt;span class=&quot;fill&quot;&gt;([\s\S]*?)&lt;\/span&gt;/gi, '<span class="fill">$1</span>')
    .replace(/<span class="fill">validar hallazgos y eventos reales<\/span>/gi, '')
    .replace(/<span class="fill">validar eventos reales<\/span>/gi, '')
    .replace(/<span class="fill">validar pérdida hemática, drenaje, implantes, lotes y hallazgos reales<\/span>/gi, '')
    .replace(/<span class="fill">edad<\/span>/gi, 'no informada')
    .replace(/<span class="fill">inicio<\/span>/gi, 'no informado')
    .replace(/<span class="fill">fin<\/span>/gi, 'no informado')
    .replace(/ayudantes a completar/gi, 'Dr. Carlos Zanardi y equipo')
    .replace(/<p><strong>Complicaciones:<\/strong>\s*sin complicaciones evidentes\.\s*<\/p>/gi, '<p><strong>Complicaciones:</strong> no se registraron complicaciones evidentes intraoperatorias.</p>')
    .replace(/<p><strong>Complicaciones:<\/strong>\s*sin complicaciones evidentes intraoperatorias\.\s*<\/p>/gi, '<p><strong>Complicaciones:</strong> no se registraron complicaciones evidentes intraoperatorias.</p>')
    .replace(/\s+([,.])/g, '$1')
    .replace(/\s+<\/p>/g, '</p>');
  if (!String(args.patient || '').trim()) {
    out = out.replace(/(<strong>Paciente:\s*)([^·<]+)(\s*·\s*Edad:)/i, '$1no informado$3');
  }
  if (args.type === 'hc') {
    out = out
      .replace(/\s*·\s*Inicio:\s*<span class="fill">inicio<\/span>\s*·\s*Fin:\s*<span class="fill">fin<\/span>/gi, '')
      .replace(/\s*·\s*Inicio:\s*(?:inicio|__________|<[^>]+>inicio<\/[^>]+>|<[^>]+>__________<\/[^>]+>)\s*·\s*Fin:\s*(?:fin|__________|<[^>]+>fin<\/[^>]+>|<[^>]+>__________<\/[^>]+>)/gi, '')
      .replace(/\s*·\s*Inicio:\s*[^·<]+?\s*·\s*Fin:\s*[^<]+?(?=<\/strong>|<\/p>)/gi, '');
  }
  out = out
    .replace(/dolor radicular izquierda/gi, 'dolor radicular izquierdo')
    .replace(/dolor radicular derecha/gi, 'dolor radicular derecho')
    .replace(/miembro inferior izquierda/gi, 'miembro inferior izquierdo')
    .replace(/miembro inferior derecha/gi, 'miembro inferior derecho')
    .replace(/territorio radicular izquierda/gi, 'territorio radicular izquierdo')
    .replace(/territorio radicular derecha/gi, 'territorio radicular derecho');
  if (levelText) {
    out = out
      .replace(/\ben el nivel informado\b/gi, `en ${levelText}`)
      .replace(/\ben el nivel indicado\b/gi, `en ${levelText}`)
      .replace(/\bdel nivel indicado\b/gi, `de ${levelText}`)
      .replace(/\bdel nivel afectado\b/gi, `de ${levelText}`)
      .replace(/\bnivel informado\b/gi, levelText)
      .replace(/\bnivel indicado\b/gi, levelText)
      .replace(/\bnivel afectado\b/gi, levelText);
  }
  if (locationText) {
    out = out
      .replace(/\ben la localizaci[oó]n informada\b/gi, `en ${locationText}`)
      .replace(/\blocalizaci[oó]n informada\b/gi, locationText)
      .replace(/\blado informado\b/gi, sideText || 'lado informado')
      .replace(/\blateralidad informada\b/gi, sideText || 'lateralidad informada');
  }
  if (args.type === 'parte') {
    out = out
      .replace(/\bse verificó cierre, curación, estabilidad clínica y destino postoperatorio\./gi, 'Se verificó curación, estabilidad clínica y destino postoperatorio.')
      .replace(/\blaminectom[ií]a\/hemilaminectom[ií]a\b/gi, 'descompresión posterior')
      .replace(/\bosteotom[ií]a\/hemilaminotom[ií]a mínima\b/gi, 'hemilaminotomía mínima')
      .replace(/\bcaja\/celda intersom[aá]tica\b/gi, 'caja intersomática')
      .replace(/descompresi[oó]n neural mediante descompresi[oó]n posterior,\s*/gi, 'descompresión neural mediante resección ósea selectiva, ')
      .replace(/Se realiza facetectomía\/descompresión del lado\s*(?:<span[^>]*>)?\s*lateralidad informada por el m[eé]dico\s*(?:<\/span>)?,\s*/gi, 'Se realiza descompresión del segmento instrumentado, ')
      .replace(/\blateralidad informada por el m[eé]dico\b/gi, '')
      .replace(/\s*,\s*,/g, ',')
      .replace(/\b(de\s+L\d-L\d)\s+L\d-L\d\s+(izquierda|derecha)\b/gi, '$1 $2')
      .replace(/\b(de\s+L\d-S\d)\s+L\d-S\d\s+(izquierda|derecha)\b/gi, '$1 $2');
  }
  out = applyLumbarFixationClinicalSpecifics(out, args);
  const compactOut = localCompact(out);
  const missingLevel = levelText && !compactOut.includes(localCompact(levelText));
  const missingStrictSide = strictSide && !localNorm(out).includes(localNorm(sideText));
  if (missingLevel || missingStrictSide) {
    const sideAdj = /^izquier/i.test(sideText) ? 'izquierdo' : /^derech/i.test(sideText) ? 'derecho' : '';
    const location = [levelText, strictSide ? sideText : ''].filter(Boolean).join(' ').trim();
    if (args.type === 'parte') {
      out = appendToParagraph(out, 'Operación', location ? `en ${location}` : (sideAdj ? `con abordaje ${sideAdj}` : ''));
    } else if (args.type === 'hc') {
      const hcAddition = [
        levelText ? `con hallazgo en ${levelText}` : '',
        sideAdj ? `con compromiso ${sideAdj}` : '',
      ].filter(Boolean).join(', ');
      out = appendToParagraph(out, 'Estudios', hcAddition);
    }
  }
  return out;
}

function replaceParagraph(source, label, replacement) {
  const rx = new RegExp(`(<p><strong>${label}:<\\/strong>\\s*)([\\s\\S]*?)(<\\/p>)`, 'i');
  return source.replace(rx, `$1${replacement}$3`);
}

function lumbarFixationSubtype(args) {
  const bag = normalizedText(`${args.family || ''} ${args.input || ''}`);
  if (!/\blumbar_fijacion\b|fijacion|fijación|artrodesis|instrumentacion|instrumentación|listesis|espondilolistesis|inestabilidad|canal estrecho|estenosis/.test(bag)) return null;
  const hasStenosis = /\bcanal estrecho|estenosis|recalibraje|claudicacion neurogena|claudicación neurógena\b/.test(bag);
  const hasListesis = /\blistesis|espondilolistesis|inestabilidad\b/.test(bag);
  if (hasListesis) return 'inestabilidad_degenerativa';
  if (hasStenosis) return 'canal_estrecho';
  return 'fijacion_lumbar';
}

function lumbarFixationDirectDecompressionStateFromBag(bag) {
  const directTerms = '(?:descompresion|recalibraje|laminectomia|hemilaminectomia|flavectomia|foraminotomia|liberacion\\s+(?:neural|radicular|de\\s+recesos|foraminal))';
  const negative = new RegExp(`(?:\\bsin\\s+${directTerms}|\\bno\\s+se\\s+(?:realizo|efectuo|hizo)\\s+${directTerms}|\\bno\\s+hubo\\s+${directTerms}|\\bsin\\s+descompresion\\s+directa|\\bsolo\\s+(?:fijacion|instrumentacion|artrodesis)|\\bsolamente\\s+(?:fijacion|instrumentacion|artrodesis)|\\bunicamente\\s+(?:fijacion|instrumentacion|artrodesis))`, 'i');
  if (negative.test(bag)) return 'excluded';
  const optional = new RegExp(`(?:con\\s+o\\s+sin\\s+descompresion|posible\\s+${directTerms}|${directTerms}\\s+(?:posible|segun\\s+hallazgos|de\\s+ser\\s+necesaria)|eventual\\s+${directTerms})`, 'i');
  if (optional.test(bag)) return 'unspecified';
  const explicit = new RegExp(`(?:se\\s+(?:realizo|efectuo|hizo)\\s+${directTerms}|\\b${directTerms}\\b)`, 'i');
  return explicit.test(bag) ? 'explicit' : 'unspecified';
}

function lumbarFixationExactPhrases(args, levelText, bag) {
  const spondylolisthesisEtiology = /degenerativ/.test(bag)
    ? 'degenerativa'
    : /istmic|istmica|litic|litica|lisis|pars/.test(bag)
      ? 'ístmica'
      : '';
  const spondylolisthesisLabel = spondylolisthesisEtiology
    ? `espondilolistesis ${spondylolisthesisEtiology}`
    : 'espondilolistesis lumbar';
  const specificDiagnosis = /espondilolistesis/.test(bag) && /estenosis|canal estrecho/.test(bag)
    ? `${spondylolisthesisLabel} ${esc(levelText)} con estenosis.`
    : /espondilolistesis/.test(bag)
      ? `${spondylolisthesisLabel} ${esc(levelText)}.`
      : `patología degenerativa lumbar ${esc(levelText)} con inestabilidad segmentaria.`;
  const hasPosterolateral = /posterolateral/.test(bag);
  const hasPedicular = /pedicular|transpedicular/.test(bag);
  const hasCirc360 = /\b360\b|circunferencial|plif|tlif|intersomatic|intersom[aá]tica|caja|celda/.test(bag);
  const decompressionState = lumbarFixationDirectDecompressionStateFromBag(bag);
  const stabilizationOperation = `fijación instrumentada y artrodesis lumbar ${esc(levelText)}.`;
  const specificOperation = decompressionState === 'explicit'
    ? (hasCirc360
        ? `descompresión neural, artrodesis intersomática e instrumentación transpedicular ${esc(levelText)}.`
        : `descompresión neural, fijación instrumentada y artrodesis lumbar ${esc(levelText)}.`)
    : stabilizationOperation;
  const immediateEvolution = /evolucion inmediata estable|evolución inmediata estable/.test(bag)
    ? 'Evolución inmediata estable.'
    : '';
  const familyLabel = hasPosterolateral
    ? `Fijación lumbar ${esc(levelText)} posterolateral`
    : hasCirc360
      ? `Fijación lumbar ${esc(levelText)} circunferencial`
      : `Fijación lumbar ${esc(levelText)}`;
  const minimallyInvasive = /\bmiss|miniinvasiv|mini invasiv|wiltse\b/.test(bag);
  return { specificDiagnosis, specificOperation, immediateEvolution, familyLabel, minimallyInvasive, hasCirc360, decompressionState };
}

function applyLumbarFixationClinicalSpecifics(html, args) {
  const familyKey = String(args.family || '');
  const lumbarFixationFamilies = new Set([
    'lumbar_fijacion',
    'columna_fijacion_transpedicular',
    'columna_lumbar_canal_estrecho',
    'columna_lumbar_fijacion_transpedicular',
    'columna_lumbar_espondilolistesis',
    'columna_lumbar_360_circunferencial',
    'columna_interespinoso_coflex_diam',
  ]);
  if (!lumbarFixationFamilies.has(familyKey)) return html;
  const subtype = lumbarFixationSubtype(args);
  const level = args.level || (args.input || '').match(/\bL\s*\d\s*[-/]\s*L?\s*\d\b/i)?.[0] || '';
  const levelText = level ? normalizeLevel(level) : 'segmento lumbar comprometido';
  const bag = normalizedText(args.input || '');
  const exact = lumbarFixationExactPhrases(args, levelText, bag);
	  let out = html;

	  if (args.type === 'hc' && subtype === 'inestabilidad_degenerativa') {
	    out = replaceParagraph(out, 'Motivo de ingreso', `dolor lumbar mecánico y dolor radicular por inestabilidad asociada a patología degenerativa ${esc(levelText)}, con correlación clínico-radiológica e indicación de estabilización instrumentada.`);
	    out = replaceParagraph(out, 'Enfermedad actual', `Paciente que presenta lumbalgia mecánica y dolor radicular, con limitación funcional para la marcha y actividades habituales, en contexto de ${exact.specificDiagnosis.replace(/\.$/, '')}, con correlación clínico-radiológica y criterio quirúrgico.`);
	    out = replaceParagraph(out, 'Estudios', `Patología degenerativa lumbar ${esc(levelText)} evidenciada en RM, concordante con la clínica, con criterio quirúrgico.`);
	    out = replaceParagraph(out, 'Impresión diagnóstica', exact.specificDiagnosis);
	    const miss = exact.minimallyInvasive && !exact.hasCirc360
	      ? ' por vía miniinvasiva tipo Wiltse'
	      : '';
    out = replaceParagraph(out, 'Plan', `${exact.specificOperation.replace(/\.$/, '')}${miss}. Se deja constancia de indicación, riesgos, beneficios, alternativas y consentimiento informado.`);
  }

  if (args.type === 'parte' && subtype === 'inestabilidad_degenerativa') {
    out = replaceParagraph(out, 'Diagnóstico', exact.specificDiagnosis);
    out = replaceParagraph(out, 'Operación', exact.specificOperation);
    if (exact.immediateEvolution) {
      out = out.replace(/(<p><strong>Complicaciones:<\/strong>)/i, `<p>${exact.immediateEvolution}</p> $1`);
    }
  }
  return out;
}

function titleForType(type) {
  return {
    hc: 'Historia clínica',
    parte: 'Protocolo quirúrgico',
    evolucion: 'Evolución postoperatoria',
    consent: 'Consentimiento informado',
  }[type] || 'Documento clínico';
}

function documentKindForType(type) {
  return {
    hc: 'historia_clinica',
    parte: 'protocolo_quirurgico',
    evolucion: 'evolucion_postoperatoria',
  }[type] || type;
}

function inferConsentSlug(args) {
  if (args.slug) return args.slug;
  const bag = `${args.family || ''} ${args.input || ''}`.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  if (/artroplastia|protesis cervical|protesis discal/.test(bag)) return 'artroplastia_cervical';
  if (/laminoplast|canal estrecho cervical|mielopat/.test(bag)) return 'laminoplastia_cervical';
  if (/fijacion|instrumentacion|artrodesis|canal estrecho lumbar|estenosis lumbar/.test(bag)) return 'canal_estrecho_lumbar_con_fijacion';
  if (/hernia|microdiscect|discect/.test(bag)) return 'hernia_disco_lumbar';
  return 'hernia_disco_lumbar';
}

function delegateConsent(args) {
  const slug = inferConsentSlug(args);
  const cmd = [
    CONSENT_HANDOFF,
    '--slug', slug,
    '--institution', normalizeInstitution(args.institution),
    '--date', args.date || '',
    '--level', (args.level || args.side) ? [args.level, args.side].filter(Boolean).join(' ') : '',
  ];
  if (args.patient) cmd.push('--patient', args.patient);
  if (args.dni) cmd.push('--dni', args.dni);
  if (args.team || args.assistants) cmd.push('--team', args.team || args.assistants);
  if (args.diagnosis) cmd.push('--diagnosis', args.diagnosis);
  if (args.procedure) cmd.push('--procedure', args.procedure);
  if (args.chatId) cmd.push('--chat-id', args.chatId);
  if (args.threadId) cmd.push('--thread-id', args.threadId);
  if (args.caption) cmd.push('--caption', args.caption);
  if (args.send) cmd.push('--send');
  for (const required of ['date', 'level']) {
    if (!args[required]) throw new Error(`Consentimiento requiere --${required === 'date' ? 'date' : required}`);
  }
  const raw = execFileSync(NODE, cmd, {
    cwd: APP_ROOT,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  }).trim();
  const parsed = JSON.parse(raw);
  parsed.source_bridge = 'clinical_document_handoff';
  parsed.delegated_to = CONSENT_HANDOFF;
  return parsed;
}

function normalizedText(value) {
  return String(value || '')
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ');
}

function compactClinicalToken(value) {
  return normalizedText(value).replace(/[^a-z0-9]/g, '');
}

function levelAppearsInText(level, normalized) {
  const raw = String(level || '').trim();
  if (!raw) return true;
  const compactLevel = compactClinicalToken(raw);
  const compactDoc = compactClinicalToken(normalized);
  if (compactLevel && compactDoc.includes(compactLevel)) return true;
  const tokens = normalizedText(raw)
    .split(/[^a-z0-9]+/)
    .filter((token) => token.length > 1);
  return tokens.length > 0 && tokens.every((token) => normalized.includes(token));
}

function sideAppearsInText(side, normalized) {
  const raw = normalizedText(side).trim();
  if (!raw) return true;
  if (!/^(izquierda|izquierdo|derecha|derecho)$/.test(raw)) return true;
  const equivalents = raw.startsWith('izquier')
    ? ['izquierda', 'izquierdo']
    : ['derecha', 'derecho'];
  return equivalents.some((item) => normalized.includes(item));
}

function validateClinical(args, rendered) {
  const text = rendered.text || '';
  const normalized = normalizedText(text);
  const input = normalizedText(args.input || '');
  const postoperativeSpineWoundCase = isPostoperativeSpineWoundCase(`${args.family || ''} ${args.input || ''}`);
  const motorNegatedInInput = /\b(sin|no\s+(presenta|refiere|se\s+constata|hay))\s+(deficit|déficit|paresia|debilidad|compromiso\s+motor)\b/i.test(args.input || '')
    || /\bfuerza\s+(conservada|normal|5\s*\/\s*5)\b/i.test(args.input || '');
  const motorPositivelyStatedInInput = !motorNegatedInInput
    && /\b(deficit motor|déficit motor|paresia|plejia|fuerza\s*(disminuida|menor|[0-4]\s*\/\s*5)|debilidad|pie ca[ií]do|steppage|no\s*dorsiflex|dorsiflexi[oó]n\s*(disminuida|[0-4]\s*\/\s*5))\b/i.test(args.input || '');
  const blockers = [];
  const warnings = [];
  const checks = {};
  const has = (rx) => rx.test(text);
  const nhas = (rx) => rx.test(normalized);

  const forbidden = [
    ['term_radiculalgia', /\bradiculalgia\b/i],
    ['y_o', /\by\/o\b/i],
    ['si_corresponde', /\bsi correspond(?:e|en|iera|iese)\b/i],
    ['cuando_corresponda', /\bcuando correspond(?:a|ia|ía)\b/i],
    ['segun_corresponda', /\bsegun corresponda|según corresponda\b/i],
    ['si_aplica', /\bsi aplica\b/i],
    ['eventual', /\beventual(?:mente)?\b/i],
    ['relato_origen', /Relato de origen/i],
    ['trazabilidad_clinica_visible', /Trazabilidad clínica/i],
    ['tratado_anatomia', /\bhernia posterolateral\/central habitual\b|\braiz pasante\b|\braíz pasante\b|\braiz saliente\b|\braíz saliente\b/i],
    ['cervical_diagnosis_ambiguous', /mielopat[ií]a o compromiso neurol[oó]gico/i],
    ['cervical_si_corresponden', /signos piramidales si/i],
    ['cuadro_clinico_compatible_trastorno', /cuadro cl[ií]nico compatible con trastorno/i],
    ['deficit_motor_o_sensitivo', /d[eé]ficit motor o sensitivo/i],
    ['slash_laminectomia_hemilaminectomia', /laminectom[ií]a\/hemilaminectom[ií]a/i],
    ['slash_osteotomia_hemilaminotomia', /osteotom[ií]a\/hemilaminotom[ií]a/i],
    ['slash_caja_celda', /caja\/celda/i],
    ['redundant_descompresion_posterior', /descompresi[oó]n neural mediante descompresi[oó]n posterior/i],
  ];
  const forbiddenHits = forbidden.filter(([, rx]) => rx.test(text)).map(([key]) => key);
  checks.no_forbidden_phrases = forbiddenHits.length === 0;
  if (forbiddenHits.length) blockers.push(`frases_no_permitidas:${forbiddenHits.join(',')}`);

  if (postoperativeSpineWoundCase) {
    checks.no_laminoplasty_for_postoperative_wound = !/\blaminoplast|\bcanal estrecho cervical\b|\bmielopat/i.test(text);
    if (!checks.no_laminoplasty_for_postoperative_wound) blockers.push('mismatch_hematoma_cervical_no_laminoplastia');
    if (args.type === 'parte') {
      checks.postoperative_wound_core_terms = /\bhematoma\b/.test(normalized)
        && /\blodge\b/.test(normalized)
        && /\breapertura\b/.test(normalized)
        && /\btoilette|lavado\b/.test(normalized)
        && /\bdrenaje\b/.test(normalized);
      if (!checks.postoperative_wound_core_terms) blockers.push('parte_hematoma_cervical_sin_nucleo_quirurgico');
    }
  }

  const unresolved = [
    /\bEdad:\s*edad\b/i,
    /\bInicio:\s*inicio\b/i,
    /\bFin:\s*fin\b/i,
    /\bnivel informado por el m[eé]dico\b/i,
    /\blateralidad informada por el m[eé]dico\b/i,
    /\bcompletar nivel/i,
    /\bniveles definitivos\b/i,
    /\bv[eé]rtebras instrumentadas\b/i,
    /\[completar\]|\[nivel|\[fecha\]|\[DNI\]|\[paciente\]/i,
  ];
  checks.no_visible_placeholders = !unresolved.some((rx) => rx.test(text));
  if (!checks.no_visible_placeholders) blockers.push('placeholders_visibles_en_documento');

  checks.patient_present = Boolean(args.patient) && text.includes(args.patient);
  if (!checks.patient_present) blockers.push('paciente_no_identificado');
  checks.date_present = Boolean(args.date) && text.includes(args.date);
  if (!checks.date_present) blockers.push('fecha_no_identificada');

  if (args.type === 'hc') {
    checks.hc_core_sections = /Motivo de ingreso/i.test(text) && /Enfermedad actual/i.test(text) && /Examen físico/i.test(text) && /Estudios/i.test(text) && /Plan/i.test(text);
    if (!checks.hc_core_sections) blockers.push('historia_clinica_sin_secciones_basicas');
    checks.no_hc_surgical_times = !/\bInicio:\b|\bFin:\b/i.test(text);
    if (!checks.no_hc_surgical_times) blockers.push('historia_clinica_no_debe_incluir_inicio_fin_quirurgico');
    const motorInOutput = /\b(debilidad|paresia|dorsiflexi[oó]n|hallux|marcha en talones|flexi[oó]n plantar|reflejo)\b/i.test(text);
    checks.no_unsolicited_motor_deficit = !motorInOutput || motorPositivelyStatedInInput;
    if (!checks.no_unsolicited_motor_deficit) blockers.push('deficit_motor_no_declarado_en_el_caso');
    if (!args.age) warnings.push('edad_no_informada');
    const subtype = lumbarFixationSubtype(args);
    if (subtype === 'inestabilidad_degenerativa') {
      checks.no_wrong_stenosis_default = !/\bcanal estrecho\b|\bclaudicaci[oó]n neur[oó]gena\b/i.test(text);
      if (!checks.no_wrong_stenosis_default) blockers.push('hc_inestabilidad_no_debe_default_canal_estrecho');
    }
  }

  if (args.type === 'parte') {
    const familyBag = normalizedText(`${args.family || ''} ${args.input || ''}`);
    const lumbarDisc = args.family === 'lumbar_hdl' || /hernia|microdiscect|discect/i.test(args.input || '');
    const extraforaminalLumbarDisc = lumbarDisc && /extraforaminal|extra\s*foraminal|far\s*lateral/i.test(args.input || '');
    if (extraforaminalLumbarDisc) {
      const badExtraforaminalTechnique = /espacio interlaminar|hemilaminotom[ií]a|flavectom[ií]a|hombro de la ra[ií]z|ra[ií]z pasante/i;
      checks.extraforaminal_no_interlaminar_sequence = !badExtraforaminalTechnique.test(text);
      if (!checks.extraforaminal_no_interlaminar_sequence) blockers.push('hernia_extraforaminal_con_tecnica_interlaminar');
      checks.extraforaminal_approach_present = /abordaje paravertebral[\s\S]{0,140}foraminal[\s\S]{0,100}extraforaminal/i.test(text);
      if (!checks.extraforaminal_approach_present) blockers.push('hernia_extraforaminal_sin_abordaje_extraforaminal');
    }
    const peripheralProcedure = /tunel carpiano|túnel carpiano|carpiano|nervio periferico|nervio periférico|periferico|periférico/.test(familyBag);
    const picProcedure = /monitoreo.*pic|presion intracraneana|presión intracraneana|intracraneana|sensor.*pic|sensor frontal|cateter.*presion|catéter.*presión/.test(familyBag);
    const cranialProcedure = picProcedure || /chiari|hidrocefalia|valvula|válvula|ventricul|craneo|cráneo|aneurisma|meningioma|hipofisis|hipófisis/.test(familyBag);
    const spinalOrImageGuided = !cranialProcedure && !peripheralProcedure && /lumbar|cervical|columna|bloqueo|vertebro|cifoplast|disco|fijacion|fijación|laminoplast|l[1-5]|c[1-7]/.test(familyBag);
    const positionOk = /Paciente en dec[uú]bito|Posicionamiento|dec[uú]bito|fijaci[oó]n cef[aá]lica/i.test(text);
    const imageOrPlanningOk = spinalOrImageGuided
      ? (postoperativeSpineWoundCase
          ? /sitio quir[uú]rgico|cicatriz previa|reapertura|lodge operatoria/i.test(text)
          : /control radiosc[oó]pico|Marcaci[oó]n radiosc[oó]pica/i.test(text))
      : peripheralProcedure
        ? /sitio quir[uú]rgico|trayecto anat[oó]mico|nervio afectado|liberaci[oó]n del ligamento|estructuras compresivas/i.test(text)
        : picProcedure
          ? /sitio planificado|trepanaci[oó]n|sensor\/cat[eé]ter|sistema de monitoreo|verificaci[oó]n de lectura/i.test(text)
          : /abordaje|craneotom[ií]a|fijaci[oó]n cef[aá]lica|exposici[oó]n|neuronavegaci[oó]n|planificaci[oó]n|sitio planificado/i.test(text);
    checks.parte_core_sequence = positionOk
      && /Antisepsia/i.test(text)
      && imageOrPlanningOk
      && /(Incisi[oó]n|abordaje|reapertura)/i.test(text)
      && /Hemostasia/i.test(text)
      && /(Cierre|curaci[oó]n)/i.test(text)
      && /(complicaciones|incidentes)/i.test(text);
    if (!checks.parte_core_sequence) blockers.push('parte_sin_secuencia_quirurgica_suficiente');
    checks.no_open_contraindication = !/salvo contraindicaci[oó]n/i.test(text);
    if (!checks.no_open_contraindication) blockers.push('frase_salvo_contraindicacion');
    if (!args.startTime) warnings.push('hora_inicio_no_informada');
    if (!args.endTime) warnings.push('hora_fin_no_informada');
    const assistantsResolved = Boolean(args.assistants || args.team)
      || /Ayudantes:\s*(Dr\.?\s*)?Carlos Zanardi y equipo/i.test(text);
    if (!assistantsResolved) warnings.push('ayudantes_no_informados');
  }

  const levelInInput = args.level || (args.input || '').match(/\b[CLDST]\d\s*[-/]\s*[CLDST]?\d\b/i)?.[0];
  if (levelInInput) {
    checks.level_respected = levelAppearsInText(levelInInput, normalized);
    if (!checks.level_respected) blockers.push('nivel_no_reflejado_en_documento');
  }
  if (args.side) {
    checks.side_respected = sideAppearsInText(args.side, normalized);
    if (!checks.side_respected) blockers.push('lateralidad_no_reflejada_en_documento');
  }

  const lumbarDisc = args.family === 'lumbar_hdl' || /hernia|microdiscect|discect/i.test(args.input || '');
  if (args.type === 'hc' && lumbarDisc && /l4\s*[-/]\s*l?5/i.test(`${args.level || ''} ${args.input || ''}`) && !/extraforaminal/i.test(args.input || '')) {
    checks.l4_l5_habitual_root_l5 = /radiculopat[ií]a L5/i.test(text);
    if (!checks.l4_l5_habitual_root_l5) blockers.push('hernia_l4_l5_habitual_sin_radiculopatia_l5');
  }

  const status = blockers.length
    ? 'BLOQUEADO_NO_ENVIAR'
    : warnings.length
      ? 'APTO_CON_OBSERVACIONES'
      : 'APTO_PARA_ENVIO';
  return {
    ok: blockers.length === 0,
    status,
    mode: 'flexible_obligatorio',
    standard_id: MEDICO_LEGAL_STANDARD_ID,
    blockers,
    warnings,
    checks,
    rule: 'HC y protocolo se generan fluidamente desde la app, pero nunca se envían sin tamiz. Solo bloquean contradicciones, placeholders o riesgos materiales; faltantes menores quedan como observaciones.',
  };
}

function wrapClinicalHtml(args, rendered, validation) {
  return `<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>${esc(titleForType(args.type))}</title>
  <style>
    body { font-family: Arial, sans-serif; color:#111827; line-height:1.45; max-width:820px; margin:28px auto; }
    header { display:flex; justify-content:space-between; gap:24px; border-bottom:1px solid #cbd5e1; padding-bottom:12px; margin-bottom:20px; }
    h1 { font-size:18px; margin:0; text-align:center; text-transform:uppercase; color:#102f45; }
    p { margin:0 0 10px; }
    .meta { color:#475569; font-size:12px; text-align:right; }
    .fill { background:#fff4cf; padding:0 4px; border-radius:3px; }
  </style>
</head>
<body>
  <header>
    <div><strong>${esc(institutionLabel(args.institution))}</strong><br>Servicio de Neurocirugía y Cirugía de Columna</div>
    <div class="meta">${esc(rendered.familyLabel)}<br>Dr. ${esc(args.surgeon || 'Carlos Zanardi')}</div>
  </header>
  <h1>${esc(titleForType(args.type))}</h1>
  <main>${rendered.bodyHtml}</main>
</body>
</html>`;
}

function writePayloadAndExportPdf(args, rendered, validation, baseName) {
  const pdfPath = path.join(READY_DIR, `${baseName}.pdf`);
  const payloadPath = path.join(READY_DIR, `${baseName}.payload.json`);
  const payload = {
    title: titleForType(args.type).toUpperCase(),
    institution_key: args.institution,
    institution_label: institutionLabel(args.institution),
    surgeon: args.surgeon || 'Carlos Zanardi',
    family_label: rendered.familyLabel,
    body_html: rendered.bodyHtml,
    validation_status: validation.status,
  };
  fs.writeFileSync(payloadPath, JSON.stringify(payload, null, 2));
  execFileSync(PYTHON, [PDF_EXPORTER, '--payload', payloadPath, '--output', pdfPath], {
    cwd: APP_ROOT,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  return { pdfPath, payloadPath };
}

function runJsonCommand(command, args, options = {}) {
  const raw = execFileSync(command, args, {
    cwd: options.cwd || APP_ROOT,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  }).trim();
  return raw ? JSON.parse(raw) : {};
}

async function generateSingleDocument(args, stamp) {
  if (args.type === 'consent') {
    return delegateConsent(args);
  }

  const rendered = await renderFromApp(args);
  const validation = validateClinical(args, rendered);
  const baseName = `${documentKindForType(args.type)}_${slugify(args.family)}_${slugify(args.institution)}_${slugify(args.patient || 'paciente')}_${stamp}`;
  const htmlPath = path.join(READY_DIR, `${baseName}.html`);
  fs.writeFileSync(htmlPath, wrapClinicalHtml(args, rendered, validation), 'utf8');
  const { pdfPath, payloadPath } = writePayloadAndExportPdf(args, rendered, validation, baseName);
  const stat = fs.statSync(pdfPath);
  const caption = args.caption || `${titleForType(args.type)} - ${args.patient || 'Paciente'}`;
  const sendCommand = [
    NODE,
    SEND_GUARD,
    '--file', pdfPath,
    '--chat-id', args.chatId || '<chat_id_de_la_conversacion>',
    ...(args.threadId ? ['--thread-id', args.threadId] : []),
    '--caption', caption,
    '--task', `clinica-${documentKindForType(args.type)}-${stamp}`,
    '--lane', 'clinica_medicolegal',
  ];

  const handoff = {
    created_at: new Date().toISOString(),
    status: validation.ok ? (args.send ? 'validated_ready_to_send' : 'validated_pending_telegram_send') : 'blocked_validation_failed',
    artifact_type: `${documentKindForType(args.type)}_pdf_telegram_ready`,
    source: PRODUCT_HTML,
    generator: 'app.product.html via clinical_document_handoff',
    medico_legal_standard_id: MEDICO_LEGAL_STANDARD_ID,
    constraints: {
      generated_by_app_not_by_jarvis_free_text: true,
      medico_legal_check_required: true,
      flexible_gate_for_hc_parte: true,
      red_blocks_delivery: true,
      yellow_observations_do_not_block_delivery: true,
      consent_uses_hard_gate: false,
      telegram_config_touched: false,
      delivery_requires_guard: true,
    },
    request: {
      type: args.type,
      requested_types: args.requestedTypes || [args.type],
      family: args.family,
      institution: args.institution,
      patient: args.patient || null,
      age: args.age || null,
      date: args.date || null,
      start_time: args.startTime || null,
      end_time: args.endTime || null,
      assistants: args.assistants || null,
      exceptions: args.exceptions || null,
      level: args.level || null,
      side: args.side || null,
      surgeon: args.surgeon || 'Carlos Zanardi',
      input: args.input,
    },
    files: {
      pdf: pdfPath,
      html: htmlPath,
      payload: payloadPath,
    },
    size: stat.size,
    caption,
    validation,
    send_command: sendCommand,
    delivery: null,
  };

  const manifestPath = path.join(HANDOFF_DIR, `${baseName}.json`);
  if (!validation.ok) {
    fs.writeFileSync(manifestPath, JSON.stringify(handoff, null, 2));
    return {
      ok: false,
      validated: false,
      validation_status: validation.status,
      manifest: manifestPath,
      file: pdfPath,
      html: htmlPath,
      status: handoff.status,
      warnings: validation.warnings,
      blockers: validation.blockers,
      handoff,
    };
  }

  fs.writeFileSync(manifestPath, JSON.stringify(handoff, null, 2));
  if (args.send) {
    handoff.delivery = runJsonCommand(NODE, sendCommand.slice(1), { cwd: WORKSPACE });
    handoff.status = handoff.delivery.dry_run ? 'dry_run_validated' : (handoff.delivery.ok ? 'sent' : 'send_failed');
    fs.writeFileSync(manifestPath, JSON.stringify(handoff, null, 2));
  }

  return {
    ok: true,
    validated: true,
    validation_status: validation.status,
    manifest: manifestPath,
    file: pdfPath,
    html: htmlPath,
    status: handoff.status,
    warnings: validation.warnings,
    blockers: validation.blockers || [],
    handoff,
  };
}

async function main() {
  const args = parseArgs(process.argv);
  fs.mkdirSync(READY_DIR, { recursive: true });
  fs.mkdirSync(HANDOFF_DIR, { recursive: true });

  const requestedTypes = Array.isArray(args.requestedTypes) && args.requestedTypes.length
    ? args.requestedTypes
    : [args.type];
  const multiTypeRequest = !process.argv.includes('--type') && requestedTypes.length > 1 && requestedTypes.every((type) => type !== 'consent');

  if (!multiTypeRequest) {
    const result = await generateSingleDocument(args, nowStamp());
    if (!result.ok) {
      console.error(JSON.stringify({ ok: false, validated: false, validation_status: result.validation_status, manifest: result.manifest, file: result.file, blockers: result.blockers }, null, 2));
      process.exit(3);
    }
    console.log(JSON.stringify({
      ok: true,
      validated: true,
      validation_status: result.validation_status,
      manifest: result.manifest,
      file: result.file,
      html: result.html,
      status: result.status,
      warnings: result.warnings,
    }, null, 2));
    return;
  }

  const sharedStamp = nowStamp();
  const results = [];
  for (const type of requestedTypes) {
    const result = await generateSingleDocument({ ...args, type, requestedTypes }, sharedStamp);
    results.push({ type, ...result });
  }

  const blocked = results.filter((result) => !result.ok);
  const bundleManifestPath = path.join(HANDOFF_DIR, `clinical_bundle_${slugify(args.family)}_${slugify(args.institution)}_${slugify(args.patient || 'paciente')}_${sharedStamp}.json`);
  const bundleManifest = {
    created_at: new Date().toISOString(),
    status: blocked.length ? 'blocked_validation_failed' : (args.send ? 'validated_ready_to_send_bundle' : 'validated_pending_telegram_send_bundle'),
    request: {
      requested_types: requestedTypes,
      family: args.family,
      institution: args.institution,
      patient: args.patient || null,
      input: args.input,
    },
    documents: results.map((result) => ({
      type: result.type,
      ok: result.ok,
      validated: result.validated,
      validation_status: result.validation_status,
      manifest: result.manifest,
      file: result.file,
      html: result.html,
      status: result.status,
      warnings: result.warnings,
      blockers: result.blockers,
    })),
  };
  fs.writeFileSync(bundleManifestPath, JSON.stringify(bundleManifest, null, 2));

  if (blocked.length) {
    console.error(JSON.stringify({
      ok: false,
      validated: false,
      validation_status: 'BLOQUEADO_NO_ENVIAR',
      manifest: bundleManifestPath,
      requested_types: requestedTypes,
      blocked_documents: blocked.map((result) => ({ type: result.type, blockers: result.blockers, file: result.file, manifest: result.manifest })),
    }, null, 2));
    process.exit(3);
  }

  console.log(JSON.stringify({
    ok: true,
    validated: true,
    validation_status: 'APTO_PARA_ENVIO',
    manifest: bundleManifestPath,
    requested_types: requestedTypes,
    files: results.map((result) => ({ type: result.type, file: result.file, manifest: result.manifest })),
    status: bundleManifest.status,
    warnings: results.flatMap((result) => (result.warnings || []).map((warning) => `${result.type}:${warning}`)),
  }, null, 2));
}

main().catch((error) => {
  console.error(error.stack || String(error));
  process.exit(1);
});
