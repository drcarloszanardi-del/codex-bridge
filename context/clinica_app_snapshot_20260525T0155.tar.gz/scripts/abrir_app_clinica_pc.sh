#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
HOST="${HOST:-127.0.0.1}"
PORT="${PORT:-4329}"
STATE_DIR="$APP_ROOT/state"
PID_FILE="$STATE_DIR/app_server.pid"
OUT_LOG="$STATE_DIR/app_server.out.log"
ERR_LOG="$STATE_DIR/app_server.err.log"
URL="http://$HOST:$PORT/app/product.html"
HEALTH_URL="http://$HOST:$PORT/health.json"
LAUNCHD_LABEL="ai.clinica.app-local"
LAUNCHD_PLIST="$APP_ROOT/scripts/launchd/$LAUNCHD_LABEL.plist"

mkdir -p "$STATE_DIR"

pick_node() {
  if [[ -n "${NODE_BIN:-}" && -x "$NODE_BIN" ]]; then
    printf '%s\n' "$NODE_BIN"
    return
  fi

  local bundled="$APP_ROOT/../../../tools/node-v22.22.0/bin/node"
  if [[ -x "$bundled" ]]; then
    printf '%s\n' "$bundled"
    return
  fi

  command -v node
}

health_ok() {
  curl -fsS "$HEALTH_URL" >/dev/null 2>&1
}

port_busy() {
  lsof -nP -iTCP:"$PORT" -sTCP:LISTEN >/dev/null 2>&1
}

start_with_launchd() {
  if ! command -v launchctl >/dev/null 2>&1 || [[ "$HOST" != "127.0.0.1" || "$PORT" != "4329" ]]; then
    return 1
  fi
  local domain="gui/$(id -u)"
  if ! launchctl print "$domain/$LAUNCHD_LABEL" >/dev/null 2>&1; then
    launchctl bootstrap "$domain" "$LAUNCHD_PLIST"
  fi
  launchctl kickstart -k "$domain/$LAUNCHD_LABEL"
  return 0
}

start_with_nohup() {
  NODE="$(pick_node)"
  : > "$OUT_LOG"
  : > "$ERR_LOG"
  HOST="$HOST" PORT="$PORT" nohup "$NODE" "$APP_ROOT/scripts/serve_review_only_mvp.js" >> "$OUT_LOG" 2>> "$ERR_LOG" &
  echo "$!" > "$PID_FILE"
}

if ! health_ok; then
  if port_busy; then
    echo "El puerto $PORT esta ocupado, pero la app clinica no responde en $HEALTH_URL." >&2
    echo "Cierre el proceso que usa ese puerto o ejecute con otro PORT, por ejemplo: PORT=4330 scripts/abrir_app_clinica_pc.sh" >&2
    exit 1
  fi

  if ! start_with_launchd; then
    start_with_nohup
  fi
  sleep 1
fi

if ! health_ok; then
  echo "No pude levantar la app clinica local. Revise $ERR_LOG" >&2
  exit 1
fi

if command -v open >/dev/null 2>&1; then
  open "$URL"
fi

printf 'App clinica local activa: %s\n' "$URL"
printf 'Estado: %s\n' "$HEALTH_URL"
