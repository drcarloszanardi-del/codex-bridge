#!/usr/bin/env node
const http = require('http');
const fs = require('fs');
const path = require('path');

const projectRoot = path.resolve(__dirname, '..');
const appRoot = path.join(projectRoot, 'app');
const dataRoot = path.join(projectRoot, 'data');
const qaRoot = path.join(projectRoot, 'qa');
const port = Number(process.env.PORT || 4317);
const host = process.env.HOST || '127.0.0.1';

const mime = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.md': 'text/markdown; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
  '.css': 'text/css; charset=utf-8'
};

function isWithin(root, candidate) {
  const rel = path.relative(root, candidate);
  return rel === '' || (!rel.startsWith('..') && !path.isAbsolute(rel));
}

function readJson(relPath) {
  try {
    return JSON.parse(fs.readFileSync(path.join(projectRoot, relPath), 'utf8'));
  } catch (err) {
    return null;
  }
}

function latestFreshness() {
  const dir = path.join(qaRoot, 'approval_gates');
  try {
    const latest = fs.readdirSync(dir)
      .filter((name) => /^latest_artifacts_freshness_\d{4}-\d{2}-\d{2}\.json$/.test(name))
      .sort()
      .at(-1);
    return latest ? readJson(path.join('qa', 'approval_gates', latest)) : null;
  } catch (err) {
    return null;
  }
}

function summarizeHealth() {
  const core = readJson('qa/approval_gates/clinica_core_qa_latest.json') || {};
  const detect = readJson('qa/approval_gates/medicolegal_detect_only_update_cycle_latest.json') || {};
  const manifest = readJson('qa/approval_gates/cli_app_candidate_manifest_latest.json') || {};
  const freshness = latestFreshness() || {};
  const stages = Array.isArray(detect.stages) ? detect.stages : [];
  const files = Array.isArray(manifest.files) ? manifest.files : [];
  const sourceStage = stages.find((stage) => stage.id === 'regenerate_processed_indexes');
  const sourceParsed = sourceStage && sourceStage.parsed ? sourceStage.parsed : {};
  const summaryStage = stages.find((stage) => stage.id === 'update_detect_only_summary');
  const summaryParsed = summaryStage && summaryStage.parsed ? summaryStage.parsed : {};
  const dryRunStage = stages.find((stage) => stage.id === 'build_tamiz_dry_run_promotion');
  const dryRunParsed = dryRunStage && dryRunStage.parsed ? dryRunStage.parsed : {};

  return {
    ok: true,
    service: 'clinica_app_local_review_only',
    generated_at: new Date().toISOString(),
    host,
    port,
    app: {
      mode: 'review_only',
      product_url: `http://${host}:${port}/app/product.html`,
      launch_url: `http://${host}:${port}/app/`,
      families_count: 40,
      document_types_count: 4
    },
    qa: {
      core: {
        ok: core.ok === true,
        mode: core.mode || null,
        generated_at: core.generated_at || null,
        failures: Array.isArray(core.failures) ? core.failures : [],
        warnings: Array.isArray(core.warnings) ? core.warnings : [],
        suites_count: Array.isArray(core.suites) ? core.suites.length : 0
      },
      detect_only: {
        ok: detect.ok === true,
        generated_at: detect.generated_at || null,
        skip_fetch: detect.skip_fetch === true,
        stages_count: stages.length,
        stages_ok_count: stages.filter((stage) => stage.ok === true).length,
        sources_count: Number(summaryParsed.monitored_sources_count || 0) || Number(sourceParsed.normative_sources || 0) + Number(sourceParsed.jurisprudence_candidates || 0) + Number(sourceParsed.doctrine_sources || 0) + Number(sourceParsed.internal_sources || 0),
        pending_review_count: Number(dryRunParsed.pending_review || 0)
      },
      manifest: {
        generated_at: manifest.generated_at || null,
        status: manifest.status || null,
        files_count: files.length
      },
      freshness: {
        ok: freshness.ok === true,
        generated_at: freshness.generated_at || null,
        failures: Array.isArray(freshness.failures) ? freshness.failures : []
      }
    }
  };
}

function safePath(urlPath) {
  let cleaned;
  try {
    cleaned = decodeURIComponent(urlPath.split('?')[0]);
  } catch (err) {
    return null;
  }
  const relative = (cleaned === '/' || cleaned === '/app/' || cleaned === '/app') ? '/app/index.html' : cleaned;
  const candidate = path.normalize(path.join(projectRoot, relative));
  if (!isWithin(projectRoot, candidate)) return null;
  return candidate;
}

const server = http.createServer((req, res) => {
  const requestPath = (req.url || '/').split('?')[0];

  if (requestPath === '/health.json') {
    res.writeHead(200, {
      'Content-Type': 'application/json; charset=utf-8',
      'Cache-Control': 'no-store'
    });
    res.end(JSON.stringify(summarizeHealth(), null, 2));
    return;
  }

  if (requestPath === '/favicon.ico') {
    res.writeHead(204, { 'Cache-Control': 'max-age=86400' });
    res.end();
    return;
  }

  if (requestPath === '/app/product') {
    res.writeHead(302, { Location: '/app/product.html' });
    res.end();
    return;
  }

  const filePath = safePath(req.url || '/');
  if (!filePath) {
    res.writeHead(403);
    res.end('Forbidden');
    return;
  }

  const allowed = [appRoot, dataRoot, qaRoot].some((root) => isWithin(root, filePath));
  if (!allowed) {
    res.writeHead(404);
    res.end('Not found');
    return;
  }

  fs.readFile(filePath, (err, content) => {
    if (err) {
      res.writeHead(404);
      res.end('Not found');
      return;
    }
    const ext = path.extname(filePath);
    const headers = { 'Content-Type': mime[ext] || 'application/octet-stream' };
    if (['.html', '.js', '.json', '.md'].includes(ext)) headers['Cache-Control'] = 'no-store';
    res.writeHead(200, headers);
    res.end(content);
  });
});

server.listen(port, host, () => {
  console.log(JSON.stringify({ ok: true, host, port, url: `http://${host}:${port}/app/`, product_url: `http://${host}:${port}/app/product.html` }));
});

server.on('error', (err) => {
  console.error(JSON.stringify({ ok: false, host, port, error: err.message }));
  process.exitCode = 1;
});
