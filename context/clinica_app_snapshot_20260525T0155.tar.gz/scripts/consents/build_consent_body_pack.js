const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const appRoot = path.resolve(__dirname, '..', '..');
const clinicRoot = path.resolve(appRoot, '..');
const indexPath = path.join(appRoot, 'data', 'derived', 'consent_canonicals', 'consent_canonical_index_2026-05-19.json');
const sourceCorpusPath = path.join(appRoot, 'data', 'derived', 'consent_source_corpus', 'neurocirugia_consent_source_corpus_latest.json');
const outputDir = path.join(appRoot, 'data', 'derived', 'consent_canonicals');
const outputPath = path.join(outputDir, 'consent_body_pack_2026-05-19.json');

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function sha256(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function esc(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function inlineMarkdown(value) {
  return esc(value)
    .replace(/\*\*([^*]+)\*\*/g, '<strong>$1</strong>')
    .replace(/\*([^*]+)\*/g, '<em>$1</em>');
}

function markdownToHtml(markdown) {
  const lines = markdown.replace(/\r\n/g, '\n').split('\n');
  const blocks = [];
  let paragraph = [];
  let list = [];

  function flushParagraph() {
    if (!paragraph.length) return;
    blocks.push(`<p>${inlineMarkdown(paragraph.join(' ').trim())}</p>`);
    paragraph = [];
  }

  function flushList() {
    if (!list.length) return;
    blocks.push(`<ul>${list.map((item) => `<li>${inlineMarkdown(item)}</li>`).join('')}</ul>`);
    list = [];
  }

  for (const rawLine of lines) {
    const line = rawLine.trim();
    if (!line) {
      flushParagraph();
      flushList();
      continue;
    }
    if (/^#\s+/.test(line)) {
      flushParagraph();
      flushList();
      blocks.push(`<p><strong>${inlineMarkdown(line.replace(/^#\s+/, ''))}</strong></p>`);
      continue;
    }
    if (/^##+\s+/.test(line)) {
      flushParagraph();
      flushList();
      blocks.push(`<p><strong>${inlineMarkdown(line.replace(/^##+\s+/, ''))}</strong></p>`);
      continue;
    }
    if (/^[-*]\s+/.test(line)) {
      flushParagraph();
      list.push(line.replace(/^[-*]\s+/, ''));
      continue;
    }
    flushList();
    paragraph.push(line);
  }
  flushParagraph();
  flushList();
  return blocks.join('\n');
}

function stripHtmlDocument(html) {
  return String(html || '')
    .replace(/<!doctype[^>]*>/gi, '')
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/<style[\s\S]*?<\/style>/gi, '')
    .replace(/<head[\s\S]*?<\/head>/gi, '')
    .replace(/<body[^>]*>/i, '')
    .replace(/<\/body>/i, '')
    .replace(/<\/?html[^>]*>/gi, '')
    .replace(/\s+class="[^"]*"/gi, '')
    .replace(/\s+style="[^"]*"/gi, '')
    .replace(/\s+id="[^"]*"/gi, '')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function plainTextFromHtml(html) {
  return String(html || '')
    .replace(/<li[^>]*>/gi, '\n- ')
    .replace(/<\/(p|h[1-6]|div|ul|ol|li)>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/[ \t]+/g, ' ')
    .replace(/\n[ \t]+/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function readSource(filePath) {
  if (!filePath || !fs.existsSync(filePath)) {
    return {
      exists: false,
      source_format: 'missing',
      body_html: '',
      body_text: '',
      source_sha256: null
    };
  }
  const raw = fs.readFileSync(filePath, 'utf8');
  const ext = path.extname(filePath).toLowerCase();
  const bodyHtml = ext === '.html' || ext === '.htm' ? stripHtmlDocument(raw) : markdownToHtml(raw);
  return {
    exists: true,
    source_format: ext.replace('.', '') || 'text',
    body_html: bodyHtml,
    body_text: plainTextFromHtml(bodyHtml),
    source_sha256: sha256(raw)
  };
}

function preferredSource(entry) {
  const candidates = [
    entry.source_of_truth,
    entry.approved_reference,
    ...(entry.institution_overrides || [])
  ].filter(Boolean);
  return candidates.find((candidate) => fs.existsSync(candidate)) || candidates[0] || null;
}

const canonicalIndex = readJson(indexPath);
const entries = canonicalIndex.entries.map((entry) => {
  const sourcePath = preferredSource(entry);
  const source = readSource(sourcePath);
  return {
    slug: entry.slug,
    title: entry.title,
    approval_status: entry.approval_status,
    delivery_allowed: entry.delivery_allowed,
    institution_scope: entry.institution_scope,
    approved_by: entry.approved_by,
    source_path: sourcePath,
    source_format: source.source_format,
    source_sha256: source.source_sha256,
    source_exists: source.exists,
    supported_institutions: entry.supported_institutions || [],
    allowed_variables: entry.allowed_variables || canonicalIndex.allowed_variables,
    protected_sections: canonicalIndex.protected_sections,
    clinical_blocking: entry.clinical_blocking || [],
    administrative_non_blocking: entry.administrative_non_blocking || [],
    body_html: source.body_html,
    body_text: source.body_text,
    lineage_note: 'Cuerpo recuperado desde Jarvis y normalizado para la línea formal del PDF de consentimiento del 19/05/2026. No cambia el estado de aprobación clínica/legal del documento.',
    output_capabilities: {
      app_html: true,
      word_docx: true,
      pdf: true,
      logo_header: true
    }
  };
});

const bySlug = Object.fromEntries(entries.map((entry) => [entry.slug, entry]));
const appFamilyMap = {
  ...canonicalIndex.app_family_map,
  columna_disco_cervical: 'artrodesis_cervical',
  tumores_intracraneales: 'neurocirugia_general_otras_patologias',
  vascular_aneurismas_tvt: 'neurocirugia_general_otras_patologias'
};

const output = {
  generated_at: new Date().toISOString(),
  source: 'jarvis_consent_canonical_body_pack',
  source_index: indexPath,
  reference_pdf_style: '/Users/jarvis/Downloads/consentimiento_canal_estrecho_l4_l5_fijacion_clinica_centro_sin_fecha_19052026.pdf',
  clinic_root: clinicRoot,
  guard_rule: canonicalIndex.guard_rule,
  approval_warning: 'Los consentimientos operational_derived son base operativa recuperada; no deben entregarse como aprobados exactos hasta validación explícita del Dr. Zanardi.',
  protected_sections: canonicalIndex.protected_sections,
  allowed_variables: canonicalIndex.allowed_variables,
  institutions: canonicalIndex.institutions,
  normative_requirements: [
    'Identificación de paciente, documento, institución y fecha.',
    'Diagnóstico, procedimiento específico, nivel/lateralidad cuando aplique.',
    'Objetivo, beneficios esperados sin promesa de resultado.',
    'Riesgos y complicaciones relevantes por patología.',
    'Alternativas terapéuticas y consecuencias previsibles de no tratar.',
    'Anestesia, hemoderivados, preguntas, segunda opinión, rechazo o revocación.',
    'Firmas, aclaración, DNI y matrícula; integración a historia clínica.'
  ],
  source_corpus_enrichment: fs.existsSync(sourceCorpusPath)
    ? {
        source: sourceCorpusPath,
        corpus_id: readJson(sourceCorpusPath).corpus_id,
        generated_at: readJson(sourceCorpusPath).generated_at,
        privacy_mode: readJson(sourceCorpusPath).privacy_mode,
        filtered_for_consent_corpus: readJson(sourceCorpusPath).filtered_for_consent_corpus,
        families: readJson(sourceCorpusPath).families
      }
    : null,
  export_capabilities: {
    html: true,
    docx: true,
    pdf: true,
    pdf_engine: 'reportlab',
    docx_engine: 'python-docx',
    logo_header: true
  },
  recovered_counts: canonicalIndex.recovered_counts,
  entries,
  by_slug: bySlug,
  app_family_map: appFamilyMap
};

fs.mkdirSync(outputDir, { recursive: true });
fs.writeFileSync(outputPath, JSON.stringify(output, null, 2));
console.log(outputPath);
