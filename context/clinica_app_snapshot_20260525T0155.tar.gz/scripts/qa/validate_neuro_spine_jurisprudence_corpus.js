#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..', '..');
const corpusPath = path.join(root, 'data', 'derived', 'jurisprudence_neuro_spine', 'jurisprudence_neuro_spine_corpus_latest.json');
const tamizPath = path.join(root, 'data', 'derived', 'medicolegal_tamiz', 'medicolegal_tamiz_pack_2026-05-19.json');
const qaDir = path.join(root, 'qa', 'approval_gates');

function assert(ok, message, failures) {
  if (!ok) failures.push(message);
}

function main() {
  const failures = [];
  assert(fs.existsSync(corpusPath), `No existe corpus: ${corpusPath}`, failures);
  assert(fs.existsSync(tamizPath), `No existe tamiz: ${tamizPath}`, failures);
  if (failures.length) throw new Error(failures.join('\n'));

  const corpus = JSON.parse(fs.readFileSync(corpusPath, 'utf8'));
  const tamiz = JSON.parse(fs.readFileSync(tamizPath, 'utf8'));
  const records = corpus.records || [];
  const doctrine = corpus.doctrine || [];
  const rules = corpus.impact_rules || [];
  const gates = tamiz.gates || [];

  assert(corpus.status === 'review_only_detect_only', `Estado inesperado: ${corpus.status}`, failures);
  assert(records.length >= 12, `Pocos registros jurisprudenciales: ${records.length}`, failures);
  assert(records.filter((item) => item.reliability?.startsWith('official')).length >= 7, 'Faltan fuentes oficiales suficientes', failures);
  assert(records.some((item) => item.clinical_domain?.some((domain) => /columna/.test(domain))), 'No hay dominio columna', failures);
  assert(records.some((item) => item.clinical_domain?.some((domain) => /neuro/.test(domain))), 'No hay dominio neurocirugia', failures);
  assert(records.some((item) => item.topics?.includes('consentimiento_informado') || item.topics?.includes('consentimiento_especifico')), 'No hay consentimiento en jurisprudencia', failures);
  assert(doctrine.length >= 1, 'Falta doctrina de especialidad separada', failures);
  assert(rules.length >= 5, `Pocas reglas de impacto: ${rules.length}`, failures);

  const requiredFields = ['id', 'title', 'tribunal', 'date', 'source_url', 'source_type', 'reliability', 'legal_criterion', 'tamiz_rules'];
  for (const record of records) {
    for (const field of requiredFields) assert(Boolean(record[field]), `${record.id || 'registro'} sin ${field}`, failures);
    assert(Array.isArray(record.tamiz_rules) && record.tamiz_rules.length >= 2, `${record.id} sin tamiz suficiente`, failures);
    assert(/^https?:\/\//.test(record.source_url), `${record.id} fuente no URL`, failures);
  }

  const neuroGates = gates.filter((gate) => /^CLI-NSJ/.test(gate.id));
  assert(neuroGates.length >= 5, `Faltan gates neuro/columna: ${neuroGates.length}`, failures);
  assert(neuroGates.every((gate) => gate.foundation?.includes('Corpus neuro/columna')), 'Gates neuro sin fundamento al corpus', failures);

  const text = JSON.stringify(corpus);
  const forbiddenRisk = /APTO_PARA_ENTREGAR|cumplimiento legal garantizado|blindaje absoluto|certificado legal/i;
  assert(!forbiddenRisk.test(text), 'El corpus promete cumplimiento legal o blindaje absoluto', failures);

  const summary = {
    generated_at: new Date().toISOString(),
    ok: failures.length === 0,
    corpus_path: corpusPath,
    tamiz_path: tamizPath,
    records_count: records.length,
    official_records_count: records.filter((item) => item.reliability?.startsWith('official')).length,
    secondary_records_count: records.filter((item) => item.reliability?.startsWith('secondary')).length,
    doctrine_count: doctrine.length,
    impact_rules_count: rules.length,
    neuro_gates_count: neuroGates.length,
    failures,
  };

  fs.mkdirSync(qaDir, { recursive: true });
  const outPath = path.join(qaDir, `neuro_spine_jurisprudence_validation_${new Date().toISOString().slice(0, 10)}.json`);
  fs.writeFileSync(outPath, JSON.stringify(summary, null, 2));
  console.log(JSON.stringify(summary, null, 2));
  if (failures.length) process.exit(1);
}

main();
