#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const APP_ROOT = path.resolve(__dirname, '..', '..');
const NODE = process.env.OPENCLAW_NODE || '/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node';
const PYTHON = process.env.CLINICA_PYTHON || '/Users/jarvis/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3';
const HANDOFF = path.join(APP_ROOT, 'scripts/jarvis/consent_telegram_handoff.js');
const VISUAL_STANDARD_ID = 'consentimiento_sobrio_institucional_v1';
const CONTENT_STANDARD_ID = 'consentimiento_medicolegal_arg_v1';

function runHandoff({ slug, institution, patient, dni, team }) {
  const args = [
    HANDOFF,
    '--slug', slug,
    '--institution', institution,
    '--date', '19/05/2026',
    '--level', 'L4-L5',
  ];
  if (team) args.push('--team', team);
  if (patient) args.push('--patient', patient);
  if (dni) args.push('--dni', dni);
  const raw = execFileSync(NODE, args, {
    cwd: APP_ROOT,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  }).trim();
  return JSON.parse(raw);
}

function pdfText(file) {
  return execFileSync(PYTHON, ['-c', `
from pypdf import PdfReader
import sys
r=PdfReader(sys.argv[1])
print("\\n".join((p.extract_text() or "") for p in r.pages))
  `, file], { encoding: 'utf8' });
}

function main() {
  const visualCases = [
    { slug: 'canal_estrecho_lumbar_con_fijacion', institution: 'clinica_centro', patient: 'Juan Perez', dni: '11.111.111', team: 'Dr. Perez' },
    { slug: 'canal_estrecho_lumbar_con_fijacion', institution: 'la_pequena_familia', patient: 'Maria Gomez', dni: '22.222.222', team: 'Dr. Perez' },
    { slug: 'canal_estrecho_lumbar_con_fijacion', institution: 'higa_junin', patient: 'Carlos Lopez', dni: '33.333.333', team: 'Dr. Perez' },
  ];
  const generated = visualCases.map(runHandoff);
  const blank = runHandoff({ slug: 'hernia_disco_lumbar', institution: 'clinica_centro' });
  const canal = generated[0];
  const manifest = JSON.parse(fs.readFileSync(canal.manifest, 'utf8'));
  const text = pdfText(canal.file);
  const pages = Number(execFileSync(PYTHON, ['-c', `
from pypdf import PdfReader
import sys
print(len(PdfReader(sys.argv[1]).pages))
  `, canal.file], { encoding: 'utf8' }).trim());
  const visualTexts = generated.map((item) => pdfText(item.file));
  const blankText = pdfText(blank.file).replace(/\s+/g, ' ');
  const visualManifests = generated.map((item) => JSON.parse(fs.readFileSync(item.manifest, 'utf8')));
  const visualPageCounts = generated.map((item) => Number(execFileSync(PYTHON, ['-c', `
from pypdf import PdfReader
import sys
print(len(PdfReader(sys.argv[1]).pages))
  `, item.file], { encoding: 'utf8' }).trim()));
  const repeatedInstitutionPattern = /Cl[ií]nica Centro|Cl[ií]nica La Pequeña Familia|Clinica La Pequena Familia|HIGA Jun[ií]n|Hospital Interzonal General de Agudos/i;
  const compactText = text.replace(/\s+/g, ' ');

  const checks = {
    pdf_exists: fs.existsSync(canal.file) && fs.statSync(canal.file).size > 0,
    pdf_one_page: pages === 1,
    visual_standard_id_ok: manifest.visual_standard_id === VISUAL_STANDARD_ID,
    visual_standard_rule_ok: /logo institucional.*fundido.*cuerpo justificado.*firmas en paralelo/i.test(manifest.visual_standard_rule || ''),
    visual_all_institution_pdfs_exist: generated.every((item) => fs.existsSync(item.file) && fs.statSync(item.file).size > 0),
    visual_all_institution_one_page: visualPageCounts.every((count) => count === 1),
    visual_all_institution_standard_id: visualManifests.every((item) => item.visual_standard_id === VISUAL_STANDARD_ID),
    visual_no_institution_labels_in_text: visualTexts.every((item) => !repeatedInstitutionPattern.test(item)),
    visual_no_duplicate_institution_text: !/cl[ií]nica centro/i.test(text),
    content_standard_id_ok: manifest.content_standard_id === CONTENT_STANDARD_ID,
    content_standard_rule_ok: /Matriz R1-R8 Argentina.*historia clínica.*copia\/acceso/i.test(manifest.content_standard_rule || ''),
    content_guard_manifest_ok: manifest.constraints && manifest.constraints.medico_legal_matrix_r1_r8 === true,
    hard_validation_before_send_ok: manifest.constraints && manifest.constraints.hard_validation_before_send === true,
    manifest_validation_ok: manifest.validation && manifest.validation.ok === true && manifest.validation.status === 'APTO_PARA_ENVIO',
    manifest_format_not_content: manifest.format_proforma === 'formato_consentimiento_hernia_disco_lumbar',
    manifest_content_slug_ok: manifest.content_source_slug === 'canal_estrecho_lumbar_con_fijacion',
    content_mentions_requested_pathology: /CANAL ESTRECHO LUMBAR CON FIJACI[ÓO]N|canal estrecho lumbar/i.test(text),
    content_not_hernia: !/hernia de disco|hernia discal/i.test(text),
    content_r1_patient_act: /Yo, Juan Perez, DNI 11\.111\.111/i.test(text) && /Autorizo a los Dres\./i.test(text),
    content_blank_patient_dni_lines: /Yo,\s*\.{8,}\s*,?\s*DNI\s*\.{8,}/i.test(blankText),
    content_blank_default_team: /Autorizo al Dr\. Carlos Zanardi y equipo/i.test(blankText),
    content_no_qa_leak: !/Paciente QA|QA[-_ ]?\d|Paciente prueba|Paciente de prueba|Ayudante QA|Paciente Wrapper/i.test(text + blankText),
    content_r2_diagnosis_indication: /diagn[oó]stico de .*canal estrecho lumbar/i.test(text),
    content_r3_procedure_specific: /descompresi[oó]n|recalibraje|fijaci[oó]n|artrodesis/i.test(text),
    content_r4_specific_risks: /lesi[oó]n radicular|lesi[oó]n dural|f[ií]stula de LCR|malposici[oó]n|falla de implantes|pseudoartrosis|reintervenci[oó]n/i.test(text),
    content_r5_alternatives_no_treat: /alternativas terap[eé]uticas.*tratamiento m[eé]dico.*posibilidad de no operarme/i.test(compactText) && /si no realizo el tratamiento indicado/i.test(text),
    content_r6_autonomy_questions_revocation: /preguntas.*segunda opini[oó]n.*rechazar.*revocar/i.test(compactText),
    content_r7_signatures_license: /Firma del paciente\/representante/i.test(text) && /Firma del m[eé]dico/i.test(text) && /Matr[ií]cula: MP 63905 MN 116564/i.test(text),
    content_r8_hc_copy_access: /historia cl[ií]nica.*solicitar copia o acceso/i.test(compactText),
    content_anesthesia_blood_no_guarantee: /hemoderivados/i.test(text) && /anestesia general/i.test(text) && /no se me ha garantizado un resultado determinado/i.test(compactText),
    content_no_placeholders: !/\[(?:nivel|nivel\/es|completar)[^\]]*\]|Completar|nivel\/es y lado|nivel y lado/i.test(text),
    content_no_forbidden_open_phrases: !/\b(si corresponde|cuando corresponda|cuando correspond[ií]a|seg[uú]n corresponda|si aplica|eventual(?:mente)?|t[eé]cnica est[aá]ndar)\b/i.test(text),
  };
  const failures = Object.entries(checks).filter(([, ok]) => !ok).map(([key]) => key);
  const result = { ok: failures.length === 0, checks, manifest: canal.manifest, file: canal.file, visual_files: generated.map((item) => item.file) };
  console.log(JSON.stringify(result, null, 2));
  if (failures.length) process.exit(1);
}

main();
