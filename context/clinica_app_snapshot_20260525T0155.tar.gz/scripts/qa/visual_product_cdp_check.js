const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..', '..');
const url = 'http://127.0.0.1:4317/app/product.html';
const outDir = path.join(root, 'qa', 'screenshots');
const reportPath = path.join(root, 'qa', 'approval_gates', 'cli_app_product_visual_cdp_2026-05-19.json');

fs.mkdirSync(outDir, { recursive: true });

async function getTarget() {
  let targets;
  try {
    const response = await fetch('http://127.0.0.1:9223/json/list');
    if (!response.ok) {
      throw new Error(`HTTP ${response.status}`);
    }
    targets = await response.json();
  } catch (error) {
    throw new Error(`No se pudo leer CDP en 127.0.0.1:9223 (${error.message}). Abrir Chrome con --remote-debugging-port=9223.`);
  }
  const target = targets.find((item) => item.type === 'page' && item.url === 'about:blank')
    || targets.find((item) => item.type === 'page' && item.url.includes('127.0.0.1:4317'))
    || targets.find((item) => item.type === 'page');
  if (!target?.webSocketDebuggerUrl) throw new Error('No Chrome CDP page target found on 127.0.0.1:9223');
  return target.webSocketDebuggerUrl;
}

function connect(wsUrl) {
  const ws = new WebSocket(wsUrl);
  let nextId = 1;
  const pending = new Map();
  ws.onmessage = (event) => {
    const msg = JSON.parse(event.data);
    if (msg.id && pending.has(msg.id)) {
      const { resolve, reject } = pending.get(msg.id);
      pending.delete(msg.id);
      if (msg.error) reject(new Error(JSON.stringify(msg.error)));
      else resolve(msg.result || {});
    }
  };
  return new Promise((resolve, reject) => {
    ws.onerror = reject;
    ws.onopen = () => {
      resolve({
        send(method, params = {}) {
          const id = nextId++;
          ws.send(JSON.stringify({ id, method, params }));
          return new Promise((resolveCommand, rejectCommand) => pending.set(id, { resolve: resolveCommand, reject: rejectCommand }));
        },
        close() {
          ws.close();
        }
      });
    };
  });
}

async function waitForReady(cdp) {
  const expr = `(() => {
    const family = document.querySelector('#familySelect');
    const legal = document.querySelectorAll('#legalGate li');
    const doc = document.querySelector('#document');
    return Boolean(family && family.options.length >= 10 && legal.length >= 1 && doc && doc.innerText.length > 200);
  })()`;
  for (let i = 0; i < 40; i += 1) {
    const result = await cdp.send('Runtime.evaluate', { expression: expr, returnByValue: true });
    if (result.result?.value) return;
    await new Promise((resolve) => setTimeout(resolve, 250));
  }
  throw new Error('Product UI did not become ready');
}

async function runViewport(cdp, name, metrics) {
  await cdp.send('Emulation.setDeviceMetricsOverride', metrics);
  await cdp.send('Page.navigate', { url });
  await new Promise((resolve) => setTimeout(resolve, 1000));
  await waitForReady(cdp);
  const evalResult = await cdp.send('Runtime.evaluate', {
    returnByValue: true,
    expression: `(() => {
      const doc = document.querySelector('#document');
      const side = document.querySelector('.right');
      const family = document.querySelector('#familySelect');
      const legal = document.querySelectorAll('#legalGate li');
      const missing = document.querySelectorAll('#missing li');
      const body = document.body;
      const viewportWidth = window.innerWidth;
      return {
        title: document.title,
        viewportWidth,
        scrollWidth: Math.max(body.scrollWidth, document.documentElement.scrollWidth),
        familyOptions: family ? family.options.length : 0,
        legalItems: legal.length,
        missingItems: missing.length,
        documentChars: doc ? doc.innerText.length : 0,
        hasClinicalOutput: doc ? /Historia clínica|Motivo de ingreso|Paciente/.test(doc.innerText) : false,
        hasSidePanel: side ? side.getBoundingClientRect().width > 0 : false,
        noHorizontalOverflow: Math.max(body.scrollWidth, document.documentElement.scrollWidth) <= viewportWidth + 8
      };
    })()`
  });
  const screenshot = await cdp.send('Page.captureScreenshot', { format: 'png', captureBeyondViewport: false });
  const screenshotPath = path.join(outDir, `cli_app_product_${name}_2026-05-19.png`);
  fs.writeFileSync(screenshotPath, Buffer.from(screenshot.data, 'base64'));
  return { name, screenshot: screenshotPath, ...evalResult.result.value };
}

async function main() {
  if (typeof WebSocket === 'undefined') {
    throw new Error('WebSocket global no disponible en Node actual. Ejecutar con Node que incluya WebSocket global o inyectarlo antes de correr el script.');
  }
  const cdp = await connect(await getTarget());
  try {
    await cdp.send('Page.enable');
    await cdp.send('Runtime.enable');
    const desktop = await runViewport(cdp, 'desktop', { width: 1440, height: 1050, deviceScaleFactor: 1, mobile: false });
    const mobile = await runViewport(cdp, 'mobile', { width: 390, height: 844, deviceScaleFactor: 2, mobile: true });
    const report = {
      generated_at: new Date().toISOString(),
      url,
      status: 'ok',
      checks: [desktop, mobile]
    };
    const failures = report.checks.flatMap((check) => {
      const failed = [];
      if (check.familyOptions < 10) failed.push(`${check.name}:familyOptions`);
      if (check.legalItems < 1) failed.push(`${check.name}:legalItems`);
      if (check.documentChars < 200) failed.push(`${check.name}:documentChars`);
      if (!check.hasClinicalOutput) failed.push(`${check.name}:clinicalOutput`);
      if (!check.hasSidePanel) failed.push(`${check.name}:sidePanel`);
      if (!check.noHorizontalOverflow) failed.push(`${check.name}:horizontalOverflow`);
      return failed;
    });
    if (failures.length) {
      report.status = 'failed';
      report.failures = failures;
    }
    fs.writeFileSync(reportPath, JSON.stringify(report, null, 2) + '\n');
    console.log(JSON.stringify(report, null, 2));
    if (failures.length) process.exit(1);
  } finally {
    cdp.close();
  }
}

main().catch((error) => {
  console.error(error.stack || String(error));
  process.exit(1);
});
