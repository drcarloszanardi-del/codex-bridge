#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const APP_ROOT = path.resolve(__dirname, '..', '..');
const BANK_DIR = path.join(APP_ROOT, 'data', 'derived', 'pathology_templates');
const LEGACY_REGISTRY = path.join(APP_ROOT, 'data', 'derived', 'template_mothers', 'template_mother_registry_2026-05-19.json');
const QA_DIR = path.join(APP_ROOT, 'qa', 'approval_gates');

function latestBank() {
  const files = fs.readdirSync(BANK_DIR)
    .filter((name) => /^pathology_template_bank_\d{4}-\d{2}-\d{2}\.json$/.test(name))
    .sort();
  if (!files.length) throw new Error('No hay banco de plantillas por patología.');
  return path.join(BANK_DIR, files[files.length - 1]);
}

function assert(ok, message, failures) {
  if (!ok) failures.push(message);
}

function main() {
  const bankPath = latestBank();
  const bank = JSON.parse(fs.readFileSync(bankPath, 'utf8'));
  const legacy = JSON.parse(fs.readFileSync(LEGACY_REGISTRY, 'utf8'));
  const families = bank.families || {};
  const failures = [];
  const required = [
    'columna_lumbar_hernia_disco',
    'columna_lumbar_canal_estrecho',
    'columna_lumbar_fijacion_transpedicular',
    'columna_cervical_laminoplastia',
    'columna_cervical_disco_fusion',
    'columna_vertebroplastia',
    'tumor_meningioma',
    'tumor_glioma',
    'vascular_aneurisma',
    'malformacion_chiari',
    'trauma_craneal',
    'otros_valvulas_hidrocefalia',
  ];
  assert(bank.candidate_total >= 3000, `candidate_total bajo: ${bank.candidate_total}`, failures);
  assert(bank.sampled_total >= 500, `sampled_total bajo: ${bank.sampled_total}`, failures);
  assert(bank.family_count >= 35, `family_count bajo: ${bank.family_count}`, failures);
  for (const id of required) assert(Boolean(families[id]), `familia requerida ausente: ${id}`, failures);
  assert(legacy.run_id === bank.run_id, 'registro legacy no apunta al banco nuevo', failures);

  const familyFailures = [];
  for (const [id, family] of Object.entries(families)) {
    const mother = family.mother_template || {};
    const profile = mother.clinical_profile || {};
    if (!family.label || !family.classifier_terms?.length) familyFailures.push(`${id}: falta label o classifier_terms`);
    if (!profile.indication || !profile.procedure || !profile.diagnosis) familyFailures.push(`${id}: perfil clínico incompleto`);
    if (!Array.isArray(profile.symptoms) || !profile.symptoms.length) familyFailures.push(`${id}: sin síntomas/signos`);
    if (!mother.historia_clinica_template?.visible_sections?.length) familyFailures.push(`${id}: sin plantilla HC`);
    if (!mother.parte_quirurgico_template?.operative_sequence?.length) familyFailures.push(`${id}: sin secuencia de parte`);
    if (!mother.medico_legal_tamiz?.length) familyFailures.push(`${id}: sin tamiz médico-legal`);
  }
  failures.push(...familyFailures.slice(0, 12));

  const privacyProbe = JSON.stringify({
    families: bank.families,
    extraction_errors: bank.extraction_errors,
  });
  const privacyHits = [
    /Historia Clinica-Parte Quirurgico [A-ZÁÉÍÓÚÑ][a-záéíóúñ]+/i,
    /rel_path|abs_path|filename|file_name/i,
  ].filter((rx) => rx.test(privacyProbe)).map(String);
  assert(privacyHits.length === 0, `posible fuga de nombre/ruta de archivo: ${privacyHits.join(', ')}`, failures);

  const dangerousVisible = /\by\/o\b|\bradiculalgia\b|cuando corresponda|si corresponde|seg[uú]n corresponda|si aplica/i;
  const dangerousFamilies = Object.entries(families)
    .filter(([, family]) => dangerousVisible.test(JSON.stringify(family.mother_template?.clinical_profile || {})))
    .map(([id]) => id);
  assert(dangerousFamilies.length === 0, `lenguaje prohibido en perfiles: ${dangerousFamilies.slice(0, 8).join(', ')}`, failures);

  const result = {
    ok: failures.length === 0,
    bank_path: bankPath,
    legacy_registry: LEGACY_REGISTRY,
    candidate_total: bank.candidate_total,
    sampled_total: bank.sampled_total,
    family_count: bank.family_count,
    required_present: required.filter((id) => families[id]).length,
    privacy_mode: bank.privacy_mode,
    failures,
  };
  const outPath = path.join(QA_DIR, `pathology_template_bank_validation_${new Date().toISOString().slice(0, 10)}.json`);
  fs.writeFileSync(outPath, JSON.stringify(result, null, 2));
  console.log(JSON.stringify(result, null, 2));
  if (failures.length) process.exit(1);
}

main();
