#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
NODE_BIN="${OPENCLAW_NODE:-/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node}"
LOG_DIR="${APP_ROOT}/logs"
STATE_DIR="${APP_ROOT}/state"

mkdir -p "${LOG_DIR}" "${STATE_DIR}"

{
  echo "=== $(date -u +%Y-%m-%dT%H:%M:%SZ) clinical full nightly ==="
  "${NODE_BIN}" "${APP_ROOT}/scripts/qa/run_clinica_core_qa.js" --full
  "${NODE_BIN}" "${APP_ROOT}/scripts/build_cli_app_candidate_manifest.js"
  date -u +%Y-%m-%dT%H:%M:%SZ > "${STATE_DIR}/clinical_full_nightly_last_ok.txt"
} >> "${LOG_DIR}/clinical_full_nightly.log" 2>&1
