#!/usr/bin/env node
const fs = require('fs');
const os = require('os');
const path = require('path');
const { execFileSync, spawnSync } = require('child_process');

const APP_ROOT = path.resolve(__dirname, '..', '..');
const NODE = '/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node';
const PYTHON = '/Users/jarvis/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3';
const GUARD = path.join(APP_ROOT, 'scripts', 'jarvis', 'clinica_request_guard.js');
const WRAPPER = path.join(APP_ROOT, 'scripts', 'jarvis', 'clinica_generar_y_enviar.sh');

function runJson(command, args, allowFailure = false) {
  const proc = spawnSync(command, args, {
    cwd: APP_ROOT,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  if (!allowFailure && proc.status !== 0) {
    throw new Error(`Command failed: ${command} ${args.join(' ')}\nSTDOUT:\n${proc.stdout}\nSTDERR:\n${proc.stderr}`);
  }
  const raw = (proc.stdout || proc.stderr || '').trim();
  return raw ? JSON.parse(raw) : {};
}

function pdfText(file) {
  return execFileSync(PYTHON, ['-c', `
from pypdf import PdfReader
import sys
r=PdfReader(sys.argv[1])
print("\\n".join((p.extract_text() or "") for p in r.pages))
  `, file], { encoding: 'utf8' });
}

function makeBadSession() {
  const file = path.join(os.tmpdir(), `clinica_bad_session_${Date.now()}.jsonl`);
  const record = {
    type: 'message',
    message: {
      role: 'assistant',
      content: [
        {
          type: 'toolCall',
          name: 'write',
          arguments: {
            path: '/Users/jarvis/.openclaw/workspace/clinica/historia_clinica_manual.md',
            content: '# Historia clínica\\n\\n## Motivo de ingreso\\nTexto manual',
          },
        },
        {
          type: 'text',
          text: '[[reply_to_current]] Historia clínica:\\n\\nMotivo de ingreso: texto manual.\\n\\nArchivo guardado en: /Users/jarvis/.openclaw/workspace/clinica/historia_clinica_manual.md',
        },
      ],
    },
  };
  fs.writeFileSync(file, `${JSON.stringify(record)}\n`);
  return file;
}

function main() {
  const requestGuard = runJson(NODE, [
    GUARD,
    '--request',
    'Necesito una historia clinica y un parte quirurgico de hernia L4-L5 izquierda.',
  ]);

  const badSession = makeBadSession();
  const badAudit = runJson(NODE, [GUARD, '--session', badSession]);

  const hc = runJson(WRAPPER, [
    '--request',
    'Historia clinica paciente Ramon Perez edad 61 años hernia discal posterolateral L4-L5 izquierda con dolor radicular izquierdo. Microdiscectomia tubular L4-L5 izquierda.',
    '--institution', 'clinica_centro',
  ]);
  const parte = runJson(WRAPPER, [
    '--request',
    'Parte quirurgico paciente Ramon Perez edad 61 años hernia discal posterolateral L4-L5 izquierda. Microdiscectomia tubular L4-L5 izquierda de 08:00 a 09:10. Ayudantes Dr Gomez.',
    '--institution', 'clinica_centro',
  ]);
  const consent = runJson(WRAPPER, [
    '--request',
    'Consentimiento informado de hernia de disco lumbar L4-L5 izquierda en Clinica Centro.',
    '--institution', 'clinica_centro',
  ]);

  const hcManifest = JSON.parse(fs.readFileSync(hc.manifest, 'utf8'));
  const parteManifest = JSON.parse(fs.readFileSync(parte.manifest, 'utf8'));
  const consentManifest = JSON.parse(fs.readFileSync(consent.manifest, 'utf8'));
  const consentText = pdfText(consent.file);

  const checks = {
    request_detected_as_clinical: requestGuard.clinical_document_request === true && requestGuard.direct_answer_allowed === false,
    bad_session_flagged: badAudit.ok === false && badAudit.violations.some((item) => item.kind === 'manual_clinical_file_write'),
    hc_via_app_manifest: hc.ok === true && /app\.product\.html via clinical_document_handoff/.test(hcManifest.generator || ''),
    parte_via_app_manifest: parte.ok === true && /app\.product\.html via clinical_document_handoff/.test(parteManifest.generator || ''),
    hc_file_exists: fs.existsSync(hc.file) && hc.file.includes('/exports/telegram_ready/'),
    parte_file_exists: fs.existsSync(parte.file) && parte.file.includes('/exports/telegram_ready/'),
    consent_without_patient_keeps_dotted_lines: consent.ok === true && /\.{8,}/.test(consentText),
    consent_via_clinical_bridge:
      consent.ok === true
      && consentManifest.artifact_type === 'consentimiento_pdf_telegram_ready'
      && String(consent.manifest || '').includes('/outbox/clinica_medicolegal/telegram_ready/'),
  };
  const failures = Object.entries(checks).filter(([, ok]) => !ok).map(([key]) => key);
  const result = {
    ok: failures.length === 0,
    failures,
    checks,
    artifacts: {
      hc: hc.file,
      hc_manifest: hc.manifest,
      parte: parte.file,
      parte_manifest: parte.manifest,
      consent: consent.file,
      consent_manifest: consent.manifest,
    },
  };
  console.log(JSON.stringify(result, null, 2));
  if (failures.length) process.exit(1);
}

main();
