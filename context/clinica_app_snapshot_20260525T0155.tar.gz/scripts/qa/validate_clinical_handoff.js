#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { execFileSync, spawnSync } = require('child_process');

const APP_ROOT = path.resolve(__dirname, '..', '..');
const NODE = process.env.OPENCLAW_NODE || '/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node';
const PYTHON = process.env.CLINICA_PYTHON || '/Users/jarvis/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3';
const HANDOFF = path.join(APP_ROOT, 'scripts', 'jarvis', 'clinical_document_handoff.js');

function run(args, allowFailure = false) {
  const proc = spawnSync(NODE, [HANDOFF, ...args], {
    cwd: APP_ROOT,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  if (!allowFailure && proc.status !== 0) {
    throw new Error(`${proc.stderr}\n${proc.stdout}`);
  }
  const output = (proc.stdout || proc.stderr).trim();
  return {
    status: proc.status,
    parsed: output ? JSON.parse(output) : {},
    stderr: proc.stderr,
    stdout: proc.stdout,
  };
}

function pdfText(file) {
  return execFileSync(PYTHON, ['-c', `
from pypdf import PdfReader
import sys
r=PdfReader(sys.argv[1])
print("\\n".join((p.extract_text() or "") for p in r.pages))
  `, file], { encoding: 'utf8' });
}

function main() {
  const common = [
    '--patient', 'Paciente QA',
    '--age', '61',
    '--date', '20/05/2026',
    '--start-time', '08:00',
    '--end-time', '09:10',
    '--assistants', 'Ayudante QA',
    '--institution', 'clinica_centro',
  ];
  const input = 'Paciente prueba con hernia discal posterolateral L4-L5 izquierda y dolor radicular izquierdo, sin déficit motor referido. Microdiscectomía tubular L4-L5 izquierda.';
  const hc = run([
    '--type', 'hc',
    '--family', 'lumbar_hdl',
    '--input', input,
    '--level', 'L4-L5',
    '--side', 'izquierda',
    ...common,
  ]).parsed;
  const parte = run([
    '--type', 'parte',
    '--family', 'lumbar_hdl',
    '--input', input,
    '--level', 'L4-L5',
    '--side', 'izquierda',
    ...common,
  ]).parsed;
  const radiculopathyNoHerniaHc = run([
    '--type', 'hc',
    '--family', 'lumbar_hdl',
    '--input', 'Paciente con radiculopatía L5 derecha, dolor lumbar mecánico y dolor radicular derecho. Descompresión radicular L4-L5 derecha.',
    '--patient', 'Paciente QA Radicular',
    '--age', '61',
    '--date', '20/05/2026',
    '--level', 'L4-L5',
    '--side', 'derecha',
    '--institution', 'la_pequena_familia',
  ]).parsed;
  const fixationParte = run([
    '--type', 'parte',
    '--family', 'lumbar_fijacion',
    '--input', 'Paciente de 32 años con canal estrecho lumbar L4-L5, listesis degenerativa inestable, clínica ciática invalidante bilateral y claudicación de la marcha a pocos metros. Se realizó fijación transpedicular circunferencial L4-L5.',
    '--patient', 'Paciente QA Fijacion',
    '--age', '32',
    '--date', '20/05/2026',
    '--start-time', '08:00',
    '--end-time', '09:30',
    '--assistants', 'Ayudante QA',
    '--level', 'L4-L5',
    '--institution', 'la_pequena_familia',
  ]).parsed;
  const degenerativeListesisHc = run([
    '--type', 'hc',
    '--family', 'columna_lumbar_espondilolistesis',
    '--input', 'Paciente con espondilolistesis degenerativa L4-L5, dolor lumbar mecánico y dolor radicular. Fijación instrumentada y artrodesis L4-L5.',
    '--patient', 'Paciente QA Degenerativa',
    '--age', '61',
    '--date', '20/05/2026',
    '--level', 'L4-L5',
    '--institution', 'la_pequena_familia',
  ]).parsed;
  const fixationConventionalParte = run([
    '--type', 'parte',
    '--family', 'lumbar_fijacion',
    '--input', 'Paciente con canal estrecho lumbar L4-L5 y listesis degenerativa inestable. Se realizó fijación transpedicular circunferencial L4-L5 por vía media convencional.',
    '--patient', 'Paciente QA Convencional',
    '--age', '32',
    '--date', '20/05/2026',
    '--start-time', '08:00',
    '--end-time', '09:30',
    '--assistants', 'Ayudante QA',
    '--level', 'L4-L5',
    '--institution', 'la_pequena_familia',
  ]).parsed;
  const fixationPlifPatchParte = run([
    '--type', 'parte',
    '--family', 'lumbar_fijacion',
    '--input', 'Paciente con patología degenerativa lumbar L4-L5 con inestabilidad y compromiso neural. Fijación instrumentada y artrodesis L4-L5 sin descompresión directa, con un PLIF; sustituto oseo, drill; parche de duramadre.',
    '--patient', 'Paciente QA Materiales',
    '--age', '32',
    '--date', '20/05/2026',
    '--start-time', '08:00',
    '--end-time', '09:30',
    '--assistants', 'Ayudante QA',
    '--level', 'L4-L5',
    '--institution', 'la_pequena_familia',
  ]).parsed;
  const consent = run([
    '--type', 'consent',
    '--slug', 'hernia_disco_lumbar',
    '--patient', 'Paciente QA',
    '--dni', '11.111.111',
    '--date', '20/05/2026',
    '--level', 'L4-L5 izquierda',
    '--team', 'Ayudante QA',
    '--institution', 'clinica_centro',
  ]).parsed;
  const blocked = run([
    '--type', 'hc',
    '--family', 'lumbar_hdl',
    '--input', 'Paciente prueba con hernia discal lumbar y dolor radicular.',
    '--patient', 'Paciente Bloqueo',
    '--date', '20/05/2026',
    '--institution', 'clinica_centro',
  ], true);

  const hcManifest = JSON.parse(fs.readFileSync(hc.manifest, 'utf8'));
  const parteManifest = JSON.parse(fs.readFileSync(parte.manifest, 'utf8'));
  const fixationManifest = JSON.parse(fs.readFileSync(fixationParte.manifest, 'utf8'));
  const hcText = pdfText(hc.file);
  const parteText = pdfText(parte.file);
  const radiculopathyNoHerniaText = pdfText(radiculopathyNoHerniaHc.file);
  const fixationText = pdfText(fixationParte.file);
  const degenerativeListesisText = pdfText(degenerativeListesisHc.file);
  const fixationConventionalText = pdfText(fixationConventionalParte.file);
  const fixationPlifPatchText = pdfText(fixationPlifPatchParte.file);
  const consentText = pdfText(consent.file);
  const fixationDiagnosisLine = fixationText.split(/\n/).find((line) => /diagn[oó]stico/i.test(line)) || '';
  const plifPatchCloseIdx = fixationPlifPatchText.indexOf('Cierre por planos');
  const fixationHemostasisIdx = fixationPlifPatchText.search(/Se realiz[oó]\s+hemostasia por planos/i);
  const fixationCountIdx = fixationPlifPatchText.search(/Se efectu[oó]\s+recuento de gasas/i);
  const fixationCloseIdx = fixationPlifPatchText.indexOf('Cierre por planos');
  const fixationPostCloseText = fixationCloseIdx > -1 ? fixationPlifPatchText.slice(fixationCloseIdx) : '';
  const forbidden = /\bradiculalgia\b|\by\/o\b|si corresponde|cuando corresponda|seg[uú]n corresponda|si aplica|eventual|Relato de origen|Trazabilidad cl[ií]nica|nivel informado|lateralidad informada|validar eventos|validar hallazgos|validar p[eé]rdida/i;
  const checks = {
    hc_ok: hc.ok === true && ['APTO_PARA_ENVIO', 'APTO_CON_OBSERVACIONES'].includes(hc.validation_status),
    parte_ok: parte.ok === true && ['APTO_PARA_ENVIO', 'APTO_CON_OBSERVACIONES'].includes(parte.validation_status),
    fixation_parte_ok: fixationParte.ok === true && ['APTO_PARA_ENVIO', 'APTO_CON_OBSERVACIONES'].includes(fixationParte.validation_status),
    consent_delegated_hard_gate_ok: consent.ok === true && consent.validation_status === 'APTO_PARA_ENVIO',
    manifests_exist: fs.existsSync(hc.manifest) && fs.existsSync(parte.manifest) && fs.existsSync(consent.manifest),
    app_source_locked: /product\.html/.test(hcManifest.source) && /product\.html/.test(parteManifest.source),
    generated_by_app_not_free_text: hcManifest.constraints.generated_by_app_not_by_jarvis_free_text === true && parteManifest.constraints.generated_by_app_not_by_jarvis_free_text === true,
    medico_legal_check_required: hcManifest.constraints.medico_legal_check_required === true && parteManifest.constraints.medico_legal_check_required === true,
    red_blocks_delivery: hcManifest.constraints.red_blocks_delivery === true && parteManifest.constraints.red_blocks_delivery === true,
    hc_root_side_level_ok: /radiculopatía L5 izquierda/i.test(hcText) && /L4-L5 izquierda/i.test(hcText),
    hc_radiculopathy_without_hernia_not_converted: /radiculopatía L5 derecha/i.test(radiculopathyNoHerniaText) && /L4-L5/i.test(radiculopathyNoHerniaText) && !/hernia|posterolateral|extrusi[oó]n|fragmento discal|fragmento herniado/i.test(radiculopathyNoHerniaText),
    hc_no_unsolicited_motor: !/debilidad|dorsiflexión|hallux|marcha en talones|reflejo/i.test(hcText),
    hc_no_forbidden: !forbidden.test(hcText) && !/cuadro compatible|ra[ií]z pasante|ra[ií]z saliente/i.test(hcText),
    parte_has_sequence: /Paciente en decúbito prono/i.test(parteText) && /Marcación radioscópica del\s+nivel L4-L5/i.test(parteText) && /Incisión cutánea paramediana izquierda/i.test(parteText) && /Hemostasia/i.test(parteText) && /Cierre/i.test(parteText),
    parte_no_forbidden: !forbidden.test(parteText) && !/salvo contraindicación|cuando correspond|L4-L5\s+L4-L5/i.test(parteText),
    fixation_source_locked: /product\.html/.test(fixationManifest.source),
    fixation_no_placeholder_side: !forbidden.test(fixationText) && !/lateralidad informada|validar p[eé]rdida|<span/i.test(fixationText),
    fixation_diagnosis_line_clean: /patolog[ií]a degenerativa lumbar L4-L5 con inestabilidad segmentaria/i.test(fixationDiagnosisLine) && !/indicaci[oó]n|descompresi[oó]n|instrumentaci[oó]n|artrodesis/i.test(fixationDiagnosisLine),
    fixation_no_unsolicited_direct_decompression: /Operación:\s*fijación instrumentada y artrodesis lumbar L4-L5/i.test(fixationText) && !/Operación:[^\n.]*descompresi[oó]n/i.test(fixationText) && !/Se efectúa descompresión neural mediante|laminectom[ií]a\/hemilaminectom[ií]a|flavectom[ií]a|liberaci[oó]n de recesos|identificando y protegiendo saco dural|adecuada liberaci[oó]n neural|ausencia de compresi[oó]n residual/i.test(fixationText),
    degenerative_spondylolisthesis_not_istmica: /espondilolistesis degenerativa/i.test(degenerativeListesisText) && !/degenerativa o [íi]stmica|espondilolistesis [íi]stmica/i.test(degenerativeListesisText),
    fixation_plif_patch_clean_and_ordered: /Operación:\s*fijación instrumentada y artrodesis lumbar L4-L5/i.test(fixationPlifPatchText) && /caja PLIF/i.test(fixationPlifPatchText) && (fixationPlifPatchText.match(/\bPLIF\b/g) || []).length <= 1 && /sustituto óseo|sustituto oseo/i.test(fixationPlifPatchText) && !/Implantes\/materiales utilizados:[\s\S]{0,160}PLIF|con un PLIF|drill|parche de\s+duramadre/i.test(fixationPlifPatchText) && plifPatchCloseIdx > -1 && !/\.\./.test(fixationPlifPatchText) && !/adecuada liberaci[oó]n neural|ausencia de compresi[oó]n residual|Se efectúa descompresión neural mediante|laminectom[ií]a\/hemilaminectom[ií]a|flavectom[ií]a|liberaci[oó]n de recesos/i.test(fixationPlifPatchText),
    fixation_hemostasis_count_before_closure: fixationHemostasisIdx > -1 && fixationCountIdx > -1 && fixationCloseIdx > -1 && fixationHemostasisIdx < fixationCountIdx && fixationCountIdx < fixationCloseIdx && !/hemostasia por planos|recuento de gasas/i.test(fixationPostCloseText),
    fixation_default_uses_miss_wiltse: /vía paravertebral de Wiltse|via paravertebral de Wiltse/i.test(fixationText) && /miniinvasivo/i.test(fixationText) && !/abordaje posterior mediano/i.test(fixationText),
    fixation_conventional_only_when_requested: /abordaje posterior mediano por planos/i.test(fixationConventionalText),
    consent_text_ok: /CONSENTIMIENTO INFORMADO/i.test(consentText) && /Matr[ií]cula: MP 63905 MN 116564/i.test(consentText),
    incomplete_case_blocked: blocked.status !== 0 && blocked.parsed.validation_status === 'BLOQUEADO_NO_ENVIAR',
  };
  const failures = Object.entries(checks).filter(([, ok]) => !ok).map(([key]) => key);
  const result = {
    ok: failures.length === 0,
    checks,
    files: { hc: hc.file, parte: parte.file, radiculopathyNoHerniaHc: radiculopathyNoHerniaHc.file, fixationParte: fixationParte.file, degenerativeListesisHc: degenerativeListesisHc.file, fixationConventionalParte: fixationConventionalParte.file, fixationPlifPatchParte: fixationPlifPatchParte.file, consent: consent.file },
    manifests: { hc: hc.manifest, parte: parte.manifest, radiculopathyNoHerniaHc: radiculopathyNoHerniaHc.manifest, fixationParte: fixationParte.manifest, degenerativeListesisHc: degenerativeListesisHc.manifest, fixationConventionalParte: fixationConventionalParte.manifest, fixationPlifPatchParte: fixationPlifPatchParte.manifest, consent: consent.manifest },
    blocked_status: blocked.parsed.validation_status,
  };
  console.log(JSON.stringify(result, null, 2));
  if (failures.length) process.exit(1);
}

main();
