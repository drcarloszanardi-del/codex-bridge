#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const vm = require('vm');
const { spawnSync } = require('child_process');

const APP_ROOT = path.resolve(__dirname, '../..');
const HTML_PATH = path.join(APP_ROOT, 'app', 'product.html');
const QA_DIR = path.join(APP_ROOT, 'qa', 'approval_gates');
const OLLAMA = '/Users/jarvis/.openclaw/tools/bin/ollama';

class Element {
  constructor(id = '', tag = 'div') {
    this.id = id;
    this.tag = tag;
    this.value = '';
    this.dataset = {};
    this.children = [];
    this.options = [];
    this.listeners = {};
    this._innerHTML = '';
    this._textContent = '';
    this.classList = {
      values: new Set(),
      add: (...names) => names.forEach((name) => this.classList.values.add(name)),
      remove: (...names) => names.forEach((name) => this.classList.values.delete(name)),
      contains: (name) => this.classList.values.has(name)
    };
  }

  set innerHTML(value) {
    this._innerHTML = String(value || '');
    if (this.tag === 'select') {
      this.options = [...this._innerHTML.matchAll(/<option[^>]*value="([^"]*)"[^>]*>(.*?)<\/option>/g)]
        .map((match) => ({ value: unescapeHtml(match[1]), textContent: stripTags(match[2]) }));
      if (!this.options.some((option) => option.value === this.value)) this.value = this.options[0]?.value || '';
    }
  }

  get innerHTML() {
    return this._innerHTML;
  }

  set textContent(value) {
    this._textContent = String(value || '');
  }

  get textContent() {
    return this._textContent || stripTags(this._innerHTML);
  }

  get innerText() {
    return this.textContent;
  }

  addEventListener(type, handler) {
    this.listeners[type] = handler;
  }

  click() {
    if (this.listeners.click) this.listeners.click({ target: this });
  }
}

function stripTags(value) {
  return String(value || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function unescapeHtml(value) {
  return String(value || '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
}

function normalize(value) {
  return String(value || '')
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function makeDocument() {
  const ids = [
    'input', 'familySelect', 'patient', 'age', 'dateInput', 'startTimeInput', 'endTimeInput',
    'assistants', 'exceptions', 'institution', 'surgeon', 'generate', 'copy', 'exportHtml',
    'printDoc', 'correctionTarget', 'correction', 'applyCorrection', 'brand', 'caseMeta',
    'docTitle', 'document', 'caseStatus', 'templateMother', 'colloquialMap', 'factBoundary',
    'missing', 'coverage', 'legalScore', 'legalGate', 'legalUpdatePolicy', 'legalSourceDocs',
    'reviewQueue', 'correctionLog'
  ];
  const selectIds = new Set(['familySelect', 'institution', 'correctionTarget']);
  const elements = new Map(ids.map((id) => [id, new Element(id, selectIds.has(id) ? 'select' : 'div')]));
  const tabs = ['hc', 'parte', 'consent', 'evolucion', 'faltantes'].map((tab) => {
    const el = new Element(`tab-${tab}`, 'button');
    el.dataset.tab = tab;
    if (tab === 'hc') el.classList.add('active');
    return el;
  });

  elements.get('input').value = 'Paciente QA con patología neuroquirúrgica.';
  elements.get('familySelect').innerHTML = '<option value="auto">Detectar automáticamente</option>';
  elements.get('familySelect').value = 'auto';
  elements.get('patient').value = 'Paciente Auditoria';
  elements.get('age').value = '61';
  elements.get('dateInput').value = '20/05/2026';
  elements.get('startTimeInput').value = '08:00';
  elements.get('endTimeInput').value = '09:20';
  elements.get('assistants').value = 'Dr. Ayudante QA';
  elements.get('exceptions').value = '';
  elements.get('institution').innerHTML = '<option value="Clínica Centro">Clínica Centro</option><option value="La Pequeña Familia">La Pequeña Familia</option><option value="HIGA Junín">HIGA Junín</option>';
  elements.get('institution').value = 'Clínica Centro';
  elements.get('surgeon').value = 'Carlos Zanardi';
  elements.get('correctionTarget').innerHTML = '<option value="global">Todo el paquete</option><option value="hc">Historia clínica</option><option value="parte">Parte quirúrgico</option><option value="evolucion">Evolución</option>';
  elements.get('correctionTarget').value = 'global';

  return {
    getElementById(id) {
      if (!elements.has(id)) elements.set(id, new Element(id));
      return elements.get(id);
    },
    querySelectorAll(selector) {
      return selector === '.tab' ? tabs : [];
    },
    _elements: elements,
    _tabs: tabs
  };
}

function productScript() {
  const html = fs.readFileSync(HTML_PATH, 'utf8');
  const match = html.match(/<script>([\s\S]*?)<\/script>\s*<\/body>/);
  if (!match) throw new Error('No se encontró script principal en app/product.html');
  return match[1];
}

function localFetch(url) {
  const clean = String(url || '').replace(/^\.\.\//, '');
  const filePath = path.join(APP_ROOT, clean);
  return Promise.resolve({
    ok: fs.existsSync(filePath),
    status: fs.existsSync(filePath) ? 200 : 404,
    json: async () => JSON.parse(fs.readFileSync(filePath, 'utf8'))
  });
}

async function bootRenderer() {
  const document = makeDocument();
  const context = {
    document,
    navigator: { clipboard: { writeText: async () => undefined } },
    fetch: localFetch,
    setTimeout: () => undefined,
    console,
    Date,
    Error,
    String,
    Boolean,
    Number,
    RegExp
  };
  vm.runInNewContext(productScript(), context, { filename: HTML_PATH });
  await new Promise((resolve) => setTimeout(resolve, 0));
  await new Promise((resolve) => setTimeout(resolve, 0));
  return document;
}

const GLOBAL_RULES = [
  ['radiculalgia', /\bradiculalgia\b/i],
  ['y_o', /\by\/o\b/i],
  ['si_corresponde', /\bsi correspond(?:e|en|a|iera|iese)\b/i],
  ['cuando_corresponda', /\bcuando correspond(?:a|e|ia|ía|iera|iese)\b/i],
  ['segun_corresponda', /\bseg[uú]n corresponda\b/i],
  ['si_aplica', /\bsi aplica\b/i],
  ['eventual_como_relleno', /\beventual(?:mente)?\b/i],
  ['placeholder_generico', /\bnivel informado\b|\blateralidad informada\b|\binformad[oa] por el m[eé]dico\b|\bvalidar\b|\[completar\]|\bcompletar\b/i],
  ['tratado_anatomico_en_hc', /hernia posterolateral\/central habitual|ra[ií]z pasante|ra[ií]z saliente/i],
  ['canal_redundante', /canal estrecho lumbar[^.]{0,140}compromiso del canal|compromiso del canal y recesos laterales/i],
  ['diagnostico_con_indicacion', /Diagn[oó]stico:\s*[^.]{0,180}\b(con indicaci[oó]n|criterio de|se indica|indicaci[oó]n de)\b/i],
  ['doble_punto_o_punto', /\.\.|,,|;;/],
  ['formula_cervical_vaga', /mielopat[ií]a o compromiso neurol[oó]gico|signos piramidales si|cuadro cl[ií]nico compatible con trastorno/i]
];

const DIRECT_DECOMPRESSION_RX = /Operaci[oó]n:[^\n.]*descompresi[oó]n|Se efect[uú]a descompresi[oó]n neural mediante|laminectom[ií]a\/hemilaminectom[ií]a|flavectom[ií]a|liberaci[oó]n de recesos|identificando y protegiendo saco dural|adecuada liberaci[oó]n neural|ausencia de compresi[oó]n residual/i;
const HERNIA_INFERENCE_RX = /\bhernia\b|posterolateral|extrusi[oó]n|protrusi[oó]n|fragmento discal|fragmento herniado|microdiscectom[ií]a/i;
const MOTOR_RX = /\bdebilidad|paresia|dorsiflexi[oó]n|hallux|marcha en talones|reflejo rotuliano|reflejo aquiliano|flexi[oó]n plantar\b/i;

const SCENARIOS = [
  {
    id: 'lumbar_radiculopatia_l5_derecha_sin_hernia',
    family: 'lumbar_hdl',
    tabs: ['hc', 'parte', 'consent'],
    input: 'Paciente con radiculopatía L5 derecha, dolor lumbar mecánico y dolor radicular derecho. Descompresión radicular L4-L5 derecha.',
    checks: ['no_hernia_if_not_stated', 'no_motor_in_hc_if_not_stated']
  },
  {
    id: 'lumbar_hernia_posterolateral_explicita',
    family: 'lumbar_hdl',
    tabs: ['hc', 'parte'],
    input: 'Paciente con hernia discal posterolateral L4-L5 izquierda y dolor radicular izquierdo. Microdiscectomía tubular L4-L5 izquierda.',
    checks: ['hernia_explicit_preserved', 'no_motor_in_hc_if_not_stated']
  },
  {
    id: 'lumbar_hernia_extraforaminal_modelo_correcto',
    family: 'lumbar_hdl',
    tabs: ['hc', 'parte'],
    input: 'Paciente con hernia discal extraforaminal L4-L5 derecha, dolor radicular derecho. RM con extrusión discal extraforaminal L4-L5 derecha. Microdiscectomía extraforaminal L4-L5 derecha.',
    checks: ['extraforaminal_model', 'no_motor_in_hc_if_not_stated']
  },
  {
    id: 'canal_estrecho_lumbar_no_redundante',
    family: 'lumbar_fijacion',
    tabs: ['hc'],
    input: 'Paciente con canal estrecho lumbar L4-L5, claudicación neurógena y dolor radicular. Recalibraje lumbar L4-L5.',
    checks: ['stenosis_study_clean']
  },
  {
    id: 'fijacion_lumbar_sin_descompresion_directa',
    family: 'lumbar_fijacion',
    tabs: ['parte'],
    input: 'Paciente con patología degenerativa lumbar L4-L5 con inestabilidad y compromiso neural. Fijación instrumentada y artrodesis L4-L5 sin descompresión directa.',
    checks: ['no_direct_decompression_if_excluded', 'hemostasis_count_before_closure']
  },
  {
    id: 'fijacion_lumbar_con_descompresion_explicita',
    family: 'lumbar_fijacion',
    tabs: ['parte'],
    input: 'Paciente con patología degenerativa lumbar L4-L5 con inestabilidad y compromiso neural. Se realizó descompresión neural, fijación instrumentada y artrodesis L4-L5.',
    checks: ['direct_decompression_if_explicit', 'hemostasis_count_before_closure']
  },
  {
    id: 'plif_patch_sin_descompresion_no_mal_ubicado',
    family: 'lumbar_fijacion',
    tabs: ['parte'],
    input: 'Paciente con patología degenerativa lumbar L4-L5 con inestabilidad y compromiso neural. Fijación instrumentada y artrodesis L4-L5 sin descompresión directa, con un PLIF; sustituto oseo, drill; parche de duramadre.',
    checks: ['plif_single_and_clean', 'no_direct_decompression_if_excluded', 'hemostasis_count_before_closure']
  },
  {
    id: 'espondilolistesis_degenerativa_no_istmica',
    family: 'columna_lumbar_espondilolistesis',
    tabs: ['hc'],
    input: 'Paciente con espondilolistesis degenerativa L4-L5, dolor lumbar mecánico y dolor radicular. Fijación instrumentada y artrodesis L4-L5.',
    checks: ['degenerative_not_istmic']
  },
  {
    id: 'espondilolistesis_istmica_no_degenerativa',
    family: 'columna_lumbar_espondilolistesis',
    tabs: ['hc'],
    input: 'Paciente con espondilolistesis ístmica L5-S1, dolor lumbar mecánico y dolor radicular. Fijación instrumentada y artrodesis L5-S1.',
    checks: ['istmic_not_degenerative']
  },
  {
    id: 'laminoplastia_cervical_sin_formula_vaga',
    family: 'cervical',
    tabs: ['hc', 'parte'],
    input: 'Paciente con canal estrecho cervical C3-C7, trastorno de la marcha, torpeza manual y parestesias. Laminoplastia cervical C3-C7.',
    checks: ['cervical_no_vague_formula']
  },
  {
    id: 'aneurisma_craneal_sin_columna_inventada',
    family: 'vascular_aneurismas_tvt',
    tabs: ['hc', 'parte'],
    input: 'Paciente con aneurisma cerebral de comunicante anterior, cefalea y criterio de clipado. Craneotomía pterional derecha y clipado microquirúrgico.',
    checks: ['no_spine_terms_if_cranial']
  },
  {
    id: 'tunel_carpiano_sin_columna_inventada',
    family: 'periferico_tunel_carpiano',
    tabs: ['hc', 'parte'],
    input: 'Paciente con síndrome de túnel carpiano derecho, parestesias nocturnas y respuesta insuficiente al tratamiento conservador. Liberación del nervio mediano derecho.',
    checks: ['no_spine_terms_if_peripheral']
  }
];

function render(document, scenario, tab) {
  const get = (id) => document.getElementById(id);
  get('input').value = scenario.input;
  get('patient').value = `Paciente Auditoria ${scenario.id}`;
  get('familySelect').value = scenario.family;
  if (get('familySelect').listeners.change) get('familySelect').listeners.change();
  const tabEl = document._tabs.find((item) => item.dataset.tab === tab);
  if (tabEl) tabEl.click();
  return stripTags(get('document').innerHTML);
}

function firstIndex(text, rx) {
  const match = text.match(rx);
  return match ? match.index : -1;
}

function snippet(text, rx) {
  const idx = firstIndex(text, rx);
  if (idx < 0) return '';
  return text.slice(Math.max(0, idx - 80), Math.min(text.length, idx + 160)).replace(/\s+/g, ' ').trim();
}

function runChecks(scenario, tab, text) {
  const failures = [];
  const normalizedText = normalize(text);

  for (const [id, rx] of GLOBAL_RULES) {
    if (rx.test(text)) failures.push({ rule: `global:${id}`, snippet: snippet(text, rx) });
  }

  if (scenario.checks.includes('no_hernia_if_not_stated') && HERNIA_INFERENCE_RX.test(text)) {
    failures.push({ rule: 'case:no_hernia_if_not_stated', snippet: snippet(text, HERNIA_INFERENCE_RX) });
  }
  if (scenario.checks.includes('hernia_explicit_preserved') && !/hernia discal|hernia de disco|fragmento discal|fragmento herniado/i.test(text)) {
    failures.push({ rule: 'case:hernia_explicit_not_preserved', snippet: text.slice(0, 220) });
  }
  if (scenario.checks.includes('extraforaminal_model')) {
    if (tab === 'hc') {
      if (!/radiculopat[ií]a L4 derecha/i.test(text) || !/hernia discal extraforaminal L4-L5 derecha/i.test(text)) {
        failures.push({ rule: 'case:extraforaminal_hc_root_or_hernia_missing', snippet: text.slice(0, 300) });
      }
    }
    if (tab === 'parte') {
      if (!/abordaje paravertebral[\s\S]{0,120}foraminal[\s\S]{0,80}extraforaminal/i.test(text) || !/ra[ií]z L4/i.test(text)) {
        failures.push({ rule: 'case:extraforaminal_parte_approach_missing', snippet: text.slice(0, 420) });
      }
      const badExtraforaminalTechnique = /espacio interlaminar|hemilaminotom[ií]a|flavectom[ií]a|hombro de la ra[ií]z|ra[ií]z pasante/i;
      if (badExtraforaminalTechnique.test(text)) {
        failures.push({ rule: 'case:extraforaminal_parte_interlaminar_pattern', snippet: snippet(text, badExtraforaminalTechnique) });
      }
    }
  }
  if (scenario.checks.includes('no_motor_in_hc_if_not_stated') && tab === 'hc' && MOTOR_RX.test(text)) {
    failures.push({ rule: 'case:motor_deficit_not_stated', snippet: snippet(text, MOTOR_RX) });
  }
  if (scenario.checks.includes('stenosis_study_clean')) {
    if (!/RM lumbar con estenosis de canal y recesos laterales en L4-L5/i.test(text)) {
      failures.push({ rule: 'case:stenosis_clean_sentence_missing', snippet: text.slice(0, 260) });
    }
  }
  if (scenario.checks.includes('no_direct_decompression_if_excluded') && DIRECT_DECOMPRESSION_RX.test(text)) {
    failures.push({ rule: 'case:no_direct_decompression_if_excluded', snippet: snippet(text, DIRECT_DECOMPRESSION_RX) });
  }
  if (scenario.checks.includes('direct_decompression_if_explicit') && !/Operaci[oó]n:\s*descompresi[oó]n neural/i.test(text)) {
    failures.push({ rule: 'case:direct_decompression_missing_when_explicit', snippet: text.slice(0, 260) });
  }
  if (scenario.checks.includes('hemostasis_count_before_closure')) {
    const hemostasis = firstIndex(text, /hemostasia por planos|Hemostasia completa/i);
    const count = firstIndex(text, /recuento de gasas/i);
    const close = firstIndex(text, /Cierre por planos|Cierre de músculo/i);
    if (hemostasis < 0 || count < 0 || close < 0 || !(hemostasis < count && count < close)) {
      failures.push({ rule: 'case:hemostasis_count_not_before_closure', snippet: text.slice(Math.max(0, close - 120), close + 200) });
    }
  }
  if (scenario.checks.includes('plif_single_and_clean')) {
    const plifCount = (text.match(/\bPLIF\b/g) || []).length;
    if (plifCount !== 1 || /Implantes\/materiales utilizados:[^.]*PLIF|con un PLIF|drill|parche de\s+duramadre/i.test(text)) {
      failures.push({ rule: 'case:plif_or_materials_not_clean', snippet: snippet(text, /PLIF|Implantes\/materiales|drill|parche de\s+duramadre/i) });
    }
  }
  if (scenario.checks.includes('degenerative_not_istmic')) {
    if (!/espondilolistesis degenerativa/i.test(text) || /degenerativa o [íi]stmica|espondilolistesis [íi]stmica/i.test(text)) {
      failures.push({ rule: 'case:degenerative_converted_to_istmic_or_ambiguous', snippet: snippet(text, /espondilolistesis[^.]{0,120}/i) });
    }
  }
  if (scenario.checks.includes('istmic_not_degenerative')) {
    if (!/espondilolistesis [íi]stmica/i.test(text) || /degenerativa o [íi]stmica|espondilolistesis degenerativa/i.test(text)) {
      failures.push({ rule: 'case:istmic_converted_to_degenerativa_or_ambiguous', snippet: snippet(text, /espondilolistesis[^.]{0,120}/i) });
    }
  }
  if (scenario.checks.includes('cervical_no_vague_formula') && /cuadro clínico compatible|signos piramidales|déficit motor o sensitivo|mielopatía o compromiso/i.test(text)) {
    failures.push({ rule: 'case:cervical_vague_formula', snippet: snippet(text, /cuadro clínico compatible|signos piramidales|déficit motor o sensitivo|mielopatía o compromiso/i) });
  }
  if (scenario.checks.includes('no_spine_terms_if_cranial') && /\bL4-L5|lumbar|radicular|ra[ií]z|canal estrecho|artrodesis|fijaci[oó]n instrumentada\b/i.test(text)) {
    failures.push({ rule: 'case:cranial_output_contains_spine_terms', snippet: snippet(text, /\bL4-L5|lumbar|radicular|ra[ií]z|canal estrecho|artrodesis|fijaci[oó]n instrumentada\b/i) });
  }
  if (scenario.checks.includes('no_spine_terms_if_peripheral') && /\bL4-L5|lumbar|canal estrecho|artrodesis|fijaci[oó]n instrumentada\b/i.test(text)) {
    failures.push({ rule: 'case:peripheral_output_contains_spine_terms', snippet: snippet(text, /\bL4-L5|lumbar|canal estrecho|artrodesis|fijaci[oó]n instrumentada\b/i) });
  }
  if (!normalizedText.includes(normalize('Paciente Auditoria'))) {
    failures.push({ rule: 'case:patient_not_reflected', snippet: text.slice(0, 180) });
  }
  return failures;
}

function ollamaStatus() {
  if (!fs.existsSync(OLLAMA)) return { available: false, reason: 'ollama_binary_missing' };
  const result = spawnSync(OLLAMA, ['list'], { encoding: 'utf8', timeout: 5000 });
  return {
    available: result.status === 0,
    models: result.status === 0 ? String(result.stdout || '').split('\n').slice(1).map((line) => line.trim().split(/\s+/)[0]).filter(Boolean) : [],
    reason: result.status === 0 ? '' : String(result.stderr || result.error?.message || '').slice(0, 200)
  };
}

function nowStamp() {
  return new Date().toISOString().replace(/[-:.]/g, '').slice(0, 15);
}

function markdown(payload) {
  const lines = [
    '# Clinical Inconsistency Audit',
    '',
    `Fecha: ${payload.generated_at}`,
    `Estado: ${payload.ok ? 'OK' : 'FALLA'}`,
    `Escenarios: ${payload.scenarios_count}`,
    `Documentos renderizados: ${payload.documents_count}`,
    `Ollama local: ${payload.ollama.available ? `disponible (${payload.ollama.models.join(', ') || 'sin modelos listados'})` : 'no disponible'}`,
    '',
    '## Fallas',
    ''
  ];
  if (!payload.failures.length) {
    lines.push('- Sin fallas detectadas.');
  } else {
    for (const failure of payload.failures) {
      lines.push(`- ${failure.scenario}/${failure.tab}: ${failure.rule}`);
      if (failure.snippet) lines.push(`  - ${failure.snippet}`);
    }
  }
  lines.push('', '## Alcance', '');
  lines.push('- Auditor local determinístico, sin API tokens.');
  lines.push('- Detecta inconsistencias de redacción clínica, inferencias no soportadas y secuencia operatoria básica.');
  lines.push('- Ollama se informa como disponible solo para prechequeos baratos; no es autoridad médico-legal final.');
  return lines.join('\n') + '\n';
}

async function main() {
  fs.mkdirSync(QA_DIR, { recursive: true });
  const document = await bootRenderer();
  const results = [];
  const failures = [];

  for (const scenario of SCENARIOS) {
    for (const tab of scenario.tabs) {
      const text = render(document, scenario, tab);
      const docFailures = runChecks(scenario, tab, text);
      const item = {
        scenario: scenario.id,
        family: scenario.family,
        tab,
        ok: docFailures.length === 0,
        chars: text.length,
        failures: docFailures
      };
      results.push(item);
      for (const failure of docFailures) {
        failures.push({ scenario: scenario.id, family: scenario.family, tab, ...failure });
      }
    }
  }

  const payload = {
    ok: failures.length === 0,
    generated_at: new Date().toISOString(),
    standard: 'clinical_inconsistency_audit_v1',
    product_html: HTML_PATH,
    scenarios_count: SCENARIOS.length,
    documents_count: results.length,
    ollama: ollamaStatus(),
    rules: {
      global: GLOBAL_RULES.map(([id]) => id),
      case_specific: [...new Set(SCENARIOS.flatMap((scenario) => scenario.checks))]
    },
    failures,
    results
  };
  const stamp = nowStamp();
  const jsonPath = path.join(QA_DIR, `clinical_inconsistency_audit_${stamp}.json`);
  const mdPath = path.join(QA_DIR, `clinical_inconsistency_audit_${stamp}.md`);
  const latestJson = path.join(QA_DIR, 'clinical_inconsistency_audit_latest.json');
  const latestMd = path.join(QA_DIR, 'clinical_inconsistency_audit_latest.md');
  fs.writeFileSync(jsonPath, JSON.stringify(payload, null, 2) + '\n');
  fs.writeFileSync(mdPath, markdown(payload));
  fs.copyFileSync(jsonPath, latestJson);
  fs.copyFileSync(mdPath, latestMd);
  console.log(JSON.stringify({
    ok: payload.ok,
    scenarios_count: payload.scenarios_count,
    documents_count: payload.documents_count,
    failures_count: failures.length,
    ollama: payload.ollama,
    report: mdPath,
    json: jsonPath,
    latest_report: latestMd,
    latest_json: latestJson,
    failures: failures.slice(0, 20)
  }, null, 2));
  if (!payload.ok) process.exit(1);
}

main().catch((err) => {
  console.error(err.stack || err.message);
  process.exit(1);
});
