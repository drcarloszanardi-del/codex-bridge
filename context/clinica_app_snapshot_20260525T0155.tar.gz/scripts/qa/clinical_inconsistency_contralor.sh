#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
NODE_BIN="${OPENCLAW_NODE:-/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node}"
INTERVAL_SECONDS="${CLINICA_INCONSISTENCY_INTERVAL_SECONDS:-7200}"
LOG_DIR="${APP_ROOT}/logs"
STATE_DIR="${APP_ROOT}/state"

mkdir -p "${LOG_DIR}" "${STATE_DIR}"
echo "$$" > "${STATE_DIR}/clinical_inconsistency_contralor.pid"

while true; do
  {
    echo "=== $(date -u +%Y-%m-%dT%H:%M:%SZ) clinical inconsistency contralor ==="
    "${NODE_BIN}" "${APP_ROOT}/scripts/qa/validate_clinical_inconsistency_audit.js"
    "${NODE_BIN}" "${APP_ROOT}/scripts/qa/validate_product_mode.js"
  } >> "${LOG_DIR}/clinical_inconsistency_contralor.log" 2>&1 || true
  sleep "${INTERVAL_SECONDS}"
done
