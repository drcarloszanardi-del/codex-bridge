const fs = require('fs');
const path = require('path');
const vm = require('vm');

const root = path.resolve(__dirname, '..', '..');
const htmlPath = path.join(root, 'app', 'product.html');

class Element {
  constructor(id = '', tag = 'div') {
    this.id = id;
    this.tag = tag;
    this.value = '';
    this.dataset = {};
    this.children = [];
    this.options = [];
    this.listeners = {};
    this._innerHTML = '';
    this._textContent = '';
    this.classList = {
      values: new Set(),
      add: (...names) => names.forEach((name) => this.classList.values.add(name)),
      remove: (...names) => names.forEach((name) => this.classList.values.delete(name)),
      contains: (name) => this.classList.values.has(name)
    };
  }

  set innerHTML(value) {
    this._innerHTML = String(value || '');
    if (this.tag === 'select') {
      this.options = [...this._innerHTML.matchAll(/<option[^>]*value="([^"]*)"[^>]*>(.*?)<\/option>/g)]
        .map((match) => ({ value: unescapeHtml(match[1]), textContent: stripTags(match[2]) }));
      if (!this.options.some((option) => option.value === this.value)) {
        this.value = this.options[0]?.value || '';
      }
    }
  }

  get innerHTML() {
    return this._innerHTML;
  }

  set textContent(value) {
    this._textContent = String(value || '');
  }

  get textContent() {
    return this._textContent || stripTags(this._innerHTML);
  }

  get innerText() {
    return this.textContent;
  }

  addEventListener(type, handler) {
    this.listeners[type] = handler;
  }

  click() {
    if (this.listeners.click) this.listeners.click({ target: this });
  }
}

function stripTags(value) {
  return String(value || '').replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ').trim();
}

function unescapeHtml(value) {
  return String(value || '')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'");
}

function makeDocument() {
  const ids = [
    'input',
    'familySelect',
    'patient',
    'age',
    'dateInput',
    'startTimeInput',
    'endTimeInput',
    'assistants',
    'exceptions',
    'institution',
    'surgeon',
    'generate',
    'copy',
    'exportHtml',
    'printDoc',
    'correctionTarget',
    'correction',
    'applyCorrection',
    'brand',
    'caseMeta',
    'docTitle',
    'document',
    'caseStatus',
    'templateMother',
    'familySelectHelp',
    'familySuggestionPanel',
    'colloquialMap',
    'factBoundary',
    'missing',
    'coverage',
    'legalScore',
    'legalGate',
    'legalUpdatePolicy',
    'legalSourceDocs',
    'reviewQueue',
    'correctionLog'
  ];
  const selectIds = new Set(['familySelect', 'institution', 'correctionTarget']);
  const elements = new Map(ids.map((id) => [id, new Element(id, selectIds.has(id) ? 'select' : 'div')]));
  const tabs = ['hc', 'parte', 'consent', 'evolucion', 'faltantes'].map((tab) => {
    const el = new Element(`tab-${tab}`, 'button');
    el.dataset.tab = tab;
    if (tab === 'hc') el.classList.add('active');
    return el;
  });

  elements.get('input').value = 'Paciente prueba con aneurisma cerebral tratado por clipado. Solicito historia clinica, parte quirurgico y evolucion postoperatoria.';
  elements.get('familySelect').innerHTML = '<option value="auto">Detectar automáticamente</option>';
  elements.get('familySelect').value = 'auto';
  elements.get('patient').value = 'Paciente QA';
  elements.get('age').value = '55';
  elements.get('dateInput').value = '2026-05-19';
  elements.get('startTimeInput').value = '08:30';
  elements.get('endTimeInput').value = '10:15';
  elements.get('assistants').value = 'Ayudante QA';
  elements.get('exceptions').value = '';
  elements.get('institution').innerHTML = '<option value="Clínica Centro">Clínica Centro</option><option value="Sanatorio Allende">Sanatorio Allende</option>';
  elements.get('institution').value = 'Clínica Centro';
  elements.get('surgeon').value = 'Carlos Zanardi';
  elements.get('correctionTarget').innerHTML = '<option value="global">Todo el paquete</option><option value="hc">Historia clínica</option><option value="parte">Parte quirúrgico</option><option value="evolucion">Evolución</option>';
  elements.get('correctionTarget').value = 'global';

  return {
    getElementById(id) {
      if (!elements.has(id)) elements.set(id, new Element(id));
      return elements.get(id);
    },
    querySelectorAll(selector) {
      return selector === '.tab' ? tabs : [];
    },
    _elements: elements,
    _tabs: tabs
  };
}

function loadScript() {
  const html = fs.readFileSync(htmlPath, 'utf8');
  const match = html.match(/<script>([\s\S]*?)<\/script>\s*<\/body>/);
  if (!match) throw new Error('No product script found');
  return match[1];
}

function localFetch(url) {
  const clean = String(url).replace(/^\.\.\//, '');
  const filePath = path.join(root, clean);
  return Promise.resolve({
    ok: fs.existsSync(filePath),
    status: fs.existsSync(filePath) ? 200 : 404,
    json: async () => JSON.parse(fs.readFileSync(filePath, 'utf8'))
  });
}

async function main() {
  const sourceHtml = fs.readFileSync(htmlPath, 'utf8');
  const document = makeDocument();
  const context = {
    document,
    navigator: { clipboard: { writeText: async () => undefined } },
    fetch: localFetch,
    setTimeout: () => undefined,
    console,
    Date,
    Error,
    String,
    Boolean,
    Number,
    RegExp
  };
  vm.runInNewContext(loadScript(), context, { filename: htmlPath });
  await new Promise((resolve) => setTimeout(resolve, 0));
  await new Promise((resolve) => setTimeout(resolve, 0));

  const get = (id) => document.getElementById(id);
  get('familySelect').value = 'vascular_aneurismas_tvt';
  get('familySelect').listeners.change();
  get('correction').value = 'Agregar que se informó a familiares y que no hubo complicaciones intraoperatorias.';
  get('applyCorrection').click();

  const documentHtml = get('document').innerHTML;
  const caseHtml = get('caseStatus').innerHTML;
  const coverageHtml = get('coverage').innerHTML;
  const forbiddenVisible = /si corresponde|si corresponden|cuando correspond|seg[uú]n corresponda|si aplica|si existe|si fue utilizado|eventual|mielopat[ií]a o compromiso neurol[oó]gico|cuadro cl[ií]nico compatible con\s+trastorno|d[eé]ficit motor o sensitivo|signos piramidales/i;
  const visibleSamples = [];
  const consentFormatSamples = [];
  const samplesByKey = {};

  function renderVisibleSample(family, input, tab, key = null) {
    get('input').value = input;
    get('familySelect').value = family;
    get('familySelect').listeners.change();
    const tabEl = document._tabs.find((item) => item.dataset.tab === tab);
    if (tabEl) tabEl.click();
    const text = stripTags(get('document').innerHTML);
    visibleSamples.push(text);
    samplesByKey[key || `${family}:${tab}`] = text;
  }

  function renderConsentFormatSample(family, input) {
    get('input').value = input;
    get('familySelect').value = family;
    get('familySelect').listeners.change();
    const tabEl = document._tabs.find((item) => item.dataset.tab === 'consent');
    if (tabEl) tabEl.click();
    const text = stripTags(get('document').innerHTML);
    visibleSamples.push(text);
    consentFormatSamples.push(text);
    samplesByKey[`${family}:consent`] = text;
  }

  renderVisibleSample(
    'cervical',
    'Paciente prueba con canal estrecho cervical, trastorno de la marcha, torpeza manual y laminoplastia cervical.',
    'hc'
  );
  renderVisibleSample(
    'lumbar_hdl',
    'Paciente prueba con hernia discal posterolateral L4-L5 izquierda y dolor radicular izquierdo. Microdiscectomía tubular L4-L5 izquierda.',
    'hc'
  );
  renderVisibleSample(
    'lumbar_hdl',
    'Paciente prueba con hernia discal posterolateral L4-L5 izquierda y dolor radicular izquierdo. Microdiscectomía tubular L4-L5 izquierda.',
    'parte'
  );
  renderVisibleSample(
    'lumbar_hdl',
    'Paciente prueba con hernia discal extraforaminal L4-L5 derecha y dolor radicular derecho. RM con extrusión discal extraforaminal L4-L5 derecha. Microdiscectomía extraforaminal L4-L5 derecha.',
    'hc',
    'lumbar_extraforaminal:hc'
  );
  renderVisibleSample(
    'lumbar_hdl',
    'Paciente prueba con hernia discal extraforaminal L4-L5 derecha y dolor radicular derecho. RM con extrusión discal extraforaminal L4-L5 derecha. Microdiscectomía extraforaminal L4-L5 derecha.',
    'parte',
    'lumbar_extraforaminal:parte'
  );
  renderVisibleSample(
    'lumbar_hdl',
    'Paciente prueba con radiculopatía L5 derecha, dolor lumbar mecánico y dolor radicular derecho. Descompresión radicular L4-L5 derecha.',
    'hc',
    'lumbar_radiculopatia_sin_hernia:hc'
  );
  renderVisibleSample(
    'lumbar_hdl',
    'Paciente prueba con radiculopatía L5 derecha, dolor lumbar mecánico y dolor radicular derecho. Descompresión radicular L4-L5 derecha.',
    'parte',
    'lumbar_radiculopatia_sin_hernia:parte'
  );
  renderVisibleSample(
    'lumbar_fijacion',
    'Paciente prueba con canal estrecho lumbar L4-L5, inestabilidad asociada a patología degenerativa y fijación L4-L5.',
    'hc'
  );
  renderVisibleSample(
    'columna_lumbar_espondilolistesis',
    'Paciente prueba con espondilolistesis degenerativa L4-L5, dolor lumbar mecánico y dolor radicular. Fijación instrumentada y artrodesis L4-L5.',
    'hc',
    'espondilolistesis_degenerativa:hc'
  );
  renderVisibleSample(
    'columna_lumbar_espondilolistesis',
    'Paciente prueba con espondilolistesis ístmica L5-S1, dolor lumbar mecánico y dolor radicular. Fijación instrumentada y artrodesis L5-S1.',
    'hc',
    'espondilolistesis_istmica:hc'
  );
  renderVisibleSample(
    'lumbar_fijacion',
    'Paciente prueba con patología degenerativa lumbar L4-L5 con inestabilidad y compromiso neural, con indicación de descompresión e instrumentación.',
    'parte'
  );
  renderVisibleSample(
    'lumbar_fijacion',
    'Paciente prueba con patología degenerativa lumbar L4-L5 con inestabilidad y compromiso neural. Fijación instrumentada y artrodesis L4-L5 sin descompresión directa.',
    'parte',
    'lumbar_fijacion_sin_descompresion_directa:parte'
  );
  renderVisibleSample(
    'lumbar_fijacion',
    'Paciente prueba con patología degenerativa lumbar L4-L5 con inestabilidad y compromiso neural. Fijación instrumentada y artrodesis L4-L5 sin descompresión directa, con un PLIF; sustituto oseo, drill; parche de duramadre.',
    'parte',
    'lumbar_fijacion_plif_patch_sin_directa:parte'
  );
  renderVisibleSample(
    'lumbar_fijacion',
    'Paciente prueba con patología degenerativa lumbar L4-L5 con inestabilidad y compromiso neural. Se realizó descompresión neural, fijación instrumentada y artrodesis L4-L5.',
    'parte',
    'lumbar_fijacion_con_descompresion_directa:parte'
  );
  renderVisibleSample(
    'lumbar_fijacion',
    'Paciente prueba con patología degenerativa lumbar L4-L5 con inestabilidad y compromiso neural. Se realizó descompresión neural, fijación instrumentada y artrodesis L4-L5. Se colocó parche de duramadre.',
    'parte',
    'lumbar_fijacion_con_descompresion_patch:parte'
  );
  renderVisibleSample(
    'cervical',
    'Paciente prueba con canal estrecho cervical, trastorno de la marcha, torpeza manual y laminoplastia cervical.',
    'parte'
  );
  renderVisibleSample(
    'lumbar_fijacion',
    'Paciente prueba con patología degenerativa lumbar en L4-L5 derecha con indicación de descompresión neural y estabilización instrumentada.',
    'consent'
  );
  renderConsentFormatSample(
    'lumbar_hdl',
    'Paciente prueba con hernia discal posterolateral L4-L5 izquierda y dolor radicular izquierdo. Microdiscectomía tubular L4-L5 izquierda.'
  );
  renderConsentFormatSample(
    'lumbar_fijacion',
    'Paciente prueba con patología degenerativa lumbar en L4-L5 derecha con indicación de descompresión neural y estabilización instrumentada.'
  );
  renderConsentFormatSample(
    'cervical',
    'Paciente prueba con canal estrecho cervical, trastorno de la marcha, torpeza manual y laminoplastia cervical.'
  );

  const templateMotherHtml = get('templateMother').innerHTML;
  get('familySelect').value = 'auto';
  get('input').value = 'Paciente prueba con hernia discal posterolateral L4-L5 izquierda y dolor radicular izquierdo. Microdiscectomía tubular L4-L5 izquierda.';
  get('familySelect').listeners.change();
  const autoSuggestionHtml = get('familySuggestionPanel').innerHTML + get('familySelectHelp').innerHTML + get('caseStatus').innerHTML + get('packageSummary').innerHTML;

  get('familySelect').value = 'cervical';
  get('familySelect').listeners.change();
  const manualSuggestionHtml = get('familySuggestionPanel').innerHTML + get('familySelectHelp').innerHTML;

  get('exceptions').value = 'No se colocó drenaje. Sin monitoreo neurofisiológico intraoperatorio.';
  get('input').value = 'Paciente prueba con espondilolistesis L4-L5 para fijación lumbar MISS.';
  get('familySelect').value = 'lumbar_fijacion';
  get('familySelect').listeners.change();
  const parteTab = document._tabs.find((item) => item.dataset.tab === 'parte');
  if (parteTab) parteTab.click();

  const exceptionParteSample = stripTags(get('document').innerHTML || '');
  const reviewQueueHtml = get('reviewQueue').innerHTML || '';
  const lumbarFixationParte = samplesByKey['lumbar_fijacion:parte'] || '';
  const lumbarFixationDiagnosisLine = (lumbarFixationParte.match(/Diagnóstico:\s*(.*?)\s+Operación:/i) || [])[1] || '';
  const lumbarFixationPlifPatch = samplesByKey['lumbar_fijacion_plif_patch_sin_directa:parte'] || '';
  const plifPatchIdx = lumbarFixationPlifPatch.indexOf('parche de duramadre');
  const plifPatchCloseIdx = lumbarFixationPlifPatch.indexOf('Cierre por planos');
  const lumbarFixationExplicitPatch = samplesByKey['lumbar_fijacion_con_descompresion_patch:parte'] || '';
  const explicitPatchIdx = lumbarFixationExplicitPatch.indexOf('parche de duramadre');
  const explicitPatchCloseIdx = lumbarFixationExplicitPatch.indexOf('Cierre por planos');
  const lumbarFixationSequenceText = lumbarFixationPlifPatch || samplesByKey['lumbar_fijacion_sin_descompresion_directa:parte'] || '';
  const hemostasisIdx = lumbarFixationSequenceText.indexOf('Se realizó hemostasia por planos');
  const countIdx = lumbarFixationSequenceText.indexOf('Se efectuó recuento de gasas');
  const closeIdx = lumbarFixationSequenceText.indexOf('Cierre por planos');
  const postCloseText = closeIdx > -1 ? lumbarFixationSequenceText.slice(closeIdx) : '';
  const radicNoHerniaHc = samplesByKey['lumbar_radiculopatia_sin_hernia:hc'] || '';
  const radicNoHerniaParte = samplesByKey['lumbar_radiculopatia_sin_hernia:parte'] || '';
  const lumbarExtraforaminalHc = samplesByKey['lumbar_extraforaminal:hc'] || '';
  const lumbarExtraforaminalParte = samplesByKey['lumbar_extraforaminal:parte'] || '';
  const lumbarStenosisHc = samplesByKey['lumbar_fijacion:hc'] || '';

  const result = {
    product_html: htmlPath,
    family_options: get('familySelect').options.length,
    manual_family_status_ok: /TVT|MAV|vascular|Aneurisma/i.test(caseHtml),
    document_uses_template_mother: /Candidatos detectados|Muestra estructural validada/i.test(templateMotherHtml)
      && !/Plantilla madre operatoria|Estructura madre local aplicada|Familia documental/i.test(documentHtml),
    legal_gate_items: (get('legalGate').innerHTML.match(/<li>/g) || []).length,
    legal_score_review_only: /revisión médica antes de uso real/.test(get('legalScore').innerHTML),
    correction_logged: /Corrección integrada|familiares/.test(get('correctionLog').innerHTML + documentHtml),
    export_manifest_summary_visible: /Resumen del manifiesto local/i.test(sourceHtml) && /sha256 .*bytes|Sin archivos trazados visibles en el manifiesto cargado|Manifiesto no disponible/i.test(sourceHtml),
    export_detect_only_sources_visible: /Fuentes detect-only cargadas/i.test(sourceHtml) && /Sin fuentes detect-only trazadas en esta corrida|rel_path|sha256/i.test(sourceHtml),
    family_auto_suggestion_confidence_visible: /Sugerencia autom[aá]tica/i.test(autoSuggestionHtml) && /Confianza:\s*\d+%/i.test(stripTags(autoSuggestionHtml)) && /Hernia de disco lumbar|microdiscectom/i.test(stripTags(autoSuggestionHtml)) && /señal|registro local|hernia|dolor radicular/i.test(stripTags(autoSuggestionHtml)),
    family_manual_override_visible: /Correcci[oó]n manual/i.test(manualSuggestionHtml) && /Canal estrecho cervical|laminoplastia/i.test(stripTags(manualSuggestionHtml)) && /Sugerido originalmente/i.test(manualSuggestionHtml),
    draft_guard_block_visible: /BORRADOR BLOQUEADO/i.test(autoSuggestionHtml) && /sin revisi[oó]n m[eé]dica\/Codex Guard|revisi[oó]n m[eé]dica y Codex Guard/i.test(stripTags(autoSuggestionHtml)),
    no_forbidden_visible_phrases: visibleSamples.every((text) => !forbiddenVisible.test(text)),
    lumbar_hdl_root_side_level_ok: /radiculopatía L5 izquierda/i.test(samplesByKey['lumbar_hdl:hc'] || '') && /L4-L5 izquierda/i.test(samplesByKey['lumbar_hdl:hc'] || '') && /Marcación radioscópica del nivel L4-L5/i.test(samplesByKey['lumbar_hdl:parte'] || '') && /paramediana izquierda/i.test(samplesByKey['lumbar_hdl:parte'] || '') && !/lateralidad informada|nivel informado|raíz pasante|raíz saliente/i.test(`${samplesByKey['lumbar_hdl:hc'] || ''} ${samplesByKey['lumbar_hdl:parte'] || ''}`),
    lumbar_extraforaminal_hc_root_ok: /radiculopatía L4 derecha/i.test(lumbarExtraforaminalHc) && /hernia discal extraforaminal L4-L5 derecha/i.test(lumbarExtraforaminalHc),
    lumbar_extraforaminal_parte_not_interlaminar: /abordaje paravertebral[\s\S]{0,120}foraminal[\s\S]{0,80}extraforaminal/i.test(lumbarExtraforaminalParte) && /raíz L4/i.test(lumbarExtraforaminalParte) && !/espacio interlaminar|hemilaminotomía|flavectomía|hombro de la raíz|raíz pasante/i.test(lumbarExtraforaminalParte),
    lumbar_radiculopathy_without_hernia_not_converted: /radiculopatía L5 derecha/i.test(radicNoHerniaHc) && /L4-L5/i.test(radicNoHerniaHc) && !/hernia|posterolateral|extrusi[oó]n|fragmento discal/i.test(radicNoHerniaHc),
    lumbar_radiculopathy_without_hernia_parte_clean: /descompresión radicular lumbar L4-L5 derecha/i.test(radicNoHerniaParte) && !/hernia|posterolateral|extrusi[oó]n|fragmento discal|fragmento herniado/i.test(radicNoHerniaParte),
    lumbar_stenosis_study_wording_not_redundant: /RM lumbar con estenosis de canal y recesos laterales en L4-L5/i.test(lumbarStenosisHc) && !/canal estrecho lumbar[^.]{0,120}compromiso del canal|compromiso del canal y recesos laterales/i.test(lumbarStenosisHc),
    no_unsolicited_motor_deficit_hc: !/debilidad|paresia|dorsiflexión|hallux|reflejo/i.test(samplesByKey['lumbar_hdl:hc'] || ''),
    cervical_hc_style_ok: /Enfermedad actual:\s*Trastorno de la marcha/i.test(samplesByKey['cervical:hc'] || '') && !/cuadro clínico compatible con trastorno|signos piramidales|déficit motor o sensitivo/i.test(samplesByKey['cervical:hc'] || ''),
    espondilolistesis_degenerativa_not_istmica: /espondilolistesis degenerativa/i.test(samplesByKey['espondilolistesis_degenerativa:hc'] || '') && !/degenerativa o [íi]stmica|espondilolistesis [íi]stmica/i.test(samplesByKey['espondilolistesis_degenerativa:hc'] || ''),
    espondilolistesis_istmica_not_degenerativa: /espondilolistesis [íi]stmica/i.test(samplesByKey['espondilolistesis_istmica:hc'] || '') && !/degenerativa o [íi]stmica|espondilolistesis degenerativa/i.test(samplesByKey['espondilolistesis_istmica:hc'] || ''),
    consent_hernia_format_reused: consentFormatSamples.every((text) => /CONSENTIMIENTO INFORMADO/i.test(text) && /Lugar y fecha:/i.test(text) && /Yo,/i.test(text) && /Autorizo a los Dres\./i.test(text) && /Se me informó especialmente:/i.test(text) && /Habiendo leído y comprendido este documento/i.test(text) && /Firma del paciente:/i.test(text) && /Firma del médico:/i.test(text)),
    consent_lumbar_fixation_diagnosis_separated: /con diagnóstico de patología degenerativa lumbar L4-L5 con compromiso neural e inestabilidad segmentaria/i.test(samplesByKey['lumbar_fijacion:consent'] || '') && /Autorizo a los Dres\.[^.]+fijación instrumentada y artrodesis lumbar L4-L5, con o sin descompresión neural/i.test(samplesByKey['lumbar_fijacion:consent'] || '') && !/L4-L5 derecha/i.test(samplesByKey['lumbar_fijacion:consent'] || '') && !/descompresión o recalibraje/i.test(samplesByKey['lumbar_fijacion:consent'] || '') && !/con diagnóstico de[^.]{0,180}con indicación de descompresión neural/i.test(samplesByKey['lumbar_fijacion:consent'] || ''),
    parte_lumbar_fixation_diagnosis_only: /^patología degenerativa lumbar L4-L5 con inestabilidad y compromiso neural$/i.test(lumbarFixationDiagnosisLine.trim()) && !/(con indicación|criterio de|descompresión e instrumentación|descompresión neural|instrumentación circunferencial)/i.test(lumbarFixationDiagnosisLine),
    parte_lumbar_fixation_setup_not_duplicated: (lumbarFixationParte.match(/protección ocular/gi) || []).length <= 1 && (lumbarFixationParte.match(/acolchado de puntos de apoyo/gi) || []).length <= 1,
    parte_lumbar_fixation_no_direct_decompression_respected: /Operación:\s*fijación instrumentada y artrodesis lumbar L4-L5/i.test(samplesByKey['lumbar_fijacion_sin_descompresion_directa:parte'] || '') && /No se realizó descompresión neural directa/i.test(samplesByKey['lumbar_fijacion_sin_descompresion_directa:parte'] || '') && !/Se efectúa descompresión neural mediante|laminectomía\/hemilaminectomía|flavectomía|liberación de recesos|identificando y protegiendo saco dural|adecuada liberación neural|ausencia de compresión residual|Operación:[^\n.]*descompresión/i.test(samplesByKey['lumbar_fijacion_sin_descompresion_directa:parte'] || ''),
    parte_lumbar_fixation_plif_patch_not_duplicated_or_misplaced: /caja PLIF/i.test(lumbarFixationPlifPatch) && (lumbarFixationPlifPatch.match(/\bPLIF\b/g) || []).length <= 1 && /sustituto óseo/i.test(lumbarFixationPlifPatch) && !/Implantes\/materiales utilizados:[^.]*PLIF|con un PLIF|drill|parche de duramadre/i.test(lumbarFixationPlifPatch) && plifPatchCloseIdx > -1 && !/\.\./.test(lumbarFixationPlifPatch) && !/adecuada liberación neural|ausencia de compresión residual/i.test(lumbarFixationPlifPatch),
    parte_lumbar_fixation_hemostasis_count_before_closure: hemostasisIdx > -1 && countIdx > -1 && closeIdx > -1 && hemostasisIdx < countIdx && countIdx < closeIdx && !/hemostasia por planos|recuento de gasas/i.test(postCloseText),
    parte_lumbar_fixation_explicit_decompression_respected: /Operación:\s*descompresión neural, fijación instrumentada y artrodesis lumbar L4-L5/i.test(samplesByKey['lumbar_fijacion_con_descompresion_directa:parte'] || '') && /Se efectúa descompresión neural mediante/i.test(samplesByKey['lumbar_fijacion_con_descompresion_directa:parte'] || ''),
    parte_lumbar_fixation_explicit_patch_before_closure: explicitPatchIdx > -1 && explicitPatchCloseIdx > -1 && explicitPatchIdx < explicitPatchCloseIdx && !/Cierre por planos[^]*parche de duramadre/i.test(lumbarFixationExplicitPatch),
    registry_loaded: /Candidatos detectados|Muestra estructural validada/i.test(templateMotherHtml),
    consent_supported: /consentimientos locales|Consentimiento informado|salida clínico-legal completa/i.test(caseHtml + documentHtml),
    dual_output_hc_parte_evolucion: /data-tab="hc"/.test(sourceHtml) && /data-tab="parte"/.test(sourceHtml) && /data-tab="consent"/.test(sourceHtml) && /data-tab="evolucion"/.test(sourceHtml) && /option value="hc"/.test(sourceHtml) && /option value="parte"/.test(sourceHtml) && /option value="consent"/.test(sourceHtml) && /option value="evolucion"/.test(sourceHtml),
    same_input_flow_visible: /Historia, parte y consentimiento|rutinas verdaderas|matriz Jarvis de consentimientos/i.test(get('brand').innerHTML + caseHtml + coverageHtml),
    medico_legal_gate_visible: /Ley 26\.529|Buscador SAIJ|jurisprudencia|normativa/i.test(get('legalUpdatePolicy').innerHTML + get('reviewQueue').innerHTML),
    legal_update_supported: /Ley 26\.529|Buscador SAIJ|jurisprudencia|normativa/i.test(get('legalUpdatePolicy').innerHTML + get('reviewQueue').innerHTML),
    quick_exceptions_visible: /Excepciones reales declaradas:/i.test(exceptionParteSample) && /No se colocó drenaje/i.test(exceptionParteSample) && /Sin monitoreo neurofisiológico intraoperatorio/i.test(exceptionParteSample),
    review_queue_priority_visible: /Siguiente acción segura:|Uso asistencial real:|Frase a vigilar:/i.test(reviewQueueHtml),
    status: 'ok'
  };

  const failures = Object.entries(result)
    .filter(([key, value]) => key !== 'product_html' && key !== 'status' && (value === false || value === 0))
    .map(([key]) => key);
  if (failures.length) {
    result.status = 'failed';
    result.failures = failures;
    console.error(JSON.stringify(result, null, 2));
    process.exit(1);
  }
  console.log(JSON.stringify(result, null, 2));
}

main().catch((error) => {
  console.error(error.stack || String(error));
  process.exit(1);
});
