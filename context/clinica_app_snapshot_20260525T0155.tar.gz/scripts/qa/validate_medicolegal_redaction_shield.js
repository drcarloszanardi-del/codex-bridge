#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..', '..');
const productPath = path.join(root, 'app', 'product.html');
const agentsPath = '/Users/jarvis/AGENTS.md';
const contractPath = path.join(root, 'docs', 'contrato_blindaje_redaccion_medicolegal_2026-05-24.md');
const radarPath = path.join(root, 'docs', 'radar_fuentes_normativas_jurisprudencia_neuro_columna_5_3_2026-05-24.md');

const product = fs.readFileSync(productPath, 'utf8');
const agents = fs.readFileSync(agentsPath, 'utf8');
const contract = fs.readFileSync(contractPath, 'utf8');
const radar = fs.readFileSync(radarPath, 'utf8');

const checks = {
  durable_agents_always_on: /SIEMPRE: leyes, normativas, jurisprudencia oficial/.test(agents)
    && /Subagentes baratos pueden buscar, clasificar/.test(agents),
  product_policy_present: /const REDACTION_BLINDAJE_POLICY/.test(product)
    && /normativa_argentina/.test(product)
    && /jurisprudencia_oficial/.test(product)
    && /doctrina_tecnica_curada/.test(product),
  product_gate_present: /function runRedactionShieldGate/.test(product)
    && /BL-HC-001/.test(product)
    && /BL-PARTE-001/.test(product)
    && /BL-PARTE-003/.test(product)
    && /BL-CONS-001/.test(product),
  product_gate_merged: /\.\.\.runRedactionShieldGate\(docs\),\s*\.\.\.tamizResults/.test(product),
  product_export_audit_present: /redaction_shield:\s*\{/.test(product)
    && /Contrato corpus a redacción/.test(product)
    && /Blindaje redaccional/.test(product),
  product_clinical_sanitize_present: /FUNDAMENTOS MEDICOLEGALES EMBEBIDOS/.test(product)
    && /Fundamento:/.test(product),
  contract_mentions_laws_norms_jurisprudence: /Leyes y normativas argentinas oficiales/.test(contract)
    && /Jurisprudencia oficial/.test(contract)
    && /Doctrina tecnica/.test(contract),
  radar_source_scope_ok: /SAIJ/.test(radar)
    && /CIJ \/ CSJN/.test(radar)
    && /JUBA \/ SCBA/.test(radar)
    && /AANC \/ RANC/.test(radar)
    && /ley, norma, fallo/.test(radar),
  no_terminal_certification_claim: /terminalLegalCertification:\s*false/.test(product)
    && /No declara certificacion legal terminal/.test(contract)
};

const failures = Object.entries(checks)
  .filter(([, ok]) => !ok)
  .map(([key]) => key);

const result = {
  ok: failures.length === 0,
  product: productPath,
  contract: contractPath,
  radar: radarPath,
  checks,
  failures
};

console.log(JSON.stringify(result, null, 2));
if (failures.length) process.exit(1);
