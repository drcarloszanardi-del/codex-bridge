#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { execFileSync, spawnSync } = require('child_process');

const APP_ROOT = path.resolve(__dirname, '..', '..');
const WORKSPACE = '/Users/jarvis/.openclaw/workspace';
const PYTHON = process.env.CLINICA_PYTHON || '/Users/jarvis/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3';
const WRAPPER = path.join(APP_ROOT, 'scripts', 'jarvis', 'clinica_generar_y_enviar.sh');
const QA_DIR = path.join(APP_ROOT, 'qa', 'approval_gates');
const DATE_ID = new Date().toISOString().slice(0, 10);

const FORBIDDEN = [
  ['radiculalgia', /\bradiculalgia\b/i],
  ['y_o', /\by\/o\b/i],
  ['si_corresponde', /\bsi correspond(?:e|en|iera|iese|a)\b/i],
  ['cuando_corresponda', /\bcuando correspond(?:a|e|ia|ía|iera|iese)\b/i],
  ['segun_corresponda', /\bseg[uú]n corresponda\b/i],
  ['si_aplica', /\bsi aplica\b/i],
  ['si_existe', /\bsi existe\b/i],
  ['eventual', /\beventual(?:mente)?\b/i],
  ['relato_origen', /Relato de origen/i],
  ['trazabilidad_clinica', /Trazabilidad clínica/i],
  ['nivel_informado', /nivel informado|lateralidad informada|localizaci[oó]n informada/i],
  ['completar_placeholder', /\bcompletar\b|\[completar\]|\[nivel|\[fecha\]|\[DNI\]|\[paciente\]/i],
  ['validar_placeholder', /\bvalidar\b/i],
  ['tratado_anatomia', /hernia posterolateral\/central habitual|ra[ií]z pasante|ra[ií]z saliente/i],
  ['cervical_ambiguo', /mielopat[ií]a o compromiso neurol[oó]gico/i],
  ['deficit_motor_o_sensitivo', /d[eé]ficit motor o sensitivo/i],
  ['posible_hc_finding', /\bposible hipoestesia|posible d[eé]ficit/i],
];

const BASE = {
  age: '58',
  date: '20/05/2026',
  startTime: '08:00',
  endTime: '09:20',
  assistants: 'Dr. Ayudante QA',
};

const REQUESTS = [
  {
    id: 'REQ-001',
    request_text: 'Jarvis, mandame por Telegram consentimiento de hernia de disco lumbar L4-L5 izquierda para Clínica Centro.',
    type: 'consent',
    slug: 'hernia_disco_lumbar',
    institution: 'clinica_centro',
    patient: 'Paciente Noche 01',
    dni: 'QA-0001',
    level: 'L4-L5 izquierda',
    expect: [/CONSENTIMIENTO INFORMADO/i, /hernia de disco lumbar/i, /L4-L5 izquierda/i],
  },
  {
    id: 'REQ-002',
    request_text: 'Jarvis, necesito historia clínica para hernia extraforaminal L4-L5 derecha.',
    type: 'hc',
    family: 'columna_lumbar_hernia_disco',
    institution: 'la_pequena_familia',
    patient: 'Paciente Noche 02',
    level: 'L4-L5',
    side: 'derecha',
    input: 'Hernia de disco extraforaminal L4-L5 derecha con dolor radicular derecho. RM con extrusión discal extraforaminal L4-L5 derecha. Microdiscectomía derecha.',
    expect: [/radiculopat[ií]a L4 derecha/i, /dolor radicular derecho/i, /L4-L5/i],
  },
  {
    id: 'REQ-003',
    request_text: 'Jarvis, parte quirúrgico de microdiscectomía tubular L4-L5 izquierda.',
    type: 'parte',
    family: 'columna_lumbar_hernia_disco',
    institution: 'clinica_centro',
    patient: 'Paciente Noche 03',
    level: 'L4-L5',
    side: 'izquierda',
    input: 'Hernia de disco lumbar L4-L5 izquierda con dolor radicular izquierdo. Microdiscectomía tubular L4-L5 izquierda.',
    expect: [/Paciente en dec[uú]bito prono/i, /Marcaci[oó]n radiosc[oó]pica[\s\S]*L4-L5/i, /paramediana izquierda/i, /Hemostasia/i, /Cierre/i],
  },
  {
    id: 'REQ-004',
    request_text: 'Jarvis, consentimiento canal estrecho con fijación en LPF.',
    type: 'consent',
    slug: 'canal_estrecho_lumbar_con_fijacion',
    institution: 'la_pequena_familia',
    patient: 'Paciente Noche 04',
    dni: 'QA-0004',
    level: 'L4-L5 bilateral',
    expect: [/canal estrecho lumbar/i, /fijaci[oó]n/i, /Matr[ií]cula:\s*MP 63905 MN 116564/i],
  },
  {
    id: 'REQ-005',
    request_text: 'Jarvis, historia clínica de canal estrecho lumbar L4-L5 sin fijación.',
    type: 'hc',
    family: 'columna_lumbar_canal_estrecho',
    institution: 'higa_junin',
    patient: 'Paciente Noche 05',
    level: 'L4-L5',
    side: 'bilateral',
    input: 'Canal estrecho lumbar L4-L5 con claudicación neurogénica y lumbalgia. Recalibraje y descompresión lumbar L4-L5 bilateral sin implantes.',
    expect: [/claudicaci[oó]n/i, /canal estrecho lumbar/i, /L4-L5/i],
  },
  {
    id: 'REQ-006',
    request_text: 'Jarvis, parte de fijación transpedicular L4-L5 con inestabilidad degenerativa.',
    type: 'parte',
    family: 'columna_lumbar_fijacion_transpedicular',
    institution: 'clinica_centro',
    patient: 'Paciente Noche 06',
    level: 'L4-L5',
    side: 'bilateral',
    input: 'Inestabilidad asociada a patología degenerativa L4-L5 con canal estrecho. Descompresión, fijación transpedicular y artrodesis L4-L5.',
    expect: [/control radiosc[oó]pico/i, /chequeo radiosc[oó]pico[\s\S]*del material/i, /tornillos transpediculares/i],
  },
  {
    id: 'REQ-007',
    request_text: 'Jarvis, consentimiento artrodesis cervical C5-C6 derecha.',
    type: 'consent',
    slug: 'artrodesis_cervical',
    institution: 'higa_junin',
    patient: 'Paciente Noche 07',
    dni: 'QA-0007',
    level: 'C5-C6 derecha',
    expect: [/ARTRODESIS CERVICAL/i, /C5-C6 derecha/i, /alternativas terap[eé]uticas/i],
  },
  {
    id: 'REQ-008',
    request_text: 'Jarvis, historia clínica de laminoplastia cervical C3-C7 por mielopatía.',
    type: 'hc',
    family: 'columna_cervical_laminoplastia',
    institution: 'clinica_centro',
    patient: 'Paciente Noche 08',
    level: 'C3-C7',
    side: 'bilateral',
    input: 'Canal estrecho cervical C3-C7 con mielopatía, trastorno de la marcha y torpeza manual. Laminoplastia cervical C3-C7.',
    expect: [/Enfermedad actual:\s*Trastorno de la marcha/i, /C3-C7/i, /mielopat[ií]a cervical/i],
  },
  {
    id: 'REQ-009',
    request_text: 'Jarvis, protocolo de laminoplastia cervical C3-C7.',
    type: 'parte',
    family: 'columna_cervical_laminoplastia',
    institution: 'clinica_centro',
    patient: 'Paciente Noche 09',
    level: 'C3-C7',
    side: 'bilateral',
    input: 'Canal estrecho cervical C3-C7 con mielopatía. Laminoplastia cervical C3-C7.',
    expect: [/laminoplastia/i, /C3-C7/i, /protecci[oó]n ocular/i, /Hemostasia/i],
  },
  {
    id: 'REQ-010',
    request_text: 'Jarvis, consentimiento de Chiari para Clínica Centro.',
    type: 'consent',
    slug: 'chiari',
    institution: 'clinica_centro',
    patient: 'Paciente Noche 10',
    dni: 'QA-0010',
    level: 'cráneo cervical',
    expect: [/MALFORMACI[oó]N DE CHIARI/i, /cr[aá]neo-cervical|cr[aá]neo cervical/i, /f[ií]stula de LCR/i],
  },
  {
    id: 'REQ-011',
    request_text: 'Jarvis, parte de Chiari con descompresión de fosa posterior.',
    type: 'parte',
    family: 'malformacion_chiari',
    institution: 'clinica_centro',
    patient: 'Paciente Noche 11',
    level: 'cráneo cervical',
    side: 'medial',
    input: 'Malformación de Chiari I con cefalea occipital y siringomielia. Descompresión de fosa posterior y cráneo cervical.',
    expect: [/fosa posterior/i, /suboccipital/i, /C1/i, /Cierre/i],
  },
  {
    id: 'REQ-012',
    request_text: 'Jarvis, consentimiento válvula de hidrocefalia LPF.',
    type: 'consent',
    slug: 'hidrocefalia_derivaciones',
    institution: 'la_pequena_familia',
    patient: 'Paciente Noche 12',
    dni: 'QA-0012',
    level: 'ventrículo peritoneal derecha',
    expect: [/DERIVACI[oó]N DE HIDROCEFALIA/i, /v[aá]lvula|derivaci[oó]n/i, /sobredrenaje|subdrenaje/i],
  },
  {
    id: 'REQ-013',
    request_text: 'Jarvis, protocolo de válvula DVP derecha.',
    type: 'parte',
    family: 'otros_valvulas_hidrocefalia',
    institution: 'la_pequena_familia',
    patient: 'Paciente Noche 13',
    level: 'ventricular',
    side: 'derecha',
    input: 'Hidrocefalia sintomática con trastorno de la marcha y deterioro cognitivo. Colocación de válvula de derivación ventrículo peritoneal derecha.',
    expect: [/Carlos Zanardi/i, /v[aá]lvula|derivaci[oó]n/i, /derecha/i, /Hemostasia/i],
  },
  {
    id: 'REQ-014',
    request_text: 'Jarvis, consentimiento quiste facetario L4-L5 derecho.',
    type: 'consent',
    slug: 'exeresis_quiste_facetario_lumbar_sin_fijacion',
    institution: 'clinica_centro',
    patient: 'Paciente Noche 14',
    dni: 'QA-0014',
    level: 'L4-L5 derecha',
    expect: [/QUISTE FACETARIO/i, /L4-L5 derecha/i, /lesi[oó]n radicular/i],
  },
  {
    id: 'REQ-015',
    request_text: 'Jarvis, historia clínica de quiste facetario lumbar L4-L5 derecho.',
    type: 'hc',
    family: 'columna_quiste_facetario',
    institution: 'higa_junin',
    patient: 'Paciente Noche 15',
    level: 'L4-L5',
    side: 'derecha',
    input: 'Quiste facetario lumbar L4-L5 derecho con dolor radicular derecho y compresión radicular. Exéresis de quiste facetario L4-L5 derecho.',
    expect: [/quiste facetario/i, /L4-L5/i, /derech/i],
  },
  {
    id: 'REQ-016',
    request_text: 'Jarvis, consentimiento de vertebroplastia D12.',
    type: 'consent',
    slug: 'cifoplastia_vertebroplastia',
    institution: 'la_pequena_familia',
    patient: 'Paciente Noche 16',
    dni: 'QA-0016',
    level: 'D12',
    expect: [/VERTEBROPLASTIA|CIFOPLASTIA/i, /D12/i, /fuga de cemento/i],
  },
  {
    id: 'REQ-017',
    request_text: 'Jarvis, protocolo de cifoplastia L1.',
    type: 'parte',
    family: 'columna_cifoplastia',
    institution: 'higa_junin',
    patient: 'Paciente Noche 17',
    level: 'L1',
    side: 'bilateral',
    input: 'Fractura vertebral L1 dolorosa con acuñamiento y edema. Cifoplastia L1 con balón y cemento.',
    expect: [/Paciente en dec[uú]bito|Posicionamiento/i, /cemento|PMMA|bal[oó]n/i, /L1/i],
  },
  {
    id: 'REQ-018',
    request_text: 'Jarvis, consentimiento espondilodiscitis dorsal HIGA.',
    type: 'consent',
    slug: 'espondilodiscitis_dorsal_higa_junin',
    institution: 'higa_junin',
    patient: 'Paciente Noche 18',
    dni: 'QA-0018',
    level: 'D7-D8',
    expect: [/ESPONDILODISCITIS DORSAL/i, /D7-D8/i, /tratamiento antibi[oó]tico/i],
  },
  {
    id: 'REQ-019',
    request_text: 'Jarvis, historia clínica de meningioma frontal izquierdo.',
    type: 'hc',
    family: 'tumor_meningioma',
    institution: 'clinica_centro',
    patient: 'Paciente Noche 19',
    level: 'frontal',
    side: 'izquierda',
    input: 'Meningioma frontal izquierdo con cefalea y crisis comicial. Craneotomía frontal izquierda y exéresis tumoral.',
    expect: [/meningioma/i, /frontal izquierda/i, /crisis/i],
  },
  {
    id: 'REQ-020',
    request_text: 'Jarvis, protocolo de aneurisma comunicante anterior izquierda.',
    type: 'parte',
    family: 'vascular_aneurisma',
    institution: 'higa_junin',
    patient: 'Paciente Noche 20',
    level: 'comunicante anterior',
    side: 'izquierda',
    input: 'Aneurisma cerebral de comunicante anterior con indicación de clipado. Craneotomía pterional izquierda y clipado aneurismático.',
    expect: [/aneurisma/i, /clipado/i, /izquierda/i, /Cierre/i],
  },
  {
    id: 'REQ-021',
    request_text: 'Jarvis, protocolo con parche de duramadre y sellador dural, si hubo apertura dural.',
    type: 'parte',
    family: 'columna_lumbar_hernia_disco',
    institution: 'clinica_centro',
    patient: 'Paciente Noche 21',
    level: 'L5-S1',
    side: 'derecha',
    exceptions: 'Se produjo apertura dural puntiforme. Se utilizó parche de duramadre y sellador dural.',
    input: 'Hernia de disco lumbar L5-S1 derecha con dolor radicular derecho. Microdiscectomía tubular L5-S1 derecha.',
    expect: [/parche de duramadre/i, /sellador dural/i, /L5-S1/i, /derecha/i],
  },
  {
    id: 'REQ-022',
    request_text: 'Jarvis, consentimiento artroplastia cervical C5-C6 derecha.',
    type: 'consent',
    slug: 'artroplastia_cervical',
    institution: 'clinica_centro',
    patient: 'Paciente Noche 22',
    dni: 'QA-0022',
    level: 'C5-C6 derecha',
    expect: [/ARTROPLASTIA CERVICAL/i, /C5-C6 derecha/i, /pr[oó]tesis cervical/i],
  },
  {
    id: 'REQ-023',
    request_text: 'Jarvis, parte de biopsia vertebral D8.',
    type: 'parte',
    family: 'columna_biopsia_vertebral',
    institution: 'clinica_centro',
    patient: 'Paciente Noche 23',
    level: 'D8',
    side: 'bilateral',
    input: 'Lesión vertebral D8 de etiología a determinar. Biopsia vertebral percutánea D8 guiada por radioscopia.',
    expect: [/biopsia/i, /D8/i, /radiosc[oó]p/i],
  },
  {
    id: 'REQ-024',
    request_text: 'Jarvis, historia clínica y parte deben bloquear si falta nivel/lado en hernia.',
    negative: true,
    type: 'parte',
    family: 'columna_lumbar_hernia_disco',
    institution: 'clinica_centro',
    patient: 'Paciente Bloqueo Noche',
    input: 'Paciente con hernia discal lumbar y dolor radicular.',
    expectBlock: /BLOQUEADO_NO_ENVIAR|placeholders_visibles|nivel_no_reflejado|lateralidad/i,
  },
];

function toCliKey(key) {
  return `--${key.replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`)}`;
}

function runWrapper(args) {
  const argv = [];
  for (const [key, value] of Object.entries(args)) {
    if (value === undefined || value === null || value === '') continue;
    argv.push(toCliKey(key), String(value));
  }
  const proc = spawnSync(WRAPPER, argv, {
    cwd: APP_ROOT,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  const raw = (proc.status === 0 ? proc.stdout : proc.stderr || proc.stdout).trim();
  let parsed = null;
  try {
    parsed = raw ? JSON.parse(raw) : {};
  } catch {
    parsed = { raw };
  }
  return { status: proc.status, parsed, stdout: proc.stdout, stderr: proc.stderr, argv };
}

function pdfText(file) {
  const raw = execFileSync(PYTHON, ['-c', `
from pypdf import PdfReader
import json, sys
r=PdfReader(sys.argv[1])
text="\\n".join((p.extract_text() or "") for p in r.pages)
print(json.dumps({"pages": len(r.pages), "text": text}, ensure_ascii=False))
  `, file], {
    cwd: APP_ROOT,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  }).trim();
  return JSON.parse(raw);
}

function buildArgs(item) {
  const args = {
    type: item.type,
    institution: item.institution,
    patient: item.patient,
    date: item.date || BASE.date,
  };
  if (item.type === 'consent') {
    args.slug = item.slug;
    args.dni = item.dni;
    args.level = item.level;
    args.team = item.team || BASE.assistants;
  } else {
    args.family = item.family;
    args.input = item.input;
    args.age = item.age || BASE.age;
    args.startTime = item.startTime || BASE.startTime;
    args.endTime = item.endTime || BASE.endTime;
    args.assistants = item.assistants || BASE.assistants;
    args.level = item.level;
    args.side = item.side;
    args.exceptions = item.exceptions;
  }
  return args;
}

function validateManifest(item, parsed, failures) {
  if (!parsed.manifest || !fs.existsSync(parsed.manifest)) {
    failures.push('manifest_no_existe');
    return null;
  }
  const manifest = JSON.parse(fs.readFileSync(parsed.manifest, 'utf8'));
  if (!manifest.send_command || !Array.isArray(manifest.send_command)) failures.push('manifest_sin_send_command');
  const commandText = (manifest.send_command || []).join(' ');
  if (!/telegram_send_document_guard\.js/.test(commandText)) failures.push('send_command_no_usa_guard');
  if (!/--lane clinica_medicolegal/.test(commandText)) failures.push('send_command_sin_lane_clinica');
  if (/--send\b/.test(commandText)) failures.push('send_command_no_debe_ejecutar_envio_en_dry_run');
  if (!manifest.validation || !manifest.validation.ok) failures.push('manifest_validation_no_ok');
  if (!manifest.files?.pdf && !manifest.file) failures.push('manifest_sin_pdf');
  if (manifest.status !== 'validated_pending_telegram_send') failures.push(`manifest_status_${manifest.status}`);
  if (manifest.request?.patient !== item.patient) failures.push('manifest_paciente_no_coincide');
  return manifest;
}

function validateText(item, parsed, failures) {
  if (!parsed.file || !fs.existsSync(parsed.file)) {
    failures.push('pdf_no_existe');
    return;
  }
  const { pages, text } = pdfText(parsed.file);
  const compact = text.replace(/\s+/g, ' ');
  if (item.type === 'consent' && pages !== 1) failures.push('consentimiento_no_una_carilla');
  if (!compact.includes(item.patient)) failures.push('pdf_sin_paciente');
  if (!compact.includes(item.date || BASE.date)) failures.push('pdf_sin_fecha');
  const forbiddenHits = FORBIDDEN.filter(([, rx]) => rx.test(text)).map(([key]) => key);
  if (forbiddenHits.length) failures.push(`forbidden:${forbiddenHits.join(',')}`);
  for (const rx of item.expect || []) {
    if (!rx.test(text)) failures.push(`expectation_missing:${rx}`);
  }
  if (item.type === 'parte') {
    for (const rx of [/protecci[oó]n ocular/i, /acolchado de puntos de apoyo/i, /Antisepsia/i, /profilaxis antibi[oó]tica/i, /Hemostasia/i, /Cierre|curaci[oó]n/i, /No se registraron incidentes/i]) {
      if (!rx.test(text)) failures.push(`parte_missing:${rx}`);
    }
  }
  if (item.type === 'hc') {
    for (const section of ['Motivo de ingreso', 'Enfermedad actual', 'Examen físico', 'Estudios', 'Plan']) {
      if (!compact.includes(section)) failures.push(`hc_sin_${section.replace(/\s+/g, '_')}`);
    }
  }
}

function main() {
  fs.mkdirSync(QA_DIR, { recursive: true });
  const results = [];
  const failures = [];
  for (const item of REQUESTS) {
    const run = runWrapper(buildArgs(item));
    const result = {
      id: item.id,
      request_text: item.request_text,
      type: item.type,
      status: run.status,
      file: run.parsed?.file || null,
      manifest: run.parsed?.manifest || null,
      failures: [],
    };
    if (item.negative) {
      const output = `${run.stdout}\n${run.stderr}\n${JSON.stringify(run.parsed)}`;
      if (run.status === 0) result.failures.push('negative_case_no_bloqueado');
      if (!item.expectBlock.test(output)) result.failures.push('negative_case_sin_motivo_de_bloqueo');
    } else {
      if (run.status !== 0 || run.parsed?.ok !== true) {
        result.failures.push(`handoff_failed:${run.parsed?.validation_status || run.status}`);
      } else {
        validateManifest(item, run.parsed, result.failures);
        validateText(item, run.parsed, result.failures);
      }
    }
    if (result.failures.length) failures.push({ id: item.id, type: item.type, request_text: item.request_text, failures: result.failures, file: result.file, manifest: result.manifest });
    results.push(result);
  }

  const summary = {
    generated_at: new Date().toISOString(),
    ok: failures.length === 0,
    requests_count: REQUESTS.length,
    positive_requests_count: REQUESTS.filter((item) => !item.negative).length,
    negative_requests_count: REQUESTS.filter((item) => item.negative).length,
    files_generated_count: results.filter((item) => item.file).length,
    standard: 'jarvis_overnight_request_delivery_contract_v1',
    rules: [
      'Jarvis debe usar clinica_generar_y_enviar.sh o clinical_document_handoff.js; no redactar libremente.',
      'Sin --send por defecto: dejar manifest validated_pending_telegram_send y send_command con telegram_send_document_guard.js.',
      'Consentimiento siempre hard gate, una carilla, matricula MP 63905 MN 116564 y proforma sobria.',
      'HC/parte fluidos, pero bloquean placeholders, frases abiertas y contradicciones medicolegales.',
    ],
    failures,
    results,
  };
  const outPath = path.join(QA_DIR, `jarvis_overnight_requests_${DATE_ID}.json`);
  fs.writeFileSync(outPath, JSON.stringify(summary, null, 2));
  console.log(JSON.stringify({
    ok: summary.ok,
    requests_count: summary.requests_count,
    files_generated_count: summary.files_generated_count,
    failures_count: failures.length,
    outPath,
    failures: failures.slice(0, 20),
  }, null, 2));
  if (!summary.ok) process.exit(1);
}

main();
