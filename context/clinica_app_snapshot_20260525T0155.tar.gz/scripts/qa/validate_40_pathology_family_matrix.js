#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { execFileSync, spawnSync } = require('child_process');

const APP_ROOT = path.resolve(__dirname, '../..');
const NODE = process.env.OPENCLAW_NODE || '/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node';
const PYTHON = process.env.CLINICA_PYTHON || '/Users/jarvis/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3';
const HANDOFF = path.join(APP_ROOT, 'scripts', 'jarvis', 'clinical_document_handoff.js');
const BANK = path.join(APP_ROOT, 'data/derived/pathology_templates/pathology_template_bank_2026-05-20.json');
const QA_DIR = path.join(APP_ROOT, 'qa', 'approval_gates');
const DATE_ID = new Date().toISOString().slice(0, 10);

const FORBIDDEN = [
  ['radiculalgia', /\bradiculalgia\b/i],
  ['y_o', /\by\/o\b/i],
  ['si_corresponde', /\bsi correspond(?:e|en|iera|iese|a)\b/i],
  ['cuando_corresponda', /\bcuando correspond(?:a|e|ia|ía|iera|iese)\b/i],
  ['segun_corresponda', /\bseg[uú]n corresponda\b/i],
  ['si_aplica', /\bsi aplica\b/i],
  ['relato_origen', /Relato de origen/i],
  ['trazabilidad_clinica', /Trazabilidad clínica/i],
  ['placeholder_generico', /\bcompletar\b|\[completar\]|\[nivel|\[fecha\]|\[DNI\]|\[paciente\]|\binformad[oa] por el m[eé]dico\b/i],
  ['validar_placeholder', /\bvalidar\b/i],
  ['tratado_anatomia', /hernia posterolateral\/central habitual|ra[ií]z pasante|ra[ií]z saliente/i],
  ['cervical_ambiguo', /mielopat[ií]a o compromiso neurol[oó]gico|signos piramidales si|cuadro cl[ií]nico compatible con trastorno/i],
];

function pdfText(file) {
  const raw = execFileSync(PYTHON, ['-c', `
from pypdf import PdfReader
import json, sys
r=PdfReader(sys.argv[1])
text="\\n".join((p.extract_text() or "") for p in r.pages)
print(json.dumps({"pages": len(r.pages), "text": text}, ensure_ascii=False))
`, file], {
    cwd: APP_ROOT,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
    timeout: 30000,
  }).trim();
  return JSON.parse(raw);
}

function normalized(value) {
  return String(value || '')
    .toLowerCase()
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .replace(/\s+/g, ' ')
    .trim();
}

function sideVariants(side) {
  const value = normalized(side);
  if (!value) return [];
  if (value === 'izquierda' || value === 'izquierdo') return ['izquierda', 'izquierdo'];
  if (value === 'derecha' || value === 'derecho') return ['derecha', 'derecho'];
  if (value === 'bilateral') return ['bilateral', 'ambos lados', 'ambas', 'bilateralmente'];
  if (value === 'medial') return ['medial', 'linea media', 'central'];
  return [value];
}

function requiresLateralHardCheck(scenario, type) {
  const family = scenario.family || '';
  if (!/^(izquierda|derecha|izquierdo|derecho|bilateral|medial)$/i.test(scenario.side || '')) return false;
  if (/^medial$/i.test(scenario.side || '')) return false;
  if (/canal_estrecho|laminoplastia|vertebroplastia|cifoplastia|biopsia_vertebral|columna_tumor|infeccion|chiari|neurofisiologia|otros_neurocirugia/.test(family)) return false;
  if (/hipofisis|quiste_coloide|mielomeningocele/.test(family)) return false;
  if (/coflex|interespinoso/.test(family)) return false;
  if (/fijacion|espondilolistesis|360/.test(family) && type === 'hc') return false;
  return true;
}

function requiresLevelHardCheck(scenario) {
  const family = scenario.family || '';
  if (/chiari/.test(family)) return false;
  return Boolean(scenario.level);
}

function scenarioForFamily(family) {
  const key = family.id;
  const label = family.label || key;
  let level = 'L4-L5';
  let side = 'izquierda';
  let clinical = `${label} con síntomas concordantes, limitación funcional, estudios compatibles y criterio quirúrgico.`;
  let procedure = `Procedimiento neuroquirúrgico correspondiente a ${label}.`;

  if (/cervical/.test(key)) {
    level = /laminoplastia/.test(key) ? 'C3-C7' : 'C5-C6';
    side = /laminoplastia/.test(key) ? 'bilateral' : 'derecha';
    clinical = /laminoplastia/.test(key)
      ? `Canal estrecho cervical ${level} con mielopatía, trastorno de la marcha y torpeza manual. Laminoplastia cervical ${level}.`
      : `Patología discal cervical ${level} ${side} con cervicobraquialgia y dolor radicular ${side}. Abordaje cervical anterior ${level}.`;
    procedure = /laminoplastia/.test(key) ? `laminoplastia cervical ${level}` : `discectomía cervical anterior ${level}`;
  } else if (/hernia_disco/.test(key)) {
    clinical = `Hernia de disco lumbar posterolateral ${level} ${side} con lumbalgia y dolor radicular ${side}. RM con extrusión discal ${level} ${side}. Microdiscectomía tubular ${level} ${side}.`;
    procedure = `microdiscectomía tubular ${level} ${side}`;
  } else if (/canal_estrecho/.test(key)) {
    side = 'bilateral';
    clinical = `Canal estrecho lumbar ${level} con claudicación neurogénica y lumbalgia. Recalibraje y descompresión lumbar ${level} bilateral.`;
    procedure = `descompresión/recalibraje lumbar ${level}`;
  } else if (/fijacion|espondilolistesis|360|coflex|interespinoso/.test(key)) {
    side = /360/.test(key) ? 'izquierda' : 'bilateral';
    clinical = `Inestabilidad asociada a patología degenerativa ${level} con dolor lumbar mecánico, dolor radicular y limitación funcional. Fijación por vía miniinvasiva tipo Wiltse, descompresión y artrodesis ${level}.`;
    procedure = `fijación MISS por vía de Wiltse ${level}`;
  } else if (/vertebroplastia|cifoplastia|biopsia_vertebral|columna_tumor|infeccion/.test(key)) {
    level = /infeccion/.test(key) ? 'D7-D8' : /biopsia|tumor/.test(key) ? 'D8' : 'D12';
    side = 'bilateral';
    clinical = `${label} ${level} con dolor local, estudios compatibles y criterio quirúrgico. Procedimiento ${label} ${level} bajo control radioscópico.`;
    procedure = `${label} ${level}`;
  } else if (/quiste_facetario/.test(key)) {
    clinical = `Quiste facetario lumbar ${level} ${side} con dolor radicular ${side} y compresión radicular. Exéresis de quiste facetario ${level} ${side}.`;
    procedure = `exéresis de quiste facetario ${level} ${side}`;
  } else if (/tumor_hipofisis/.test(key)) {
    level = 'selar';
    side = 'medial';
    clinical = `Macroadenoma hipofisario selar con compromiso visual. Abordaje endoscópico endonasal transesfenoidal y exéresis tumoral.`;
    procedure = 'abordaje endoscópico endonasal transesfenoidal';
  } else if (/tumor_|absceso|craneoplastia|trauma_craneal/.test(key)) {
    level = /fosa/.test(key) ? 'fosa posterior' : /quiste_coloide/.test(key) ? 'tercer ventrículo' : 'frontal';
    side = /quiste_coloide/.test(key) ? 'medial' : 'izquierda';
    clinical = `${label} ${level} ${side} con clínica y estudios compatibles. Craneotomía y tratamiento neuroquirúrgico ${side}.`;
    procedure = `craneotomía ${side}`;
  } else if (/vascular/.test(key)) {
    level = /tvt|mav/.test(key) ? 'lesión vascular' : 'comunicante anterior';
    side = 'izquierda';
    clinical = `${label} ${level} con indicación de tratamiento neuroquirúrgico. Craneotomía pterional ${side} y tratamiento vascular.`;
    procedure = `tratamiento vascular ${side}`;
  } else if (/chiari/.test(key)) {
    level = 'cráneo cervical';
    side = 'medial';
    clinical = `Malformación de Chiari I con cefalea occipital y siringomielia. Descompresión de fosa posterior y cráneo cervical.`;
    procedure = 'descompresión de fosa posterior';
  } else if (/aracnoideo/.test(key)) {
    level = 'temporal';
    side = 'derecha';
    clinical = `Quiste aracnoideo temporal derecho sintomático con estudios compatibles. Fenestración microquirúrgica.`;
    procedure = 'fenestración de quiste aracnoideo';
  } else if (/mielomeningocele/.test(key)) {
    level = 'lumbosacro';
    side = 'medial';
    clinical = `Mielomeningocele lumbosacro con indicación de reparación quirúrgica. Cierre por planos y reparación neural.`;
    procedure = 'reparación de mielomeningocele';
  } else if (/fistula_lcr/.test(key)) {
    level = 'base anterior';
    side = 'derecha';
    clinical = `Fístula de LCR de base anterior derecha con rinorraquia y estudios compatibles. Reparación quirúrgica.`;
    procedure = 'reparación de fístula de LCR';
  } else if (/trigemino/.test(key)) {
    level = 'ángulo pontocerebeloso';
    side = 'derecha';
    clinical = `Neuralgia del trigémino derecha refractaria al tratamiento médico. Descompresión microvascular derecha.`;
    procedure = 'descompresión microvascular trigeminal';
  } else if (/tunel_carpiano|bloqueo|sacroiliaco/.test(key)) {
    level = /sacro/.test(key) ? 'sacroilíaco' : /bloqueo/.test(key) ? 'lumbar' : 'muñeca';
    side = 'derecha';
    clinical = `${label} ${side} con síntomas concordantes y respuesta insuficiente al tratamiento conservador. Procedimiento correspondiente ${side}.`;
    procedure = `${label} ${side}`;
  } else if (/monitoreo_pic|valvulas_hidrocefalia/.test(key)) {
    level = /monitoreo/.test(key) ? 'frontal' : 'ventricular';
    side = 'derecha';
    clinical = /monitoreo/.test(key)
      ? `Traumatismo craneal grave con indicación de monitoreo de presión intracraneana. Colocación de sensor frontal derecho.`
      : `Hidrocefalia sintomática con trastorno de la marcha y deterioro cognitivo. Colocación de válvula de derivación ventrículo peritoneal derecha.`;
    procedure = /monitoreo/.test(key) ? 'colocación de sensor de PIC' : 'derivación ventrículo peritoneal derecha';
  } else if (/neurofisiologia/.test(key)) {
    level = 'intraoperatorio';
    side = 'bilateral';
    clinical = `Monitoreo neurofisiológico intraoperatorio en procedimiento de columna con riesgo neurológico.`;
    procedure = 'monitorización neurofisiológica intraoperatoria';
  }

  return {
    family: key,
    label,
    level,
    side,
    input: `${clinical} ${procedure}.`,
  };
}

function runHandoff(args) {
  const argv = [HANDOFF];
  for (const [key, value] of Object.entries(args)) {
    if (value === undefined || value === null || value === '') continue;
    argv.push(`--${key.replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`)}`, String(value));
  }
  const result = spawnSync(NODE, argv, {
    cwd: APP_ROOT,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
    timeout: 420000,
  });
  const raw = (result.status === 0 ? result.stdout : result.stderr || result.stdout).trim();
  let parsed = null;
  try {
    parsed = raw ? JSON.parse(raw) : {};
  } catch {
    parsed = { raw };
  }
  return { status: result.status, parsed, stdout: result.stdout, stderr: result.stderr, error: result.error || null };
}

function validateDocument({ scenario, type, parsed }) {
  const failures = [];
  if (!parsed.file || !fs.existsSync(parsed.file)) {
    failures.push('pdf_no_existe');
    return { failures };
  }
  const { text, pages } = pdfText(parsed.file);
  const compact = text.replace(/\s+/g, ' ');
  for (const [key, rx] of FORBIDDEN) {
    if (rx.test(text)) failures.push(`forbidden:${key}`);
  }
  if (!compact.includes(scenario.patient)) failures.push('paciente_no_presente');
  if (!compact.includes(scenario.date)) failures.push('fecha_no_presente');
  const normalizedText = normalized(compact);
  if (requiresLevelHardCheck(scenario) && !normalizedText.includes(normalized(scenario.level))) failures.push('nivel_no_presente');
  if (requiresLateralHardCheck(scenario, type)) {
    const variants = sideVariants(scenario.side);
    if (!variants.some((variant) => normalizedText.includes(variant))) failures.push('lateralidad_no_presente');
  }
  if (type === 'hc') {
    for (const section of ['Motivo de ingreso', 'Enfermedad actual', 'Examen físico', 'Estudios', 'Plan']) {
      if (!compact.includes(section)) failures.push(`hc_sin_${section.replace(/\s+/g, '_')}`);
    }
  }
  if (type === 'parte') {
    for (const [key, rx] of [
      ['posicion', /Paciente en dec[uú]bito|posicionamiento/i],
      ['proteccion_ocular', /protecci[oó]n ocular/i],
      ['acolchado', /acolchado de puntos de apoyo/i],
      ['antisepsia', /Antisepsia|antisepsia/i],
      ['profilaxis', /profilaxis antibi[oó]tica/i],
      ['hemostasia', /Hemostasia|hemostasia/i],
      ['cierre', /Cierre|cierre|curaci[oó]n/i],
      ['incidentes', /No se registraron incidentes|no se registraron complicaciones/i],
    ]) {
      if (!rx.test(text)) failures.push(`parte_sin_${key}`);
    }
  }
  return { pages, failures };
}

function main() {
  fs.mkdirSync(QA_DIR, { recursive: true });
  const bank = JSON.parse(fs.readFileSync(BANK, 'utf8'));
  const families = Object.values(bank.families || {});
  const outputs = [];
  const failures = [];

  families.forEach((family, index) => {
    const scenario = {
      ...scenarioForFamily(family),
      patient: `Paciente Matriz ${String(index + 1).padStart(2, '0')}`,
      age: String(40 + (index % 35)),
      date: '20/05/2026',
      startTime: `${String(8 + (index % 8)).padStart(2, '0')}:00`,
      endTime: `${String(9 + (index % 8)).padStart(2, '0')}:15`,
      assistants: 'Dr. Ayudante QA',
      institution: index % 3 === 0 ? 'clinica_centro' : index % 3 === 1 ? 'la_pequena_familia' : 'higa_junin',
    };
    const caseResult = { family: scenario.family, label: scenario.label, documents: [] };
    for (const type of ['hc', 'parte']) {
      const run = runHandoff({
        type,
        family: scenario.family,
        input: scenario.input,
        patient: scenario.patient,
        age: scenario.age,
        date: scenario.date,
        startTime: scenario.startTime,
        endTime: scenario.endTime,
        assistants: scenario.assistants,
        level: scenario.level,
        side: scenario.side,
        institution: scenario.institution,
      });
      const doc = {
        type,
        command_status: run.status,
        validation_status: run.parsed?.validation_status || null,
        file: run.parsed?.file || null,
        manifest: run.parsed?.manifest || null,
        failures: [],
      };
      if (run.status !== 0 || run.parsed?.ok !== true) {
        doc.failures.push(`handoff_failed:${run.parsed?.validation_status || run.status}`);
        for (const blocker of run.parsed?.blockers || []) doc.failures.push(String(blocker));
      } else {
        try {
          Object.assign(doc, validateDocument({ scenario, type, parsed: run.parsed }));
        } catch (err) {
          doc.failures.push(`pdf_text_extract_failed:${err.code || 'UNKNOWN'}`);
        }
      }
      if (doc.failures.length) {
        failures.push({ family: scenario.family, label: scenario.label, type, failures: doc.failures, file: doc.file });
      }
      caseResult.documents.push(doc);
    }
    outputs.push(caseResult);
  });

  const summary = {
    generated_at: new Date().toISOString(),
    ok: failures.length === 0,
    standard: 'all_pathology_family_matrix_v1',
    families_count: families.length,
    documents_count: outputs.reduce((sum, item) => sum + item.documents.length, 0),
    policy_state: {
      product: 'local_candidate_ready_for_user_test',
      legal_tamiz: 'BASE_AVANZADA_REVIEW_ONLY',
      terminal_legal_certification: false,
    },
    rules: [
      'HC y parte por cada una de las familias del banco local.',
      'No se exige consentimiento universal: los consentimientos dependen de madre/canónico trazable.',
      'Hard checks: identidad, fecha, nivel/lado cuando aplica, secciones HC, controles operatorios, ausencia de frases prohibidas.',
    ],
    failures,
    outputs,
  };
  const outPath = path.join(QA_DIR, `clinical_40_family_matrix_${DATE_ID}.json`);
  fs.writeFileSync(outPath, JSON.stringify(summary, null, 2) + '\n');
  console.log(JSON.stringify({
    ok: summary.ok,
    families_count: summary.families_count,
    documents_count: summary.documents_count,
    failures_count: failures.length,
    outPath,
    failures: failures.slice(0, 20),
  }, null, 2));
  if (!summary.ok) process.exit(1);
}

main();
