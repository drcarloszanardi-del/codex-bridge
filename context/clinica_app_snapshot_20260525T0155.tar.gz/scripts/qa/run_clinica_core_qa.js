#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const repo = path.resolve(__dirname, '../..');
const approvalDir = path.join(repo, 'qa/approval_gates');
const pinnedNode = '/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node';
const nodeBin = fs.existsSync(pinnedNode) ? pinnedNode : process.execPath;
const fullMode = process.argv.includes('--full');
const strictMode = process.argv.includes('--strict');

const coreSuites = [
  { script: 'validate_clinica_route_guard.js', group: 'route', timeoutMs: 300000 },
  { script: 'validate_jarvis_wrapper.js', group: 'jarvis', timeoutMs: 420000 },
  { script: 'validate_clinical_handoff.js', group: 'documents', timeoutMs: 420000 },
  { script: 'validate_consent_handoff.js', group: 'documents', timeoutMs: 420000 },
  { script: 'validate_product_mode.js', group: 'product', timeoutMs: 120000 },
  { script: 'validate_medicolegal_redaction_shield.js', group: 'medicolegal', timeoutMs: 120000 },
  { script: 'validate_clinical_inconsistency_audit.js', group: 'product', timeoutMs: 120000 },
  { script: 'validate_clinical_send_gate.js', group: 'telegram_gate', timeoutMs: 420000 },
];

const fullSuites = [
  { script: 'validate_pathology_template_bank.js', group: 'corpus', timeoutMs: 180000 },
  { script: 'validate_neurocirugia_consent_source_corpus.js', group: 'corpus', timeoutMs: 180000 },
  { script: 'validate_neuro_spine_jurisprudence_corpus.js', group: 'medicolegal', timeoutMs: 180000 },
  { script: 'validate_20_pathology_scenarios.js', group: 'clinical_scenarios', timeoutMs: 900000 },
  { script: 'validate_40_pathology_family_matrix.js', group: 'clinical_matrix', timeoutMs: 2400000 },
  { script: 'validate_jarvis_overnight_requests.js', group: 'jarvis_synthetic_requests', timeoutMs: 600000 },
  { script: 'build_clinica_operational_baseline.js', group: 'baseline', timeoutMs: 120000 },
];

const postFullSuites = [
  { script: 'validate_latest_artifacts_freshness.js', group: 'freshness', timeoutMs: 120000 },
];

const suites = fullMode ? [...coreSuites, ...fullSuites] : coreSuites;

function nowStamp() {
  return new Date().toISOString().replace(/[-:.]/g, '').slice(0, 15);
}

function runSuite(suite) {
  const started = Date.now();
  const scriptPath = path.join(__dirname, suite.script);
  const result = spawnSync(nodeBin, [scriptPath], {
    cwd: repo,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
    timeout: suite.timeoutMs,
  });
  let parsed = null;
  const stdout = String(result.stdout || '').trim();
  try {
    parsed = JSON.parse(stdout);
  } catch {}
  return {
    suite: suite.script,
    group: suite.group,
    ok: result.status === 0 && (!parsed || parsed.ok !== false),
    exit_status: result.status,
    signal: result.signal || null,
    timed_out: result.error?.code === 'ETIMEDOUT',
    duration_ms: Date.now() - started,
    parsed,
    stdout_tail: stdout.slice(-2000),
    stderr_tail: String(result.stderr || '').trim().slice(-2000),
  };
}

function markdownReport(payload) {
  const lines = [
    `# Clinica ${payload.mode} QA`,
    '',
    `Fecha: ${payload.generated_at}`,
    `Estado: ${payload.ok ? 'OK' : 'FALLA'}`,
    `Modo: ${payload.mode}`,
    `Node: ${payload.node_bin}`,
    '',
    '## Suites',
    '',
  ];
  for (const suite of payload.suites) {
    const timeout = suite.timed_out ? ' TIMEOUT' : '';
    lines.push(`- ${suite.ok ? 'OK' : 'FALLA'} ${suite.group}/${suite.suite}${timeout} (${suite.duration_ms} ms)`);
    if (!suite.ok && suite.stderr_tail) lines.push(`  - stderr: ${suite.stderr_tail.replace(/\n/g, ' ').slice(0, 500)}`);
    if (!suite.ok && suite.stdout_tail) lines.push(`  - stdout: ${suite.stdout_tail.replace(/\n/g, ' ').slice(0, 500)}`);
  }
  lines.push('', '## Politica', '');
  lines.push('- Esto valida ruta local/app/Jarvis para prueba controlada.');
  lines.push('- No convierte el tamiz medicolegal en certificacion legal terminal.');
  lines.push('- Jarvis sigue obligado a usar wrapper unico y manifiesto apto.');
  if (payload.mode === 'full') {
    lines.push('- La corrida completa agrega corpus, jurisprudencia, matriz de 40 familias, 20 escenarios y pedidos sintéticos de Jarvis.');
    lines.push('- Se verifica frescura de artefactos latest para detectar estado stale.');
  }
  return lines.join('\n') + '\n';
}

function writeReport(payload, paths) {
  fs.writeFileSync(paths.jsonPath, JSON.stringify(payload, null, 2) + '\n');
  fs.writeFileSync(paths.mdPath, markdownReport(payload));
  fs.copyFileSync(paths.jsonPath, paths.latestJson);
  fs.copyFileSync(paths.mdPath, paths.latestMd);
}

function main() {
  fs.mkdirSync(approvalDir, { recursive: true });
  const results = suites.map(runSuite);
  let failures = results.filter((suite) => !suite.ok).map((suite) => suite.suite);
  const warnings = [];
  if (!fullMode && !strictMode) warnings.push('core_only: ejecutar con --full para paquete ampliado de app/corpus/Jarvis');
  const payload = {
    ok: failures.length === 0,
    mode: fullMode ? 'full' : 'core',
    generated_at: new Date().toISOString(),
    repo,
    node_bin: nodeBin,
    policy_state: {
      product: 'local_candidate_ready_for_user_test',
      legal_tamiz: 'BASE_AVANZADA_REVIEW_ONLY',
      terminal_legal_certification: false,
    },
    failures,
    warnings,
    suites: results,
  };
  const stamp = nowStamp();
  const prefix = fullMode ? 'clinica_full_qa' : 'clinica_core_qa';
  const jsonPath = path.join(approvalDir, `${prefix}_${stamp}.json`);
  const mdPath = path.join(approvalDir, `${prefix}_${stamp}.md`);
  const latestJson = path.join(approvalDir, `${prefix}_latest.json`);
  const latestMd = path.join(approvalDir, `${prefix}_latest.md`);
  const paths = { jsonPath, mdPath, latestJson, latestMd };
  if (fullMode) {
    writeReport(payload, paths);
    const postResults = postFullSuites.map(runSuite);
    payload.suites.push(...postResults);
    failures = payload.suites.filter((suite) => !suite.ok).map((suite) => suite.suite);
    payload.failures = failures;
    payload.ok = failures.length === 0;
  }
  writeReport(payload, paths);
  console.log(JSON.stringify({
    ok: payload.ok,
    mode: payload.mode,
    failures,
    warnings,
    report: mdPath,
    json: jsonPath,
    latest_report: latestMd,
    latest_json: latestJson,
  }, null, 2));
  if (!payload.ok) process.exit(1);
}

main();
