#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const APP_ROOT = path.resolve(__dirname, '..', '..');
const QA_DIR = path.join(APP_ROOT, 'qa', 'approval_gates');

const MAX_AGE_HOURS = Number(process.env.CLINICA_QA_LATEST_MAX_AGE_HOURS || 30);
const MAX_AGE_MS = MAX_AGE_HOURS * 60 * 60 * 1000;

function expect(condition, message, failures) {
  if (!condition) failures.push(message);
}

function safeJson(filePath) {
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return null;
  }
}

function checkFresh(filePath, failures, label) {
  expect(fs.existsSync(filePath), `${label}:missing`, failures);
  if (!fs.existsSync(filePath)) return null;
  const stat = fs.statSync(filePath);
  const ageMs = Date.now() - stat.mtimeMs;
  expect(ageMs <= MAX_AGE_MS, `${label}:stale:${Math.round(ageMs / 3600000)}h`, failures);
  return { filePath, mtime: stat.mtime.toISOString(), age_hours: Number((ageMs / 3600000).toFixed(2)) };
}

function main() {
  const failures = [];
  const details = {};
  const latestCore = path.join(QA_DIR, 'clinica_core_qa_latest.json');
  const latestFull = path.join(QA_DIR, 'clinica_full_qa_latest.json');
  const latestBaseline = path.join(QA_DIR, 'clinica_operational_baseline_latest.json');
  const latestDetectOnly = path.join(QA_DIR, 'medicolegal_detect_only_update_cycle_latest.json');

  details.core = checkFresh(latestCore, failures, 'core_latest');
  details.full = checkFresh(latestFull, failures, 'full_latest');
  details.baseline = checkFresh(latestBaseline, failures, 'baseline_latest');
  details.detect_only = checkFresh(latestDetectOnly, failures, 'detect_only_latest');

  const coreJson = safeJson(latestCore);
  const fullJson = safeJson(latestFull);
  const detectOnlyJson = safeJson(latestDetectOnly);

  expect(Boolean(coreJson), 'core_latest:json_invalid', failures);
  expect(Boolean(fullJson), 'full_latest:json_invalid', failures);
  expect(Boolean(detectOnlyJson), 'detect_only_latest:json_invalid', failures);
  if (coreJson) {
    const coreSuites = new Set((coreJson.suites || []).map((suite) => suite.script || suite.suite));
    expect(coreSuites.has('validate_clinica_route_guard.js'), 'core_latest:missing_route_guard_suite', failures);
    expect(coreSuites.has('validate_jarvis_wrapper.js'), 'core_latest:missing_wrapper_suite', failures);
    expect(coreSuites.has('validate_clinical_send_gate.js'), 'core_latest:missing_send_gate_suite', failures);
  }
  if (fullJson) {
    const fullSuites = new Set((fullJson.suites || []).map((suite) => suite.script || suite.suite));
    expect(fullSuites.has('validate_40_pathology_family_matrix.js'), 'full_latest:missing_40_family_suite', failures);
    expect(fullSuites.has('validate_neurocirugia_consent_source_corpus.js'), 'full_latest:missing_consent_corpus_suite', failures);
  }
  if (detectOnlyJson) {
    expect(detectOnlyJson.mode === 'detect_only', 'detect_only_latest:mode_not_detect_only', failures);
    expect(detectOnlyJson.safety?.change_candidates_count >= 0, 'detect_only_latest:missing_safety_change_candidates', failures);
  }

  const output = {
    ok: failures.length === 0,
    generated_at: new Date().toISOString(),
    max_age_hours: MAX_AGE_HOURS,
    details,
    failures,
  };

  const outPath = path.join(QA_DIR, `latest_artifacts_freshness_${new Date().toISOString().slice(0, 10)}.json`);
  fs.writeFileSync(outPath, JSON.stringify(output, null, 2) + '\n');
  console.log(JSON.stringify(output, null, 2));
  if (!output.ok) process.exit(1);
}

main();
