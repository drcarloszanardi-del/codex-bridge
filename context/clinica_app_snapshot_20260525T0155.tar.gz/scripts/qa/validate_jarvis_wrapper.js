#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { execFileSync, spawnSync } = require('child_process');

const APP_ROOT = path.resolve(__dirname, '..', '..');
const PYTHON = '/Users/jarvis/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3';
const WRAPPER = path.join(APP_ROOT, 'scripts', 'jarvis', 'clinica_generar_y_enviar.sh');

function runWrapper(args, allowFailure = false) {
  const proc = spawnSync(WRAPPER, args, {
    cwd: APP_ROOT,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  if (!allowFailure && proc.status !== 0) {
    throw new Error(`${proc.stderr}\n${proc.stdout}`);
  }
  const output = (proc.stdout || proc.stderr).trim();
  return {
    status: proc.status,
    parsed: output ? JSON.parse(output) : {},
    stdout: proc.stdout,
    stderr: proc.stderr,
  };
}

function pdfInfo(file) {
  return JSON.parse(execFileSync(PYTHON, ['-c', `
from pypdf import PdfReader
import json, sys
r=PdfReader(sys.argv[1])
text="\\n".join((p.extract_text() or "") for p in r.pages)
print(json.dumps({"pages": len(r.pages), "text": text}, ensure_ascii=False))
  `, file], { encoding: 'utf8' }));
}

function main() {
  const hc = runWrapper([
    '--type', 'hc',
    '--family', 'lumbar_hdl',
    '--input', 'Paciente con hernia discal posterolateral L4-L5 izquierda y dolor radicular izquierdo. Microdiscectomía tubular L4-L5 izquierda.',
    '--patient', 'Paciente Wrapper',
    '--age', '61',
    '--date', '20/05/2026',
    '--start-time', '08:00',
    '--end-time', '09:00',
    '--assistants', 'Ayudante Wrapper',
    '--level', 'L4-L5',
    '--side', 'izquierda',
    '--institution', 'clinica_centro',
  ]).parsed;
  const consent = runWrapper([
    '--type', 'consent',
    '--slug', 'hernia_disco_lumbar',
    '--patient', 'Paciente Wrapper',
    '--dni', '11.111.111',
    '--date', '20/05/2026',
    '--level', 'L4-L5 izquierda',
    '--team', 'Ayudante Wrapper',
    '--institution', 'clinica_centro',
  ]).parsed;
  const blocked = runWrapper([
    '--type', 'parte',
    '--family', 'lumbar_hdl',
    '--input', 'Paciente con hernia discal lumbar y dolor radicular.',
    '--patient', 'Paciente Bloqueo Wrapper',
    '--date', '20/05/2026',
    '--institution', 'clinica_centro',
  ], true);
  const ocampoLike = runWrapper([
    '--request',
    'Parte quirúrgico. Paciente Ocampo Wrapper. Fecha 20/05/2026. Postoperatorio de cirugía cervical posterior realizada hace 10 días por colección infecciosa. Paciente con hematoma en lodge operatoria cervical posterior. Se realiza reapertura de herida cervical posterior desde C3 a C7, evacuación de hematoma de lodge operatoria, toilette quirúrgica amplia, revisión del lecho, hemostasia y colocación de drenaje.',
    '--chat-id',
    '8648521646',
  ]).parsed;

  const hcPdf = pdfInfo(hc.file);
  const consentPdf = pdfInfo(consent.file);
  const ocampoPdf = pdfInfo(ocampoLike.file);
  const ocampoManifest = JSON.parse(fs.readFileSync(ocampoLike.manifest, 'utf8'));
  const ocampoText = ocampoPdf.text;
  const checks = {
    wrapper_exists: fs.existsSync(WRAPPER),
    hc_pdf_created: hc.ok === true && fs.existsSync(hc.file) && hcPdf.pages >= 1,
    hc_validated: ['APTO_PARA_ENVIO', 'APTO_CON_OBSERVACIONES'].includes(hc.validation_status),
    consent_pdf_created: consent.ok === true && fs.existsSync(consent.file) && consentPdf.pages === 1,
    consent_validated: consent.validation_status === 'APTO_PARA_ENVIO',
    blocked_without_pdf_send: blocked.status !== 0 && blocked.parsed.validation_status === 'BLOQUEADO_NO_ENVIAR',
    ocampo_hematoma_not_laminoplasty: ocampoLike.ok === true
      && /hematoma/i.test(ocampoText)
      && /lodge/i.test(ocampoText)
      && /reapertura/i.test(ocampoText)
      && /toilette/i.test(ocampoText)
      && /drenaje/i.test(ocampoText)
      && !/laminoplast|canal estrecho cervical|mielopat/i.test(ocampoText)
      && ocampoManifest.validation.checks.no_laminoplasty_for_postoperative_wound === true,
    no_external_converter_needed: /clinical_document_handoff/.test(JSON.stringify(JSON.parse(fs.readFileSync(hc.manifest, 'utf8')))),
  };
  const failures = Object.entries(checks).filter(([, ok]) => !ok).map(([key]) => key);
  const result = { ok: failures.length === 0, checks, hc: hc.file, consent: consent.file, ocampo_like: ocampoLike.file, blocked_status: blocked.parsed.validation_status };
  console.log(JSON.stringify(result, null, 2));
  if (failures.length) process.exit(1);
}

main();
