const fs = require('fs');
const path = require('path');

const appRoot = path.resolve(__dirname, '..', '..');
const corpusPath = path.join(appRoot, 'data', 'derived', 'consent_source_corpus', 'neurocirugia_consent_source_corpus_latest.json');
const packPath = path.join(appRoot, 'data', 'derived', 'consent_canonicals', 'consent_body_pack_2026-05-19.json');
const qaDir = path.join(appRoot, 'qa', 'approval_gates');

function readJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function failIf(condition, failures, message) {
  if (condition) failures.push(message);
}

const failures = [];
failIf(!fs.existsSync(corpusPath), failures, `missing corpus ${corpusPath}`);
failIf(!fs.existsSync(packPath), failures, `missing pack ${packPath}`);

let corpus = null;
let pack = null;
if (fs.existsSync(corpusPath)) corpus = readJson(corpusPath);
if (fs.existsSync(packPath)) pack = readJson(packPath);

if (corpus) {
  failIf(corpus.privacy_mode !== 'derived_features_only_no_full_text_no_patient_names_no_source_paths', failures, 'privacy mode is not derived-only');
  failIf((corpus.total_files_seen || 0) < 1000, failures, 'too few source files seen');
  failIf((corpus.extraction_failures || 0) > 10, failures, 'too many extraction failures');
  failIf((corpus.filtered_for_consent_corpus?.unique_sources || 0) < 100, failures, 'too few unique clinical consent sources');
  failIf((corpus.filtered_for_consent_corpus?.families_count || 0) < 15, failures, 'too few consent families');

  const requiredFamilies = [
    'hernia_disco_lumbar',
    'canal_estrecho_lumbar_con_fijacion',
    'canal_estrecho_lumbar_sin_fijacion',
    'vertebroplastia_cifoplastia',
    'laminoplastia_cervical_canal_cervical',
    'hidrocefalia_derivaciones',
    'hematoma_subdural_epidural',
    'tunel_carpiano_cubital_periferico'
  ];
  for (const family of requiredFamilies) {
    failIf(!corpus.families?.[family], failures, `missing family ${family}`);
  }

  const serialized = JSON.stringify(corpus).toLowerCase();
  failIf(serialized.includes('/users/jarvis/desktop/neurocirugia/consentimientos/consentimientos/'), failures, 'full source path leaked');
  failIf(serialized.includes('autorizo a los dres'), failures, 'full legacy consent text appears to be leaked');
  failIf(serialized.includes('con mayor o menor detalle'), failures, 'legacy full prose appears to be leaked');
  failIf(corpus.entries?.some((entry) => 'source_path' in entry || 'body_text' in entry || 'raw_text' in entry), failures, 'entries contain raw source fields');
}

if (pack && corpus) {
  failIf(!pack.source_corpus_enrichment, failures, 'consent body pack lacks source corpus enrichment');
  failIf(pack.source_corpus_enrichment?.source !== corpusPath, failures, 'pack enrichment points to wrong source corpus');
  failIf(pack.source_corpus_enrichment?.filtered_for_consent_corpus?.unique_sources !== corpus.filtered_for_consent_corpus.unique_sources, failures, 'pack enrichment count mismatch');
}

const output = {
  generated_at: new Date().toISOString(),
  ok: failures.length === 0,
  corpus_path: corpusPath,
  pack_path: packPath,
  total_files_seen: corpus?.total_files_seen || 0,
  extraction_failures: corpus?.extraction_failures || 0,
  unique_sources: corpus?.filtered_for_consent_corpus?.unique_sources || 0,
  families_count: corpus?.filtered_for_consent_corpus?.families_count || 0,
  pack_enriched: Boolean(pack?.source_corpus_enrichment),
  failures
};

fs.mkdirSync(qaDir, { recursive: true });
fs.writeFileSync(path.join(qaDir, 'neurocirugia_consent_source_corpus_validation_2026-05-20.json'), JSON.stringify(output, null, 2) + '\n');
console.log(JSON.stringify(output, null, 2));
if (!output.ok) process.exit(1);

