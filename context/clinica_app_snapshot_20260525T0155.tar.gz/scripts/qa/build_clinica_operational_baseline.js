#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const appRoot = path.resolve(__dirname, '../..');
const workspace = '/Users/jarvis/.openclaw/workspace';
const qaDir = path.join(appRoot, 'qa', 'approval_gates');

const required = [
  ['product_html', path.join(appRoot, 'app/product.html')],
  ['product_logic', path.join(appRoot, 'app/app.js')],
  ['jarvis_request_guard', path.join(appRoot, 'scripts/jarvis/clinica_request_guard.js')],
  ['jarvis_wrapper', path.join(appRoot, 'scripts/jarvis/clinica_generar_y_enviar.sh')],
  ['clinical_handoff', path.join(appRoot, 'scripts/jarvis/clinical_document_handoff.js')],
  ['consent_handoff', path.join(appRoot, 'scripts/jarvis/consent_telegram_handoff.js')],
  ['telegram_text_guard', path.join(workspace, 'scripts/send_telegram_message.js')],
  ['telegram_raw_document_guard', path.join(workspace, 'scripts/send_telegram_document.js')],
  ['telegram_manifest_guard', path.join(workspace, 'scripts/telegram_send_document_guard.js')],
  ['pathology_bank', path.join(appRoot, 'data/derived/pathology_templates/pathology_template_bank_2026-05-20.json')],
  ['template_mothers', path.join(appRoot, 'data/derived/template_mothers/template_mother_registry_2026-05-20.json')],
  ['consent_mothers', path.join(appRoot, 'data/derived/consent_mothers/consent_mother_registry_2026-05-19.json')],
  ['consent_source_corpus', path.join(appRoot, 'data/derived/consent_source_corpus/neurocirugia_consent_source_corpus_latest.json')],
  ['consent_canonical_index', path.join(appRoot, 'data/derived/consent_canonicals/consent_canonical_index_2026-05-19.json')],
  ['consent_body_pack', path.join(appRoot, 'data/derived/consent_canonicals/consent_body_pack_2026-05-19.json')],
  ['medicolegal_tamiz_pack', path.join(appRoot, 'data/derived/medicolegal_tamiz/medicolegal_tamiz_pack_2026-05-19.json')],
  ['jurisprudence_corpus', path.join(appRoot, 'data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_corpus_latest.json')],
  ['jurisprudence_impact_matrix', path.join(appRoot, 'data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_impact_matrix_latest.md')],
  ['corpus_doc', path.join(appRoot, 'docs/corpus_medicolegal_argentino.md')],
  ['impact_matrix_doc', path.join(appRoot, 'docs/matriz_impacto_redaccional_hc_partes.md')],
  ['rules_doc', path.join(appRoot, 'docs/reglas_internas_redaccion_medicolegal.md')],
  ['jarvis_contract_doc', path.join(appRoot, 'docs/JARVIS_CONTRATO_OPERATIVO_CLINICA_2026-05-20.md')],
  ['core_qa_latest', path.join(qaDir, 'clinica_core_qa_latest.json')],
];

const optional = [
  ['full_qa_latest', path.join(qaDir, 'clinica_full_qa_latest.json')],
  ['jarvis_overnight_requests', path.join(qaDir, 'jarvis_overnight_requests_2026-05-20.json')],
  ['clinical_20_scenarios', path.join(qaDir, 'clinical_20_pathology_scenarios_2026-05-20.json')],
  ['pathology_validation', path.join(qaDir, 'pathology_template_bank_validation_2026-05-20.json')],
  ['consent_source_validation', path.join(qaDir, 'neurocirugia_consent_source_corpus_validation_2026-05-20.json')],
  ['jurisprudence_validation', path.join(qaDir, 'neuro_spine_jurisprudence_validation_2026-05-20.json')],
];

function sha256(filePath) {
  return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
}

function fileEntry(label, filePath, requiredFlag) {
  const exists = fs.existsSync(filePath);
  const entry = {
    label,
    required: requiredFlag,
    exists,
    path: filePath,
  };
  if (!exists) return entry;
  const stat = fs.statSync(filePath);
  entry.sha256 = sha256(filePath);
  entry.size_bytes = stat.size;
  entry.mtime = stat.mtime.toISOString();
  return entry;
}

function readJson(filePath) {
  if (!fs.existsSync(filePath)) return null;
  try {
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch {
    return null;
  }
}

function pickMetrics() {
  const pathology = readJson(path.join(appRoot, 'data/derived/pathology_templates/pathology_template_bank_2026-05-20.json'));
  const consentSource = readJson(path.join(appRoot, 'data/derived/consent_source_corpus/neurocirugia_consent_source_corpus_latest.json'));
  const tamiz = readJson(path.join(appRoot, 'data/derived/medicolegal_tamiz/medicolegal_tamiz_pack_2026-05-19.json'));
  const coreQa = readJson(path.join(qaDir, 'clinica_core_qa_latest.json'));
  const fullQa = readJson(path.join(qaDir, 'clinica_full_qa_latest.json'));
  return {
    pathology_bank: {
      candidate_total: pathology?.candidate_total ?? pathology?.summary?.candidate_total ?? null,
      sampled_total: pathology?.sampled_total ?? pathology?.summary?.sampled_total ?? null,
      family_count: pathology?.family_count ?? pathology?.families?.length ?? null,
      privacy_mode: pathology?.privacy_mode ?? null,
    },
    consent_source_corpus: {
      total_files_seen: consentSource?.total_files_seen ?? consentSource?.summary?.total_files_seen ?? null,
      unique_sources: consentSource?.filtered_for_consent_corpus?.unique_sources ?? null,
      families_count: consentSource?.filtered_for_consent_corpus?.families_count ?? null,
      extraction_failures: consentSource?.extraction_failures?.length ?? consentSource?.extraction_failures ?? null,
    },
    medicolegal_tamiz: {
      status: tamiz?.status ?? tamiz?.mode ?? null,
      gates_total: tamiz?.gates?.length ?? null,
      critical_gates: Array.isArray(tamiz?.gates) ? tamiz.gates.filter((gate) => gate.severity === 'critical').length : null,
    },
    qa: {
      core_ok: coreQa?.ok ?? null,
      full_ok: fullQa?.ok ?? null,
      core_generated_at: coreQa?.generated_at ?? null,
      full_generated_at: fullQa?.generated_at ?? null,
    },
  };
}

function markdown(payload) {
  const lines = [
    '# Clinica Operational Baseline',
    '',
    `Fecha: ${payload.generated_at}`,
    `Estado: ${payload.ok ? 'OK' : 'FALLA'}`,
    `Producto: ${payload.policy_state.product}`,
    `Tamiz medico-legal: ${payload.policy_state.legal_tamiz}`,
    '',
    '## Archivos Requeridos',
    '',
  ];
  for (const entry of payload.files.filter((item) => item.required)) {
    lines.push(`- ${entry.exists ? 'OK' : 'FALTA'} ${entry.label}: ${entry.path}`);
  }
  lines.push('', '## Archivos Opcionales', '');
  for (const entry of payload.files.filter((item) => !item.required)) {
    lines.push(`- ${entry.exists ? 'OK' : 'FALTA'} ${entry.label}: ${entry.path}`);
  }
  lines.push('', '## Metricas', '');
  lines.push(`- Familias de patologias: ${payload.metrics.pathology_bank.family_count ?? 'sin dato'}`);
  lines.push(`- Candidatos de plantillas: ${payload.metrics.pathology_bank.candidate_total ?? 'sin dato'}`);
  lines.push(`- Fuentes unicas de consentimientos: ${payload.metrics.consent_source_corpus.unique_sources ?? 'sin dato'}`);
  lines.push(`- Familias de consentimientos fuente: ${payload.metrics.consent_source_corpus.families_count ?? 'sin dato'}`);
  lines.push(`- Core QA: ${payload.metrics.qa.core_ok === true ? 'OK' : 'pendiente/falla'}`);
  lines.push(`- Full QA: ${payload.metrics.qa.full_ok === true ? 'OK' : 'pendiente/falla'}`);
  lines.push('', '## Limites', '');
  lines.push('- Este baseline fija artefactos y hashes; no certifica juridicamente el contenido.');
  lines.push('- Jarvis sigue sin permiso para redactar documentos clinicos por fuera del wrapper.');
  return lines.join('\n') + '\n';
}

function main() {
  fs.mkdirSync(qaDir, { recursive: true });
  const files = [
    ...required.map(([label, filePath]) => fileEntry(label, filePath, true)),
    ...optional.map(([label, filePath]) => fileEntry(label, filePath, false)),
  ];
  const missingRequired = files.filter((entry) => entry.required && !entry.exists).map((entry) => entry.label);
  const payload = {
    ok: missingRequired.length === 0,
    generated_at: new Date().toISOString(),
    app_root: appRoot,
    policy_state: {
      product: 'local_candidate_ready_for_user_test',
      legal_tamiz: 'BASE_AVANZADA_REVIEW_ONLY',
      terminal_legal_certification: false,
      jarvis_role: 'nexo_only_wrapper_and_telegram',
    },
    missing_required: missingRequired,
    metrics: pickMetrics(),
    files,
  };
  const stamp = payload.generated_at.replace(/[-:.]/g, '').slice(0, 15);
  const jsonPath = path.join(qaDir, `clinica_operational_baseline_${stamp}.json`);
  const mdPath = path.join(qaDir, `clinica_operational_baseline_${stamp}.md`);
  const latestJson = path.join(qaDir, 'clinica_operational_baseline_latest.json');
  const latestMd = path.join(qaDir, 'clinica_operational_baseline_latest.md');
  fs.writeFileSync(jsonPath, JSON.stringify(payload, null, 2) + '\n');
  fs.writeFileSync(mdPath, markdown(payload));
  fs.copyFileSync(jsonPath, latestJson);
  fs.copyFileSync(mdPath, latestMd);
  console.log(JSON.stringify({ ok: payload.ok, missing_required: missingRequired, json: jsonPath, report: mdPath }, null, 2));
  if (!payload.ok) process.exit(1);
}

main();
