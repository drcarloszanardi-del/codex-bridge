#!/usr/bin/env bash
set -euo pipefail

APP_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
NODE_BIN="${OPENCLAW_NODE:-/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node}"
LOG_DIR="${APP_ROOT}/logs"
STATE_DIR="${APP_ROOT}/state"

mkdir -p "${LOG_DIR}" "${STATE_DIR}"

{
  echo "=== $(date -u +%Y-%m-%dT%H:%M:%SZ) clinical inconsistency once ==="
  "${NODE_BIN}" "${APP_ROOT}/scripts/qa/validate_clinical_inconsistency_audit.js"
  "${NODE_BIN}" "${APP_ROOT}/scripts/qa/validate_product_mode.js"
  date -u +%Y-%m-%dT%H:%M:%SZ > "${STATE_DIR}/clinical_inconsistency_last_ok.txt"
} >> "${LOG_DIR}/clinical_inconsistency_contralor.log" 2>&1
