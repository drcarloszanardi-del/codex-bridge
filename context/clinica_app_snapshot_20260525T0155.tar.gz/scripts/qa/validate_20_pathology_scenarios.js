#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { execFileSync, spawnSync } = require('child_process');

const APP_ROOT = path.resolve(__dirname, '..', '..');
const WORKSPACE = '/Users/jarvis/.openclaw/workspace';
const NODE = process.env.OPENCLAW_NODE || '/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node';
const PYTHON = process.env.CLINICA_PYTHON || '/Users/jarvis/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3';
const HANDOFF = path.join(APP_ROOT, 'scripts', 'jarvis', 'clinical_document_handoff.js');
const QA_DIR = path.join(APP_ROOT, 'qa', 'approval_gates');
const DATE_ID = new Date().toISOString().slice(0, 10);
const HANDOFF_TIMEOUT_MS = Number(process.env.CLINICA_QA_HANDOFF_TIMEOUT_MS || 420000);
const PDF_TEXT_TIMEOUT_MS = Number(process.env.CLINICA_QA_PDF_TEXT_TIMEOUT_MS || 60000);

const FORBIDDEN_COMMON = [
  ['radiculalgia', /\bradiculalgia\b/i],
  ['y_o', /\by\/o\b/i],
  ['si_corresponde', /\bsi correspond(?:e|en|iera|iese|a)\b/i],
  ['cuando_corresponda', /\bcuando correspond(?:a|e|ia|ía|iera|iese)\b/i],
  ['segun_corresponda', /\bseg[uú]n corresponda\b/i],
  ['si_aplica', /\bsi aplica\b/i],
  ['relato_origen', /Relato de origen/i],
  ['trazabilidad_clinica', /Trazabilidad clínica/i],
  ['lateralidad_placeholder', /lateralidad informada por el médico|nivel informado por el médico/i],
  ['completar_placeholder', /\bcompletar\b|\[completar\]|\[nivel|\[fecha\]|\[DNI\]|\[paciente\]/i],
  ['validar_placeholder', /\bvalidar\b/i],
  ['tratado_anatomia', /hernia posterolateral\/central habitual|ra[ií]z pasante|ra[ií]z saliente/i],
  ['diagnostico_cervical_ambiguo', /mielopat[ií]a o compromiso neurol[oó]gico/i],
  ['cervical_si_corresponden', /signos piramidales si/i],
  ['cuadro_clinico_compatible_trastorno', /cuadro cl[ií]nico compatible con trastorno/i],
];

const CASES = [
  {
    id: 'T01',
    family: 'columna_lumbar_hernia_disco',
    level: 'L4-L5',
    side: 'izquierda',
    consentSlug: 'hernia_disco_lumbar',
    input: 'Hernia de disco lumbar posterolateral L4-L5 izquierda con lumbalgia y dolor radicular izquierdo. RM con extrusión discal L4-L5 izquierda. Microdiscectomía tubular L4-L5 izquierda.',
    expect: { hc: [/radiculopat[ií]a L5 izquierda/i, /RM donde se evidencia extrusi[oó]n discal.*L4-L5.*izquierda/i], parte: [/(Marcaci[oó]n|control) radiosc[oó]pic[oa][\s\S]*L4-L5/i, /paramediana izquierda/i] },
  },
  {
    id: 'T02',
    family: 'columna_lumbar_hernia_disco',
    level: 'L4-L5',
    side: 'derecha',
    consentSlug: 'hernia_disco_lumbar',
    input: 'Hernia de disco extraforaminal L4-L5 derecha con dolor radicular derecho. RM con extrusión discal foraminal/extraforaminal L4-L5 derecha. Microdiscectomía L4-L5 derecha.',
    expect: {
      hc: [/radiculopat[ií]a L4 derecha/i, /extrusi[oó]n discal.*L4-L5.*derecha/i],
      parte: [/L4-L5/i, /derecha/i, /abordaje paravertebral[\s\S]{0,120}foraminal[\s\S]{0,80}extraforaminal/i, /ra[ií]z L4/i],
    },
    forbid: {
      parte: [/espacio interlaminar/i, /hemilaminotom[ií]a/i, /flavectom[ií]a/i, /hombro de la ra[ií]z/i, /ra[ií]z pasante/i],
    },
  },
  {
    id: 'T03',
    family: 'columna_lumbar_canal_estrecho',
    level: 'L4-L5',
    side: 'bilateral',
    consentSlug: 'canal_estrecho_lumbar_sin_fijacion',
    input: 'Canal estrecho lumbar L4-L5 con claudicación neurogénica y lumbalgia. Recalibraje y descompresión lumbar L4-L5 bilateral sin implantes.',
    expect: { hc: [/canal estrecho lumbar|estenosis/i, /claudicaci[oó]n/i], parte: [/control radiosc[oó]pico/i, /descompresi[oó]n/i] },
  },
  {
    id: 'T04',
    family: 'columna_lumbar_fijacion_transpedicular',
    level: 'L4-L5',
    side: 'bilateral',
    consentSlug: 'canal_estrecho_lumbar_con_fijacion',
    input: 'Inestabilidad asociada a patología degenerativa L4-L5 con canal estrecho y claudicación neurogénica. Descompresión, fijación transpedicular y artrodesis L4-L5.',
    expect: { hc: [/inestabilidad asociada a patolog[ií]a degenerativa|patolog[ií]a degenerativa lumbar/i], parte: [/chequeo del material/i, /control radiosc[oó]pico/i] },
  },
  {
    id: 'T05',
    family: 'columna_lumbar_espondilolistesis',
    level: 'L5-S1',
    side: 'bilateral',
    consentSlug: 'canal_estrecho_lumbar_con_fijacion',
    input: 'Espondilolistesis L5-S1 con lumbalgia mecánica, dolor radicular y limitación funcional. Descompresión, reducción parcial, fijación pedicular y artrodesis L5-S1.',
    expect: { hc: [/espondilolistesis|patolog[ií]a degenerativa lumbar/i, /L5-S1/i], parte: [/chequeo del material/i, /L5-S1/i] },
  },
  {
    id: 'T06',
    family: 'columna_lumbar_360_circunferencial',
    level: 'L4-L5',
    side: 'izquierda',
    consentSlug: 'canal_estrecho_lumbar_con_fijacion',
    input: 'Patología degenerativa L4-L5 con inestabilidad y estenosis foraminal izquierda. Fijación circunferencial 360 L4-L5 con descompresión e intersomática.',
    expect: { hc: [/L4-L5/i, /inestabilidad/i], parte: [/chequeo del material/i, /intersom[aá]tic/i] },
  },
  {
    id: 'T07',
    family: 'columna_interespinoso_coflex_diam',
    level: 'L4-L5',
    side: 'bilateral',
    input: 'Estenosis lumbar dinámica L4-L5 con claudicación neurogénica. Descompresión y colocación de dispositivo interespinoso Coflex L4-L5.',
    expect: { hc: [/estenosis|canal estrecho/i, /L4-L5/i], parte: [/control radiosc[oó]pico/i, /Coflex|interespinoso|dispositivo/i] },
  },
  {
    id: 'T08',
    family: 'columna_cervical_disco_fusion',
    level: 'C5-C6',
    side: 'derecha',
    consentSlug: 'artroplastia_cervical',
    input: 'Hernia discal cervical C5-C6 derecha con cervicobraquialgia y dolor radicular derecho. Discectomía cervical anterior y artrodesis C5-C6.',
    expect: { hc: [/C5-C6/i, /dolor radicular/i], parte: [/abordaje|Incisi[oó]n/i, /C5-C6/i] },
  },
  {
    id: 'T09',
    family: 'columna_cervical_artroplastia',
    level: 'C5-C6',
    side: 'derecha',
    consentSlug: 'artrodesis_cervical',
    input: 'Hernia discal cervical C5-C6 derecha con dolor radicular derecho. Discectomía cervical anterior y artroplastia cervical C5-C6.',
    expect: { hc: [/C5-C6/i, /dolor radicular/i], parte: [/artroplastia|pr[oó]tesis|implante/i, /C5-C6/i] },
  },
  {
    id: 'T10',
    family: 'columna_cervical_laminoplastia',
    level: 'C3-C7',
    side: 'bilateral',
    consentSlug: 'laminoplastia_cervical',
    input: 'Canal estrecho cervical C3-C7 con mielopatía, trastorno de la marcha y torpeza manual. Laminoplastia cervical C3-C7.',
    expect: { hc: [/Enfermedad actual:\s*Trastorno de la marcha/i, /C3-C7/i], parte: [/laminoplastia/i, /C3-C7/i] },
  },
  {
    id: 'T11',
    family: 'columna_vertebroplastia',
    level: 'D12',
    side: 'bilateral',
    consentSlug: 'cifoplastia_vertebroplastia',
    input: 'Fractura aplastamiento vertebral D12 dolorosa con edema en RM. Vertebroplastia percutánea D12 con control radioscópico.',
    expect: { hc: [/fractura|aplastamiento/i, /D12/i], parte: [/control radiosc[oó]pico/i, /cemento|vertebroplastia/i] },
  },
  {
    id: 'T12',
    family: 'columna_cifoplastia',
    level: 'L1',
    side: 'bilateral',
    consentSlug: 'cifoplastia_vertebroplastia',
    input: 'Fractura vertebral L1 dolorosa con acuñamiento y edema. Cifoplastia L1 con balón y cemento.',
    expect: { hc: [/fractura|acuñamiento/i, /L1/i], parte: [/cifoplastia|bal[oó]n|cemento/i, /L1/i] },
  },
  {
    id: 'T13',
    family: 'columna_biopsia_vertebral',
    level: 'D8',
    side: 'bilateral',
    consentSlug: 'biopsia_vertebral_mas_cifoplastia_vertebroplastia',
    input: 'Lesión vertebral D8 de etiología a determinar. Biopsia vertebral percutánea D8 guiada por radioscopia.',
    expect: { hc: [/lesi[oó]n vertebral|biopsia/i, /D8/i], parte: [/biopsia/i, /D8/i] },
  },
  {
    id: 'T14',
    family: 'columna_infeccion_desbridamiento_retiro',
    level: 'D7-D8',
    side: 'bilateral',
    consentSlug: 'espondilodiscitis_dorsal_higa_junin',
    input: 'Espondilodiscitis dorsal D7-D8 con dolor, compromiso infeccioso y necesidad de desbridamiento. Descompresión, toma de muestra, desbridamiento y fijación dorsal.',
    expect: { hc: [/espondilodiscitis|infecci[oó]n/i, /D7-D8/i], parte: [/muestra|cultivo|desbridamiento|fijaci[oó]n/i] },
  },
  {
    id: 'T15',
    family: 'columna_quiste_facetario',
    level: 'L4-L5',
    side: 'derecha',
    consentSlug: 'exeresis_quiste_facetario_lumbar_sin_fijacion',
    input: 'Quiste facetario lumbar L4-L5 derecho con dolor radicular derecho y compresión radicular. Exéresis de quiste facetario L4-L5 derecho.',
    expect: { hc: [/quiste facetario/i, /L4-L5/i], parte: [/quiste/i, /derecha/i] },
  },
  {
    id: 'T16',
    family: 'tumor_meningioma',
    level: 'frontal',
    side: 'izquierda',
    input: 'Meningioma frontal izquierdo con cefalea y crisis comicial. Craneotomía frontal izquierda y exéresis tumoral.',
    expect: { hc: [/meningioma/i, /frontal izquierda/i], parte: [/craneotom[ií]a|abordaje/i, /ex[eé]resis|resecci[oó]n/i] },
  },
  {
    id: 'T17',
    family: 'tumor_hipofisis_base_craneo',
    level: 'selar',
    side: 'medial',
    input: 'Macroadenoma hipofisario selar con compromiso visual. Abordaje endoscópico endonasal transesfenoidal y exéresis tumoral.',
    expect: { hc: [/hip[oó]fisis|macroadenoma|selar/i, /visual/i], parte: [/endonasal|transesfenoidal|endosc[oó]pico/i] },
  },
  {
    id: 'T18',
    family: 'vascular_aneurisma',
    level: 'comunicante anterior',
    side: 'izquierda',
    input: 'Aneurisma cerebral de comunicante anterior con indicación de clipado. Craneotomía pterional izquierda y clipado aneurismático.',
    expect: { hc: [/aneurisma/i, /comunicante anterior/i], parte: [/clipado|aneurisma|craneotom[ií]a/i] },
  },
  {
    id: 'T19',
    family: 'malformacion_chiari',
    level: 'cráneo cervical',
    side: 'medial',
    consentSlug: 'chiari',
    input: 'Malformación de Chiari I con cefalea occipital y siringomielia. Descompresión de fosa posterior y cráneo cervical.',
    expect: { hc: [/Chiari/i, /cefalea|siringomielia/i], parte: [/fosa posterior|cr[aá]neo cervical|descompresi[oó]n/i] },
  },
  {
    id: 'T20',
    family: 'otros_valvulas_hidrocefalia',
    level: 'ventricular',
    side: 'derecha',
    consentSlug: 'hidrocefalia_derivaciones',
    input: 'Hidrocefalia sintomática con trastorno de la marcha y deterioro cognitivo. Colocación de válvula de derivación ventrículo peritoneal derecha.',
    expect: { hc: [/hidrocefalia/i, /marcha|cognitivo/i], parte: [/v[aá]lvula|derivaci[oó]n|ventr[ií]culo/i] },
  },
];

function pdfText(file) {
  const sleepMs = (ms) => {
    Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
  };

  const waitForStableFile = (target) => {
    for (let attempt = 0; attempt < 12; attempt += 1) {
      try {
        const first = fs.statSync(target);
        if (!first.isFile() || first.size <= 0) throw new Error('file_not_ready');
        sleepMs(25);
        const second = fs.statSync(target);
        if (first.size === second.size) return;
      } catch {
        // keep retrying
      }
    }
  };

  waitForStableFile(file);

  const script = [
    'from pypdf import PdfReader',
    'import sys, json',
    'r=PdfReader(sys.argv[1])',
    'text="\\\\n".join((p.extract_text() or "") for p in r.pages)',
    'print(json.dumps({"pages": len(r.pages), "text": text}, ensure_ascii=False))',
  ].join('\n');

  const timeouts = [PDF_TEXT_TIMEOUT_MS, Math.max(PDF_TEXT_TIMEOUT_MS * 3, 120000)];
  let lastErr = null;
  for (const timeout of timeouts) {
    try {
      const raw = execFileSync(PYTHON, ['-c', script, file], {
        cwd: APP_ROOT,
        encoding: 'utf8',
        stdio: ['ignore', 'pipe', 'pipe'],
        timeout,
      }).trim();
      return JSON.parse(raw);
    } catch (err) {
      lastErr = err;
      if (err?.code === 'ETIMEDOUT') continue;
      throw err;
    }
  }
  throw lastErr;
}

function runHandoff(args) {
  const argv = [HANDOFF];
  for (const [key, value] of Object.entries(args)) {
    if (value === undefined || value === null || value === '') continue;
    argv.push(`--${key.replace(/[A-Z]/g, (m) => `-${m.toLowerCase()}`)}`, String(value));
  }
  const result = spawnSync(NODE, argv, {
    cwd: APP_ROOT,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
    timeout: HANDOFF_TIMEOUT_MS,
  });
  if (result.error) {
    return {
      status: result.status ?? 1,
      parsed: {
        ok: false,
        validation_status: 'QA_SUBPROCESS_ERROR',
        error: {
          message: result.error.message,
          code: result.error.code,
          errno: result.error.errno,
          syscall: result.error.syscall,
        },
      },
      stderr: result.stderr,
      stdout: result.stdout,
    };
  }
  const source = result.status === 0 ? result.stdout : result.stderr || result.stdout;
  let parsed = null;
  try {
    parsed = JSON.parse(String(source).trim());
  } catch {
    parsed = { raw: source.trim() };
  }
  return { status: result.status, parsed, stderr: result.stderr, stdout: result.stdout };
}

function hasAny(text, rules) {
  return rules.filter(([key, rx]) => rx.test(text)).map(([key]) => key);
}

function validateText({ item, type, text, pages }) {
  const failures = [];
  const compact = text.replace(/\s+/g, ' ');
  const forbiddenHits = hasAny(text, FORBIDDEN_COMMON);
  if (forbiddenHits.length) failures.push(`forbidden:${forbiddenHits.join(',')}`);
  if (!compact.includes(item.patient)) failures.push('paciente_no_presente');
  if (!compact.includes(item.date)) failures.push('fecha_no_presente');
  if (type === 'hc') {
    for (const section of ['Motivo de ingreso', 'Enfermedad actual', 'Examen físico', 'Estudios', 'Plan']) {
      if (!compact.includes(section)) failures.push(`hc_sin_${section.replace(/\s+/g, '_')}`);
    }
    if (/\bposible\b/i.test(text)) failures.push('hc_posible_no_admitido');
    const motorInInput = /d[eé]ficit motor|paresia|debilidad|fuerza|dorsiflexi[oó]n|hallux|pie ca[ií]do|reflejo/i.test(item.input);
    if (!motorInInput && /debilidad|paresia|dorsiflexi[oó]n|hallux|marcha en talones|d[eé]ficit motor|fuerza/i.test(text)) {
      failures.push('hc_deficit_motor_no_declarado');
    }
  }
  if (type === 'parte') {
    const requiredTokens = [
      ['Paciente en decúbito', /Paciente en dec[uú]bito|Posicionamiento/i],
      ['Antisepsia', /Antisepsia/i],
      ['Hemostasia', /Hemostasia/i],
      ['Cierre', /Cierre/i],
    ];
    for (const [token, rx] of requiredTokens) {
      if (!rx.test(text)) failures.push(`parte_sin_${token.replace(/\s+/g, '_')}`);
    }
    const cranialProcedure = /Chiari|hidrocefalia|v[aá]lvula|aneurisma|meningioma|hip[oó]fisis|cr[aá]neo|fosa posterior/i.test(`${item.family} ${item.input}`);
    if (!cranialProcedure && /columna|lumbar|cervical|L\d|C\d|D\d|vertebro|cifo|fijaci[oó]n|disco|quiste facetario/i.test(`${item.family} ${item.input}`) && !/radiosc[oó]pico|rayos|fluoroscop|neuronavegaci[oó]n/i.test(text)) {
      failures.push('parte_sin_control_imagen_o_planificacion');
    }
    if (/fijaci[oó]n|instrument|tornillo|placa|cage|caja|v[aá]lvula|interespinoso|Coflex|artroplastia/i.test(item.input) && !/chequeo del material|implante|placa|tornillo|v[aá]lvula|Coflex|pr[oó]tesis|material/i.test(text)) {
      failures.push('parte_implante_sin_material');
    }
  }
  for (const rx of item.expect?.[type] || []) {
    if (!rx.test(text)) failures.push(`expectation_missing:${rx}`);
  }
  for (const rx of item.forbid?.[type] || []) {
    if (rx.test(text)) failures.push(`case_forbidden:${rx}`);
  }
  return { type, pages, failures };
}

function baseArgs(item, type) {
  return {
    type,
    family: item.family,
    input: item.input,
    patient: item.patient,
    age: item.age,
    date: item.date,
    startTime: item.startTime,
    endTime: item.endTime,
    assistants: item.assistants,
    level: item.level,
    side: item.side,
    institution: item.institution,
  };
}

function main() {
  fs.mkdirSync(QA_DIR, { recursive: true });
  const cases = CASES.map((item, index) => ({
    ...item,
    patient: `Paciente QA ${String(index + 1).padStart(2, '0')}`,
    age: String(45 + (index % 30)),
    date: '20/05/2026',
    startTime: `${String(8 + (index % 8)).padStart(2, '0')}:00`,
    endTime: `${String(9 + (index % 8)).padStart(2, '0')}:20`,
    assistants: 'Dr. Ayudante QA',
    institution: index % 3 === 0 ? 'clinica_centro' : index % 3 === 1 ? 'la_pequena_familia' : 'higa_junin',
  }));

  const outputs = [];
  const failures = [];

  for (const item of cases) {
    console.log(`[${item.id}] start ${item.family}`);
    const caseResult = { id: item.id, family: item.family, documents: [] };
    for (const type of ['hc', 'parte']) {
      console.log(`[${item.id}] generate ${type}`);
      const run = runHandoff(baseArgs(item, type));
      const doc = {
        type,
        command_status: run.status,
        validation_status: run.parsed?.validation_status || null,
        file: run.parsed?.file || null,
        manifest: run.parsed?.manifest || null,
        warnings: run.parsed?.warnings || [],
      };
      if (run.status !== 0 || run.parsed?.ok !== true) {
        doc.failures = [`handoff_failed:${run.parsed?.validation_status || run.status}`, ...(run.parsed?.blockers || [])];
      } else {
        try {
          const { text, pages } = pdfText(run.parsed.file);
          const validation = validateText({ item, type, text, pages });
          doc.pages = pages;
          doc.failures = validation.failures;
        } catch (err) {
          doc.failures = [`pdf_text_extract_failed:${err.code || 'UNKNOWN'}`];
        }
      }
      if (doc.failures.length) failures.push({ case_id: item.id, family: item.family, type, failures: doc.failures, file: doc.file });
      caseResult.documents.push(doc);
    }
    if (item.consentSlug) {
      console.log(`[${item.id}] generate consent:${item.consentSlug}`);
      const run = runHandoff({
        ...baseArgs(item, 'consent'),
        slug: item.consentSlug,
        dni: `QA${String(outputs.length + 1).padStart(8, '0')}`,
      });
      const doc = {
        type: 'consent',
        slug: item.consentSlug,
        command_status: run.status,
        validation_status: run.parsed?.validation_status || null,
        file: run.parsed?.file || null,
        manifest: run.parsed?.manifest || null,
        failures: [],
      };
      if (run.status !== 0 || run.parsed?.ok !== true) {
        doc.failures = [`consent_handoff_failed:${run.parsed?.validation_status || run.status}`, ...(run.parsed?.failures || [])];
      } else {
        try {
          const { text, pages } = pdfText(run.parsed.file);
          doc.pages = pages;
          const consentForbidden = hasAny(text, FORBIDDEN_COMMON.filter(([key]) => !['completar_placeholder'].includes(key)));
          if (pages !== 1) doc.failures.push('consent_no_una_carilla');
          if (!/CONSENTIMIENTO INFORMADO/i.test(text)) doc.failures.push('consent_sin_titulo');
          if (!/Matr[ií]cula:\s*MP 63905 MN 116564/i.test(text)) doc.failures.push('consent_sin_matricula');
          if (consentForbidden.length) doc.failures.push(`consent_forbidden:${consentForbidden.join(',')}`);
        } catch (err) {
          doc.failures.push(`pdf_text_extract_failed:${err.code || 'UNKNOWN'}`);
        }
      }
      if (doc.failures.length) failures.push({ case_id: item.id, family: item.family, type: 'consent', failures: doc.failures, file: doc.file });
      caseResult.documents.push(doc);
    }
    outputs.push(caseResult);
  }

  const summary = {
    generated_at: new Date().toISOString(),
    ok: failures.length === 0,
    cases_count: cases.length,
    documents_count: outputs.reduce((sum, item) => sum + item.documents.length, 0),
    consent_documents_count: outputs.reduce((sum, item) => sum + item.documents.filter((doc) => doc.type === 'consent').length, 0),
    standard: 'broad_pathology_scenario_gate_v1',
    rules: [
      'sin radiculalgia, y/o, si corresponde/cuando corresponda/segun corresponda/si aplica',
      'sin placeholders visibles ni campos nivel/lateralidad informada por el medico',
      'HC con secciones basicas y sin deficit motor no declarado',
      'parte con secuencia, posicion, antisepsia, control/planificacion, hemostasia y cierre',
      'consentimiento una carilla, matricula seteada y hard gate propio',
    ],
    failures,
    outputs,
  };
  const outPath = path.join(QA_DIR, `clinical_20_pathology_scenarios_${DATE_ID}.json`);
  fs.writeFileSync(outPath, JSON.stringify(summary, null, 2));
  console.log(JSON.stringify({
    ok: summary.ok,
    cases_count: summary.cases_count,
    documents_count: summary.documents_count,
    consent_documents_count: summary.consent_documents_count,
    failures_count: failures.length,
    outPath,
    failures: failures.slice(0, 20),
  }, null, 2));
  if (!summary.ok) process.exit(1);
}

main();
