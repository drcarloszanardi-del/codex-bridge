#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { execFileSync, spawnSync } = require('child_process');

const repo = path.resolve(__dirname, '../..');
const workspace = '/Users/jarvis/.openclaw/workspace';
const nodeBin = '/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node';
const handoff = path.join(repo, 'scripts/jarvis/clinical_document_handoff.js');
const rawSend = path.join(workspace, 'scripts/send_telegram_document.js');
const guardedSend = path.join(workspace, 'scripts/telegram_send_document_guard.js');
const sendMessage = path.join(workspace, 'scripts/send_telegram_message.js');

function runJson(command, args, options = {}) {
  const raw = execFileSync(command, args, {
    cwd: repo,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
    ...options,
  }).trim();
  return JSON.parse(raw || '{}');
}

function runExit(command, args, options = {}) {
  return spawnSync(command, args, {
    cwd: repo,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
    ...options,
  });
}

function expect(condition, name, failures) {
  if (!condition) failures.push(name);
}

function main() {
  const failures = [];
  const tmpDir = path.join(repo, 'tmp');
  fs.mkdirSync(tmpDir, { recursive: true });
  const manualPdf = path.join(tmpDir, 'consentimiento_manual_sin_manifest_test.pdf');
  fs.writeFileSync(manualPdf, '%PDF-1.4\n% manual clinical test without app manifest\n%%EOF\n');

  const rawManual = runExit(nodeBin, [
    rawSend,
    '--file', manualPdf,
    '--chat-id', '8648521646',
    '--caption', 'Consentimiento informado manual sin manifiesto',
    '--dry-run',
  ]);
  const rawManualText = [rawManual.stdout, rawManual.stderr].join('\n');
  expect(rawManual.status !== 0, 'raw_send_blocks_manual_clinical_pdf', failures);
  expect(rawManualText.includes('BLOCK_CLINICAL_DOCUMENT_NO_APP_MANIFEST'), 'raw_send_reports_no_manifest', failures);

  const manualPdfOutsideClinica = path.join('/tmp', 'parte_quirurgico_manual_sin_manifest_test.pdf');
  fs.writeFileSync(manualPdfOutsideClinica, '%PDF-1.4\nPARTE QUIRURGICO\nPaciente: Test\n%%EOF\n');
  const outsideManual = runExit(nodeBin, [
    rawSend,
    '--file', manualPdfOutsideClinica,
    '--chat-id', '8648521646',
    '--caption', 'Parte quirurgico manual sin manifiesto',
    '--dry-run',
  ]);
  const outsideManualText = [outsideManual.stdout, outsideManual.stderr].join('\n');
  expect(outsideManual.status !== 0, 'raw_send_blocks_manual_clinical_pdf_outside_clinica_path', failures);
  expect(outsideManualText.includes('BLOCK_CLINICAL_DOCUMENT_NO_APP_MANIFEST'), 'raw_send_outside_clinica_reports_no_manifest', failures);

  const clinicalText = [
    'HISTORIA CLINICA',
    'Paciente: Juan Perez.',
    'Motivo de ingreso: dolor lumbar con dolor radicular.',
    'Enfermedad actual: Paciente que presenta dolor lumbar irradiado.',
    'Examen fisico: cuadro radicular concordante.',
    'Estudios: RM lumbar.',
    'Plan: microdiscectomia lumbar.',
    'Este bloque simula un documento clinico largo y debe ser bloqueado como texto libre.',
  ].join('\n');
  const clinicalTextBlocked = runExit(nodeBin, [
    sendMessage,
    '--chat-id', '8648521646',
    '--text', clinicalText,
  ]);
  const clinicalTextBlockedText = [clinicalTextBlocked.stdout, clinicalTextBlocked.stderr].join('\n');
  expect(clinicalTextBlocked.status !== 0, 'message_send_blocks_clinical_free_text', failures);
  expect(clinicalTextBlockedText.includes('BLOCK_CLINICAL_TEXT_FREEFORM'), 'message_send_reports_clinical_free_text_block', failures);

  const guardedManual = runExit(nodeBin, [
    guardedSend,
    '--file', manualPdf,
    '--chat-id', '8648521646',
    '--caption', 'Consentimiento informado manual sin manifiesto',
    '--dry-run',
  ]);
  const guardedManualText = [guardedManual.stdout, guardedManual.stderr].join('\n');
  expect(guardedManual.status !== 0, 'guarded_send_blocks_manual_clinical_pdf', failures);
  expect(guardedManualText.includes('BLOCK_CLINICAL_DOCUMENT_NO_APP_MANIFEST'), 'guarded_send_reports_no_manifest', failures);

  const validConsent = runJson(nodeBin, [
    handoff,
    '--type', 'consent',
    '--slug', 'hernia_disco_lumbar',
    '--date', '20/05/2026',
    '--level', 'L4-L5 izquierda',
    '--institution', 'clinica_centro',
  ]);
  expect(validConsent.ok === true, 'valid_consent_generated', failures);
  expect(validConsent.file && fs.existsSync(validConsent.file), 'valid_consent_file_exists', failures);

  const allowed = runExit(nodeBin, [
    guardedSend,
    '--file', validConsent.file,
    '--chat-id', '8648521646',
    '--caption', 'Consentimiento informado (hernia_disco_lumbar)',
    '--dry-run',
  ]);
  const allowedPayload = JSON.parse((allowed.stdout || '{}').trim() || '{}');
  expect(allowed.status === 0, 'guarded_send_allows_app_manifest_pdf', failures);
  expect(allowedPayload.dry_run === true, 'guarded_send_dry_run_ok', failures);
  expect(Boolean(allowedPayload.clinical_manifest), 'guarded_send_reports_manifest', failures);
  expect(allowedPayload.validation_status === 'APTO_PARA_ENVIO', 'guarded_send_reports_validation_status', failures);

  const qaHc = runJson(nodeBin, [
    handoff,
    '--type', 'hc',
    '--family', 'lumbar_hdl',
    '--input', 'Paciente QA con hernia discal L4-L5 izquierda y dolor radicular izquierdo.',
    '--patient', 'Paciente QA',
    '--age', '61',
    '--date', '20/05/2026',
    '--level', 'L4-L5',
    '--side', 'izquierda',
    '--institution', 'clinica_centro',
  ]);
  expect(qaHc.ok === true, 'qa_hc_generated_for_block_test', failures);
  expect(qaHc.file && fs.existsSync(qaHc.file), 'qa_hc_file_exists', failures);

  const qaBlocked = runExit(nodeBin, [
    guardedSend,
    '--file', qaHc.file,
    '--chat-id', '8648521646',
    '--caption', 'Historia clínica QA',
    '--dry-run',
  ]);
  const qaBlockedText = [qaBlocked.stdout, qaBlocked.stderr].join('\n');
  expect(qaBlocked.status !== 0, 'guarded_send_blocks_qa_clinical_data', failures);
  expect(qaBlockedText.includes('BLOCK_CLINICAL_DOCUMENT_TEST_DATA'), 'guarded_send_reports_qa_block', failures);

  const qaBypassAttempt = runExit(nodeBin, [
    guardedSend,
    '--file', qaHc.file,
    '--chat-id', '8648521646',
    '--caption', 'Historia clínica QA',
    '--dry-run',
  ], {
    env: { ...process.env, ALLOW_CLINICA_QA_SEND: '1' },
  });
  const qaBypassAttemptText = [qaBypassAttempt.stdout, qaBypassAttempt.stderr].join('\n');
  expect(qaBypassAttempt.status !== 0, 'guarded_send_rejects_qa_env_bypass', failures);
  expect(qaBypassAttemptText.includes('BLOCK_CLINICAL_DOCUMENT_TEST_DATA'), 'guarded_send_reports_qa_env_bypass_block', failures);

  const result = {
    ok: failures.length === 0,
    failures,
    checks: {
      raw_send_blocks_manual_clinical_pdf: rawManual.status !== 0,
      raw_send_blocks_manual_clinical_pdf_outside_clinica_path: outsideManual.status !== 0,
      message_send_blocks_clinical_free_text: clinicalTextBlocked.status !== 0,
      guarded_send_blocks_manual_clinical_pdf: guardedManual.status !== 0,
      guarded_send_allows_app_manifest_pdf: allowed.status === 0,
      guarded_send_blocks_qa_clinical_data: qaBlocked.status !== 0,
      guarded_send_rejects_qa_env_bypass: qaBypassAttempt.status !== 0,
    },
    artifacts: {
      manual_pdf: manualPdf,
      valid_consent: validConsent.file,
      valid_manifest: validConsent.manifest,
      qa_hc: qaHc.file,
      qa_manifest: qaHc.manifest,
    },
  };
  console.log(JSON.stringify(result, null, 2));
  if (!result.ok) process.exit(1);
}

main();
