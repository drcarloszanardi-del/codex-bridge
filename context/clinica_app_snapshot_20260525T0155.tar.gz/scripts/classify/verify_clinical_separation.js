#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

const root = path.resolve(__dirname, '..', '..');
const dbPath = path.join(root, 'data', 'db', 'medicolegal.sqlite');
const qaPath = path.join(root, 'qa', 'approval_gates', 'clinical_dry_run_summary.json');
const manifestPath = path.join(root, 'data', 'processed', 'metadata', 'hc_sintetica_dry_run_001.manifest.json');
const stylePath = path.join(root, 'data', 'derived', 'style_corpus', 'hc_sintetica_dry_run_001.style.txt');
const legalSeedPath = path.join(root, 'data', 'raw', 'legal', 'ley_26529_derechos_paciente_seed.txt');

const query = (sql) => JSON.parse(execFileSync('sqlite3', ['-cmd', '.timeout 5000', '-json', dbPath, sql], { encoding: 'utf8' }));
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const styleText = fs.readFileSync(stylePath, 'utf8');

const summary = {
  generatedAt: new Date().toISOString(),
  dbPath,
  manifestPath,
  stylePath,
  legalSeedPath,
  checks: {
    manifestExists: fs.existsSync(manifestPath),
    styleCorpusExists: fs.existsSync(stylePath),
    legalSeedExists: fs.existsSync(legalSeedPath),
    manifestPendingClassification: manifest.processing.classification === 'clasificacion_pendiente',
    manifestStyleSeparated: manifest.processing.styleCorpusSeparated === true,
    styleCorpusMentionsSeparation: styleText.includes('SEPARADO'),
    clinicalPendingReviewCount: query("SELECT COUNT(*) AS count FROM norm_index WHERE corpus='clinico' AND publication_state='pending_review' AND review_status='clasificacion_pendiente';")[0].count,
    legalActiveCount: query("SELECT COUNT(*) AS count FROM publication_registry WHERE publication_state='active';")[0].count,
    sourceActiveCount: query("SELECT COUNT(*) AS count FROM source_registry WHERE publication_state='active';")[0].count,
    rawDoctorCount: query("SELECT COUNT(*) AS count FROM raw_documents WHERE document_kind='historia_clinica' AND storage_path LIKE '%/data/raw/doctor/inbox/%';")[0].count
  }
};

summary.ok = summary.checks.manifestExists &&
  summary.checks.styleCorpusExists &&
  summary.checks.legalSeedExists &&
  summary.checks.manifestPendingClassification &&
  summary.checks.manifestStyleSeparated &&
  summary.checks.styleCorpusMentionsSeparation &&
  summary.checks.clinicalPendingReviewCount >= 1 &&
  summary.checks.legalActiveCount === 0 &&
  summary.checks.sourceActiveCount === 0 &&
  summary.checks.rawDoctorCount >= 1;

if (!summary.ok) {
  fs.writeFileSync(qaPath, JSON.stringify(summary, null, 2));
  process.exitCode = 1;
} else {
  fs.writeFileSync(qaPath, JSON.stringify(summary, null, 2));
}

console.log(JSON.stringify(summary, null, 2));
