#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = path.resolve(__dirname, '..', '..');
const taxonomyPath = path.join(root, 'schemas', 'cli_app_clinical_pathology_taxonomy_2026_05_18.json');
const extractorPath = path.join(root, 'schemas', 'cli_app_missing_fields_extractor_2026_05_18.json');
const reconciliationPath = path.join(root, 'data', 'processed', 'doctor', 'cli_app_generation_reconciliation_map_2026_05_18.json');
const dryRunPath = path.join(root, 'qa', 'approval_gates', 'cli_app_missing_fields_dry_run_2026_05_18.json');
const manifestPath = path.join(root, 'data', 'processed', 'doctor', 'cli_app_neuro_ingest_priority_2026_05_18.manifest.json');
const styleCorpusPath = path.join(root, 'data', 'derived', 'style_corpus', 'cli_app_neuro_ingest_priority_2026_05_18.style.txt');

const outDir = path.join(root, 'data', 'processed', 'review_only');
const outPath = path.join(outDir, 'cli_app_review_only_integration_v0_2026_05_18.json');

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, 'utf8'));
}

function sha(text) {
  return crypto.createHash('sha256').update(String(text)).digest('hex');
}

const taxonomy = readJson(taxonomyPath);
const extractor = readJson(extractorPath);
const reconciliation = readJson(reconciliationPath);
const dryRun = readJson(dryRunPath);
const manifest = readJson(manifestPath);
const styleCorpus = fs.readFileSync(styleCorpusPath, 'utf8');

const manifestBySubtree = manifest.items.reduce((acc, item) => {
  acc[item.subtree] = (acc[item.subtree] || 0) + 1;
  return acc;
}, {});

const styleHeader = styleCorpus.split(/\n+/).slice(0, 8).map((line) => {
  if (/^(### SOURCE:|CORPUS DE ESTILO|RUN_ID:|GENERATED_AT:|TOTAL_FILES|EXTRACTIONS_)/.test(line)) return line;
  return '[REDACTED_SENSITIVE_STYLE_CONTENT]';
});
const styleSensitive = /NOMBRE Y APELLIDO:|EDAD:|OS:|ANTE CUALQUIER DUDA:|FECHA DE INGRESO:/i.test(styleCorpus);

const reviewCases = dryRun.cases.map((entry) => {
  const family = taxonomy.families.find((f) => f.family_code === entry.family_code) || null;
  const template = (reconciliation.candidate_templates || []).find((t) => {
    if (!family) return false;
    return t.pathology_family && family.domain && t.pathology_family.includes(family.domain.replace('columna_', 'columna_'));
  }) || null;
  return {
    case_id: entry.case_id,
    family_code: entry.family_code,
    family_label: family ? family.label : null,
    domain: family ? family.domain : null,
    semaforo: entry.semaforo,
    publication_activation_allowed: false,
    review_only: true,
    source_guardrails: {
      phi_detected: entry.source_ref.phi_detected,
      rel_path_exposed: entry.source_ref.rel_path_exposed,
      no_literal_phi_output: entry.no_literal_phi_output,
      no_pdf_generated: entry.no_pdf_generated
    },
    selected_template: template ? {
      template_id: template.template_id,
      pathology_family: template.pathology_family,
      activation_signals_count: (template.activation_signals || []).length
    } : null,
    missing_fields_map: {
      present_count: entry.fields_present.length,
      missing_count: entry.fields_missing.length,
      fields_present: entry.fields_present,
      fields_missing: entry.fields_missing,
      blocked_inference_domains: entry.no_inference_fields_blocked
    },
    draft_contract: {
      allowed_output_keys: reconciliation.generation_contract.required_output_keys,
      final_generation_blocked: true,
      pdf_generation_allowed: false,
      human_review_required: true,
      codex_guard_required: true
    },
    alerts: entry.alerts
  };
});

const output = {
  task: 'CLI-APP-001-MEDICOLEGAL-HC-PARTES-20260517',
  generated_at: new Date().toISOString(),
  version: 'review_only_v0',
  publication_activation_allowed: false,
  pdf_generation_allowed: false,
  review_only: true,
  human_review_required: true,
  codex_guard_required: true,
  input_artifacts: {
    taxonomy: taxonomyPath,
    extractor: extractorPath,
    reconciliation_map: reconciliationPath,
    dry_run: dryRunPath,
    manifest: manifestPath,
    style_corpus: styleCorpusPath
  },
  integration_contract: {
    objective: 'paquete interno revisable para seleccionar familia, plantilla y mapa de campos faltantes sin activar generacion productiva',
    forbidden_actions: [
      'generate_final_hc',
      'generate_final_parte',
      'generate_pdf',
      'activate_publication',
      'emit_literal_phi'
    ],
    required_flags: {
      publication_activation_allowed: false,
      pdf_generation_allowed: false,
      human_review_required: true,
      codex_guard_required: true
    },
    no_invention_policy: {
      materiales: 'must_remain_missing_when_absent',
      lotes: 'must_remain_missing_when_absent',
      hallazgos: 'manual_review_only_if_missing',
      complicaciones: 'manual_review_only_if_missing'
    }
  },
  readiness_summary: {
    families_catalogued: taxonomy.families.length,
    families_with_dry_run_cases: dryRun.summary.families_with_match,
    semaforo_coverage: dryRun.summary.semaforo_coverage,
    manifest_total_items: manifest.items.length,
    manifest_by_subtree: manifestBySubtree,
    style_memory_sensitive_source_detected: styleSensitive,
    style_memory_operational_use: reconciliation.style_memory.safe_operational_use,
    review_status: 'internal_only_pending_human_review'
  },
  review_cases: reviewCases,
  risks_and_gaps: {
    blocking_gaps: [
      'style_corpus_source_contains_sensitive_local_text_and_must_not_feed any external/public output',
      'template selection remains draft and cannot trigger automatic final document generation',
      'missing fields remain unresolved for yellow/red cases and require manual completion'
    ],
    remaining_gaps_from_reconciliation: reconciliation.qa.remaining_gaps,
    style_header_preview: styleHeader
  },
  provenance_sha256: {
    taxonomy: sha(fs.readFileSync(taxonomyPath, 'utf8')),
    extractor: sha(fs.readFileSync(extractorPath, 'utf8')),
    reconciliation: sha(fs.readFileSync(reconciliationPath, 'utf8')),
    dry_run: sha(fs.readFileSync(dryRunPath, 'utf8'))
  }
};

fs.mkdirSync(outDir, { recursive: true });
fs.writeFileSync(outPath, JSON.stringify(output, null, 2));
console.log(outPath);
