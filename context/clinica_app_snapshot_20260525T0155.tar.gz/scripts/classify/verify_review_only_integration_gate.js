#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..', '..');
const integrationPath = path.join(root, 'data', 'processed', 'review_only', 'cli_app_review_only_integration_v0_2026_05_18.json');
const outPath = path.join(root, 'qa', 'approval_gates', 'cli_app_review_only_integration_gate_2026_05_18.json');

const data = JSON.parse(fs.readFileSync(integrationPath, 'utf8'));
const raw = fs.readFileSync(integrationPath, 'utf8');

function hasLiteralPhi(text) {
  const patterns = [
    /NOMBRE Y APELLIDO:/i,
    /EDAD:/i,
    /\bOS:\b/i,
    /ANTE CUALQUIER DUDA:/i,
    /FECHA DE INGRESO:/i,
    /Ver[oó]nica|Gast[oó]n|Mariela|Manso|Palazzo|Chalu|Yocca/i
  ];
  return patterns.some((re) => re.test(text));
}

const checks = [];
function addCheck(name, ok, detail) {
  checks.push({ name, status: ok ? 'ok' : 'fail', detail });
}

addCheck('publication_activation_allowed_false', data.publication_activation_allowed === false, { actual: data.publication_activation_allowed });
addCheck('pdf_generation_allowed_false', data.pdf_generation_allowed === false, { actual: data.pdf_generation_allowed });
addCheck('human_review_required_true', data.human_review_required === true, { actual: data.human_review_required });
addCheck('codex_guard_required_true', data.codex_guard_required === true, { actual: data.codex_guard_required });
addCheck('forbidden_actions_declared', Array.isArray(data.integration_contract?.forbidden_actions) && data.integration_contract.forbidden_actions.includes('generate_pdf') && data.integration_contract.forbidden_actions.includes('emit_literal_phi'), { forbidden_actions: data.integration_contract?.forbidden_actions || [] });
addCheck('review_cases_present', Array.isArray(data.review_cases) && data.review_cases.length > 0, { count: Array.isArray(data.review_cases) ? data.review_cases.length : 0 });
addCheck('all_cases_review_only', (data.review_cases || []).every((entry) => entry.review_only === true), {});
addCheck('all_cases_block_final_generation', (data.review_cases || []).every((entry) => entry.draft_contract?.final_generation_blocked === true), {});
addCheck('all_cases_no_pdf', (data.review_cases || []).every((entry) => entry.source_guardrails?.no_pdf_generated === true), {});
addCheck('all_cases_no_literal_phi_output', (data.review_cases || []).every((entry) => entry.source_guardrails?.no_literal_phi_output === true && entry.source_guardrails?.rel_path_exposed === false), {});
addCheck('no_literal_phi_in_artifact', !hasLiteralPhi(raw), {});
addCheck('no_invention_policy_declared', data.integration_contract?.no_invention_policy?.materiales === 'must_remain_missing_when_absent' && data.integration_contract?.no_invention_policy?.lotes === 'must_remain_missing_when_absent' && data.integration_contract?.no_invention_policy?.hallazgos === 'manual_review_only_if_missing' && data.integration_contract?.no_invention_policy?.complicaciones === 'manual_review_only_if_missing', data.integration_contract?.no_invention_policy || {});

const failing = checks.filter((c) => c.status === 'fail');
const output = {
  task: data.task,
  generated_at: new Date().toISOString(),
  artifact_under_test: integrationPath,
  decision: failing.length === 0 ? 'PASS_REVIEW_ONLY' : 'FAIL_REVIEW_ONLY',
  publication_activation_allowed: data.publication_activation_allowed,
  pdf_generation_allowed: data.pdf_generation_allowed,
  human_review_required: data.human_review_required,
  codex_guard_required: data.codex_guard_required,
  checks,
  summary: {
    checks_total: checks.length,
    checks_failed: failing.length,
    review_cases: Array.isArray(data.review_cases) ? data.review_cases.length : 0,
    semaforo_coverage: data.readiness_summary?.semaforo_coverage || null
  },
  readiness_note: failing.length === 0
    ? 'Paquete v0 interno revisable apto para revision humana/Codex Guard, sin publicacion ni PDF.'
    : 'Gate fallido: corregir antes de usar el paquete review_only.'
};

fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, JSON.stringify(output, null, 2));
console.log(outPath);
if (failing.length > 0) process.exit(1);
