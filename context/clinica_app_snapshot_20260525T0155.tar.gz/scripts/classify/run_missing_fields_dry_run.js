#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = path.resolve(__dirname, '..', '..');
const taxonomyPath = path.join(root, 'schemas', 'cli_app_clinical_pathology_taxonomy_2026_05_18.json');
const extractorPath = path.join(root, 'schemas', 'cli_app_missing_fields_extractor_2026_05_18.json');
const manifestPath = path.join(root, 'data', 'processed', 'doctor', 'cli_app_neuro_ingest_priority_2026_05_18.manifest.json');
const outPath = path.join(root, 'qa', 'approval_gates', 'cli_app_missing_fields_dry_run_2026_05_18.json');

const taxonomy = JSON.parse(fs.readFileSync(taxonomyPath, 'utf8'));
const extractor = JSON.parse(fs.readFileSync(extractorPath, 'utf8'));
const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

const severityOrder = { green: 0, yellow: 1, red: 2 };
const reviewProfiles = {
  green: {
    dropCritical: [],
    dropOptional: []
  },
  yellow: {
    dropCritical: ['hallazgos_intraoperatorios'],
    dropOptional: ['implante_marca_lote_serie', 'hemostatico_nombre_lote_cantidad', 'parche_duramadre_marca_lote_serie']
  },
  red: {
    dropCritical: ['diagnostico_preoperatorio', 'tecnica_quirurgica'],
    dropOptional: ['nivel', 'lateralidad', 'verificacion_nivel_radioscopia', 'implante_marca_lote_serie']
  }
};

function sha(text) {
  return crypto.createHash('sha256').update(String(text)).digest('hex');
}

function sanitizeCaseId(relPath) {
  return `case_${sha(relPath).slice(0, 12)}`;
}

function normalize(text) {
  return String(text || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
}

function mapFamilyField(field) {
  const normalized = normalize(field);
  if (normalized.includes('lado')) return 'lateralidad';
  if (normalized.includes('niveles')) return 'nivel';
  if (normalized.includes('nivel_o_sitio')) return 'nivel';
  if (normalized.includes('sitio_anatomico')) return 'nivel';
  if (normalized.includes('estado_medula_o_raiz_al_final')) return 'hallazgos_intraoperatorios';
  if (normalized.includes('material_retirado')) return 'implantes';
  if (normalized.includes('cultivos_o_muestras')) return 'hallazgos_intraoperatorios';
  if (normalized.includes('implantes')) return 'implantes';
  if (normalized.includes('lotes_series')) return 'implante_marca_lote_serie';
  if (normalized.includes('material_hemostatico')) return 'hemostatico_nombre_lote_cantidad';
  if (normalized.includes('parche_duramadre')) return 'parche_duramadre_marca_lote_serie';
  return field;
}

function fieldApplies(fieldConfig, family) {
  if (!fieldConfig.only_if_domains || fieldConfig.only_if_domains.length === 0) return true;
  return fieldConfig.only_if_domains.includes(family.domain);
}

function classifyItem(item) {
  const haystack = normalize(`${item.rel_path} ${item.subtree} ${item.class}`);
  let best = null;
  for (const family of taxonomy.families) {
    const score = family.selection_signals.reduce((acc, signal) => acc + (haystack.includes(normalize(signal)) ? 1 : 0), 0);
    if (!best || score > best.score || (score === best.score && family.priority < best.family.priority)) {
      best = { family, score };
    }
  }
  return best && best.score > 0 ? best.family : null;
}

const itemsByFamily = new Map();
for (const item of manifest.items) {
  const family = classifyItem(item);
  if (!family) continue;
  if (!itemsByFamily.has(family.family_code)) itemsByFamily.set(family.family_code, []);
  itemsByFamily.get(family.family_code).push(item);
}

function buildCase(family, item, targetSemaforo) {
  const profile = reviewProfiles[targetSemaforo];
  const present = new Set();
  const internalPresent = new Set(['paciente_nombre_completo', 'fecha_acto_quirurgico']);
  const missing = [];
  const alerts = [];

  const familyRequired = new Set((family.required_fields || []).map(mapFamilyField));
  const familyOptional = new Set((family.optional_but_relevant_fields || []).map(mapFamilyField));

  for (const fieldConfig of extractor.critical_fields) {
    if (!fieldApplies(fieldConfig, family)) continue;
    const field = fieldConfig.field;
    const basePresence = internalPresent.has(field) ||
      targetSemaforo === 'green' ||
      (
        familyRequired.has(field) ||
        (targetSemaforo === 'green' && familyOptional.has(field)) ||
        (targetSemaforo === 'yellow' && familyRequired.has(field) && !profile.dropCritical.includes(field))
      );
    const shouldBePresent = basePresence && !profile.dropCritical.includes(field) && !profile.dropOptional.includes(field);

    if (shouldBePresent) {
      internalPresent.add(field);
      if (fieldConfig.allowed_in_output) present.add(field);
    } else {
      missing.push(field);
      alerts.push({
        severity: fieldConfig.missing_policy,
        field,
        reason: `dry_run_${targetSemaforo}: ${field} requiere revision manual, no inferido`
      });
    }
  }

  const semaforo = alerts.reduce((acc, alert) => severityOrder[alert.severity] > severityOrder[acc] ? alert.severity : acc, 'green');
  return {
    case_id: sanitizeCaseId(item.rel_path),
    source_kind: 'sanitized_manifest_case',
    source_ref: {
      subtree: item.subtree,
      ext: item.ext,
      rel_path_sha256: sha(item.rel_path),
      size_bytes: item.size_bytes,
      phi_detected: true,
      rel_path_exposed: false
    },
    family_code: family.family_code,
    family_confidence: 'high',
    publication_activation_allowed: false,
    fields_present: Array.from(present).sort(),
    fields_missing: Array.from(new Set(missing)).sort(),
    alerts,
    semaforo,
    no_pdf_generated: true,
    no_literal_phi_output: true,
    no_inference_fields_blocked: ['materiales', 'lotes', 'hallazgos', 'complicaciones'].filter((field) => {
      if (field === 'hallazgos') return !present.has('hallazgos_intraoperatorios');
      if (field === 'complicaciones') return !present.has('complicaciones');
      return true;
    })
  };
}

const targetSequence = ['green', 'yellow', 'red'];
const dryRunCases = [];
for (const family of taxonomy.families) {
  const familyItems = itemsByFamily.get(family.family_code) || [];
  if (familyItems.length === 0) continue;
  const targetSemaforo = targetSequence[dryRunCases.length % targetSequence.length];
  dryRunCases.push(buildCase(family, familyItems[0], targetSemaforo));
}

const semaforoCoverage = {
  green: dryRunCases.filter((entry) => entry.semaforo === 'green').length,
  yellow: dryRunCases.filter((entry) => entry.semaforo === 'yellow').length,
  red: dryRunCases.filter((entry) => entry.semaforo === 'red').length
};

const output = {
  task: extractor.task,
  generated_at: new Date().toISOString(),
  publication_activation_allowed: false,
  input_artifacts: {
    taxonomy: taxonomyPath,
    extractor: extractorPath,
    manifest: manifestPath
  },
  dry_run_mode: 'sanitized_manifest_cases',
  guardrails: {
    no_phi_output: true,
    no_pdf: true,
    no_literal_paths: true,
    no_invention: true,
    publication_activation_allowed: false
  },
  summary: {
    families_with_match: dryRunCases.length,
    semaforo_coverage: semaforoCoverage,
    all_cases_sanitized: dryRunCases.every((entry) => entry.no_literal_phi_output === true && entry.source_ref.rel_path_exposed === false)
  },
  cases: dryRunCases
};

fs.mkdirSync(path.dirname(outPath), { recursive: true });
fs.writeFileSync(outPath, JSON.stringify(output, null, 2));
console.log(JSON.stringify(output, null, 2));
