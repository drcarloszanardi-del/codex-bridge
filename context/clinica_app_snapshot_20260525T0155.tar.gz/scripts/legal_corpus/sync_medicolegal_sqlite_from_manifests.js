#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { spawnSync } = require('child_process');

const root = path.resolve(__dirname, '..', '..');
const dbPath = path.join(root, 'data', 'db', 'medicolegal.sqlite');
const qaDir = path.join(root, 'qa', 'approval_gates');
function pickLatestManifest(dir) {
  const files = fs
    .readdirSync(dir)
    .filter((file) => /^manifest_\d{4}-\d{2}-\d{2}\.json$/.test(file))
    .sort();
  if (!files.length) return null;
  return path.join(dir, files.at(-1));
}

const manifestSpecs = [
  { layer: 'normativo', manifest: pickLatestManifest(path.join(root, 'data', 'raw', 'legal')) },
  { layer: 'jurisprudencia', manifest: pickLatestManifest(path.join(root, 'data', 'raw', 'jurisprudence')) },
  { layer: 'doctrina', manifest: pickLatestManifest(path.join(root, 'data', 'raw', 'doctrine')) },
  { layer: 'interno', manifest: pickLatestManifest(path.join(root, 'data', 'raw', 'internal')) },
];

function sha256(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

function sqlString(value) {
  if (value === null || value === undefined) return 'NULL';
  return `'${String(value).replace(/'/g, "''")}'`;
}

function inferSourceType(layer, item) {
  if (layer === 'normativo') return 'official_normative';
  if (layer === 'jurisprudencia') return 'official_judicial';
  if (layer === 'doctrina') return 'official_doctrine';
  if (layer === 'interno') return 'internal_rulebook';
  return 'manual_upload';
}

function inferDocumentKind(layer) {
  if (layer === 'normativo') return 'norma';
  if (layer === 'jurisprudencia') return 'jurisprudencia';
  if (layer === 'doctrina') return 'doctrina';
  if (layer === 'interno') return 'regla_interna';
  return 'anexo';
}

function inferJurisdiction(item) {
  if (item.jurisdiction) return item.jurisdiction;
  const text = `${item.id} ${item.title} ${item.official_url || ''}`.toLowerCase();
  if (text.includes('buenos aires') || text.includes('pba') || text.includes('gba.gob')) return 'provincia_buenos_aires';
  if (text.includes('caba') || text.includes('ciudad autonoma')) return 'caba';
  if (text.includes('federal')) return 'federal';
  return 'nacional';
}

function inferAuthority(item, layer) {
  const text = `${item.official_url || ''} ${item.title || ''}`.toLowerCase();
  if (text.includes('gba.gob') || text.includes('buenos aires')) return 'Provincia de Buenos Aires';
  if (text.includes('jusrionegro')) return 'Poder Judicial de Rio Negro';
  if (text.includes('juba.scba')) return 'SCBA/JUBA';
  if (text.includes('saij.gob')) return 'SAIJ';
  if (text.includes('mpf.gob')) return 'Ministerio Publico Fiscal';
  if (text.includes('argentina.gob') || text.includes('infoleg')) return 'Estado Nacional Argentino';
  if (layer === 'interno') return 'OpenClaw Clinica';
  return 'Fuente oficial o interna';
}

function inferPublicationDate(item) {
  if (item.publication_date) return item.publication_date;
  const text = `${item.id} ${item.title}`.toLowerCase();
  const known = [
    [/26529/, '2009-11-20'],
    [/17132/, '1967-01-31'],
    [/25326/, '2000-11-02'],
    [/25506/, '2001-12-14'],
    [/26994|cccn/, '2014-10-08'],
    [/1089/, '2012-07-06'],
    [/11179|codigo_penal/, '1984-10-29'],
    [/27706/, '2023-03-16'],
    [/393_2023|decreto-393/, '2023-07-31'],
    [/14494/, '2013-03-19'],
    [/1600_2024/, '2024-08-19'],
    [/182_2019/, '2019-03-12'],
    [/1558_2001/, '2001-12-03'],
    [/27553/, '2020-08-11'],
  ];
  for (const [rx, date] of known) if (rx.test(text)) return date;
  return String(item.fetched_at || new Date().toISOString()).slice(0, 10);
}

function shortCitation(item) {
  const text = item.title || item.id;
  return text.replace(/\s+/g, ' ').slice(0, 120);
}

function loadItems() {
  const items = [];
  for (const spec of manifestSpecs) {
    if (!fs.existsSync(spec.manifest)) continue;
    const manifest = JSON.parse(fs.readFileSync(spec.manifest, 'utf8'));
    for (const item of manifest) {
      if (!item.raw_path || !fs.existsSync(item.raw_path)) continue;
      const bytes = fs.readFileSync(item.raw_path);
      items.push({
        ...item,
        layer: spec.layer,
        absolute_raw_path: item.raw_path,
        raw_hash: item.sha256 || sha256(bytes),
        binary_hash: sha256(bytes),
        file_name: path.basename(item.raw_path),
      });
    }
  }
  return items;
}

function runSql(sql) {
  const result = spawnSync('sqlite3', [dbPath], {
    cwd: root,
    encoding: 'utf8',
    input: sql,
    stdio: ['pipe', 'pipe', 'pipe'],
  });
  if (result.status !== 0) {
    throw new Error(result.stderr || result.stdout || `sqlite3 exited ${result.status}`);
  }
  return result.stdout;
}

function main() {
  fs.mkdirSync(qaDir, { recursive: true });
  const items = loadItems();
  const now = new Date().toISOString();
  const statements = ['BEGIN;'];

  for (const item of items) {
    const sourceId = item.id;
    const rawId = `${sourceId}_raw`;
    const normId = `${sourceId}_idx`;
    const sourceType = inferSourceType(item.layer, item);
    const documentKind = inferDocumentKind(item.layer);
    const jurisdiction = inferJurisdiction(item);
    const publicationDate = inferPublicationDate(item);
    const authority = inferAuthority(item, item.layer);
    const reviewStatus = item.layer === 'interno' ? 'clasificado' : 'clasificacion_pendiente';
    const official = item.official_url && !String(item.official_url).startsWith('file://') ? 1 : 0;

    statements.push(`INSERT INTO source_registry (
      id, source_type, authority_name, title, jurisdiction, official_url, alternate_url, source_hash,
      publication_date, effective_date, control_date, vigencia_status, publication_state, review_status,
      is_official_source, notes, updated_at
    ) VALUES (
      ${sqlString(sourceId)}, ${sqlString(sourceType)}, ${sqlString(authority)}, ${sqlString(item.title || sourceId)},
      ${sqlString(jurisdiction)}, ${sqlString(item.official_url || item.final_url || 'file://local')},
      ${sqlString(item.alternate_url || null)}, ${sqlString(item.raw_hash)}, ${sqlString(publicationDate)},
      ${sqlString(publicationDate)}, ${sqlString(now.slice(0, 10))}, ${sqlString('pendiente_control')},
      ${sqlString('pending_review')}, ${sqlString(reviewStatus)}, ${official},
      ${sqlString('Sincronizado desde manifiestos detect-only; no activa reglas productivas.')}, ${sqlString(now)}
    )
    ON CONFLICT(id) DO UPDATE SET
      source_hash=excluded.source_hash,
      alternate_url=excluded.alternate_url,
      control_date=excluded.control_date,
      publication_state='pending_review',
      review_status=excluded.review_status,
      notes=excluded.notes,
      updated_at=excluded.updated_at;`);

    statements.push(`INSERT INTO raw_documents (
      id, source_id, document_kind, file_name, mime_type, storage_path, binary_hash, text_hash,
      ingestion_method, created_by, notes
    ) VALUES (
      ${sqlString(rawId)}, ${sqlString(sourceId)}, ${sqlString(documentKind)}, ${sqlString(item.file_name)},
      ${sqlString(item.content_type || 'application/octet-stream')}, ${sqlString(item.absolute_raw_path)},
      ${sqlString(item.binary_hash)}, ${sqlString(item.raw_hash)}, ${sqlString('crawler_detect_only')},
      ${sqlString('codex')}, ${sqlString('Documento raw sincronizado desde manifiesto local.')}
    )
    ON CONFLICT(id) DO UPDATE SET
      binary_hash=excluded.binary_hash,
      text_hash=excluded.text_hash,
      mime_type=excluded.mime_type,
      storage_path=excluded.storage_path,
      notes=excluded.notes;`);

    statements.push(`INSERT INTO norm_index (
      id, source_id, raw_document_id, corpus, title, short_citation, specialty,
      publication_state, vigencia_status, review_status, updated_at
    ) VALUES (
      ${sqlString(normId)}, ${sqlString(sourceId)}, ${sqlString(rawId)}, ${sqlString(item.layer)},
      ${sqlString(item.title || sourceId)}, ${sqlString(shortCitation(item))}, ${sqlString(item.layer === 'jurisprudencia' ? 'medicolegal' : 'documental')},
      ${sqlString('pending_review')}, ${sqlString('pendiente_control')}, ${sqlString(reviewStatus)}, ${sqlString(now)}
    )
    ON CONFLICT(id) DO UPDATE SET
      title=excluded.title,
      short_citation=excluded.short_citation,
      publication_state='pending_review',
      vigencia_status='pendiente_control',
      review_status=excluded.review_status,
      updated_at=excluded.updated_at;`);
  }

  statements.push('COMMIT;');
  runSql(statements.join('\n'));
  const countsRaw = runSql("select 'source_registry', count(*) from source_registry union all select 'raw_documents', count(*) from raw_documents union all select 'norm_index', count(*) from norm_index union all select 'internal_rules', count(*) from internal_rules union all select 'change_candidates', count(*) from change_candidates;");
  const counts = Object.fromEntries(countsRaw.trim().split(/\n/).filter(Boolean).map((line) => {
    const [key, value] = line.split('|');
    return [key, Number(value)];
  }));
  const summary = {
    generated_at: now,
    ok: true,
    mode: 'detect_only',
    db_path: dbPath,
    synced_sources: items.length,
    counts,
    activation_state: 'pending_review',
  };
  const out = path.join(qaDir, 'medicolegal_sqlite_sync_2026-05-20.json');
  fs.writeFileSync(out, JSON.stringify(summary, null, 2) + '\n');
  console.log(JSON.stringify(summary, null, 2));
}

main();
