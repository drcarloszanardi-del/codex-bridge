#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = path.resolve(__dirname, '..', '..');
const outDir = path.join(root, 'data', 'derived', 'medicolegal_tamiz');
const qaDir = path.join(root, 'qa', 'approval_gates');
const generatedAt = new Date().toISOString();

for (const dir of [outDir, qaDir]) fs.mkdirSync(dir, { recursive: true });

const sourceDocs = [
  'docs/corpus_medicolegal_argentino.md',
  'docs/matriz_impacto_redaccional_hc_partes.md',
  'docs/reglas_internas_redaccion_medicolegal.md',
  'docs/fuentes_actualizacion_medicolegal.md',
  'data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_corpus_latest.json',
  'data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_impact_matrix_latest.md'
].map((rel) => {
  const abs = path.join(root, rel);
  const text = fs.readFileSync(abs, 'utf8');
  return {
    rel,
    sha256: crypto.createHash('sha256').update(text).digest('hex'),
    bytes: Buffer.byteLength(text)
  };
});

const pack = {
  generated_at: generatedAt,
  status: 'review_only_detect_only',
  product_principle: 'El documento clinico sale limpio. El tamiz medico legal opera como motor lateral: detecta faltantes, propone campos y bloquea cierres inseguros sin citar leyes dentro de la historia o el parte.',
  source_docs: sourceDocs,
  update_policy: {
    mode: 'detect_only',
    sources: [
      'InfoLEG: Ley 26.529, Ley 17.132, Ley 25.326, Ley 25.506, CCCN, Decreto 1089/2012, Codigo Penal',
      'Argentina.gob.ar: Mi historia clinica y fuentes oficiales operativas',
      'SAIJ: busquedas estructuradas de jurisprudencia sobre historia clinica, consentimiento, responsabilidad medica y acto quirurgico',
      'Corpus neuro/columna: SAIJ, fallos judiciales oficiales y candidatos secundarios trazables con confiabilidad separada'
    ],
    rule: 'Todo cambio normativo o jurisprudencial queda como candidato de revision; nunca modifica plantillas reales sin aprobacion humana/Codex Guard.'
  },
  gates: [
    {
      id: 'CLI-R001',
      label: 'Identificacion completa del acto',
      severity: 'critical',
      targets: ['historia_clinica', 'parte_quirurgico', 'evolucion'],
      required_facts: ['paciente', 'edad', 'fecha', 'hora', 'institucion', 'autor'],
      foundation: 'Ley 17.132 + Ley 26.529 arts. 12-15 + Dec. 1089/2012 arts. 12 y 15',
      safe_prompt: 'Complete paciente, edad, fecha, hora, ambito y profesional antes de usar.'
    },
    {
      id: 'CLI-R002',
      label: 'Consentimiento con contenido material',
      severity: 'critical',
      targets: ['historia_clinica', 'parte_quirurgico'],
      required_facts: ['consentimiento', 'riesgos', 'alternativas'],
      foundation: 'Ley 26.529 arts. 5-6 + CCCN art. 59 + Dec. 1089/2012 art. 5',
      safe_prompt: 'No basta escribir consentimiento firmado; debe constar informacion, riesgos, beneficios, alternativas y posibilidad de rechazo.'
    },
    {
      id: 'CLI-R003',
      label: 'Correlacion clinico-radiologica',
      severity: 'high',
      targets: ['historia_clinica'],
      required_facts: ['clinica', 'examen', 'estudios', 'nivel_lateralidad'],
      foundation: 'CCCN arts. 1724-1726 + estandar de medios',
      safe_prompt: 'Una conducta invasiva debe unir sintomas, examen fisico y estudio complementario.'
    },
    {
      id: 'CLI-R004',
      label: 'Hallazgos y tecnica no genericos',
      severity: 'critical',
      targets: ['parte_quirurgico'],
      required_facts: ['abordaje', 'nivel_lateralidad', 'hallazgos', 'maniobras', 'cierre'],
      foundation: 'Ley 26.529 art. 15 + CCCN arts. 1725-1726',
      safe_prompt: 'El parte debe decir que se encontro y que se hizo, no solo nombrar el procedimiento.'
    },
    {
      id: 'CLI-R005',
      label: 'Complicaciones, incidentes y hemostasia',
      severity: 'critical',
      targets: ['parte_quirurgico', 'evolucion'],
      required_facts: ['complicaciones', 'hemostasia', 'perdida_hematica'],
      foundation: 'CCCN arts. 1710 y 1724',
      safe_prompt: 'Si no hubo incidentes debe decirse con sobriedad; si los hubo, deben narrarse con respuesta aplicada.'
    },
    {
      id: 'CLI-R006',
      label: 'Addendas sin borrado',
      severity: 'high',
      targets: ['correcciones'],
      required_facts: ['autor_addenda', 'fecha_addenda', 'motivo_addenda'],
      foundation: 'Ley 26.529 art. 13 + Dec. 1089/2012 art. 15',
      safe_prompt: 'Toda correccion posterior debe quedar como addenda trazable, no como reemplazo silencioso.'
    },
    {
      id: 'CLI-R007',
      label: 'Minima exposicion de datos sensibles',
      severity: 'high',
      targets: ['todos'],
      required_facts: ['finalidad_datos', 'destinatario'],
      foundation: 'Ley 25.326 + CP art. 156 + CCCN arts. 51-53',
      safe_prompt: 'No incluir datos, imagenes o comentarios que no aporten al acto asistencial o continuidad de cuidados.'
    },
    {
      id: 'CLI-R008',
      label: 'Justificacion clinica explicita',
      severity: 'high',
      targets: ['historia_clinica'],
      required_facts: ['motivo_conducta', 'alternativas_descartadas'],
      foundation: 'CCCN arts. 1710, 1724-1726 + SAIJ estandar de medios',
      safe_prompt: 'La indicacion debe explicar por que se elige esa conducta y no otra.'
    },
    {
      id: 'CLI-R009',
      label: 'Control final verificable',
      severity: 'critical',
      targets: ['parte_quirurgico'],
      required_facts: ['control_final', 'recuento', 'estado_final'],
      foundation: 'SAIJ eventos quirurgicos evitables + CP arts. 84 y 94',
      safe_prompt: 'Cerrar el acto con control final, recuentos/verificacion equivalente y estado al finalizar.'
    },
    {
      id: 'CLI-R010',
      label: 'Continuidad asistencial y alta',
      severity: 'high',
      targets: ['evolucion', 'historia_clinica'],
      required_facts: ['destino', 'indicaciones', 'signos_alarma', 'control'],
      foundation: 'Ley 26.529 arts. 2 y 15 + CP art. 106',
      safe_prompt: 'Toda alta o pase debe dejar instrucciones, alarma y via de reconsulta.'
    },
    {
      id: 'CLI-R011',
      label: 'Acceso/copia del consentimiento',
      severity: 'medium',
      targets: ['historia_clinica'],
      required_facts: ['copia_consentimiento', 'preguntas'],
      foundation: 'Ley 26.529 arts. 2, 5 y 14 + SAIJ acceso a consentimiento',
      safe_prompt: 'Conviene documentar copia, oportunidad de lectura y preguntas.'
    },
    {
      id: 'CLI-R012',
      label: 'Cronologia quirurgica',
      severity: 'high',
      targets: ['parte_quirurgico'],
      required_facts: ['inicio', 'secuencia', 'respuesta_desvios'],
      foundation: 'CCCN arts. 1710, 1724-1726 + CP arts. 84 y 94',
      safe_prompt: 'Narrar inicio, hallazgo, maniobra, control, incidente/respuesta y estado final.'
    },
    {
      id: 'CLI-R013',
      label: 'Imagenes y registros clinicos con finalidad explicitada',
      severity: 'high',
      targets: ['historia_clinica', 'parte_quirurgico', 'evolucion'],
      required_facts: ['finalidad_registro', 'resguardo', 'limite_circulacion'],
      foundation: 'CCCN art. 53 + Ley 25.326 + CP art. 156',
      safe_prompt: 'Toda imagen o video clinico debe dejar finalidad, resguardo y limite de circulacion.'
    },
    {
      id: 'CLI-R014',
      label: 'Transicion quirofano-recuperacion',
      severity: 'high',
      targets: ['parte_quirurgico', 'evolucion'],
      required_facts: ['egreso_quirofano', 'destino', 'responsable_recibe'],
      foundation: 'SAIJ traslado/anestesista/intervencion quirurgica + CCCN arts. 1724-1726',
      safe_prompt: 'Cerrar con condicion de egreso, destino y responsable que recibe.'
    },
    {
      id: 'CLI-R015',
      label: 'Acceso posterior verificable',
      severity: 'medium',
      targets: ['evolucion', 'alta'],
      required_facts: ['canal_acceso', 'reconsulta'],
      foundation: 'Ley 26.529 arts. 2, 5, 14 y 15',
      safe_prompt: 'Dejar canal de acceso/reconsulta y disponibilidad de documentacion relevante.'
    },
    {
      id: 'CLI-NSJ001',
      label: 'Indicacion neuro/columna con alternativas',
      severity: 'critical',
      targets: ['historia_clinica', 'consentimiento_informado'],
      required_facts: ['clinica', 'examen', 'estudios', 'motivo_conducta', 'alternativas_descartadas'],
      foundation: 'Corpus neuro/columna NSJ-001, NSJ-002, NSJ-005, NSJ-006, NSJ-010',
      safe_prompt: 'En cirugia programada de columna/neuro, unir clinica, examen, estudios e indicacion; documentar fracaso o descarte de alternativas.'
    },
    {
      id: 'CLI-NSJ002',
      label: 'Nivel, lateralidad, raiz y control por imagen',
      severity: 'critical',
      targets: ['historia_clinica', 'parte_quirurgico'],
      required_facts: ['nivel_lateralidad', 'raiz_comprometida', 'estudios', 'control_imagen'],
      foundation: 'Corpus neuro/columna NSJ-005, NSJ-006, NSJ-008, NSJ-009, NSJ-010',
      safe_prompt: 'Columna debe dejar nivel/lado/raiz cuando aplique y control por imagen/radioscopia cuando define nivel o implantes.'
    },
    {
      id: 'CLI-NSJ003',
      label: 'Seguridad intraoperatoria y respuesta a incidentes',
      severity: 'critical',
      targets: ['parte_quirurgico', 'evolucion'],
      required_facts: ['abordaje', 'proteccion_posicion', 'hemostasia', 'recuento', 'estado_final', 'complicacion_respuesta'],
      foundation: 'Corpus neuro/columna NSJ-003, NSJ-004, NSJ-007, NSJ-010',
      safe_prompt: 'El parte debe reconstruir posicion, proteccion, hallazgos, maniobras, hemostasia, recuento, respuesta ante desvio y destino.'
    },
    {
      id: 'CLI-NSJ004',
      label: 'Consentimiento neuroquirurgico especifico',
      severity: 'critical',
      targets: ['consentimiento_informado'],
      required_facts: ['consentimiento', 'consentimiento_especifico', 'riesgos', 'alternativas', 'preguntas'],
      foundation: 'Corpus neuro/columna NSJ-005, NSJ-006, NSJ-007, NSJ-009, NSJ-011, NSJ-013, NSD-001',
      safe_prompt: 'El consentimiento debe identificar patologia, procedimiento, beneficios, riesgos propios, alternativas, no tratamiento, revocacion y oportunidad de preguntas.'
    },
    {
      id: 'CLI-NSJ005',
      label: 'Urgencia neurologica con tiempos y derivacion',
      severity: 'high',
      targets: ['historia_clinica', 'evolucion'],
      required_facts: ['hora', 'examen', 'destino', 'responsable_recibe', 'secuencia'],
      foundation: 'Corpus neuro/columna NSJ-012, NSJ-013',
      safe_prompt: 'En urgencia neuro, registrar horarios, examen, medidas, comunicaciones, derivacion y condicion de traslado.'
    }
  ],
  unsafe_phrases: [
    { phrase: 'sin particularidades', risk: 'borra hallazgos relevantes si existian', replacement: 'describir hallazgos positivos y negativos utiles' },
    { phrase: 'consentimiento firmado', risk: 'formula insuficiente si no hay contenido material', replacement: 'consentimiento informado con riesgos, beneficios, alternativas y copia/disponibilidad' },
    { phrase: 'procedimiento habitual', risk: 'parte generico', replacement: 'tecnica secuencial con hallazgos, maniobras y control final' },
    { phrase: 'sin complicaciones', risk: 'puede ser seguro solo si se valido dato real', replacement: 'sin complicaciones intraoperatorias evidentes, con hemostasia/control final documentados' }
  ],
  document_policy: {
    clinical_text_must_not_include: ['citas legales', 'jurisprudencia', 'dictamen de cumplimiento legal', 'promesas de blindaje absoluto'],
    clinical_text_must_include_when_available: ['razonamiento clinico', 'nivel y lateralidad', 'hallazgos', 'tecnica', 'controles', 'evolucion', 'indicaciones'],
    missing_data_behavior: 'marcar faltante sensible; no inventar ni convertir en afirmacion.'
  }
};

const packPath = path.join(outDir, 'medicolegal_tamiz_pack_2026-05-19.json');
const qaPath = path.join(qaDir, 'medicolegal_tamiz_pack_2026-05-19_summary.json');
fs.writeFileSync(packPath, JSON.stringify(pack, null, 2));

const qa = {
  generated_at: generatedAt,
  pack_path: packPath,
  source_docs: sourceDocs,
  gates_count: pack.gates.length,
  critical_count: pack.gates.filter((gate) => gate.severity === 'critical').length,
  unsafe_phrases_count: pack.unsafe_phrases.length,
  status: 'ok_review_only_detect_only'
};
fs.writeFileSync(qaPath, JSON.stringify(qa, null, 2));
console.log(JSON.stringify(qa, null, 2));
