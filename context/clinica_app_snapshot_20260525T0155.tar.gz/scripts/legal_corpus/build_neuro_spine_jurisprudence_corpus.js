#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = path.resolve(__dirname, '..', '..');
const outDir = path.join(root, 'data', 'derived', 'jurisprudence_neuro_spine');
const qaDir = path.join(root, 'qa', 'approval_gates');
const generatedAt = new Date().toISOString();
const dateId = generatedAt.slice(0, 10);

for (const dir of [outDir, qaDir]) fs.mkdirSync(dir, { recursive: true });

function sha256(text) {
  return crypto.createHash('sha256').update(text).digest('hex');
}

const sources = {
  saijDossier: 'https://www.saij.gob.ar/docs-f/dossier-f/mala_praxis_medica.pdf',
  rionegro: 'https://fallos.jusrionegro.gov.ar',
  microjurisCarotida: 'https://aldiaargentina.microjuris.com/2022/05/20/fallos-mala-praxis-lesiones-en-la-arteria-carotida-de-una-paciente-durante-una-practica-quirurgica/',
  microjurisColumnaIndicacion: 'https://aldiaargentina.microjuris.com/2018/12/17/responsabilidad-del-medico-demandado-al-practicar-una-cirugia-que-no-era-recomendable-por-no-tratarse-de-una-situacion-de-urgencia/',
  microjurisColumnaSinMalaPraxis: 'https://aldiaargentina.microjuris.com/2017/07/31/no-existe-mala-praxis-por-parte-de-un-medico-cirujano-y-un-hospital/',
  infojudicialFleni: 'https://www.infojudicial.com.ar/areas/jurisprudencia/jurisprudencia-2019/danos-y-perjuicios-mala-praxis-medica-intervencion-qururgica-infeccion-ausencia-de-culpa-medica/130393/',
  mpfCompetencia: 'https://www.mpf.gob.ar/dictamenes/2025/VAbramovich/agosto/C_P_CIV_2343_2025_CS1.pdf',
  rancConsent: 'https://aanc.org.ar/ranc/items/show/759',
  rionegroAvendano: 'https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=e71e6494-30d0-4d45-abf9-b2bbf6e72a17&option_text=0&usarSearch=1',
  jubaRaquimedular: 'https://juba.scba.gov.ar/VerTextoCompleto.aspx?idFallo=180817',
  jubaNeurotrauma: 'https://juba.scba.gov.ar/VerTextoCompleto.aspx?idFallo=30512',
};

const records = [
  {
    id: 'NSJ-001',
    title: 'Batista Walter Jose y otros c/ Sanatorio Quintana S.A. y otro',
    tribunal: 'Camara Nacional de Apelaciones en lo Civil y Comercial Federal, Sala III',
    date: '2005-09-06',
    jurisdiction: 'Nacional - Capital Federal',
    source_url: sources.saijDossier,
    source_locator: 'SAIJ N0015875, dossier Mala Praxis Medica, paginas 16-17',
    source_type: 'official_summary',
    reliability: 'official_saij_summary',
    clinical_domain: ['neurocirugia', 'nervio_periferico', 'diagnostico_diferencial'],
    topics: ['diagnostico', 'estudios_complementarios', 'especialidad', 'pericia'],
    facts_summary: 'La ficha SAIJ diferencia la actuacion del traumatologo de la del neurocirujano ante sintomas neurologicos persistentes luego de cirugias previas.',
    legal_criterion: 'Cuando el cuadro deja de encajar en el diagnostico inicial, el especialista debe documentar reevaluacion y estudios razonables antes de sostener o repetir una conducta.',
    tamiz_rules: [
      'Historia clinica: si hay sintomas neurologicos persistentes o cambiantes, documentar reevaluacion, diagnostico diferencial y estudios pedidos.',
      'Historia clinica: no anclar la indicacion quirurgica a un diagnostico previo si el relato clinico exige nueva correlacion.',
      'Consentimiento: explicar objetivo real y limite esperable del procedimiento cuando hay secuelas o diagnostico incierto.'
    ],
    affected_documents: ['historia_clinica', 'consentimiento_informado'],
  },
  {
    id: 'NSJ-002',
    title: 'Hernandez Jose Luis c/ OSECAC y otros',
    tribunal: 'Camara Nacional de Apelaciones en lo Civil y Comercial Federal, Sala III',
    date: '2009-03-03',
    jurisdiction: 'Nacional - Capital Federal',
    source_url: sources.saijDossier,
    source_locator: 'SAIJ N0015877, dossier Mala Praxis Medica, pagina 148',
    source_type: 'official_summary',
    reliability: 'official_saij_summary',
    clinical_domain: ['neurocirugia', 'diagnostico_neurologico'],
    topics: ['estudios_complementarios', 'sintomas_nuevos', 'responsabilidad_profesional'],
    facts_summary: 'La ficha atribuye relevancia a no haber completado estudios necesarios frente a nueva presentacion neurologica.',
    legal_criterion: 'La defensa mejora cuando la historia muestra por que se pidieron o no se pidieron estudios, con base en sintomas y examen.',
    tamiz_rules: [
      'Historia clinica: incluir sintomas cardinales, examen neurologico util y estudio que sostiene la conducta.',
      'Historia clinica: si el caso es programado, dejar explicitado por que no se espera o por que no se elige alternativa menos invasiva.',
      'Parte quirurgico: sostener hallazgos y secuencia para que la pericia futura pueda reconstruir lex artis.'
    ],
    affected_documents: ['historia_clinica', 'parte_quirurgico'],
  },
  {
    id: 'NSJ-003',
    title: 'Hernandez Jose Luis c/ OSECAC y otros - riesgo quirurgico y negligencia',
    tribunal: 'Camara Nacional de Apelaciones en lo Civil y Comercial Federal, Sala III',
    date: '2009-03-03',
    jurisdiction: 'Nacional - Capital Federal',
    source_url: sources.saijDossier,
    source_locator: 'SAIJ D0134737, dossier Mala Praxis Medica, paginas 146-147',
    source_type: 'official_summary',
    reliability: 'official_saij_summary',
    clinical_domain: ['neurocirugia', 'acto_quirurgico'],
    topics: ['complicaciones', 'riesgo_quirurgico', 'hemostasia', 'infeccion'],
    facts_summary: 'El sumario advierte que invocar en abstracto una complicacion o riesgo quirurgico no basta si no se explica cientificamente el obstaculo o la respuesta.',
    legal_criterion: 'Ante un evento intraoperatorio o postoperatorio, la documentacion debe mostrar mecanismo, control, medidas adoptadas y estado final.',
    tamiz_rules: [
      'Parte quirurgico: no usar formulas genericas para incidentes; si hubo desvio, narrar mecanismo, control y respuesta.',
      'Parte quirurgico: si no hubo incidentes evidentes, cerrar con hemostasia, recuento, control final y destino.',
      'Evolucion: ante infeccion, sangrado, deficit o LCR, documentar deteccion, conducta y seguimiento.'
    ],
    affected_documents: ['parte_quirurgico', 'evolucion'],
  },
  {
    id: 'NSJ-004',
    title: 'Hernandez Jose Luis c/ OSECAC y otros - rol de cirujano y ayudante',
    tribunal: 'Camara Nacional de Apelaciones en lo Civil y Comercial Federal, Sala III',
    date: '2009-03-03',
    jurisdiction: 'Nacional - Capital Federal',
    source_url: sources.saijDossier,
    source_locator: 'SAIJ D0134739, dossier Mala Praxis Medica, paginas 146-147',
    source_type: 'official_summary',
    reliability: 'official_saij_summary',
    clinical_domain: ['neurocirugia', 'acto_quirurgico'],
    topics: ['equipo_quirurgico', 'roles', 'responsabilidad_personal'],
    facts_summary: 'El sumario distingue la planificacion/ejecucion del cirujano de la funcion de asistencia del ayudante.',
    legal_criterion: 'El parte debe identificar equipo y roles sin diluir la direccion tecnica del acto.',
    tamiz_rules: [
      'Parte quirurgico: consignar cirujano, ayudantes y rol operativo sin usar formulas ambiguas.',
      'Parte quirurgico: el cirujano principal debe quedar identificado como responsable de indicacion tecnica y secuencia operatoria.',
      'Consentimiento: autorizacion dirigida al profesional/equipo identificado, no solo a la institucion.'
    ],
    affected_documents: ['parte_quirurgico', 'consentimiento_informado'],
  },
  {
    id: 'NSJ-005',
    title: 'V. L. M. N. y otros c/ E. R. J. y otro',
    tribunal: 'Camara Nacional de Apelaciones en lo Civil, Sala H',
    date: '2018-10-17',
    jurisdiction: 'Nacional - Capital Federal',
    source_url: sources.microjurisColumnaIndicacion,
    source_locator: 'Microjuris MJJ115305, fallo publico, lineas 62-82 y 207-215 relevadas',
    source_type: 'secondary_public_full_text',
    reliability: 'secondary_full_text_pending_official_copy',
    clinical_domain: ['columna_lumbar', 'lumbociatalgia', 'artrodesis'],
    topics: ['indicacion_quirurgica', 'alternativas_conservadoras', 'durotomia', 'lesion_radicular'],
    facts_summary: 'Se responsabilizo por una indicacion quirurgica no urgente sin agotar alternativas menos invasivas y por mala resolucion de complicacion raquidea.',
    legal_criterion: 'La historia debe justificar con precision por que la cirugia es necesaria y por que las alternativas conservadoras no alcanzan o no aplican al caso.',
    tamiz_rules: [
      'Historia clinica: en cirugia programada de columna, documentar fracaso del tratamiento conservador o motivo concreto de indicacion directa.',
      'Consentimiento: incluir alternativas razonables, no tratamiento y riesgos propios de columna: lesion radicular, lesion dural/LCR, deficit neurologico, dolor residual y reintervencion.',
      'Parte quirurgico: si ocurre durotomia, LCR o lesion radicular, describir reparacion, interconsulta o conducta concreta.'
    ],
    affected_documents: ['historia_clinica', 'parte_quirurgico', 'consentimiento_informado'],
  },
  {
    id: 'NSJ-006',
    title: 'R. C. c/ Fundacion para la Lucha contra Enfermedades Neurologicas y otros',
    tribunal: 'Camara Nacional de Apelaciones en lo Civil, Sala J',
    date: '2019-05-09',
    jurisdiction: 'Nacional - Capital Federal',
    source_url: sources.infojudicialFleni,
    source_locator: 'Infojudicial, fallo publico, lineas 100-116 y 140-141 relevadas',
    source_type: 'secondary_public_full_text',
    reliability: 'secondary_full_text_pending_official_copy',
    clinical_domain: ['columna_lumbar', 'hernia_disco', 'infeccion_sitio_quirurgico'],
    topics: ['infeccion', 'recidiva', 'historia_clinica', 'consentimiento'],
    facts_summary: 'Caso de hernia de disco con cirugias y complicaciones infecciosas; el analisis pericial valoro antecedentes, signos documentados, estudios y consentimiento sobre recidiva.',
    legal_criterion: 'Los eventos adversos de columna se valoran con historia, signos, imagenes, consentimiento especifico y conducta de seguimiento, no solo por el resultado.',
    tamiz_rules: [
      'Historia clinica: describir signos y sintomas presentes sin inventar deficit; si hay deficit motor, consignarlo solo si fue informado.',
      'Consentimiento: para hernia discal debe incluir recidiva, infeccion, dolor residual, fibrosis, lesion dural/LCR y reintervencion.',
      'Parte quirurgico/evolucion: ante infeccion, toilette o recidiva, documentar hallazgo, cultivo/tratamiento si existe y razon de reintervencion.'
    ],
    affected_documents: ['historia_clinica', 'parte_quirurgico', 'consentimiento_informado', 'evolucion'],
  },
  {
    id: 'NSJ-007',
    title: 'M. G. L. c/ Asociacion Civil Hospital Aleman',
    tribunal: 'Camara Nacional de Apelaciones en lo Civil, Sala C',
    date: '2022-04-13',
    jurisdiction: 'Nacional - Capital Federal',
    source_url: sources.microjurisCarotida,
    source_locator: 'Microjuris MJJ136905, fallo publico, lineas 62-90 y 245-253 relevadas',
    source_type: 'secondary_public_full_text',
    reliability: 'secondary_full_text_pending_official_copy',
    clinical_domain: ['neurocirugia_craneal', 'hipofisis', 'lesion_vascular'],
    topics: ['consentimiento_informado', 'incidente_intraoperatorio', 'respuesta_ante_complicacion'],
    facts_summary: 'Caso de hipofisectomia transesfenoidal con lesion carotidea, discusion sobre consentimiento y responsabilidad del cirujano/hospital.',
    legal_criterion: 'En neurocirugia craneal, el consentimiento debe ser personal y especifico; si hay incidente vascular, el parte debe describir deteccion, control, equipos convocados y estado final.',
    tamiz_rules: [
      'Consentimiento: incluir riesgos severos materiales de la patologia y procedimiento, aun cuando no prometa listar cada contingencia infrecuente.',
      'Parte quirurgico: ante sangrado vascular o incidente mayor, narrar control, hemostaticos/packing si fueron usados, interconsulta y procedimiento complementario.',
      'Evolucion: documentar estado neurologico, terapia/recuperacion, estudios y plan posterior.'
    ],
    affected_documents: ['parte_quirurgico', 'consentimiento_informado', 'evolucion'],
  },
  {
    id: 'NSJ-008',
    title: 'Q. C. B. c/ A. E. y otros',
    tribunal: 'Suprema Corte de Justicia de Mendoza, Sala I',
    date: '2017-06-14',
    jurisdiction: 'Mendoza',
    source_url: sources.microjurisColumnaSinMalaPraxis,
    source_locator: 'Microjuris MJJ105305, fallo publico, lineas 72-77 relevadas',
    source_type: 'secondary_public_full_text',
    reliability: 'secondary_full_text_pending_official_copy',
    clinical_domain: ['columna_lumbar', 'implantes', 'control_radiologico'],
    topics: ['protocolo_quirurgico', 'control_imagen', 'consentimiento_por_indicios'],
    facts_summary: 'El rechazo de mala praxis se apoyo, entre otros elementos, en constancia protocolar de control radiologico y datos previos que respaldaban consentimiento.',
    legal_criterion: 'El parte de columna con implantes gana fuerza si registra control de rayos/radioscopia y chequeo del montaje.',
    tamiz_rules: [
      'Parte quirurgico: en procedimientos de columna con implantes, documentar control radioscopico y chequeo del material.',
      'Historia clinica: dejar constancia de estudios previos y derivacion/consulta especializada cuando sostienen la decision.',
      'Consentimiento: registrar procedimiento, riesgos, alternativas y oportunidad de preguntas.'
    ],
    affected_documents: ['parte_quirurgico', 'historia_clinica', 'consentimiento_informado'],
  },
  {
    id: 'NSJ-009',
    title: 'Villacura Carlos c/ Pilafis Salvador y Clinica Roca S.A.',
    tribunal: 'Juzgado Civil, Comercial, Mineria y Sucesiones N. 1 - General Roca',
    date: '2021-10-06',
    jurisdiction: 'Rio Negro',
    source_url: 'https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=22651551-3d3a-4cde-a2e2-c4ef831189e2&option_text=0&usarSearch=1',
    source_locator: 'Poder Judicial de Rio Negro, sentencia 35/2021, lineas 245-263 relevadas',
    source_type: 'official_full_text',
    reliability: 'official_judiciary_full_text',
    clinical_domain: ['columna_lumbar', 'hernia_foraminal', 'postoperatorio'],
    topics: ['consentimiento_especifico', 'alternativas', 'revocacion', 'seguimiento_postoperatorio'],
    facts_summary: 'El tribunal valoro que el consentimiento explicaba procedimiento, riesgos, complicaciones, alternativas y revocacion, y que la historia registraba seguimiento.',
    legal_criterion: 'El consentimiento de hernia lumbar debe ser especifico de patologia/procedimiento y el seguimiento posoperatorio debe quedar trazado.',
    tamiz_rules: [
      'Consentimiento: hernia lumbar debe explicar naturaleza de hernia, finalidad de cirugia, riesgos, alternativas y revocacion.',
      'Evolucion: registrar controles posoperatorios, movilidad, dolor, herida y pautas de alarma.',
      'Historia clinica: no transformar el consentimiento en texto administrativo; debe estar unido a indicacion clinica.'
    ],
    affected_documents: ['consentimiento_informado', 'evolucion', 'historia_clinica'],
  },
  {
    id: 'NSJ-010',
    title: 'Marchan Susana Ester c/ Gomez, Labat y Sanatorio Juan XXIII',
    tribunal: 'Juzgado Civil, Comercial, Mineria y Sucesiones N. 9 - General Roca',
    date: '2023-11-30',
    jurisdiction: 'Rio Negro',
    source_url: 'https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=826c19cc-0054-43d5-8a73-caa89eb1c0b0&option_text=0&usarSearch=1',
    source_locator: 'Poder Judicial de Rio Negro, fallo completo, lineas 213-233 y 242-255 relevadas',
    source_type: 'official_full_text',
    reliability: 'official_judiciary_full_text',
    clinical_domain: ['columna_lumbar', 'hernia_disco', 'pericia_medica'],
    topics: ['prueba_pericial', 'nexo_causal', 'documentacion_clinica'],
    facts_summary: 'Demanda rechazada por falta de prueba tecnica suficiente; el tribunal remarca el peso de la pericia para reconstruir conducta medica y nexo causal.',
    legal_criterion: 'La documentacion debe ser lo bastante completa para que una pericia futura reconstruya indicacion, tecnica, eventos y seguimiento.',
    tamiz_rules: [
      'Historia clinica: unir sintomas, examen, estudios y razon de indicacion quirurgica.',
      'Parte quirurgico: registrar hallazgos, liberacion neural, controles y cierre con precision.',
      'Evolucion: consignar estado neurologico y seguimiento inmediato.'
    ],
    affected_documents: ['historia_clinica', 'parte_quirurgico', 'evolucion'],
  },
  {
    id: 'NSJ-011',
    title: 'Olivares Anselmo Eduardo c/ Sanatorio Juan XXIII y otros',
    tribunal: 'Juzgado Civil, Comercial, Mineria y Sucesiones N. 9 - General Roca',
    date: '2017-12-15',
    jurisdiction: 'Rio Negro',
    source_url: 'https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=03651b40-774a-4e75-bdde-7011bfc10081&option_text=0&usarSearch=1',
    source_locator: 'Poder Judicial de Rio Negro, sentencia 68/2017, lineas 76-100 y 191-199 relevadas',
    source_type: 'official_full_text',
    reliability: 'official_judiciary_full_text',
    clinical_domain: ['columna_lumbar', 'bloqueo_peridural', 'canal_estrecho'],
    topics: ['procedimiento_invasivo_no_quirurgico', 'complicacion', 'lex_artis'],
    facts_summary: 'Reclamo por complicacion neurologica luego de peridural con corticoides; demanda rechazada luego de valorar indicacion, tecnica, complicacion y causalidad.',
    legal_criterion: 'Tambien los procedimientos percutaneos o no quirurgicos de columna exigen indicacion, consentimiento, tecnica y evolucion documentadas.',
    tamiz_rules: [
      'Historia clinica: para bloqueos/infiltraciones consignar diagnostico, nivel, objetivo y razon de no cirugia.',
      'Consentimiento: incluir riesgos del procedimiento peridural/infiltrativo, alternativas y revocacion.',
      'Evolucion: si aparece evento neurologico, registrar cronologia, examen, conducta y respuesta.'
    ],
    affected_documents: ['historia_clinica', 'consentimiento_informado', 'evolucion'],
  },
  {
    id: 'NSJ-012',
    title: 'Gomez Franco Maximiliano - emergencia por hemorragia cerebral',
    tribunal: 'Juzgado Civil, Comercial y Sucesiones N. 31 - Choele Choel',
    date: '2016-02-26',
    jurisdiction: 'Rio Negro',
    source_url: 'https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/descargar-archivo-pdf?id_protocolo=87d3795e-accd-4940-acfa-0453c48c63c5',
    source_locator: 'Poder Judicial de Rio Negro, PDF fallo completo, paginas 2-5 y 18-20 relevadas',
    source_type: 'official_full_text',
    reliability: 'official_judiciary_full_text',
    clinical_domain: ['neuroemergencia', 'hemorragia_cerebral', 'derivacion'],
    topics: ['emergencia', 'derivacion', 'tiempos', 'pericia', 'protocolos'],
    facts_summary: 'Caso de emergencia neurologica con discusion de tiempos, derivacion, complejidad disponible y pericia forense.',
    legal_criterion: 'En urgencias neurologicas, la defensa documental depende de horarios, examen inicial, medidas, llamadas, derivaciones y razon de cada traslado.',
    tamiz_rules: [
      'Historia/evolucion: urgencias neuro deben incluir hora de inicio/atencion, estado neurologico, medidas iniciales y criterio de derivacion.',
      'Evolucion: registrar comunicaciones, destino y condicion durante traslado.',
      'Consentimiento: en urgencia, diferenciar consentimiento posible, representante o imposibilidad razonada.'
    ],
    affected_documents: ['historia_clinica', 'evolucion', 'consentimiento_informado'],
  },
  {
    id: 'NSJ-014',
    title: 'Echenique Silva Beatriz c/ Pardal Carlos y otros',
    tribunal: 'Camara Nacional de Apelaciones en lo Civil, Capital Federal',
    date: '2010-09-24',
    jurisdiction: 'Nacional - Capital Federal',
    source_url: sources.saijDossier,
    source_locator: 'SAIJ C0408007/C0403565, dossier Mala Praxis Medica, pagina 144',
    source_type: 'official_summary',
    reliability: 'official_saij_summary',
    clinical_domain: ['neurocirugia_craneal', 'aneurisma', 'hemorragia_subaracnoidea'],
    topics: ['craneotomia', 'urgencia', 'cronologia', 'tecnica_quirurgica', 'implantes'],
    facts_summary: 'Sumarios sobre neurocirugia por aneurisma con hemorragia subaracnoidea; valoran asistencia inmediata, diagnostico, arteriografia, cirugia temprana y descripcion basica de pasos quirurgicos.',
    legal_criterion: 'En neurocirugia craneal urgente, la documentacion debe reconstruir oportunidad diagnostica, indicacion, pasos esenciales, controles y razon tecnica sin exigir inventario superfluo que no cambie el resultado.',
    tamiz_rules: [
      'Historia/evolucion: en HSA/aneurisma, registrar horario, estado neurologico, estudios, causa identificada y oportunidad quirurgica.',
      'Parte quirurgico craneal: describir abordaje y pasos esenciales, clipado/tratamiento, control y cierre; no inventar marcas/lotes si no son necesarios para la defensa del caso.',
      'Consentimiento/urgencia: si la opcion tecnica era unica o vital, dejar clara la urgencia, riesgos inevitables y el modo de informacion posible.'
    ],
    affected_documents: ['historia_clinica', 'parte_quirurgico', 'evolucion', 'consentimiento_informado'],
  },
  {
    id: 'NSJ-015',
    title: 'Gonzalez Roberto Oscar c/ F.L.E.N.I.',
    tribunal: 'Camara Nacional de Apelaciones en lo Civil, Sala C',
    date: '2007-02-08',
    jurisdiction: 'Nacional - Capital Federal',
    source_url: sources.saijDossier,
    source_locator: 'SAIJ C0402692/C0402693/C0401680, dossier Mala Praxis Medica, paginas 58-59',
    source_type: 'official_summary',
    reliability: 'official_saij_summary',
    clinical_domain: ['institucion_neurologica', 'infeccion_intrahospitalaria', 'historia_clinica'],
    topics: ['historia_clinica', 'epicrisis', 'firma_sello', 'infeccion', 'deber_seguridad'],
    facts_summary: 'Sumarios sobre F.L.E.N.I. e infeccion intrahospitalaria; remarcan historia clinica detallada por dias/horas, estudios, medicacion, evolucion, sin enmiendas y con firma/sello.',
    legal_criterion: 'La historia clinica y la epicrisis deben ser recuperables, consistentes y firmadas; las diferencias entre copias u originales agravan la discusion probatoria.',
    tamiz_rules: [
      'Historia clinica/evolucion: consignar dias u horas relevantes, estudios, medicacion, evolucion y profesional responsable.',
      'Correcciones: toda modificacion posterior debe ser addenda fechada, sin reemplazar silenciosamente el texto previo.',
      'Infeccion o evento intrahospitalario: documentar medidas, deteccion, tratamiento y seguimiento sin agregar afirmaciones retrospectivas no verificables.'
    ],
    affected_documents: ['historia_clinica', 'evolucion', 'epicrisis'],
  },
  {
    id: 'NSJ-016',
    title: 'Fantini Carlos c/ Clinica Roca S.A. y otros',
    tribunal: 'Camara de Apelaciones en lo Civil, Comercial, Familia y Mineria - General Roca',
    date: '2009-04-22',
    jurisdiction: 'Rio Negro',
    source_url: 'https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=de7c9a44-365f-4678-a950-3f370afb4256&option_text=0&usarSearch=1',
    source_locator: 'Poder Judicial de Rio Negro, sentencia 37/2009, lineas 16-20 y 28 relevadas',
    source_type: 'official_full_text',
    reliability: 'official_judiciary_full_text',
    clinical_domain: ['columna', 'anestesia', 'complicacion_via_aerea'],
    topics: ['acto_anestesico', 'intubacion', 'cirugia_columna', 'complicacion_no_evitable'],
    facts_summary: 'Reclamo vinculado a cirugia de columna e intubacion; la defensa describio el acto anestesico y el proceso de intubacion conforme normas del caso.',
    legal_criterion: 'Aunque el parte quirurgico sea del cirujano, la documentacion de columna debe dejar claro el marco anestesico, posicionamiento, proteccion y transicion para reconstruir la cadena quirurgica.',
    tamiz_rules: [
      'Parte quirurgico: consignar anestesia, posicionamiento, proteccion ocular, acolchado y destino posoperatorio.',
      'Parte/evolucion: si hubo evento de via aerea u otra complicacion anestesica conocida por el equipo quirurgico, dejar trazada la comunicacion y conducta coordinada.',
      'No usar formulas vagas sobre anestesia para cubrir hechos que pertenecen al registro anestesico; el parte quirurgico debe limitarse a lo observado/realizado por el equipo.'
    ],
    affected_documents: ['parte_quirurgico', 'evolucion'],
  },
  {
    id: 'NSJ-013',
    title: 'C. P. c/ P. S. R. y otros - dictamen de competencia',
    tribunal: 'Procuracion General de la Nacion',
    date: '2025-08-01',
    jurisdiction: 'Federal',
    source_url: sources.mpfCompetencia,
    source_locator: 'MPF CIV 2343/2025/CS1, paginas 1-2 relevadas',
    source_type: 'official_prosecutor_opinion',
    reliability: 'official_pending_merits_non_precedential',
    clinical_domain: ['neurocirugia', 'consentimiento_informado', 'contexto_aspo'],
    topics: ['competencia', 'consentimiento', 'urgencia', 'historia_clinica'],
    facts_summary: 'Dictamen competencial que refleja una demanda por neurocirugia supuestamente no urgente y sin consentimiento informado, sin resolver merito medico.',
    legal_criterion: 'No es precedente de fondo, pero sirve como alerta de busqueda futura: neurocirugia programada, consentimiento y alternativas siguen siendo focos litigiosos.',
    tamiz_rules: [
      'Consentimiento: no permitir salida si falta procedimiento, riesgos, alternativas, no tratamiento y firmas/fecha.',
      'Historia clinica: en procedimiento no urgente, documentar por que se programa y por que no se posterga.',
      'Updater: mantener este caso en cola hasta sentencia de fondo o fallo de competencia CSJN.'
    ],
    affected_documents: ['historia_clinica', 'consentimiento_informado'],
  },
  {
    id: 'NSJ-017',
    title: 'Avendaño Jorge Osvaldo c/ Gomez Oscar Joaquin, Sanatorio Juan XXIII S.A. y OSPEDYC',
    tribunal: 'Juzgado Civil, Comercial, Mineria y Sucesiones N. 1 - General Roca',
    date: '2021-11-15',
    jurisdiction: 'Rio Negro',
    source_url: sources.rionegroAvendano,
    source_locator: 'Poder Judicial de Rio Negro, sentencia 44/2021, fallo completo oficial',
    source_type: 'official_full_text',
    reliability: 'official_judiciary_full_text',
    clinical_domain: ['columna_cervical', 'laminoplastia', 'mielopatia'],
    topics: ['consentimiento_informado', 'historia_clinica', 'estado_neurologico_basal', 'evolucion_postoperatoria'],
    facts_summary: 'Caso de laminoplastia cervical con debate sobre estado neurologico previo, consentimiento, evolucion posoperatoria y suficiencia de la historia clinica.',
    legal_criterion: 'En canal estrecho cervical/laminoplastia, la documentacion debe dejar clinica basal, indicacion, procedimiento efectivamente indicado, consentimiento especifico y evolucion neurologica posoperatoria.',
    tamiz_rules: [
      'Historia clinica cervical: iniciar por sintomas reales como trastorno de la marcha, torpeza manual, parestesias o deficit informado, sin formulas alternativas genericas.',
      'Consentimiento: para laminoplastia/canal cervical, consignar mielopatia o compromiso neurologico concreto, objetivo de descompresion y riesgos neurologicos/materiales.',
      'Parte/evolucion: registrar niveles, tecnica de laminoplastia, estado neurologico inmediato y seguimiento.'
    ],
    affected_documents: ['historia_clinica', 'parte_quirurgico', 'consentimiento_informado', 'evolucion'],
  },
  {
    id: 'NSJ-018',
    title: 'I., A. S. c/ Clinica y Maternidad Maria Auxiliadora y otro/a',
    tribunal: 'Camara Civil y Comercial de Azul, Sala II',
    date: '2021-03-31',
    jurisdiction: 'Provincia de Buenos Aires',
    source_url: sources.jubaRaquimedular,
    source_locator: 'SCBA/JUBA idFallo 180817, texto completo oficial',
    source_type: 'official_full_text',
    reliability: 'official_judiciary_full_text',
    clinical_domain: ['lesion_raquimedular', 'anestesia_raquidea', 'alta'],
    topics: ['historia_clinica', 'alta_prematura', 'registro_anestesico', 'seguimiento'],
    facts_summary: 'Aunque no es cirugia de columna, aporta criterio sobre lesion raquimedular/anestesia, alta y omisiones documentales en historia clinica.',
    legal_criterion: 'Cuando el evento involucra eje raquimedular o anestesia, la cadena documental debe distinguir acto quirurgico, registro anestesico, estado neurologico y decision de alta/seguimiento.',
    tamiz_rules: [
      'Parte quirurgico: no cubrir hechos anestesicos que pertenecen al registro anestesico, pero si consignar posicionamiento, proteccion y transicion observada.',
      'Evolucion/alta: ante sintomas neurologicos o dolor no habitual, documentar examen, conducta, responsable y pauta de reconsulta.',
      'Historia clinica: evitar alta o cierre sin estado neurologico y condiciones de seguimiento si hubo evento raquimedular.'
    ],
    affected_documents: ['parte_quirurgico', 'evolucion', 'historia_clinica'],
  },
  {
    id: 'NSJ-019',
    title: 'M., E. y otros c/ Hospital Municipal Vicente Lopez y otros',
    tribunal: 'Suprema Corte de Justicia de la Provincia de Buenos Aires',
    date: '2013-05-02',
    jurisdiction: 'Provincia de Buenos Aires',
    source_url: sources.jubaNeurotrauma,
    source_locator: 'SCBA/JUBA idFallo 30512, texto completo oficial',
    source_type: 'official_full_text',
    reliability: 'official_judiciary_full_text',
    clinical_domain: ['neurotrauma', 'infeccion', 'historia_clinica'],
    topics: ['historia_clinica', 'infeccion', 'cultivo_antibiograma', 'responsabilidad_institucional'],
    facts_summary: 'Neurotrauma con intervenciones e infeccion; el fallo valora historia clinica, cultivos, antibiograma, conducta terapeutica y carga probatoria.',
    legal_criterion: 'En neurocirugia con infeccion o reintervencion, la documentacion debe dejar cronologia, cultivos/tratamiento cuando existen, evolucion y razonamiento de la conducta.',
    tamiz_rules: [
      'Evolucion: ante fiebre, herida, coleccion o sospecha infecciosa, registrar hallazgo, estudio/cultivo si se solicita y plan antibiotico/quirurgico.',
      'Historia clinica/parte: si hay reintervencion, dejar causa, hallazgo, muestra/cultivo si corresponde y estado final.',
      'Tamiz institucional: diferenciar complicacion posible de omision de control o tratamiento documentable.'
    ],
    affected_documents: ['historia_clinica', 'parte_quirurgico', 'evolucion'],
  },
];

const doctrine = [
  {
    id: 'NSD-001',
    title: 'Consentimiento medico informado escrito en neurocirugia',
    source_url: sources.rancConsent,
    source_type: 'argentine_neurosurgery_journal',
    reliability: 'doctrine_specialty_argentina',
    clinical_domain: ['neurocirugia', 'consentimiento_informado'],
    impact: [
      'El consentimiento neuroquirurgico debe ser personalizado y elaborado como proceso, no como tramite administrativo.',
      'Debe cubrir naturaleza del procedimiento, beneficios, riesgos tipicos, riesgos personalizados, alternativas incluida no intervencion, preguntas y firmas.',
      'En cirugia programada conviene entregarlo con tiempo de lectura y dejar constancia en historia clinica.'
    ],
  },
];

const updateQueries = [
  'site:saij.gob.ar neurocirugia mala praxis responsabilidad medica',
  'site:saij.gob.ar neurocirujano responsabilidad medica mala praxis',
  'site:saij.gob.ar cirugia columna mala praxis responsabilidad medica',
  'site:saij.gob.ar hernia disco cirugia mala praxis danos perjuicios',
  'site:fallos.jusrionegro.gov.ar cirugia de columna mala praxis',
  '"neurocirugia" "consentimiento informado" "mala praxis" Argentina fallo',
  '"cirugia de columna" "consentimiento informado" "danos y perjuicios" Argentina',
  '"hernia de disco" "mala praxis" "danos y perjuicios" Argentina',
  '"hipofisectomia" "carotida" "danos y perjuicios" Argentina',
  '"neurocirujano" "OSECAC" "responsabilidad medica"',
  '"Echenique" "Pardal" aneurisma mala praxis',
  '"craneotomia" "responsabilidad medica" "SAIJ"',
  '"Gonzalez" "F.L.E.N.I." "historia clinica"',
  '"Fantini" "Clinica Roca" columna intubacion',
];

const impactRules = [
  {
    id: 'NJ-TAMIZ-001',
    label: 'Indicacion neuro/columna con correlacion y alternativas',
    source_records: ['NSJ-001', 'NSJ-002', 'NSJ-005', 'NSJ-006', 'NSJ-010', 'NSJ-017'],
    applies_to: ['historia_clinica', 'consentimiento_informado'],
    rule: 'Toda indicacion neuroquirurgica o de columna programada debe mostrar clinica, examen, estudios, diagnostico y razon de la conducta elegida, incluyendo fracaso o descarte de alternativas cuando no sea urgencia.',
  },
  {
    id: 'NJ-TAMIZ-002',
    label: 'Nivel, lateralidad, raiz y control por imagen en columna',
    source_records: ['NSJ-005', 'NSJ-006', 'NSJ-008', 'NSJ-009', 'NSJ-010'],
    applies_to: ['historia_clinica', 'parte_quirurgico'],
    rule: 'Columna exige nivel/lateralidad, raiz comprometida cuando aplique, estudio concordante y control radioscopico/rayos en procedimientos donde define nivel o implantes.',
  },
  {
    id: 'NJ-TAMIZ-003',
    label: 'Parte quirurgico con respuesta ante incidentes',
    source_records: ['NSJ-003', 'NSJ-004', 'NSJ-007', 'NSJ-010', 'NSJ-014', 'NSJ-016', 'NSJ-017', 'NSJ-018'],
    applies_to: ['parte_quirurgico', 'evolucion'],
    rule: 'El parte debe permitir reconstruir posicion, proteccion, abordaje, hallazgo, maniobra, control, hemostasia, recuento, incidente si existio, respuesta y destino.',
  },
  {
    id: 'NJ-TAMIZ-004',
    label: 'Consentimiento neuroquirurgico material y especifico',
    source_records: ['NSJ-005', 'NSJ-006', 'NSJ-007', 'NSJ-009', 'NSJ-011', 'NSJ-013', 'NSJ-017', 'NSD-001'],
    applies_to: ['consentimiento_informado'],
    rule: 'Consentimiento no sale si no identifica patologia, procedimiento, beneficios, riesgos propios, alternativas, no tratamiento, revocacion, fecha/firma y oportunidad de preguntas.',
  },
  {
    id: 'NJ-TAMIZ-005',
    label: 'Urgencia neurologica con tiempos y derivacion',
    source_records: ['NSJ-012', 'NSJ-013', 'NSJ-014'],
    applies_to: ['historia_clinica', 'evolucion'],
    rule: 'En urgencia neurologica se registran horarios, examen, medidas, comunicaciones, criterio de derivacion y condicion de traslado o imposibilidad de consentimiento ordinario.',
  },
  {
    id: 'NJ-TAMIZ-006',
    label: 'Integridad y recuperabilidad de historia clinica neuro/institucional',
    source_records: ['NSJ-015', 'NSJ-019'],
    applies_to: ['historia_clinica', 'evolucion', 'epicrisis'],
    rule: 'La historia clinica, evolucion y epicrisis deben permitir reconstruir dias/horas relevantes, estudios, medicacion, profesional responsable y addendas sin enmiendas silenciosas.',
  },
];

const searchCoverage = {
  generated_at: generatedAt,
  limitation: 'Primer corte trazable. No afirma exhaustividad absoluta de toda la jurisprudencia argentina; deja fuentes, queries y cola de actualizacion para ampliar y revalidar.',
  prioritized_sources: [
    'SAIJ y dossier oficial de mala praxis medica',
    'Buscador de fallos del Poder Judicial de Rio Negro',
    'Procuracion General de la Nacion para dictamenes recientes',
    'Fuentes secundarias publicas cuando contienen tribunal, fecha, partes y texto/sumario suficiente',
    'Revista Argentina de Neurocirugia como doctrina de especialidad, separada de jurisprudencia'
  ],
  update_queries: updateQueries,
};

const corpus = {
  generated_at: generatedAt,
  status: 'review_only_detect_only',
  corpus: 'jurisprudencia_neurocirugia_columna_argentina',
  records_count: records.length,
  doctrine_count: doctrine.length,
  reliability_policy: {
    official_judiciary_full_text: 'Puede alimentar reglas de tamiz como fuente fuerte, siempre en modo review_only.',
    official_saij_summary: 'Puede alimentar reglas de tamiz como fuente oficial resumida; buscar texto completo si se citara hacia afuera.',
    secondary_full_text_pending_official_copy: 'Solo candidato reforzador; no citar como fuente oficial hasta obtener copia judicial/SAIJ.',
    official_pending_merits_non_precedential: 'Solo alerta/cola; no regla de fondo sobre responsabilidad.',
  },
  records,
  doctrine,
  impact_rules: impactRules,
  search_coverage: searchCoverage,
};

const corpusJson = path.join(outDir, `jurisprudence_neuro_spine_corpus_${dateId}.json`);
const corpusLatestJson = path.join(outDir, 'jurisprudence_neuro_spine_corpus_latest.json');
fs.writeFileSync(corpusJson, JSON.stringify(corpus, null, 2));
fs.writeFileSync(corpusLatestJson, JSON.stringify(corpus, null, 2));

const md = `# Corpus jurisprudencial neurocirugia/columna Argentina

Estado: \`review_only_detect_only\`  
Fecha de corte: ${generatedAt}

Este es un primer corte trazable para reforzar el tamiz medico-legal de la app. No se presenta como exhaustividad absoluta de toda la jurisprudencia argentina: separa fuente oficial, sumario oficial, fuente secundaria publica y alerta pendiente, y deja queries para actualizacion.

## Politica de confiabilidad
- \`official_judiciary_full_text\`: fuente judicial oficial con texto completo.
- \`official_saij_summary\`: sumario/ficha oficial SAIJ; util para tamiz, pendiente de texto completo si se va a citar hacia afuera.
- \`secondary_full_text_pending_official_copy\`: fuente publica secundaria con tribunal/fecha/partes; usar solo como candidato hasta obtener copia oficial.
- \`official_pending_merits_non_precedential\`: alerta oficial sin sentencia de fondo; no se usa como precedente material.

## Reglas de impacto para la app
${impactRules.map((rule) => `### ${rule.id} - ${rule.label}
- Aplica a: ${rule.applies_to.join(', ')}
- Regla: ${rule.rule}
- Fuentes: ${rule.source_records.join(', ')}
`).join('\n')}

## Jurisprudencia cargada
${records.map((record) => `### ${record.id} - ${record.title}
- Tribunal: ${record.tribunal}
- Fecha: ${record.date}
- Jurisdiccion: ${record.jurisdiction}
- Fuente: ${record.source_url}
- Localizador: ${record.source_locator}
- Confiabilidad: \`${record.reliability}\`
- Dominio clinico: ${record.clinical_domain.join(', ')}
- Criterio operativo: ${record.legal_criterion}
- Impacto documental: ${record.affected_documents.join(', ')}
- Tamiz:
${record.tamiz_rules.map((item) => `  - ${item}`).join('\n')}
`).join('\n')}

## Doctrina de especialidad separada
${doctrine.map((item) => `### ${item.id} - ${item.title}
- Fuente: ${item.source_url}
- Confiabilidad: \`${item.reliability}\`
${item.impact.map((rule) => `  - ${rule}`).join('\n')}
`).join('\n')}

## Queries para proximo actualizador
${updateQueries.map((query) => `- \`${query}\``).join('\n')}
`;

const corpusMd = path.join(outDir, `jurisprudence_neuro_spine_impact_matrix_${dateId}.md`);
const corpusLatestMd = path.join(outDir, 'jurisprudence_neuro_spine_impact_matrix_latest.md');
fs.writeFileSync(corpusMd, md);
fs.writeFileSync(corpusLatestMd, md);

const qa = {
  generated_at: generatedAt,
  status: 'ok_review_only_detect_only',
  corpus_json: corpusJson,
  corpus_md: corpusMd,
  sha256_json: sha256(JSON.stringify(corpus, null, 2)),
  records_count: records.length,
  doctrine_count: doctrine.length,
  official_records_count: records.filter((item) => item.reliability.startsWith('official')).length,
  secondary_records_count: records.filter((item) => item.reliability.startsWith('secondary')).length,
  impact_rules_count: impactRules.length,
  update_queries_count: updateQueries.length,
};

const qaPath = path.join(qaDir, `neuro_spine_jurisprudence_corpus_${dateId}_summary.json`);
fs.writeFileSync(qaPath, JSON.stringify(qa, null, 2));
console.log(JSON.stringify(qa, null, 2));
