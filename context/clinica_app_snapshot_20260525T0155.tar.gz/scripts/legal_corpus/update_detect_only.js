#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..', '..');
const rawBase = path.join(root, 'data', 'raw');
const processedBase = path.join(root, 'data', 'processed', 'legal_corpus');
const qaDir = path.join(root, 'qa', 'approval_gates');
const outputPath = path.join(qaDir, 'medicolegal_update_detect_only_summary.json');
function findLatestByPrefix(dir, prefix) {
  const dated = fs
    .readdirSync(dir)
    .filter((file) => new RegExp(`^${prefix}\\d{4}-\\d{2}-\\d{2}\\.json$`).test(file))
    .sort();
  if (dated.length) return path.join(dir, dated.at(-1));
  const fallback = path.join(dir, `${prefix}latest.json`);
  if (fs.existsSync(fallback)) return fallback;
  throw new Error(`No ${prefix}<date>.json or ${prefix}latest.json found in ${dir}`);
}

function findLatestManifest(layerDir) {
  const files = fs
    .readdirSync(layerDir)
    .filter((file) => /^manifest_\d{4}-\d{2}-\d{2}\.json$/.test(file))
    .sort();
  if (!files.length) throw new Error(`No manifest_YYYY-MM-DD.json found in ${layerDir}`);
  return path.join(layerDir, files.at(-1));
}

const jurisprudenceCandidatesPath = findLatestByPrefix(processedBase, 'jurisprudencia_candidates_');

const manifestSpecs = [
  { layer: 'normativo', file: findLatestManifest(path.join(rawBase, 'legal')) },
  { layer: 'jurisprudencia', file: findLatestManifest(path.join(rawBase, 'jurisprudence')) },
  { layer: 'doctrina', file: findLatestManifest(path.join(rawBase, 'doctrine')) },
  { layer: 'interno', file: findLatestManifest(path.join(rawBase, 'internal')) }
];
const declaredLayers = ['normativo', 'jurisprudencia', 'doctrina', 'interno', 'clinico'];

function safeReadJson(file) {
  return JSON.parse(fs.readFileSync(file, 'utf8'));
}

function safeReadOptionalJson(file, fallback) {
  if (!fs.existsSync(file)) return fallback;
  return safeReadJson(file);
}

function loadManifest(spec) {
  const items = safeReadJson(spec.file);
  return items.map((item) => {
    const meta_path = item.raw_path.replace(/\.(html|json|md)$/i, '.meta.json');
    return {
      id: item.id,
      layer: spec.layer,
      title: item.title,
      official_url: item.official_url,
      final_url: item.final_url,
      raw_path: item.raw_path,
      meta_path,
      sha256: item.sha256,
      fetched_at: item.fetched_at,
      content_type: item.content_type,
      exists: fs.existsSync(item.raw_path),
      meta_exists: fs.existsSync(meta_path)
    };
  });
}

const manifests = manifestSpecs.flatMap(loadManifest);
const jurisprudenceCandidates = safeReadOptionalJson(jurisprudenceCandidatesPath, []);
const missingRaw = manifests.filter((item) => !item.exists).map((item) => ({
  id: item.id,
  layer: item.layer,
  raw_path: item.raw_path
}));
const missingMeta = manifests.filter((item) => !item.meta_exists).map((item) => ({
  id: item.id,
  layer: item.layer,
  meta_path: item.meta_path
}));

function classifyReviewBucket(item) {
  const text = `${item.id} ${item.title}`.toLowerCase();
  if (item.layer === 'normativo') return 'normativo_general';
  if (item.layer === 'doctrina') return 'criterios_operativos';
  if (item.layer === 'interno') return 'reglas_internas';
  if (text.includes('historia') && text.includes('clinica')) return 'historia_clinica';
  if (text.includes('consentimiento')) return 'consentimiento';
  if (text.includes('quir')) return 'seguridad_quirurgica';
  if (text.includes('error')) return 'error_inexcusable';
  return 'jurisprudencia_general';
}

function buildReviewItem(item) {
  const review_bucket = classifyReviewBucket(item);
  return {
    id: `review_${item.id}`,
    source_id: item.id,
    layer: item.layer,
    review_bucket,
    reason: 'source_monitored_detect_only',
    requested_state: 'pending_review',
    priority: item.layer === 'normativo' ? 'high' : item.layer === 'jurisprudencia' ? 'medium' : 'high',
    artifact: item.raw_path
  };
}

function classifyCandidateBucket(candidate) {
  const text = `${candidate.query_label || ''} ${candidate.titulo || ''} ${candidate.texto_resumen_fuente || ''} ${candidate.friendly_url || ''}`.toLowerCase();
  if (text.includes('historia clinica') || text.includes('autenticidad')) return 'historia_clinica';
  if (text.includes('consentimiento')) return 'consentimiento';
  if (text.includes('quirurg') || text.includes('oblito') || text.includes('anestes')) return 'seguridad_quirurgica';
  if (text.includes('error inexcusable') || text.includes('error-excusable') || text.includes('iatrogenia')) return 'error_inexcusable';
  return 'jurisprudencia_general';
}

function classifyCandidateRelevance(candidate) {
  const text = `${candidate.query_label || ''} ${candidate.titulo || ''} ${candidate.texto_resumen_fuente || ''} ${candidate.friendly_url || ''}`.toLowerCase();
  if (text.includes('mercado cambiario') || text.includes('dolares')) return 'low';
  if (text.includes('accidentes trabajo') || text.includes('contrato-trabajo') || text.includes('homologacion')) return 'medium';
  return 'high';
}

const pendingReviewQueue = manifests.map(buildReviewItem);
function classifyCandidateExclusion(candidate) {
  const text = `${candidate.query_label || ''} ${candidate.titulo || ''} ${candidate.texto_resumen_fuente || ''} ${candidate.friendly_url || ''}`.toLowerCase();
  if (text.includes('mercado cambiario') || text.includes('dolares')) {
    return 'out_of_scope_non_medicolegal_match';
  }
  return null;
}

const candidateQueue = jurisprudenceCandidates.map((candidate, index) => ({
  id: `candidate_${String(index + 1).padStart(3, '0')}`,
  source_query: candidate.source_query,
  review_bucket: classifyCandidateBucket(candidate),
  priority: classifyCandidateRelevance(candidate),
  exclusion_reason: classifyCandidateExclusion(candidate),
  fecha: candidate.fecha || null,
  tribunal: candidate.tribunal || null,
  titulo: candidate.titulo || null,
  friendly_url: candidate.friendly_url,
  confidence: candidate.confidence,
  artifact: jurisprudenceCandidatesPath
}));
const candidateQueuePrioritized = candidateQueue
  .filter((candidate) => !candidate.exclusion_reason && candidate.priority !== 'low')
  .sort((a, b) => {
    const priorityOrder = { high: 0, medium: 1, low: 2 };
    return (priorityOrder[a.priority] ?? 9) - (priorityOrder[b.priority] ?? 9);
  });
const candidateQueueExcluded = candidateQueue.filter((candidate) => Boolean(candidate.exclusion_reason));
const layerCoverage = Object.fromEntries(
  declaredLayers.map((layer) => [
    layer,
    {
      monitored_sources_count: manifests.filter((item) => item.layer === layer).length,
      review_queue_count: pendingReviewQueue.filter((item) => item.layer === layer).length
    }
  ])
);

const summary = {
  generated_at: new Date().toISOString(),
  mode: 'detect_only',
  status: missingRaw.length ? 'warning_missing_raw' : 'ok_pending_review',
  publication_activation_allowed: false,
  monitored_layers: declaredLayers,
  monitored_sources_count: manifests.length,
  monitored_sources: manifests,
  layer_coverage: layerCoverage,
  checks: {
    raw_paths_exist: missingRaw.length === 0,
    meta_paths_exist: missingMeta.length === 0,
    hashes_present: manifests.every((item) => Boolean(item.sha256)),
    official_urls_present: manifests.every((item) => Boolean(item.official_url)),
    final_urls_present: manifests.every((item) => Boolean(item.final_url)),
    detect_only_no_auto_activation: true
  },
  change_candidates: manifests.map((item) => ({
    source_id: item.id,
    layer: item.layer,
    change_type: 'baseline_snapshot',
    sha256_before: null,
    sha256_after: item.sha256,
    fetched_at: item.fetched_at,
    final_url: item.final_url,
    review_bucket: classifyReviewBucket(item),
    activation_state: 'pending_review'
  })),
  pending_review_queue: pendingReviewQueue,
  review_queue_by_bucket: pendingReviewQueue.reduce((acc, item) => {
    acc[item.review_bucket] = (acc[item.review_bucket] || 0) + 1;
    return acc;
  }, {}),
  jurisprudence_candidate_queue: {
    source_artifact: jurisprudenceCandidatesPath,
    total_candidates_detected: candidateQueue.length,
    prioritized_candidates: candidateQueuePrioritized.length,
    deprioritized_candidates: candidateQueue.filter((candidate) => candidate.priority === 'low').length,
    excluded_candidates: candidateQueueExcluded.length,
    prioritized_by_bucket: candidateQueuePrioritized.reduce((acc, item) => {
      acc[item.review_bucket] = (acc[item.review_bucket] || 0) + 1;
      return acc;
    }, {}),
    excluded_by_reason: candidateQueueExcluded.reduce((acc, item) => {
      acc[item.exclusion_reason] = (acc[item.exclusion_reason] || 0) + 1;
      return acc;
    }, {}),
    items: candidateQueuePrioritized,
    excluded_items: candidateQueueExcluded
  },
  risk_delta: {
    total_pending_high_priority_normativo: pendingReviewQueue.filter((item) => item.layer === 'normativo' && item.priority === 'high').length,
    total_pending_high_priority_jurisprudencia: candidateQueuePrioritized.filter((item) => item.priority === 'high').length,
    seguridad_quirurgica_candidates: candidateQueuePrioritized.filter((item) => item.review_bucket === 'seguridad_quirurgica').length,
    consentimiento_candidates: candidateQueuePrioritized.filter((item) => item.review_bucket === 'consentimiento').length,
    historia_clinica_candidates: candidateQueuePrioritized.filter((item) => item.review_bucket === 'historia_clinica').length,
    out_of_scope_filtered_candidates: candidateQueueExcluded.length,
    activation_blocked_until_review: true
  },
  gaps: [
    'Falta incorporar complementarias adicionales de Ley 26.529 y validar si existe normativa sectorial especifica adicional de historia clinica electronica, mas alla del puente oficial ya capturado entre Decreto 1089/2012 art. 13 y Ley 25.506.',
    'Falta agregar fallos/sumarios con texto completo o evidencia estructurada mas fuerte para consentimiento informado y partes quirurgicos.',
    'La capa clinico debe seguir vacia y no activarse hasta recibir documentos reales del doctor con revision humana.',
    'La capa doctrina e interno ya tienen snapshots raw detect-only; falta sumar fuentes doctrinarias externas estructuradas si aparecen sin confundirlas con norma.'
  ],
  missing_raw: missingRaw,
  missing_meta: missingMeta
};

fs.mkdirSync(qaDir, { recursive: true });
fs.writeFileSync(outputPath, JSON.stringify(summary, null, 2));
console.log(JSON.stringify(summary, null, 2));
