#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { spawnSync } = require('child_process');

const root = path.resolve(__dirname, '..', '..');
const qaDir = path.join(root, 'qa', 'approval_gates');
const pinnedNode = '/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node';
const nodeBin = fs.existsSync(pinnedNode) ? pinnedNode : process.execPath;
const args = new Set(process.argv.slice(2));
const skipFetch = args.has('--skip-fetch');
const startedAt = new Date().toISOString();
const stageResults = [];

function stamp(value = new Date()) {
  return value.toISOString().replace(/[-:]/g, '').replace(/\.\d{3}Z$/, 'Z');
}

function relative(filePath) {
  return path.relative(root, filePath);
}

function readJson(filePath) {
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function parseJsonLoose(text) {
  const clean = String(text || '').trim();
  if (!clean) return null;
  try {
    return JSON.parse(clean);
  } catch {
    const start = clean.indexOf('{');
    const end = clean.lastIndexOf('}');
    if (start !== -1 && end !== -1 && end > start) {
      try {
        return JSON.parse(clean.slice(start, end + 1));
      } catch {}
    }
  }
  return null;
}

function runStage(id, scriptRel, extraArgs = [], options = {}) {
  const started = Date.now();
  const scriptPath = path.join(root, scriptRel);
  const result = spawnSync(nodeBin, [scriptPath, ...extraArgs], {
    cwd: root,
    encoding: 'utf8',
    stdio: ['ignore', 'pipe', 'pipe'],
    timeout: options.timeoutMs || 600000,
  });
  const stdout = String(result.stdout || '').trim();
  const stderr = String(result.stderr || '').trim();
  const parsed = parseJsonLoose(stdout);
  const stage = {
    id,
    script: scriptRel,
    ok: result.status === 0,
    exit_status: result.status,
    signal: result.signal || null,
    timed_out: result.error?.code === 'ETIMEDOUT',
    duration_ms: Date.now() - started,
    parsed,
    stdout_tail: stdout.slice(-2000),
    stderr_tail: stderr.slice(-2000),
  };
  stageResults.push(stage);
  if (!stage.ok) {
    const reason = stderr || stdout || `${scriptRel} exited ${result.status}`;
    throw new Error(`Stage ${id} failed: ${reason.slice(0, 800)}`);
  }
  return stage;
}

function ensure(condition, message, details = null) {
  if (!condition) {
    const error = new Error(message);
    error.details = details;
    throw error;
  }
}

function loadSafetySnapshot() {
  const summaryPath = path.join(qaDir, 'medicolegal_update_detect_only_summary.json');
  const tamizPath = path.join(root, 'data', 'derived', 'medicolegal_tamiz', 'medicolegal_tamiz_pack_2026-05-19.json');
  const promotionPath = path.join(qaDir, 'tamiz_dry_run_promotion_2026-05-20.json');
  const sqlitePath = path.join(qaDir, 'medicolegal_sqlite_sync_2026-05-20.json');

  const summary = readJson(summaryPath);
  const tamiz = readJson(tamizPath);
  const promotion = readJson(promotionPath);
  const sqlite = fs.existsSync(sqlitePath) ? readJson(sqlitePath) : null;
  return { summaryPath, tamizPath, promotionPath, sqlitePath, summary, tamiz, promotion, sqlite };
}

function assertDetectOnlySafety(snapshot) {
  const { summary, tamiz, promotion, sqlite } = snapshot;
  const changeCandidates = Array.isArray(summary.change_candidates) ? summary.change_candidates : [];
  const pendingReviewQueue = Array.isArray(summary.pending_review_queue) ? summary.pending_review_queue : [];
  const promotionStatuses = Array.isArray(promotion.statuses) ? promotion.statuses : [];

  ensure(summary.mode === 'detect_only', 'Updater summary is not detect_only', { mode: summary.mode });
  ensure(summary.publication_activation_allowed === false, 'Publication activation unexpectedly allowed');
  ensure(summary.checks?.detect_only_no_auto_activation === true, 'Detect-only no-auto-activation check missing');
  ensure((summary.missing_raw || []).length === 0, 'Updater detected missing raw sources', summary.missing_raw);
  ensure((summary.missing_meta || []).length === 0, 'Updater detected missing metadata sources', summary.missing_meta);
  ensure(changeCandidates.every((item) => item.activation_state === 'pending_review'), 'A change candidate is not pending_review');
  ensure(pendingReviewQueue.every((item) => item.requested_state === 'pending_review'), 'A review queue item requested active state');
  ensure(String(tamiz.status || '').includes('review_only'), 'Tamiz pack is not review_only', { status: tamiz.status });
  ensure(tamiz.update_policy?.mode === 'detect_only', 'Tamiz update policy is not detect_only');
  ensure(promotion.mode === 'detect_only', 'Promotion artifact is not detect_only', { mode: promotion.mode });
  ensure(promotion.legal_certification === false, 'Promotion artifact claims legal certification');
  ensure(promotionStatuses.every((item) => item.enforcement !== 'production' && item.status !== 'active'), 'Promotion artifact contains active/production status');
  if (sqlite) {
    ensure(sqlite.mode === 'detect_only', 'SQLite sync is not detect_only', { mode: sqlite.mode });
    ensure(sqlite.activation_state === 'pending_review', 'SQLite sync activation state is not pending_review');
  }

  return {
    monitored_sources_count: summary.monitored_sources_count,
    pending_review_queue_count: pendingReviewQueue.length,
    change_candidates_count: changeCandidates.length,
    high_priority_normative: summary.risk_delta?.total_pending_high_priority_normativo || 0,
    high_priority_jurisprudence: summary.risk_delta?.total_pending_high_priority_jurisprudencia || 0,
    tamiz_gates: Array.isArray(tamiz.gates) ? tamiz.gates.length : null,
    sqlite_synced_sources: sqlite?.synced_sources || null,
  };
}

function markdownReport(payload) {
  const lines = [
    '# Medicolegal Detect-Only Update Cycle',
    '',
    `Fecha: ${payload.generated_at}`,
    `Estado: ${payload.ok ? 'OK' : 'FALLA'}`,
    `Modo: ${payload.mode}`,
    `Fetch remoto: ${payload.skip_fetch ? 'omitido' : 'ejecutado'}`,
    '',
    '## Etapas',
    '',
  ];
  for (const stage of payload.stages) {
    const suffix = stage.timed_out ? ' TIMEOUT' : '';
    lines.push(`- ${stage.ok ? 'OK' : 'FALLA'} ${stage.id}${suffix} (${stage.duration_ms} ms)`);
    if (!stage.ok && stage.stderr_tail) lines.push(`  - stderr: ${stage.stderr_tail.replace(/\n/g, ' ').slice(0, 500)}`);
    if (!stage.ok && stage.stdout_tail) lines.push(`  - stdout: ${stage.stdout_tail.replace(/\n/g, ' ').slice(0, 500)}`);
  }
  lines.push('', '## Compuer­ta de seguridad', '');
  if (payload.safety) {
    lines.push(`- Fuentes monitoreadas: ${payload.safety.monitored_sources_count}`);
    lines.push(`- Cola pending_review: ${payload.safety.pending_review_queue_count}`);
    lines.push(`- Change candidates pending_review: ${payload.safety.change_candidates_count}`);
    lines.push(`- Normativo alta prioridad: ${payload.safety.high_priority_normative}`);
    lines.push(`- Jurisprudencia alta prioridad: ${payload.safety.high_priority_jurisprudence}`);
    lines.push(`- Gates del tamiz: ${payload.safety.tamiz_gates}`);
    if (payload.safety.sqlite_synced_sources !== null) lines.push(`- Fuentes sincronizadas a SQLite: ${payload.safety.sqlite_synced_sources}`);
  } else {
    lines.push('- No se pudo completar la compuerta de seguridad.');
  }
  lines.push('', '## Politica', '');
  lines.push('- Ningun hallazgo activa reglas finales ni modifica plantillas madres sin revision.');
  lines.push('- El resultado solo alimenta cola detect-only y artefactos de QA.');
  lines.push('- Cualquier uso asistencial real sigue requiriendo revision medica y ruta canonica de la app.');
  if (!payload.ok && payload.failure) {
    lines.push('', '## Falla', '', payload.failure);
  }
  return lines.join('\n') + '\n';
}

function writeReceipt(payload) {
  fs.mkdirSync(qaDir, { recursive: true });
  const runStamp = stamp(new Date(payload.generated_at));
  const jsonPath = path.join(qaDir, `medicolegal_detect_only_update_cycle_${runStamp}.json`);
  const mdPath = path.join(qaDir, `medicolegal_detect_only_update_cycle_${runStamp}.md`);
  const latestJson = path.join(qaDir, 'medicolegal_detect_only_update_cycle_latest.json');
  const latestMd = path.join(qaDir, 'medicolegal_detect_only_update_cycle_latest.md');
  const json = JSON.stringify(payload, null, 2) + '\n';
  fs.writeFileSync(jsonPath, json);
  fs.writeFileSync(mdPath, markdownReport(payload));
  fs.copyFileSync(jsonPath, latestJson);
  fs.copyFileSync(mdPath, latestMd);
  return { jsonPath, mdPath, latestJson, latestMd };
}

let payload;
try {
  if (!skipFetch) {
    runStage('fetch_priority_legal_sources', 'scripts/legal_corpus/fetch_priority_legal_sources_2026_05_20.js', [], { timeoutMs: 900000 });
  }
  runStage('regenerate_processed_indexes', 'scripts/legal_corpus/regenerate_processed_indexes.js');
  runStage('build_neuro_spine_jurisprudence_corpus', 'scripts/legal_corpus/build_neuro_spine_jurisprudence_corpus.js');
  runStage('build_tamiz_dry_run_promotion', 'scripts/legal_corpus/build_tamiz_dry_run_promotion_2026_05_20.js');
  runStage('build_medicolegal_tamiz_pack', 'scripts/legal_corpus/build_medicolegal_tamiz_pack.js');
  runStage('update_detect_only_summary', 'scripts/legal_corpus/update_detect_only.js');
  runStage('sync_medicolegal_sqlite', 'scripts/legal_corpus/sync_medicolegal_sqlite_from_manifests.js');
  runStage('build_candidate_manifest', 'scripts/build_cli_app_candidate_manifest.js');

  const snapshot = loadSafetySnapshot();
  const safety = assertDetectOnlySafety(snapshot);
  payload = {
    ok: true,
    mode: 'detect_only',
    generated_at: new Date().toISOString(),
    started_at: startedAt,
    node_bin: nodeBin,
    skip_fetch: skipFetch,
    stages: stageResults,
    safety,
    artifacts: {
      summary: relative(snapshot.summaryPath),
      tamiz_pack: relative(snapshot.tamizPath),
      promotion: relative(snapshot.promotionPath),
      sqlite_sync: fs.existsSync(snapshot.sqlitePath) ? relative(snapshot.sqlitePath) : null,
    },
  };
} catch (error) {
  payload = {
    ok: false,
    mode: 'detect_only',
    generated_at: new Date().toISOString(),
    started_at: startedAt,
    node_bin: nodeBin,
    skip_fetch: skipFetch,
    stages: stageResults,
    failure: error.message || String(error),
    failure_details: error.details || null,
  };
}

const receipt = writeReceipt(payload);
const response = {
  ok: payload.ok,
  mode: payload.mode,
  skip_fetch: payload.skip_fetch,
  report: receipt.mdPath,
  json: receipt.jsonPath,
  latest_report: receipt.latestMd,
  latest_json: receipt.latestJson,
  safety: payload.safety || null,
  failure: payload.failure || null,
};
console.log(JSON.stringify(response, null, 2));
if (!payload.ok) process.exit(1);
