#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..', '..');
const qaDir = path.join(root, 'qa', 'approval_gates');
const outDir = path.join(root, 'data', 'derived', 'jurisprudence_neuro_spine');
fs.mkdirSync(qaDir, { recursive: true });
fs.mkdirSync(outDir, { recursive: true });

const generatedAt = new Date().toISOString();
const approvedForDryRun = [
  'CLI-R001',
  'CLI-R002',
  'CLI-R003',
  'CLI-R004',
  'CLI-R005',
  'CLI-R006',
  'CLI-R007',
  'CLI-R009',
  'CLI-R010',
  'CLI-R012',
  'CLI-R013',
  'CLI-R014',
  'CLI-R015',
  'CLI-NSJ002',
  'CLI-NSJ003',
  'CLI-NSJ005',
];
const softWarning = ['CLI-R008', 'CLI-R011', 'CLI-NSJ001', 'CLI-NSJ004'];
const pendingReview = ['NJ-TAMIZ-006', 'NSJ-005', 'NSJ-006', 'NSJ-007', 'NSJ-008', 'NSJ-013'];

const promotion = {
  generated_at: generatedAt,
  mode: 'detect_only',
  legal_certification: false,
  product_document_policy: 'No insertar citas legales ni promesas de blindaje en HC, consentimiento o parte; el tamiz opera como compuerta lateral.',
  statuses: [
    ...approvedForDryRun.map((id) => ({
      id,
      status: 'approved_for_dry_run',
      enforcement: 'detect_only_gate',
      note: 'Puede usarse para pruebas de falsos positivos/negativos; no activa certificacion legal ni bloqueo productivo terminal por si solo.',
    })),
    ...softWarning.map((id) => ({
      id,
      status: 'soft_warning',
      enforcement: 'detect_only_warning',
      note: 'Regla clinicamente valiosa pero sensible al contexto; no debe sobrebloquear sin revision humana.',
    })),
    ...pendingReview.map((id) => ({
      id,
      status: 'pending_review',
      enforcement: 'no_activation',
      note: 'Mantener como candidato o fuente auxiliar hasta completar fuente oficial/revision material.',
    })),
  ],
};

const officializationQueue = {
  generated_at: generatedAt,
  mode: 'detect_only',
  purpose: 'Separar fuentes neuro/columna que deben oficializarse o mantenerse como candidato antes de alimentar reglas fuertes.',
  already_added_official_candidates: [
    {
      id: 'NSJ-017',
      title: 'Avendaño Jorge Osvaldo c/ Gomez Oscar Joaquin, Sanatorio Juan XXIII S.A. y OSPEDYC',
      source_url: 'https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=e71e6494-30d0-4d45-abf9-b2bbf6e72a17&option_text=0&usarSearch=1',
      status: 'official_full_text_added_to_corpus',
    },
    {
      id: 'NSJ-018',
      title: 'I., A. S. c/ Clinica y Maternidad Maria Auxiliadora y otro/a',
      source_url: 'https://juba.scba.gov.ar/VerTextoCompleto.aspx?idFallo=180817',
      status: 'official_full_text_added_to_corpus',
    },
    {
      id: 'NSJ-019',
      title: 'M., E. y otros c/ Hospital Municipal Vicente Lopez y otros',
      source_url: 'https://juba.scba.gov.ar/VerTextoCompleto.aspx?idFallo=30512',
      status: 'official_full_text_added_to_corpus',
    },
  ],
  still_secondary_pending_official_copy: [
    {
      id: 'NSJ-005',
      title: 'V. L. M. N. y otros c/ E. R. J. y otro',
      current_reliability: 'secondary_full_text_pending_official_copy',
    },
    {
      id: 'NSJ-006',
      title: 'R. C. c/ FLENI',
      current_reliability: 'secondary_full_text_pending_official_copy',
    },
    {
      id: 'NSJ-007',
      title: 'M. G. L. c/ Hospital Aleman',
      current_reliability: 'secondary_full_text_pending_official_copy',
    },
    {
      id: 'NSJ-008',
      title: 'Q. C. B. c/ A. E.',
      current_reliability: 'secondary_full_text_pending_official_copy',
    },
  ],
  rule: 'Las fuentes secundarias no se citan en documentos clinicos ni se usan como fundamento unico de bloqueo.',
};

const promotionPath = path.join(qaDir, 'tamiz_dry_run_promotion_2026-05-20.json');
const queuePath = path.join(outDir, 'officialization_queue_2026-05-20.json');
fs.writeFileSync(promotionPath, JSON.stringify(promotion, null, 2) + '\n');
fs.writeFileSync(queuePath, JSON.stringify(officializationQueue, null, 2) + '\n');
console.log(JSON.stringify({
  ok: true,
  promotion_path: promotionPath,
  officialization_queue_path: queuePath,
  approved_for_dry_run: approvedForDryRun.length,
  soft_warning: softWarning.length,
  pending_review: pendingReview.length,
}, null, 2));
