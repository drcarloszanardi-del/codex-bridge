#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = path.resolve(__dirname, '..', '..');
const rawDir = path.join(root, 'data', 'raw', 'legal');
const manifestPath = path.join(rawDir, `manifest_${new Date().toISOString().slice(0, 10)}.json`);

const sources = [
  {
    id: 'norm_ley_27706_infoleg',
    title: 'Ley 27.706, Programa Federal Unico de Informatizacion y Digitalizacion de Historias Clinicas',
    official_url: 'https://servicios.infoleg.gob.ar/infolegInternet/anexos/380000-384999/380710/norma.htm',
    alternate_url: 'https://www.argentina.gob.ar/normativa/nacional/ley-27706-380710/texto',
    file: 'norm_ley_27706_infoleg.html',
    publication_date: '2023-03-16',
    jurisdiction: 'nacional',
  },
  {
    id: 'norm_dec_393_2023_infoleg',
    title: 'Decreto 393/2023 reglamentario de Ley 27.706',
    official_url: 'https://servicios.infoleg.gob.ar/infolegInternet/anexos/385000-389999/387475/norma.htm',
    alternate_url: 'https://www.argentina.gob.ar/normativa/nacional/decreto-393-2023-387475/texto',
    file: 'norm_dec_393_2023_infoleg.html',
    publication_date: '2023-07-31',
    jurisdiction: 'nacional',
  },
  {
    id: 'norm_ley_14494_pba',
    title: 'Provincia de Buenos Aires Ley 14.494, historia clinica electronica unica',
    official_url: 'https://normas.gba.gob.ar/ar-b/ley/2013/14494/11338',
    alternate_url: 'https://www.ms.gba.gov.ar/sitios/saluddigitalbonaerense/wp-content/uploads/sites/245/2022/10/Ley-Provincial-14.494.pdf',
    file: 'norm_ley_14494_pba.html',
    publication_date: '2013-03-19',
    jurisdiction: 'provincia_buenos_aires',
  },
  {
    id: 'norm_dec_1600_2024_pba',
    title: 'Provincia de Buenos Aires Decreto 1600/2024 reglamentario de Ley 14.494',
    official_url: 'https://normas.gba.gob.ar/ar-b/decreto/2024/1600/451942',
    alternate_url: 'https://normas.gba.gob.ar/documentos/0vwKpRIz.pdf',
    file: 'norm_dec_1600_2024_pba.html',
    publication_date: '2024-08-19',
    jurisdiction: 'provincia_buenos_aires',
  },
  {
    id: 'norm_dec_182_2019_firma_digital_argentina_gob',
    title: 'Decreto 182/2019 reglamentario de Firma Digital',
    official_url: 'https://www.argentina.gob.ar/normativa/nacional/decreto-182-2019-320735/texto',
    alternate_url: 'https://servicios.infoleg.gob.ar/infolegInternet/anexos/320000-324999/320735/norma.htm',
    file: 'norm_dec_182_2019_firma_digital_argentina_gob.html',
    publication_date: '2019-03-12',
    jurisdiction: 'nacional',
  },
  {
    id: 'norm_dec_1558_2001_datos_personales_argentina_gob',
    title: 'Decreto 1558/2001 reglamentario de Proteccion de Datos Personales',
    official_url: 'https://www.argentina.gob.ar/normativa/nacional/decreto-1558-2001-70368/texto',
    alternate_url: 'https://www.argentina.gob.ar/normativa/nacional/decreto-1558-2001-70368/actualizacion',
    file: 'norm_dec_1558_2001_datos_personales_argentina_gob.html',
    publication_date: '2001-12-03',
    jurisdiction: 'nacional',
  },
  {
    id: 'norm_ley_27553_receta_teleasistencia_argentina_gob',
    title: 'Ley 27.553, recetas electronicas o digitales y teleasistencia',
    official_url: 'https://www.argentina.gob.ar/normativa/nacional/ley-27553-340919/texto',
    alternate_url: 'https://servicios.infoleg.gob.ar/infolegInternet/anexos/340000-344999/340919/texact.htm',
    file: 'norm_ley_27553_receta_teleasistencia_argentina_gob.html',
    publication_date: '2020-08-11',
    jurisdiction: 'nacional',
  },
];

function sha256(buffer) {
  return crypto.createHash('sha256').update(buffer).digest('hex');
}

async function fetchWithFallback(source) {
  const urls = [source.official_url, source.alternate_url].filter(Boolean);
  let lastError;
  for (const url of urls) {
    try {
      const res = await fetch(url, {
        headers: {
          'user-agent': 'Codex medicolegal corpus updater/2026-05-20',
          'accept': 'text/html,application/xhtml+xml,application/pdf,*/*',
        },
      });
      if (!res.ok) {
        lastError = new Error(`HTTP ${res.status} ${url}`);
        continue;
      }
      const arrayBuffer = await res.arrayBuffer();
      return {
        final_url: res.url || url,
        content_type: res.headers.get('content-type') || 'application/octet-stream',
        buffer: Buffer.from(arrayBuffer),
      };
    } catch (err) {
      lastError = err;
    }
  }
  throw lastError || new Error(`No fetchable URL for ${source.id}`);
}

function upsertManifestItem(manifest, item) {
  const index = manifest.findIndex((existing) => existing.id === item.id);
  if (index === -1) manifest.push(item);
  else manifest[index] = item;
}

async function main() {
  fs.mkdirSync(rawDir, { recursive: true });
  const manifest = fs.existsSync(manifestPath) ? JSON.parse(fs.readFileSync(manifestPath, 'utf8')) : [];
  const fetchedAt = new Date().toISOString();
  const results = [];

  for (const source of sources) {
    const fetched = await fetchWithFallback(source);
    const rawPath = path.join(rawDir, source.file);
    fs.writeFileSync(rawPath, fetched.buffer);
    const hash = sha256(fetched.buffer);
    const meta = {
      id: source.id,
      title: source.title,
      official_url: source.official_url,
      alternate_url: source.alternate_url || null,
      final_url: fetched.final_url,
      content_type: fetched.content_type,
      fetched_at: fetchedAt,
      sha256: hash,
      raw_path: rawPath,
      publication_date: source.publication_date,
      jurisdiction: source.jurisdiction,
      mode: 'detect_only',
      activation_state: 'pending_review',
    };
    fs.writeFileSync(rawPath.replace(/\.(html|pdf)$/i, '.meta.json'), JSON.stringify(meta, null, 2) + '\n');
    upsertManifestItem(manifest, {
      id: source.id,
      title: source.title,
      layer: 'normativo',
      source_type: path.extname(rawPath).slice(1) || 'html',
      official_url: source.official_url,
      alternate_url: source.alternate_url || null,
      fetched_at: fetchedAt,
      final_url: fetched.final_url,
      content_type: fetched.content_type,
      publication_date: source.publication_date,
      jurisdiction: source.jurisdiction,
      sha256: hash,
      raw_path: rawPath,
      activation_state: 'pending_review',
    });
    results.push({ id: source.id, sha256: hash, bytes: fetched.buffer.length, final_url: fetched.final_url });
  }

  manifest.sort((a, b) => String(a.id).localeCompare(String(b.id)));
  fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2) + '\n');
  console.log(JSON.stringify({
    ok: true,
    fetched_at: fetchedAt,
    manifest: manifestPath,
    added_or_updated: results.length,
    results,
  }, null, 2));
}

main().catch((err) => {
  console.error(err.stack || String(err));
  process.exit(1);
});
