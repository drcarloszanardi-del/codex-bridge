#!/usr/bin/env node
const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..', '..');
const processedDir = path.join(root, 'data/processed/legal_corpus');
fs.mkdirSync(processedDir, { recursive: true });

function pickLatestManifest(dir) {
  const manifestFiles = fs
    .readdirSync(dir)
    .filter((file) => /^manifest_\d{4}-\d{2}-\d{2}\.json$/.test(file))
    .sort();
  if (!manifestFiles.length) {
    throw new Error(`No manifest_YYYY-MM-DD.json found in ${dir}`);
  }
  return path.join(dir, manifestFiles.at(-1));
}

const rawLegal = JSON.parse(fs.readFileSync(pickLatestManifest(path.join(root, 'data/raw/legal')), 'utf8'));
const rawJur = JSON.parse(fs.readFileSync(pickLatestManifest(path.join(root, 'data/raw/jurisprudence')), 'utf8'));
const rawDoctrine = JSON.parse(fs.readFileSync(pickLatestManifest(path.join(root, 'data/raw/doctrine')), 'utf8'));
const rawInternal = JSON.parse(fs.readFileSync(pickLatestManifest(path.join(root, 'data/raw/internal')), 'utf8'));

function extractResults(file, label) {
  const j = JSON.parse(fs.readFileSync(file, 'utf8'));
  const docList = (j.searchResults && j.searchResults.documentResultList) || j.documentResultList || [];
  if (Array.isArray(docList) && docList.length) {
    return docList.slice(0, 5).map((item) => {
      let parsed = {};
      try {
        parsed = JSON.parse(item.documentAbstract || '{}');
      } catch {
        parsed = {};
      }
      const doc = parsed.document || {};
      const metadata = doc.metadata || {};
      const content = doc.content || {};
      const friendly = metadata['friendly-url'] || {};
      return {
        source_query: path.basename(file, '.json'),
        query_label: label,
        friendly_url: friendly.description || '',
        subdomain: friendly.subdomain || '',
        tribunal: content.tribunal || '',
        fecha: content.fecha || '',
        titulo: content.sobre || content['titulo-rubro'] || '',
        texto_resumen_fuente: content.texto || content.sumario || '',
        confidence: 'structured_search_result_pending_full_text_review'
      };
    });
  }
  const arr = (j.searchResults && j.searchResults.searchResults) || j.searchResults || j.results || j.items || [];
  return arr
    .filter((x) => x && typeof x === 'object' && (x.title || x.titulo || x.subdomain || x.link || x.date || x.fecha))
    .slice(0, 5)
    .map((x) => ({
      source_query: path.basename(file, '.json'),
      query_label: label,
      friendly_url: x.link || x.url || x.friendlyUrl || x.titulo || x.title || '',
      subdomain: x.subdomain || x.subdominio || '',
      tribunal: x.traditionalCourt || x.court || x.tribunal || '',
      fecha: x.date || x.fecha || '',
      titulo: x.title || x.titulo || '',
      texto_resumen_fuente: x.text || x.texto || x.texto_resumen_fuente || '',
      confidence: 'structured_search_result_pending_full_text_review'
    }));
}

const labelMap = {
  jur_saij_historia_clinica_prueba: 'historia clinica prueba',
  jur_saij_responsabilidad_medica_consentimiento: 'responsabilidad medica consentimiento',
  jur_saij_consentimiento_informado_medico: 'consentimiento informado medico',
  jur_saij_operacion_quirurgica_negligencia_medica: 'operacion quirurgica negligencia medica'
};

const jurCandidates = rawJur.flatMap((item) => extractResults(item.raw_path, labelMap[item.id] || item.title));
const dateStamp = new Date().toISOString().slice(0, 10);
const candidatesPath = path.join(processedDir, `jurisprudencia_candidates_${dateStamp}.json`);
const candidatesLatestPath = path.join(processedDir, 'jurisprudencia_candidates_latest.json');
fs.writeFileSync(candidatesPath, JSON.stringify(jurCandidates, null, 2));
fs.writeFileSync(candidatesLatestPath, JSON.stringify(jurCandidates, null, 2));

const index = {
  generated_at: new Date().toISOString(),
  normative_sources: rawLegal.length,
  jurisprudence_queries: rawJur.length,
  jurisprudence_candidates: jurCandidates.length,
  doctrine_sources: rawDoctrine.length,
  internal_sources: rawInternal.length,
  items: [...rawLegal, ...rawJur, ...rawDoctrine, ...rawInternal]
};
const indexPath = path.join(processedDir, `index_${dateStamp}.json`);
const indexLatestPath = path.join(processedDir, 'index_latest.json');
fs.writeFileSync(indexPath, JSON.stringify(index, null, 2));
fs.writeFileSync(indexLatestPath, JSON.stringify(index, null, 2));

console.log(JSON.stringify({
  index_path: indexPath,
  index_latest_path: indexLatestPath,
  jurisprudence_path: candidatesPath,
  jurisprudence_latest_path: candidatesLatestPath,
  normative_sources: rawLegal.length,
  jurisprudence_queries: rawJur.length,
  jurisprudence_candidates: jurCandidates.length,
  doctrine_sources: rawDoctrine.length,
  internal_sources: rawInternal.length
}, null, 2));
