#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const root = path.resolve(__dirname, '..', '..');
const schemaPath = path.join(root, 'schemas', 'app.sqlite.sql');
const taxonomyPath = path.join(root, 'schemas', 'taxonomy.seed.json');
const dataRawDir = path.join(root, 'data', 'raw', 'legal');
const dataDbDir = path.join(root, 'data', 'db');
const qaDir = path.join(root, 'qa', 'approval_gates');
const dbPath = path.join(dataDbDir, 'medicolegal.sqlite');
const samplePath = path.join(dataRawDir, 'ley_26529_derechos_paciente_seed.txt');
const summaryPath = path.join(qaDir, 'bootstrap_detect_only_summary.json');

fs.mkdirSync(dataRawDir, { recursive: true });
fs.mkdirSync(dataDbDir, { recursive: true });
fs.mkdirSync(qaDir, { recursive: true });

const taxonomy = JSON.parse(fs.readFileSync(taxonomyPath, 'utf8'));
const sampleText = [
  'Ley 26.529 de Derechos del Paciente en su Relacion con los Profesionales e Instituciones de la Salud.',
  'Seed interno de bootstrap detect-only para validar trazabilidad medicolegal sin activacion automatica.',
  'Fuente oficial de referencia: InfoLEG / Boletin Oficial, jurisdiccion nacional.'
].join('\n');
fs.writeFileSync(samplePath, sampleText);

if (fs.existsSync(dbPath)) fs.rmSync(dbPath);
execFileSync('sqlite3', ['-cmd', '.timeout 5000', dbPath], { input: fs.readFileSync(schemaPath, 'utf8') });

const sourceHash = crypto.createHash('sha256').update(sampleText).digest('hex');
const excerpt = 'Seed detect-only de Ley 26.529 para consentimiento informado y trazabilidad medicolegal.';
const excerptHash = crypto.createHash('sha256').update(excerpt).digest('hex');
const now = new Date().toISOString();

const sample = {
  sourceId: 'src_ley_26529_seed',
  rawId: 'raw_ley_26529_seed',
  normId: 'norm_ley_26529_seed',
  fragmentId: 'frag_ley_26529_seed',
  changeId: 'chg_ley_26529_seed',
  queueId: 'rq_ley_26529_seed',
  publicationId: 'pub_ley_26529_seed'
};

const sql = `
BEGIN TRANSACTION;
INSERT INTO source_registry (
  id, source_type, authority_name, title, jurisdiction, official_url, alternate_url, source_hash,
  publication_date, effective_date, control_date, vigencia_status, publication_state, review_status,
  is_official_source, notes
) VALUES (
  '${sample.sourceId}', 'official_normative', 'Honorable Congreso de la Nacion Argentina',
  'Ley 26.529 - Derechos del Paciente', 'nacional',
  'https://servicios.infoleg.gob.ar/infolegInternet/anexos/160000-164999/160432/norma.htm',
  'https://www.boletinoficial.gob.ar/', '${sourceHash}', '2009-11-20', '2009-11-20', '${now}',
  'vigente', 'draft', 'importado', 1,
  'Bootstrap detect-only generado desde taxonomy.seed.json (${taxonomy.guardrails.auto_update_mode}).'
);
INSERT INTO raw_documents (
  id, source_id, document_kind, file_name, mime_type, storage_path, binary_hash, text_hash,
  ingestion_method, immutable_status, created_by, notes
) VALUES (
  '${sample.rawId}', '${sample.sourceId}', 'norma', 'ley_26529_derechos_paciente_seed.txt', 'text/plain',
  '${samplePath}', '${sourceHash}', '${sourceHash}', 'filesystem_sync', 'immutable', 'jarvis_bootstrap',
  'Documento seed local para corrida detect-only.'
);
INSERT INTO norm_index (
  id, source_id, raw_document_id, corpus, title, short_citation, specialty,
  publication_state, vigencia_status, review_status
) VALUES (
  '${sample.normId}', '${sample.sourceId}', '${sample.rawId}', 'normativo',
  'Ley 26.529 - Derechos del Paciente', 'Ley 26.529', 'medicina_legal',
  'draft', 'vigente', 'clasificado'
);
INSERT INTO evidence_fragments (
  id, norm_index_id, raw_document_id, fragment_type, page_label, section_label, excerpt,
  excerpt_hash, proposition, citation_locator, review_status
) VALUES (
  '${sample.fragmentId}', '${sample.normId}', '${sample.rawId}', 'summary', 'n/a', 'seed',
  '${excerpt}', '${excerptHash}', 'Base para consentimiento informado y trazabilidad medico legal.',
  'seed-local', 'clasificado'
);
INSERT INTO change_candidates (
  id, source_id, raw_document_id, candidate_type, detection_method, detected_change_summary,
  old_hash, new_hash, publication_state, review_status, automation_mode, notes
) VALUES (
  '${sample.changeId}', '${sample.sourceId}', '${sample.rawId}', 'new_source', 'crawler_detect_only',
  'Alta detect-only de fuente legal nacional pendiente de revision humana.',
  NULL, '${sourceHash}', 'pending_review', 'clasificacion_pendiente', 'detect_only',
  'No puede activarse automaticamente.'
);
INSERT INTO review_queue (
  id, entity_type, entity_id, queue_reason, severity, requested_publication_state,
  current_publication_state, status, requested_by, notes
) VALUES (
  '${sample.queueId}', 'change_candidates', '${sample.changeId}',
  'Validar fuente legal y decidir publicacion sin auto-activacion.', 'high',
  'approved', 'pending_review', 'pending_review', 'bootstrap_detect_only',
  'Cola creada por bootstrap interno; cualquier activacion requiere aprobacion humana explicita.'
);
INSERT INTO publication_registry (
  id, entity_type, entity_id, publication_state, effective_from, approved_by, approved_at, change_ticket_id, notes
) VALUES (
  '${sample.publicationId}', 'source_registry', '${sample.sourceId}', 'pending_review', '${now}', NULL, NULL,
  '${sample.changeId}', 'Registro de publicacion no activo generado por bootstrap detect-only.'
);
INSERT INTO audit_log (
  id, actor_type, actor_id, entity_type, entity_id, action_type, previous_state, new_state, artifact_path, evidence_hash, notes
) VALUES (
  'audit_bootstrap_detect_only_seed', 'system', 'bootstrap_detect_only', 'change_candidates', '${sample.changeId}',
  'detect_change', 'draft', 'pending_review', '${summaryPath}', '${sourceHash}',
  'Seed detect-only creado sin activar publication_registry.'
);
COMMIT;`;

execFileSync('sqlite3', ['-cmd', '.timeout 5000', dbPath], { input: sql });

const query = (q) => execFileSync('sqlite3', ['-cmd', '.timeout 5000', '-json', dbPath, q], { encoding: 'utf8' });
const result = {
  dbPath,
  samplePath,
  source: JSON.parse(query(`SELECT id, jurisdiction, official_url, source_hash, publication_state, review_status FROM source_registry WHERE id='${sample.sourceId}';`)),
  candidate: JSON.parse(query(`SELECT id, candidate_type, publication_state, review_status, automation_mode FROM change_candidates WHERE id='${sample.changeId}';`)),
  queue: JSON.parse(query(`SELECT id, entity_type, status, severity, requested_publication_state FROM review_queue WHERE id='${sample.queueId}';`)),
  publicationRegistryActiveCount: JSON.parse(query(`SELECT COUNT(*) AS count FROM publication_registry WHERE publication_state='active';`))[0].count,
  sourceRegistryActiveCount: JSON.parse(query(`SELECT COUNT(*) AS count FROM source_registry WHERE publication_state='active';`))[0].count,
  internalRulesActiveCount: JSON.parse(query(`SELECT COUNT(*) AS count FROM internal_rules WHERE publication_state='active';`))[0].count,
  generatedAt: now
};

if (result.publicationRegistryActiveCount !== 0 || result.sourceRegistryActiveCount !== 0 || result.internalRulesActiveCount !== 0) {
  throw new Error('Detect-only guard failed: hay registros activos inesperados.');
}

fs.writeFileSync(summaryPath, JSON.stringify(result, null, 2));
console.log(JSON.stringify(result, null, 2));
