#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const root = path.resolve(__dirname, '..', '..');
const dbPath = path.join(root, 'data', 'db', 'medicolegal.sqlite');
const baseDirs = {
  inbox: path.join(root, 'data', 'raw', 'doctor', 'inbox'),
  processedText: path.join(root, 'data', 'processed', 'text'),
  processedMetadata: path.join(root, 'data', 'processed', 'metadata'),
  styleCorpus: path.join(root, 'data', 'derived', 'style_corpus'),
  qa: path.join(root, 'qa', 'approval_gates')
};

for (const dir of Object.values(baseDirs)) fs.mkdirSync(dir, { recursive: true });
if (!fs.existsSync(dbPath)) throw new Error(`SQLite no inicializado: ${dbPath}`);

const syntheticText = [
  'DRY-RUN SINTETICO. SIN DATOS REALES NI PHI.',
  'Historia clinica simulada para validar pipeline previo a archivos reales del doctor.',
  'Paciente: CASO_DEMO_001.',
  'Motivo: dolor lumbar con irradiacion ciatica, evaluacion prequirurgica.',
  'Plan: correlacion clinico-radiologica, consentimiento y eventual parte quirurgico pendiente.',
  'Nota de estilo: mantener este corpus separado del corpus legal e interno hasta revision humana.'
].join('\n');

const rawFileName = '2026-05-17_dry_run_historia_clinica_sintetica.txt';
const rawPath = path.join(baseDirs.inbox, rawFileName);
fs.writeFileSync(rawPath, syntheticText);

const sha256 = (value) => crypto.createHash('sha256').update(value).digest('hex');
const binaryHash = sha256(fs.readFileSync(rawPath));
const textHash = sha256(syntheticText);
const now = new Date().toISOString();

const manifest = {
  runId: 'cli_dry_run_001',
  generatedAt: now,
  mode: 'synthetic_dry_run',
  contains_phi: false,
  raw: {
    fileName: rawFileName,
    path: rawPath,
    binaryHash,
    textHash,
    immutableStatus: 'immutable'
  },
  processing: {
    classification: 'clasificacion_pendiente',
    corpus: 'clinico',
    legalActivation: 'forbidden_detect_only',
    styleCorpusSeparated: true
  }
};

const textOutPath = path.join(baseDirs.processedText, 'hc_sintetica_dry_run_001.txt');
const metadataOutPath = path.join(baseDirs.processedMetadata, 'hc_sintetica_dry_run_001.manifest.json');
const styleOutPath = path.join(baseDirs.styleCorpus, 'hc_sintetica_dry_run_001.style.txt');
fs.writeFileSync(textOutPath, syntheticText);
fs.writeFileSync(metadataOutPath, JSON.stringify(manifest, null, 2));
fs.writeFileSync(styleOutPath, [
  'CORPUS DE ESTILO CLINICO SEPARADO.',
  'Origen: dry-run sintetico.',
  'Estado: clasificacion_pendiente.',
  'Prohibido mezclar con normativa/reglas internas activas.'
].join('\n'));

const ids = {
  sourceId: 'src_clinica_dry_run_001',
  rawId: 'raw_clinica_dry_run_001',
  indexId: 'idx_clinica_dry_run_001',
  auditId: 'audit_clinica_dry_run_001'
};

const escape = (s) => String(s).replace(/'/g, "''");
const sql = `
BEGIN TRANSACTION;
DELETE FROM audit_log WHERE id='${ids.auditId}';
DELETE FROM norm_index WHERE id='${ids.indexId}';
DELETE FROM raw_documents WHERE id='${ids.rawId}';
DELETE FROM source_registry WHERE id='${ids.sourceId}';
INSERT INTO source_registry (
  id, source_type, authority_name, title, jurisdiction, official_url, alternate_url, source_hash,
  publication_date, effective_date, control_date, vigencia_status, publication_state, review_status,
  is_official_source, notes
) VALUES (
  '${ids.sourceId}', 'official_doctrine', 'Dr. Carlos Zanardi (origen sintetico local)',
  'Dry-run sintetico historia clinica', 'otras',
  'file://${escape(rawPath)}', NULL, '${binaryHash}', '${now.slice(0,10)}', '${now.slice(0,10)}', '${now}',
  'pendiente_control', 'pending_review', 'clasificacion_pendiente', 0,
  'Fixture sintetico pre-ingesta sin PHI para validar pipeline clinico.'
);
INSERT INTO raw_documents (
  id, source_id, document_kind, file_name, mime_type, storage_path, binary_hash, text_hash,
  ingestion_method, immutable_status, created_by, notes
) VALUES (
  '${ids.rawId}', '${ids.sourceId}', 'historia_clinica', '${rawFileName}', 'text/plain',
  '${escape(rawPath)}', '${binaryHash}', '${textHash}', 'filesystem_sync', 'immutable', 'jarvis_dry_run',
  'Entrada sintetica sin datos reales ni PHI.'
);
INSERT INTO norm_index (
  id, source_id, raw_document_id, corpus, title, short_citation, specialty,
  publication_state, vigencia_status, review_status
) VALUES (
  '${ids.indexId}', '${ids.sourceId}', '${ids.rawId}', 'clinico',
  'Historia clinica sintetica dry-run', 'HC dry-run 001', 'columna',
  'pending_review', 'pendiente_control', 'clasificacion_pendiente'
);
INSERT INTO audit_log (
  id, actor_type, actor_id, entity_type, entity_id, action_type, previous_state, new_state, artifact_path, evidence_hash, notes
) VALUES (
  '${ids.auditId}', 'system', 'jarvis_dry_run', 'raw_documents', '${ids.rawId}', 'ingest', 'draft', 'pending_review',
  '${escape(metadataOutPath)}', '${binaryHash}', 'Dry-run clinico sintetico con hash/manifiesto y clasificacion pendiente.'
);
COMMIT;`;

execFileSync('sqlite3', ['-cmd', '.timeout 5000', dbPath], { input: sql });

const output = {
  dbPath,
  rawPath,
  textOutPath,
  metadataOutPath,
  styleOutPath,
  binaryHash,
  textHash,
  generatedAt: now
};

console.log(JSON.stringify(output, null, 2));
