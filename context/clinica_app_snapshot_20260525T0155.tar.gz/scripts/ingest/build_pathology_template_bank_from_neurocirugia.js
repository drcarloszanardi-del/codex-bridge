#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const APP_ROOT = path.resolve(__dirname, '..', '..');
const NEURO_ROOT = '/Users/jarvis/Desktop/NEUROCIRUGIA';
const OUT_DIR = path.join(APP_ROOT, 'data', 'derived', 'pathology_templates');
const TEMPLATE_DIR = path.join(APP_ROOT, 'data', 'derived', 'template_mothers');
const QA_DIR = path.join(APP_ROOT, 'qa', 'approval_gates');
const GENERATED_AT = new Date().toISOString();
const DATE_ID = GENERATED_AT.slice(0, 10);
const MAX_PER_FAMILY = Number(process.env.MAX_PER_FAMILY || 28);

const SCAN_ROOTS = [
  ['historia_parte', 'NEUROCIRUGIA DE QUIROFANO/Historia + Parte'],
  ['partes_protocolos', 'PARTES Y PROTOCOLOS'],
  ['epicrisis', 'EPICRISIS'],
  ['resumenes_hc_consentimientos', 'Consentimientos/consentimientos/Resumenes HC'],
  ['resumenes_hc_quirofano', 'NEUROCIRUGIA DE QUIROFANO/consentimientos/Resumenes HC'],
];

const SUPPORTED_EXT = new Set(['.doc', '.docx', '.odt', '.rtf', '.txt', '.htm', '.html']);
const SKIP_NAME = /(^~\$|^\.~lock|Thumbs\.db$|\.tmp$|\.lnk$|\.jpg$|\.jpeg$|\.png$|\.gif$|\.db$|\.pdf$|\.ods$|\.dot$)/i;

const COMMON_STYLE_RULES = [
  'No usar y/o, radiculalgia, si corresponde, cuando corresponda, si aplica ni posibles hallazgos no declarados.',
  'El documento visible debe ser clínico y sobrio; las reglas de auditoría quedan fuera del texto del paciente.',
  'Si el dato existe en el relato, se redacta como hecho afirmativo; si falta, queda como observación del tamiz, no como frase abierta.',
  'No agregar déficit motor, reflejos o complicaciones no informadas por el médico.',
  'No copiar textos reales de pacientes ni usar nombres de archivos como contenido clínico.'
];

const COMMON_TAMIZ = [
  'Identificación completa: paciente, edad, fecha, institución, cirujano, ayudantes y horarios cuando el documento sea quirúrgico.',
  'Correlación clínica, examen útil, estudios y diagnóstico deben justificar la indicación.',
  'Consentimiento informado: diagnóstico, procedimiento, riesgos, beneficios, alternativas, no tratamiento, preguntas y revocación.',
  'Parte quirúrgico: técnica secuencial reconstruible, hallazgos, controles críticos, hemostasia, cierre, incidentes y destino.',
  'Implantes permanentes: material utilizado y trazabilidad cuando se prepare documento final; no inventar marca, lote ni medidas.',
  'Eventos excepcionales: consignar solo si ocurrieron o fueron informados; no incorporarlos a plantillas convencionales.',
  'Salida: APTO_PARA_ENVIO, APTO_CON_OBSERVACIONES o BLOQUEADO_NO_ENVIAR según el tamiz flexible obligatorio.'
];

const BASE_OPENING_CONTROLS = [
  'Se verificó identidad del paciente, procedimiento propuesto, nivel, lateralidad y sitio quirúrgico.',
  'Se realizó posicionamiento cuidadoso con acolchado de puntos de apoyo.',
  'Se colocó protección ocular durante el posicionamiento quirúrgico.',
  'Se efectuó antisepsia amplia y colocación de campos estériles.',
  'Se administró profilaxis antibiótica conforme protocolo institucional.'
];

const BASE_CLOSING_CONTROLS = [
  'Se realizó hemostasia cuidadosa y control final del campo quirúrgico.',
  'Se efectuó recuento de gasas, agujas e instrumental conforme protocolo de quirófano.',
  'Se realizó cierre por planos y curación.',
  'No se registraron incidentes intraoperatorios evidentes.'
];

function profile({ indication, symptoms, exam, studies, diagnosis, procedure, risks, requiredFacts = [], technique = [], tamiz = [], consentSlug = null, rootRules = null }) {
  return {
    clinical_profile: {
      indication,
      symptoms,
      exam,
      studies,
      diagnosis,
      procedure,
      risks,
      root_rules: rootRules,
    },
    historia_clinica_template: {
      visible_sections: ['Motivo de ingreso', 'Enfermedad actual', 'Examen físico', 'Estudios', 'Impresión diagnóstica', 'Plan'],
      required_input_facts: ['paciente', 'edad', 'fecha', 'diagnóstico/procedimiento', ...requiredFacts],
      style_rules: COMMON_STYLE_RULES,
    },
    parte_quirurgico_template: {
      opening_controls: BASE_OPENING_CONTROLS,
      operative_sequence: technique,
      closing_controls: BASE_CLOSING_CONTROLS,
      required_input_facts: ['paciente', 'fecha', 'hora de inicio', 'hora de fin', 'ayudantes', 'procedimiento', ...requiredFacts],
    },
    medico_legal_tamiz: [...COMMON_TAMIZ, ...tamiz],
    consent_slug: consentSlug,
  };
}

const FAMILY_SPECS = [
  {
    id: 'columna_lumbar_hernia_disco',
    label: 'Hernia de disco lumbar / microdiscectomía',
    category: 'Columna',
    sourceHints: ['Historia + Parte/Columna/Disco lumbar', 'Historia + Parte/Columna/TUBULAR'],
    terms: ['hernia de disco lumbar', 'microdiscectomía', 'discectomía', 'tubular', 'extrusión discal', 'hdl'],
    pathRx: /columna\/(disco lumbar|tubular)|microdiscect|discect|hernia.*lumbar|hdl/i,
    mother: profile({
      indication: 'lumbalgia con dolor radicular persistente con correlación clínico-radiológica por hernia discal y respuesta insuficiente al tratamiento conservador.',
      symptoms: ['dolor lumbar irradiado al miembro inferior del lado informado', 'parestesias o hipoestesia en territorio radicular si fueron informadas', 'limitación funcional', 'signos de irritación radicular'],
      exam: 'cuadro compatible con radiculopatía de la raíz correspondiente al nivel y tipo de hernia, sin déficit motor salvo que haya sido informado.',
      studies: 'RM donde se evidencia extrusión discal en el nivel y lateralidad informados, concordante con la clínica y la raíz comprometida.',
      diagnosis: 'hernia discal lumbar sintomática con radiculopatía concordante.',
      procedure: 'microdiscectomía lumbar con descompresión radicular del nivel afectado',
      risks: ['persistencia o recurrencia del dolor', 'recidiva herniaria', 'fibrosis epidural', 'durotomía y pérdida de LCR', 'déficit sensitivo o motor si ocurre', 'infección', 'sangrado', 'necesidad de reoperación'],
      requiredFacts: ['nivel', 'lateralidad', 'tipo de hernia', 'raíz comprometida'],
      technique: [
        'Paciente en decúbito prono bajo anestesia general, con soportes bajo tórax, crestas ilíacas y tobillos.',
        'Se constatan pulsos pedios. Antisepsia rigurosa y colocación de campos estériles.',
        'Marcación radioscópica del nivel informado.',
        'Incisión cutánea paramediana del lado indicado, dilatación progresiva y colocación de sistema tubular si fue utilizado.',
        'Colocación de microscopio quirúrgico y abordaje del espacio interlaminar.',
        'Hemilaminotomía mínima, flavectomía homónima, identificación y protección de la raíz.',
        'Disección y extracción del fragmento discal extruido responsable de la compresión.',
        'Constatación de adecuada liberación de la raíz, saco dural pulsátil y ausencia de compresión residual evidente.',
        'Retiro del sistema tubular bajo visión directa cuando se utilizó.'
      ],
      tamiz: ['Bloquear si aparece radiculalgia, y/o, raíz incorrecta para L4-L5 habitual o déficit motor no informado.'],
      consentSlug: 'hernia_disco_lumbar',
      rootRules: {
        habitual: { 'L3-L4': 'L4', 'L4-L5': 'L5', 'L5-S1': 'S1' },
        extraforaminal: { 'L3-L4': 'L3', 'L4-L5': 'L4', 'L5-S1': 'L5' },
      },
    }),
  },
  {
    id: 'columna_lumbar_canal_estrecho',
    label: 'Canal estrecho lumbar / recalibraje',
    category: 'Columna',
    sourceHints: ['Historia + Parte/Columna/Canal estrecho'],
    terms: ['canal estrecho lumbar', 'estenosis lumbar', 'recalibraje', 'claudicación neurógena'],
    pathRx: /columna\/canal estrecho|canal estrecho lumbar|estenosis lumbar|recalibraje/i,
    mother: profile({
      indication: 'dolor lumbar y claudicación neurógena con limitación funcional por estenosis de canal lumbar, con correlación clínica e imagenológica.',
      symptoms: ['dolor lumbar', 'dolor radicular', 'claudicación neurógena', 'limitación progresiva para la marcha'],
      exam: 'examen neurológico y de marcha concordante con compromiso lumbar degenerativo, sin agregar déficit no informado.',
      studies: 'RM lumbar con estenosis de canal y recesos laterales en el nivel informado, concordante con la clínica.',
      diagnosis: 'canal estrecho lumbar sintomático.',
      procedure: 'descompresión/recalibraje microquirúrgico del canal lumbar en el nivel indicado',
      risks: ['dolor residual', 'persistencia de claudicación', 'durotomía y pérdida de LCR', 'déficit neurológico', 'infección', 'sangrado', 'inestabilidad secundaria', 'necesidad de reintervención'],
      requiredFacts: ['nivel', 'síntomas dominantes', 'si lleva o no fijación'],
      technique: [
        'Paciente en decúbito prono bajo anestesia general, con protección ocular y acolchado de puntos de apoyo.',
        'Marcación radioscópica del nivel.',
        'Abordaje posterior por planos hasta elementos posteriores.',
        'Descompresión del canal mediante laminectomía, hemilaminectomía, flavectomía y liberación de recesos laterales según el nivel informado.',
        'Identificación y protección de saco dural y raíces.',
        'Constatación de adecuada amplitud del canal y ausencia de compresión residual evidente.'
      ],
      tamiz: ['No usar relato de extrusión discal salvo que la patología sea hernia asociada explícita.'],
      consentSlug: 'canal_estrecho_lumbar',
    }),
  },
  {
    id: 'columna_lumbar_fijacion_transpedicular',
    label: 'Fijación transpedicular lumbar',
    category: 'Columna',
    sourceHints: ['Historia + Parte/Columna/Transpedicular'],
    terms: ['fijación transpedicular', 'artrodesis lumbar', 'instrumentación lumbar', 'tornillos pediculares'],
    pathRx: /columna\/transpedicular(?!\/360)|fijaci[oó]n transpedicular|instrumentaci[oó]n|tornillos/i,
    mother: profile({
      indication: 'dolor lumbar mecánico y dolor radicular por inestabilidad asociada a patología degenerativa, con correlación clínico-radiológica e indicación de descompresión y estabilización.',
      symptoms: ['lumbalgia mecánica', 'dolor radicular', 'limitación para marcha y actividades habituales', 'claudicación neurógena si fue informada'],
      exam: 'semiología lumbar y radicular concordante con el segmento comprometido, sin déficit motor salvo declaración expresa.',
      studies: 'RM y estudios dinámicos donde se evidencia patología degenerativa, estenosis o inestabilidad del nivel informado, concordante con la clínica.',
      diagnosis: 'patología degenerativa lumbar con inestabilidad y compromiso neural.',
      procedure: 'descompresión, artrodesis e instrumentación transpedicular del segmento indicado',
      risks: ['dolor residual', 'pseudoartrosis', 'falla o malposición de implantes', 'lesión radicular', 'durotomía y pérdida de LCR', 'infección', 'sangrado', 'trombosis', 'necesidad de cirugía adicional'],
      requiredFacts: ['nivel', 'si hay caja/celda', 'implantes', 'lateralidad del abordaje si aplica'],
      technique: [
        'Paciente en decúbito prono bajo anestesia general, con protección ocular, soportes y acolchado de puntos de apoyo.',
        'Marcación radioscópica del nivel y chequeo del material de instrumentación.',
        'Abordaje posterior mediano o miniinvasivo según el dato del caso.',
        'Exposición de elementos posteriores y puntos de entrada pedicular.',
        'Colocación de tornillos transpediculares bajo reparos anatómicos y control radioscópico.',
        'Descompresión neural con laminectomía o hemilaminectomía, flavectomía y liberación de recesos/forámenes.',
        'Identificación y protección de saco dural y raíces comprometidas.',
        'Colocación de barras, maniobras de reducción/compresión si fueron realizadas y chequeo radioscópico del montaje.',
        'Injerto posterolateral si fue utilizado, control de estabilidad y ausencia de compresión residual evidente.'
      ],
      tamiz: ['Implantes permanentes requieren trazabilidad para el documento final; no inventar marca, lote ni medida.'],
      consentSlug: 'canal_estrecho_lumbar_con_fijacion',
    }),
  },
  {
    id: 'columna_lumbar_espondilolistesis',
    label: 'Espondilolistesis lumbar',
    category: 'Columna',
    sourceHints: ['Historia + Parte/Columna/Transpedicular/ESPONDILOLISTESIS'],
    terms: ['espondilolistesis', 'listesis', 'inestabilidad segmentaria'],
    pathRx: /espondilolistesis|listesis/i,
    mother: profile({
      indication: 'dolor lumbar mecánico y dolor radicular por espondilolistesis lumbar, con inestabilidad segmentaria y correlación clínico-radiológica.',
      symptoms: ['lumbalgia mecánica', 'dolor radicular', 'limitación funcional', 'claudicación neurógena si fue informada'],
      exam: 'examen lumbar y radicular concordante con el nivel de listesis, sin déficit no informado.',
      studies: 'RM, radiografías dinámicas o TC donde se evidencia espondilolistesis e inestabilidad del nivel informado.',
      diagnosis: 'espondilolistesis lumbar sintomática con inestabilidad.',
      procedure: 'descompresión, reducción/estabilización y artrodesis instrumentada del nivel indicado',
      risks: ['dolor residual', 'pseudoartrosis', 'falla de implantes', 'lesión radicular', 'durotomía', 'infección', 'sangrado', 'necesidad de reintervención'],
      requiredFacts: ['nivel', 'grado de listesis si fue informado', 'implantes'],
      technique: [
        'Marcación radioscópica del nivel y chequeo del material.',
        'Abordaje posterior, exposición del segmento y colocación de tornillos pediculares.',
        'Descompresión de elementos neurales comprometidos.',
        'Maniobras de reducción o estabilización según anatomía y plan quirúrgico.',
        'Colocación de barras, control radioscópico del montaje, injerto y cierre por planos.'
      ],
      consentSlug: 'canal_estrecho_lumbar_con_fijacion',
    }),
  },
  {
    id: 'columna_lumbar_360_circunferencial',
    label: 'Artrodesis lumbar circunferencial / 360',
    category: 'Columna',
    sourceHints: ['Historia + Parte/Columna/Transpedicular/360'],
    terms: ['360', 'circunferencial', 'plif', 'tlif', 'caja intersomática', 'celda'],
    pathRx: /transpedicular\/360|circunferencial|plif|tlif|caja|celda/i,
    mother: profile({
      indication: 'dolor lumbar mecánico y dolor radicular por patología degenerativa con inestabilidad y necesidad de estabilización circunferencial.',
      symptoms: ['lumbalgia mecánica', 'dolor radicular', 'limitación funcional', 'intolerancia a la marcha'],
      exam: 'semiología lumbar y radicular concordante con el nivel informado.',
      studies: 'RM, TC o radiografías dinámicas con compromiso discal, estenosis o inestabilidad del nivel informado.',
      diagnosis: 'patología degenerativa lumbar con inestabilidad segmentaria.',
      procedure: 'descompresión, instrumentación transpedicular y artrodesis intersomática del nivel indicado',
      risks: ['pseudoartrosis', 'subsidencia o desplazamiento de caja', 'malposición de implantes', 'lesión radicular', 'durotomía', 'infección', 'sangrado', 'dolor residual'],
      requiredFacts: ['nivel', 'tipo de caja/celda si fue informado', 'lateralidad del abordaje', 'implantes'],
      technique: [
        'Abordaje posterior con marcación radioscópica y chequeo del material.',
        'Colocación de tornillos transpediculares y descompresión neural.',
        'Facetectomía o abordaje lateral intersomático según técnica informada.',
        'Discectomía, preparación de platillos, colocación de injerto y caja/celda intersomática si fue utilizada.',
        'Colocación de barras, compresión/reducción, control radioscópico del material, hemostasia y cierre.'
      ],
      consentSlug: 'canal_estrecho_lumbar_con_fijacion',
    }),
  },
  {
    id: 'columna_interespinoso_coflex_diam',
    label: 'Dispositivo interespinoso / Coflex / DIAM',
    category: 'Columna',
    sourceHints: ['Historia + Parte/Columna/COFLEX', 'Historia + Parte/Columna/COFLEX/DIAM'],
    terms: ['coflex', 'diam', 'interespinoso'],
    pathRx: /coflex|diam|interespinos/i,
    mother: profile({
      indication: 'estenosis lumbar o inestabilidad dinámica con indicación de descompresión y estabilización interespinosa.',
      symptoms: ['dolor lumbar', 'dolor radicular', 'claudicación neurógena', 'limitación funcional'],
      exam: 'examen lumbar/radicular concordante con el nivel informado.',
      studies: 'RM y estudios dinámicos con estenosis o inestabilidad del nivel tratado.',
      diagnosis: 'patología degenerativa lumbar con estenosis o inestabilidad dinámica.',
      procedure: 'descompresión lumbar y colocación de dispositivo interespinoso en el nivel indicado',
      risks: ['dolor residual', 'migración o falla de dispositivo', 'fractura de apófisis espinosa', 'infección', 'sangrado', 'reintervención'],
      requiredFacts: ['nivel', 'dispositivo', 'medida si fue informada'],
      technique: [
        'Marcación radioscópica del nivel y chequeo del dispositivo.',
        'Abordaje posterior limitado, descompresión de canal/recesos si fue realizada.',
        'Preparación del espacio interespinoso, colocación del dispositivo y control radioscópico final.'
      ],
      consentSlug: 'canal_estrecho_lumbar',
    }),
  },
  {
    id: 'columna_cervical_disco_fusion',
    label: 'Discectomía cervical anterior y fusión',
    category: 'Columna',
    sourceHints: ['Historia + Parte/Columna/Disco Cervical/Fusiones'],
    terms: ['disco cervical', 'acdf', 'artrodesis cervical', 'cage cervical', 'celda cervical'],
    pathRx: /disco cervical\/fusiones|acdf|artrodesis cervical|cage cervical|celda cervical/i,
    mother: profile({
      indication: 'cervicobraquialgia o mielorradiculopatía por hernia discal o estenosis cervical, con correlación clínica e imagenológica.',
      symptoms: ['cervicalgia', 'dolor radicular braquial', 'parestesias en territorio radicular', 'signos de compromiso medular si fueron informados'],
      exam: 'examen neurológico cervical y radicular concordante con el nivel informado.',
      studies: 'RM cervical donde se evidencia hernia discal o estenosis foraminal/canal en el nivel informado.',
      diagnosis: 'hernia discal o estenosis cervical sintomática.',
      procedure: 'discectomía cervical anterior, descompresión y artrodesis intersomática del nivel indicado',
      risks: ['disfonía', 'disfagia', 'lesión esofágica o vascular', 'lesión medular o radicular', 'pseudoartrosis', 'falla de implante', 'infección', 'sangrado', 'dolor residual'],
      requiredFacts: ['nivel', 'lateralidad si radicular', 'implante/cage si informado'],
      technique: [
        'Paciente en decúbito dorsal bajo anestesia general, con protección ocular y puntos de apoyo acolchados.',
        'Control radioscópico del nivel y chequeo del implante.',
        'Abordaje cervical anterior por planos, disección hasta espacio discal.',
        'Discectomía, descompresión neural y preparación de platillos.',
        'Colocación de injerto/cage o placa si fue utilizada, control radioscópico final y cierre por planos.'
      ],
      consentSlug: 'discectomia_cervical_anterior_fusion',
    }),
  },
  {
    id: 'columna_cervical_artroplastia',
    label: 'Artroplastia cervical',
    category: 'Columna',
    sourceHints: ['Historia + Parte/Columna/Disco Cervical/Artroplastia'],
    terms: ['artroplastia cervical', 'prótesis discal cervical'],
    pathRx: /disco cervical\/artroplastia|artroplastia cervical|protesis discal cervical|pr[oó]tesis discal/i,
    mother: profile({
      indication: 'cervicobraquialgia por patología discal cervical con indicación de descompresión y preservación de movilidad segmentaria.',
      symptoms: ['cervicalgia', 'dolor radicular braquial', 'parestesias en territorio radicular', 'limitación funcional'],
      exam: 'examen cervical y radicular concordante con el nivel indicado.',
      studies: 'RM cervical con hernia discal o compresión radicular del nivel informado.',
      diagnosis: 'patología discal cervical sintomática.',
      procedure: 'discectomía cervical anterior y colocación de prótesis discal cervical',
      risks: ['persistencia de dolor', 'heterotopía', 'migración o falla de prótesis', 'disfagia', 'disfonía', 'lesión neural o vascular', 'infección', 'sangrado'],
      requiredFacts: ['nivel', 'modelo/medida si fue informado'],
      technique: [
        'Abordaje cervical anterior con control radioscópico del nivel y chequeo del implante.',
        'Discectomía completa, descompresión, preparación de platillos y colocación de prótesis discal.',
        'Control radioscópico de posición y movilidad, hemostasia y cierre por planos.'
      ],
      consentSlug: 'artroplastia_cervical',
    }),
  },
  {
    id: 'columna_cervical_laminoplastia',
    label: 'Canal estrecho cervical / laminoplastia',
    category: 'Columna',
    sourceHints: ['Historia + Parte/Columna/Laminoplastia'],
    terms: ['laminoplastia', 'mielopatía cervical', 'canal estrecho cervical'],
    pathRx: /laminoplast|mielopat|canal estrecho cervical/i,
    mother: profile({
      indication: 'mielopatía cervical por estenosis de canal con correlación clínica e imagenológica.',
      symptoms: ['trastorno de la marcha', 'torpeza manual', 'parestesias', 'signos de compromiso medular cervical'],
      exam: 'examen neurológico compatible con mielopatía cervical, con compromiso funcional concordante con los niveles afectados.',
      studies: 'RMN cervical con estenosis de canal en los niveles informados, con señal medular si fue informada.',
      diagnosis: 'mielopatía cervical por canal estrecho.',
      procedure: 'laminoplastia cervical expansiva descompresiva',
      risks: ['déficit neurológico transitorio o permanente', 'dolor axial', 'inestabilidad', 'infección', 'sangrado', 'lesión dural', 'necesidad de reintervención'],
      requiredFacts: ['niveles', 'técnica laminoplastia', 'placas si se usaron'],
      technique: [
        'Paciente en decúbito prono, fijación cefálica y protección de puntos de apoyo.',
        'Abordaje posterior cervical por planos y exposición de niveles comprometidos.',
        'Realización de canal de apertura y bisagra contralateral.',
        'Apertura laminar, fijación con placas de laminoplastia si fueron utilizadas y control de adecuada descompresión.',
        'Hemostasia, drenaje si fue colocado, cierre por planos y curación.'
      ],
      tamiz: ['Si el médico indicó laminoplastia, no ofrecer laminectomía como alternativa visible dentro del parte.'],
      consentSlug: 'laminoplastia_cervical',
    }),
  },
  {
    id: 'columna_vertebroplastia',
    label: 'Vertebroplastia',
    category: 'Columna',
    sourceHints: ['Historia + Parte/Columna/Vertebroplastia/VERTEBROPLASTIA'],
    terms: ['vertebroplastia', 'cementación', 'pmma'],
    pathRx: /vertebroplastia(?!\/cifoplastia)|cement|pmma/i,
    mother: profile({
      indication: 'dolor axial focal por fractura vertebral con edema o colapso del cuerpo vertebral, refractario al tratamiento conservador.',
      symptoms: ['dolor axial focal', 'limitación funcional', 'dolor a la bipedestación o movilización'],
      exam: 'dolor localizado concordante con el nivel vertebral afectado, sin déficit neurológico no informado.',
      studies: 'RM, TC o centellograma con fractura vertebral activa en el nivel informado.',
      diagnosis: 'fractura vertebral dolorosa.',
      procedure: 'vertebroplastia percutánea del nivel indicado',
      risks: ['extravasación de cemento', 'dolor residual', 'fractura adyacente', 'lesión neurológica', 'embolismo', 'infección', 'sangrado'],
      requiredFacts: ['nivel vertebral', 'tipo de fractura', 'PMMA/cemento'],
      technique: [
        'Paciente en decúbito prono, antisepsia y campos estériles.',
        'Control radioscópico biplanar del nivel.',
        'Punción transpedicular o parapedicular según anatomía del nivel.',
        'Preparación e inyección controlada de PMMA bajo radioscopía.',
        'Control de distribución del cemento y ausencia de extravasación clínicamente relevante.'
      ],
      consentSlug: 'vertebroplastia',
    }),
  },
  {
    id: 'columna_cifoplastia',
    label: 'Cifoplastia',
    category: 'Columna',
    sourceHints: ['Historia + Parte/Columna/Vertebroplastia/Cifoplastia'],
    terms: ['cifoplastia', 'balón', 'fractura vertebral'],
    pathRx: /cifoplastia|kyphoplast|bal[oó]n/i,
    mother: profile({
      indication: 'dolor axial focal por fractura vertebral con colapso, con indicación de restauración parcial de altura y cementación.',
      symptoms: ['dolor axial focal', 'limitación funcional', 'dolor mecánico por fractura vertebral'],
      exam: 'dolor localizado concordante con el nivel vertebral afectado.',
      studies: 'RM o TC con fractura vertebral activa y colapso del nivel informado.',
      diagnosis: 'fractura vertebral sintomática.',
      procedure: 'cifoplastia percutánea del nivel indicado',
      risks: ['extravasación de cemento', 'fallo de expansión', 'dolor residual', 'fractura adyacente', 'lesión neurológica', 'embolismo', 'infección'],
      requiredFacts: ['nivel', 'balón/cemento si fue informado'],
      technique: [
        'Control radioscópico del nivel y punción pedicular.',
        'Colocación de balón, expansión controlada y preparación de cavidad.',
        'Inyección de PMMA bajo radioscopía y control final de distribución.'
      ],
      consentSlug: 'cifoplastia',
    }),
  },
  {
    id: 'columna_biopsia_vertebral',
    label: 'Biopsia vertebral',
    category: 'Columna',
    sourceHints: ['Historia + Parte/Columna/Biopsia vertebral'],
    terms: ['biopsia vertebral', 'punción biopsia', 'lesión vertebral'],
    pathRx: /biopsia vertebral|biopsia.*columna|punci[oó]n.*vertebral/i,
    mother: profile({
      indication: 'lesión vertebral con necesidad de diagnóstico histológico o microbiológico.',
      symptoms: ['dolor focal vertebral', 'síntomas sistémicos o neurológicos si fueron informados'],
      exam: 'examen neurológico y dolor focal concordante con el nivel afectado.',
      studies: 'RM o TC con lesión vertebral en el nivel informado.',
      diagnosis: 'lesión vertebral en estudio.',
      procedure: 'biopsia vertebral percutánea guiada por imágenes del nivel indicado',
      risks: ['muestra no diagnóstica', 'sangrado', 'infección', 'dolor residual', 'lesión neural', 'necesidad de nueva biopsia'],
      requiredFacts: ['nivel', 'lado/abordaje', 'destino de muestra'],
      technique: [
        'Control de imágenes del nivel, antisepsia y anestesia/local o general según caso.',
        'Punción percutánea hacia lesión vertebral y obtención de muestras.',
        'Envío a anatomía patológica y/o cultivo según solicitud médica.',
        'Control hemostático local y curación.'
      ],
      consentSlug: 'biopsia_vertebral',
    }),
  },
  {
    id: 'columna_tumor',
    label: 'Tumores de columna',
    category: 'Columna',
    sourceHints: ['Historia + Parte/Columna/Tumores'],
    terms: ['tumor medular', 'tumor vertebral', 'lesión intradural', 'metástasis vertebral'],
    pathRx: /columna\/tumores|tumor.*(dorsal|lumbar|cervical|medular|vertebral)|quiste medular/i,
    mother: profile({
      indication: 'lesión tumoral vertebral, intradural o extradural con dolor, compromiso neurológico o necesidad diagnóstica/terapéutica.',
      symptoms: ['dolor axial o radicular', 'déficit neurológico si fue informado', 'síntomas de compresión medular o radicular'],
      exam: 'examen neurológico concordante con el nivel y localización de la lesión.',
      studies: 'RM con lesión tumoral del nivel informado, con extensión y relación neural consignadas según el caso.',
      diagnosis: 'tumor raquimedular o vertebral en el nivel indicado.',
      procedure: 'abordaje, descompresión, biopsia o resección de lesión tumoral de columna según localización',
      risks: ['déficit neurológico', 'sangrado', 'fístula de LCR', 'inestabilidad', 'resección subtotal', 'infección', 'dolor residual', 'reintervención'],
      requiredFacts: ['nivel', 'localización intra/extradural', 'objetivo biopsia/resección/descompresión'],
      technique: [
        'Marcación del nivel y abordaje posterior o anterior según localización.',
        'Exposición de estructuras comprometidas y protección neural.',
        'Biopsia, descompresión o resección de lesión según objetivo informado.',
        'Hemostasia meticulosa, cierre dural si hubo apertura, cierre por planos y curación.'
      ],
      consentSlug: 'tumor_columna',
    }),
  },
  {
    id: 'columna_infeccion_desbridamiento_retiro',
    label: 'Infección de columna / desbridamiento / retiro',
    category: 'Columna',
    sourceHints: ['Historia + Parte/Columna/Infecciones, desbridamientos y retiros'],
    terms: ['infección de columna', 'desbridamiento', 'retiro de material', 'discitis', 'espondilodiscitis'],
    pathRx: /infecciones|desbrid|retiro|discitis|espondilodiscitis/i,
    mother: profile({
      indication: 'infección de herida, implante o columna con indicación de toilette, desbridamiento, toma de muestras o retiro de material.',
      symptoms: ['dolor', 'secreción de herida si fue informada', 'fiebre o síndrome infeccioso si fue informado', 'deterioro local'],
      exam: 'evaluación local de herida y examen neurológico concordante con el cuadro.',
      studies: 'laboratorio, cultivos o imágenes compatibles con proceso infeccioso según el caso.',
      diagnosis: 'infección neuroquirúrgica o espinal.',
      procedure: 'toilette quirúrgica, desbridamiento, toma de muestras y retiro/revisión de material según el caso',
      risks: ['persistencia o recurrencia de infección', 'necesidad de nuevas toilettes', 'sangrado', 'dolor residual', 'déficit neurológico', 'inestabilidad', 'sepsis'],
      requiredFacts: ['sitio', 'muestras/cultivos', 'material retirado si existe'],
      technique: [
        'Apertura de herida o abordaje previo, toma de muestras para cultivo si fue indicada.',
        'Lavado abundante, desbridamiento de tejido desvitalizado y revisión del material.',
        'Retiro o conservación de implantes según estabilidad y criterio informado.',
        'Hemostasia, drenaje si fue colocado y cierre por planos.'
      ],
      consentSlug: 'toilette_desbridamiento_columna',
    }),
  },
  {
    id: 'columna_quiste_facetario',
    label: 'Quiste facetario lumbar',
    category: 'Columna',
    sourceHints: ['Historia + Parte/Columna/Quiste facetario'],
    terms: ['quiste facetario', 'quiste sinovial', 'quiste artrosinovial'],
    pathRx: /quiste facetario|quiste sinovial|facetario/i,
    mother: profile({
      indication: 'dolor radicular por quiste facetario lumbar con compresión neural y correlación clínica e imagenológica.',
      symptoms: ['dolor radicular', 'lumbalgia', 'limitación funcional', 'parestesias si fueron informadas'],
      exam: 'semiología radicular concordante con el nivel y lado del quiste.',
      studies: 'RM donde se evidencia quiste facetario del nivel y lado informados con compresión neural.',
      diagnosis: 'quiste facetario lumbar sintomático.',
      procedure: 'resección microquirúrgica de quiste facetario y descompresión radicular',
      risks: ['recidiva', 'dolor residual', 'durotomía', 'déficit neurológico', 'inestabilidad', 'infección', 'sangrado'],
      requiredFacts: ['nivel', 'lado'],
      technique: [
        'Marcación radioscópica del nivel.',
        'Abordaje posterior o tubular del lado indicado.',
        'Exposición de quiste facetario, disección cuidadosa de saco dural y raíz.',
        'Resección del quiste, liberación neural, hemostasia y cierre.'
      ],
      consentSlug: 'quiste_facetario_lumbar',
    }),
  },
  {
    id: 'tumor_meningioma',
    label: 'Meningioma intracraneal',
    category: 'Cráneo tumoral',
    sourceHints: ['Historia + Parte/Tumores/Meningioma'],
    terms: ['meningioma', 'base de cráneo', 'convexidad'],
    pathRx: /tumores\/meningioma|meningioma/i,
    mother: profile({
      indication: 'lesión extraaxial compatible con meningioma, sintomática o con crecimiento/efecto de masa, con indicación de resección.',
      symptoms: ['cefalea', 'crisis convulsivas', 'déficit neurológico focal según localización', 'síntomas por efecto de masa'],
      exam: 'examen neurológico orientado a localización tumoral y déficit informado.',
      studies: 'RM de encéfalo con contraste donde se evidencia lesión extraaxial compatible con meningioma.',
      diagnosis: 'meningioma intracraneal en la localización informada.',
      procedure: 'craneotomía y resección microquirúrgica de meningioma',
      risks: ['déficit neurológico', 'sangrado', 'edema', 'convulsiones', 'infección', 'fístula de LCR', 'resección subtotal', 'recidiva', 'muerte'],
      requiredFacts: ['localización', 'lado', 'objetivo de resección'],
      technique: [
        'Posicionamiento según localización, fijación cefálica y abordaje craneal planificado.',
        'Craneotomía, apertura dural y exposición de lesión.',
        'Devascularización, reducción tumoral y disección de planos aracnoideos cuando son identificables.',
        'Resección según relación con estructuras vasculonerviosas, hemostasia, cierre dural, reposición ósea y cierre por planos.'
      ],
      consentSlug: 'meningioma_intracraneal',
    }),
  },
  {
    id: 'tumor_glioma',
    label: 'Glioma / tumor intraaxial',
    category: 'Cráneo tumoral',
    sourceHints: ['Historia + Parte/Tumores/Gliomas'],
    terms: ['glioma', 'astrocitoma', 'glioblastoma', 'tumor intraaxial'],
    pathRx: /tumores\/gliomas|glioma|glioblast|astrocit/i,
    mother: profile({
      indication: 'lesión intraaxial compatible con glioma, con indicación de resección, citorreducción o biopsia por clínica, imágenes y estrategia oncológica.',
      symptoms: ['cefalea', 'crisis convulsivas', 'déficit neurológico focal', 'alteración cognitiva o del lenguaje según localización'],
      exam: 'examen neurológico dirigido a áreas elocuentes y déficit informado.',
      studies: 'RM de encéfalo con contraste y secuencias funcionales si fueron realizadas, compatible con lesión intraaxial.',
      diagnosis: 'tumor intraaxial compatible con glioma.',
      procedure: 'craneotomía y resección/biopsia de tumor intraaxial según localización y elocuencia',
      risks: ['déficit neurológico', 'crisis convulsivas', 'edema', 'sangrado', 'infección', 'resección subtotal', 'progresión tumoral', 'muerte'],
      requiredFacts: ['localización', 'lado', 'objetivo resección/biopsia'],
      technique: [
        'Posicionamiento y craneotomía según planificación.',
        'Apertura dural, identificación cortical y abordaje de lesión.',
        'Resección o toma de muestra bajo magnificación y orientación anatómica/neuronavegación si fue utilizada.',
        'Control de hemostasia, cierre dural, reposición ósea y cierre por planos.'
      ],
      consentSlug: 'tumor_intraaxial_glioma',
    }),
  },
  {
    id: 'tumor_metastasis',
    label: 'Metástasis cerebral',
    category: 'Cráneo tumoral',
    sourceHints: ['Historia + Parte/Tumores/MTS'],
    terms: ['metástasis', 'mts', 'lesión secundaria'],
    pathRx: /tumores\/mts|metast|mts/i,
    mother: profile({
      indication: 'lesión cerebral compatible con metástasis con indicación de resección o biopsia por efecto de masa, diagnóstico o control oncológico.',
      symptoms: ['cefalea', 'déficit neurológico focal', 'crisis convulsivas', 'síndrome de hipertensión endocraneana'],
      exam: 'examen neurológico concordante con localización y clínica informada.',
      studies: 'RM/TC de encéfalo con lesión compatible con metástasis en la localización informada.',
      diagnosis: 'lesión metastásica cerebral.',
      procedure: 'craneotomía y resección/biopsia de lesión metastásica cerebral',
      risks: ['déficit neurológico', 'sangrado', 'edema', 'convulsiones', 'infección', 'recidiva/progresión', 'muerte'],
      requiredFacts: ['localización', 'lado', 'antecedente oncológico si fue informado'],
      technique: [
        'Craneotomía orientada a la lesión, apertura dural y exposición cortical.',
        'Abordaje de lesión, resección o toma de muestra y envío a anatomía patológica.',
        'Control de cavidad, hemostasia, cierre dural y cierre por planos.'
      ],
      consentSlug: 'metastasis_cerebral',
    }),
  },
  {
    id: 'tumor_fosa_posterior',
    label: 'Tumor de fosa posterior',
    category: 'Cráneo tumoral',
    sourceHints: ['Historia + Parte/Tumores/FOSA POSTERIOR'],
    terms: ['fosa posterior', 'cerebelo', 'cuarto ventrículo'],
    pathRx: /fosa posterior|cerebel|cuarto ventriculo|iv ventriculo/i,
    mother: profile({
      indication: 'lesión de fosa posterior con síntomas cerebelosos, hidrocefalia, efecto de masa o necesidad diagnóstica/terapéutica.',
      symptoms: ['cefalea', 'vómitos', 'ataxia', 'trastorno de la marcha', 'síndrome de hipertensión endocraneana'],
      exam: 'examen neurológico con foco en pares craneales, marcha, coordinación y signos cerebelosos informados.',
      studies: 'RM de encéfalo con lesión de fosa posterior y relación con tronco, cerebelo o cuarto ventrículo.',
      diagnosis: 'tumor de fosa posterior.',
      procedure: 'craneotomía/craniectomía suboccipital y resección o biopsia de lesión de fosa posterior',
      risks: ['déficit neurológico', 'alteración de pares craneales', 'hidrocefalia', 'fístula de LCR', 'sangrado', 'edema', 'infección', 'muerte'],
      requiredFacts: ['localización', 'hidrocefalia si existe', 'objetivo quirúrgico'],
      technique: [
        'Posicionamiento según abordaje, fijación cefálica y abordaje suboccipital.',
        'Apertura dural, exposición de lesión y estructuras de fosa posterior.',
        'Resección o biopsia bajo magnificación, preservando estructuras neurovasculares.',
        'Hemostasia, cierre dural hermético si es posible, reposición/cierre y curación.'
      ],
      consentSlug: 'tumor_fosa_posterior',
    }),
  },
  {
    id: 'tumor_estereotaxia_biopsia',
    label: 'Biopsia estereotáxica',
    category: 'Cráneo tumoral',
    sourceHints: ['Historia + Parte/Tumores/Estereotaxia'],
    terms: ['estereotaxia', 'biopsia estereotáxica'],
    pathRx: /estereotax|biopsia estereot/i,
    mother: profile({
      indication: 'lesión intracraneal profunda, múltiple o de riesgo elocuente con necesidad de diagnóstico histológico por biopsia estereotáxica.',
      symptoms: ['síntomas neurológicos según localización', 'déficit focal si fue informado', 'crisis convulsivas si fueron informadas'],
      exam: 'examen neurológico dirigido a localización de la lesión.',
      studies: 'RM/TC con lesión objetivo y planificación estereotáxica.',
      diagnosis: 'lesión intracraneal en estudio.',
      procedure: 'biopsia estereotáxica de lesión intracraneal',
      risks: ['hemorragia', 'déficit neurológico', 'muestra no diagnóstica', 'convulsiones', 'infección', 'necesidad de nueva biopsia'],
      requiredFacts: ['localización', 'lado', 'sistema estereotáxico/neuronavegación si informado'],
      technique: [
        'Planificación estereotáxica con imágenes.',
        'Colocación de marco o sistema de guía, antisepsia e incisión mínima.',
        'Trepanación, avance de cánula a blanco planificado y toma de muestras.',
        'Control de hemostasia, cierre y envío de material a anatomía patológica.'
      ],
      consentSlug: 'biopsia_estereotaxica',
    }),
  },
  {
    id: 'tumor_hipofisis_base_craneo',
    label: 'Hipófisis y endoscopía de base',
    category: 'Cráneo tumoral',
    sourceHints: ['Historia + Parte/Tumores/Hipofisis y endoscopia de base'],
    terms: ['hipófisis', 'hipofisario', 'endoscopía de base', 'transesfenoidal'],
    pathRx: /hipof|transesfenoid|endoscopia de base|base/i,
    mother: profile({
      indication: 'lesión selar o de base de cráneo con indicación de abordaje endoscópico por compromiso hormonal, visual, crecimiento o necesidad diagnóstica.',
      symptoms: ['cefalea', 'alteración visual', 'síntomas endocrinológicos', 'compromiso de pares craneales según localización'],
      exam: 'examen neurológico, visual y endocrinológico documentado según presentación.',
      studies: 'RM de silla turca/base de cráneo con lesión y relación con quiasma, seno cavernoso o estructuras adyacentes.',
      diagnosis: 'lesión selar, paraselar o de base de cráneo.',
      procedure: 'abordaje endoscópico endonasal/transesfenoidal y resección/biopsia de lesión',
      risks: ['fístula de LCR', 'diabetes insípida', 'alteraciones hormonales', 'lesión visual', 'sangrado', 'infección', 'resección subtotal', 'reintervención'],
      requiredFacts: ['tipo de lesión', 'abordaje', 'riesgo hormonal/visual si informado'],
      technique: [
        'Abordaje endonasal endoscópico, identificación de reparos anatómicos y apertura esfenoidal/selar según caso.',
        'Resección o biopsia de lesión bajo visión endoscópica.',
        'Control de hemostasia, reconstrucción de base si fue necesaria y taponamiento/curación según técnica.'
      ],
      consentSlug: 'hipofisis_endoscopia_base_craneo',
    }),
  },
  {
    id: 'tumor_angulo_pontocerebeloso',
    label: 'Ángulo pontocerebeloso',
    category: 'Cráneo tumoral',
    sourceHints: ['Historia + Parte/Tumores/Angulo Ponto'],
    terms: ['ángulo pontocerebeloso', 'schwannoma', 'neurinoma', 'apc'],
    pathRx: /angulo ponto|pontocerebel|schwann|neurinoma/i,
    mother: profile({
      indication: 'lesión del ángulo pontocerebeloso con síntomas auditivos, vestibulares, compresión neural o crecimiento documentado.',
      symptoms: ['hipoacusia', 'acúfenos', 'vértigo', 'ataxia', 'compromiso de pares craneales según caso'],
      exam: 'examen de pares craneales, marcha y coordinación concordante con localización.',
      studies: 'RM con lesión del ángulo pontocerebeloso y relación con conducto auditivo interno/tronco.',
      diagnosis: 'lesión del ángulo pontocerebeloso.',
      procedure: 'abordaje microquirúrgico y resección/biopsia de lesión del ángulo pontocerebeloso',
      risks: ['lesión facial', 'pérdida auditiva', 'fístula de LCR', 'déficit neurológico', 'sangrado', 'infección', 'resección subtotal'],
      requiredFacts: ['lado', 'tipo de lesión', 'abordaje si informado'],
      technique: [
        'Posicionamiento y abordaje de fosa posterior según localización.',
        'Exposición del ángulo pontocerebeloso y preservación de estructuras neurovasculares.',
        'Resección o toma de muestra de lesión, hemostasia y cierre dural.'
      ],
      consentSlug: 'angulo_pontocerebeloso',
    }),
  },
  {
    id: 'tumor_quiste_coloide',
    label: 'Quiste coloide',
    category: 'Cráneo tumoral',
    sourceHints: ['Historia + Parte/Tumores/Quiste coloide'],
    terms: ['quiste coloide', 'tercer ventrículo'],
    pathRx: /quiste coloide|tercer ventriculo|iii ventriculo/i,
    mother: profile({
      indication: 'quiste coloide del tercer ventrículo con riesgo obstructivo, hidrocefalia o síntomas compatibles.',
      symptoms: ['cefalea', 'síntomas de hipertensión endocraneana', 'vómitos', 'episodios de deterioro transitorio si fueron informados'],
      exam: 'examen neurológico y estado de conciencia documentados.',
      studies: 'RM/TC con quiste coloide y tamaño/relación ventricular informados.',
      diagnosis: 'quiste coloide del tercer ventrículo.',
      procedure: 'resección endoscópica o microquirúrgica de quiste coloide según estrategia definida',
      risks: ['hemorragia intraventricular', 'déficit de memoria', 'hidrocefalia', 'infección', 'fístula de LCR', 'resección subtotal', 'reintervención'],
      requiredFacts: ['abordaje endoscópico/microquirúrgico', 'hidrocefalia si existe'],
      technique: [
        'Abordaje ventricular planificado, acceso a ventrículo lateral y región del foramen de Monro.',
        'Identificación del quiste, aspiración/resección según técnica y control de sangrado.',
        'Control de permeabilidad ventricular, hemostasia y cierre.'
      ],
      consentSlug: 'quiste_coloide',
    }),
  },
  {
    id: 'vascular_aneurisma',
    label: 'Aneurisma cerebral',
    category: 'Vascular',
    sourceHints: ['Historia + Parte/Vascular/ANEURISMAS'],
    terms: ['aneurisma', 'clipado', 'hemorragia subaracnoidea'],
    pathRx: /aneurisma|clipado|subaracnoidea/i,
    mother: profile({
      indication: 'aneurisma cerebral roto o no roto con indicación de tratamiento según riesgo hemorrágico, anatomía vascular y estado clínico.',
      symptoms: ['cefalea súbita o hemorragia subaracnoidea si fue informado', 'déficit neurológico focal', 'hallazgo incidental con riesgo de ruptura'],
      exam: 'examen neurológico y escala clínica documentados según presentación.',
      studies: 'angioTC, angiografía o RM vascular donde se evidencia aneurisma con localización y morfología informadas.',
      diagnosis: 'aneurisma cerebral en la localización informada.',
      procedure: 'clipado microquirúrgico o tratamiento vascular según estrategia definida',
      risks: ['sangrado intraoperatorio', 'isquemia', 'vasoespasmo', 'déficit neurológico', 'hidrocefalia', 'convulsiones', 'infección', 'muerte'],
      requiredFacts: ['localización', 'lado', 'roto/no roto', 'estrategia clipado/endovascular'],
      technique: [
        'Posicionamiento y abordaje craneal según localización aneurismática.',
        'Disección cisternal, identificación de vasos aferentes/eferentes y cuello aneurismático.',
        'Clipado bajo visión microquirúrgica y control de permeabilidad vascular si fue realizado.',
        'Hemostasia, cierre dural, reposición ósea y cierre por planos.'
      ],
      consentSlug: 'aneurisma_cerebral',
    }),
  },
  {
    id: 'vascular_tvt_mav',
    label: 'TVT / MAV / lesión vascular compleja',
    category: 'Vascular',
    sourceHints: ['Historia + Parte/TVT', 'Historia + Parte/Vascular'],
    terms: ['tvt', 'mav', 'malformación arteriovenosa', 'lesión vascular'],
    pathRx: /(^|\/)tvt(\/| |$)|mav|malformaci[oó]n arteriovenosa|vascular/i,
    mother: profile({
      indication: 'lesión vascular neuroquirúrgica con indicación de tratamiento por riesgo hemorrágico, efecto clínico o estrategia diagnóstica.',
      symptoms: ['cefalea', 'convulsiones', 'déficit neurológico focal', 'hemorragia o hallazgo vascular según caso'],
      exam: 'examen neurológico concordante con localización y estado clínico.',
      studies: 'angioTC, RM vascular o angiografía con lesión vascular y anatomía relevante.',
      diagnosis: 'malformación o lesión vascular neuroquirúrgica.',
      procedure: 'tratamiento microquirúrgico, endovascular o combinado según anatomía y planificación',
      risks: ['sangrado', 'isquemia', 'déficit neurológico', 'convulsiones', 'edema', 'infección', 'muerte'],
      requiredFacts: ['tipo de lesión', 'localización', 'estrategia'],
      technique: [
        'Abordaje y exposición según localización vascular.',
        'Identificación de estructuras vasculares críticas.',
        'Tratamiento de la lesión según estrategia planificada, control hemostático y cierre.'
      ],
      consentSlug: 'lesion_vascular_cerebral',
    }),
  },
  {
    id: 'malformacion_chiari',
    label: 'Malformación de Chiari',
    category: 'Malformaciones',
    sourceHints: ['Historia + Parte/Malformaciones/Malformación de Chiari'],
    terms: ['chiari', 'descompresión fosa posterior', 'siringomielia'],
    pathRx: /chiari/i,
    mother: profile({
      indication: 'malformación de Chiari sintomática, con cefalea occipital, síntomas por Valsalva o siringomielia/compromiso neurológico documentado.',
      symptoms: ['cefalea occipital', 'cervicalgia', 'síntomas desencadenados por Valsalva', 'trastornos sensitivos o motores si fueron informados'],
      exam: 'examen neurológico craneocervical concordante con síntomas y hallazgos de imagen.',
      studies: 'RM cráneo-cervical con descenso amigdalino y siringomielia si fue informada.',
      diagnosis: 'malformación de Chiari sintomática.',
      procedure: 'descompresión de fosa posterior y unión cráneo-cervical, con duroplastia si fue indicada',
      risks: ['fístula de LCR', 'infección', 'sangrado', 'déficit neurológico', 'persistencia de síntomas', 'inestabilidad', 'reintervención'],
      requiredFacts: ['tipo de descompresión', 'duroplastia sí/no', 'siringomielia si existe'],
      technique: [
        'Posicionamiento prono o sentado según técnica, abordaje suboccipital medial.',
        'Craniectomía suboccipital y descompresión del arco posterior de C1 si fue realizada.',
        'Apertura dural y duroplastia si fue indicada.',
        'Control de hemostasia, cierre hermético por planos y curación.'
      ],
      consentSlug: 'malformacion_chiari',
    }),
  },
  {
    id: 'malformacion_quiste_aracnoideo',
    label: 'Quiste aracnoideo',
    category: 'Malformaciones',
    sourceHints: ['Historia + Parte/Malformaciones/Quiste aracnoideo'],
    terms: ['quiste aracnoideo', 'fenestración'],
    pathRx: /quiste aracnoideo/i,
    mother: profile({
      indication: 'quiste aracnoideo sintomático o con efecto de masa, con indicación de fenestración, derivación o tratamiento según localización.',
      symptoms: ['cefalea', 'convulsiones', 'efecto de masa', 'síntomas focales según localización'],
      exam: 'examen neurológico concordante con localización y clínica.',
      studies: 'RM/TC con quiste aracnoideo y efecto sobre estructuras adyacentes.',
      diagnosis: 'quiste aracnoideo.',
      procedure: 'fenestración, marsupialización o derivación de quiste aracnoideo según localización',
      risks: ['recidiva', 'higroma/subdural', 'infección', 'sangrado', 'fístula de LCR', 'déficit neurológico'],
      requiredFacts: ['localización', 'abordaje', 'fenestración/derivación'],
      technique: [
        'Abordaje craneal o endoscópico según localización.',
        'Exposición del quiste, fenestración amplia hacia cisternas o ventrículos según anatomía.',
        'Control de hemostasia, cierre y curación.'
      ],
      consentSlug: 'quiste_aracnoideo',
    }),
  },
  {
    id: 'pediatria_mielomeningocele',
    label: 'Mielomeningocele pediátrico',
    category: 'Pediatría',
    sourceHints: ['Historia + Parte/Pediatría/MMC'],
    terms: ['mielomeningocele', 'mmc', 'disrafismo'],
    pathRx: /pediatri.*mmc|mielomeningocele|(^|\/)mmc(\/| |$)/i,
    mother: profile({
      indication: 'disrafismo espinal abierto con indicación de reparación, cierre neural y cobertura de partes blandas.',
      symptoms: ['lesión lumbosacra congénita', 'compromiso neurológico de miembros inferiores si fue informado', 'vejiga neurogénica si fue informada'],
      exam: 'evaluación neurológica, cutánea y urológica inicial según datos disponibles.',
      studies: 'ecografía, RM o evaluación pediátrica/neonatal según el caso.',
      diagnosis: 'mielomeningocele/disrafismo espinal.',
      procedure: 'reparación quirúrgica de mielomeningocele con cierre por planos',
      risks: ['infección', 'fístula de LCR', 'dehiscencia', 'déficit neurológico', 'hidrocefalia', 'necesidad de derivación ventricular'],
      requiredFacts: ['nivel', 'estado de cubierta', 'DVP/DVE si asociada'],
      technique: [
        'Asepsia amplia, protección de placa neural y abordaje de lesión.',
        'Liberación y cierre de planos neurales/durales según anatomía.',
        'Cierre muscular, celular y cutáneo con cobertura adecuada.',
        'Control de hemostasia y curación estéril.'
      ],
      consentSlug: 'mielomeningocele',
    }),
  },
  {
    id: 'trauma_craneal',
    label: 'Trauma craneal / hematomas / hundimiento',
    category: 'Trauma',
    sourceHints: ['Historia + Parte/Trauma', 'Historia + Parte/Pediatría'],
    terms: ['hematoma subdural', 'hematoma extradural', 'hundimiento', 'trauma craneal', 'craniectomía descompresiva'],
    pathRx: /trauma|hematoma|hundimiento|extradural|subdural|craniectom|fractura/i,
    mother: profile({
      indication: 'trauma craneal con hematoma, hundimiento, efecto de masa o deterioro neurológico con indicación quirúrgica.',
      symptoms: ['traumatismo craneoencefálico', 'deterioro del sensorio', 'déficit neurológico focal', 'cefalea o vómitos según presentación'],
      exam: 'examen neurológico inicial, Glasgow y pupilas documentados según urgencia.',
      studies: 'TC de cráneo con hematoma, fractura, hundimiento o efecto de masa en la localización informada.',
      diagnosis: 'lesión traumática craneal quirúrgica.',
      procedure: 'craneotomía/craniectomía, evacuación de hematoma, toilette o reparación de hundimiento según lesión',
      risks: ['resangrado', 'edema cerebral', 'déficit neurológico', 'convulsiones', 'infección', 'necesidad de reintervención', 'muerte'],
      requiredFacts: ['tipo de lesión', 'lado/localización', 'Glasgow/pupilas si disponible'],
      technique: [
        'Posicionamiento según localización y preparación amplia.',
        'Incisión y craneotomía/craniectomía sobre lesión.',
        'Evacuación de hematoma o toilette de fractura, control de sangrado y descompresión.',
        'Cierre dural/óseo según estrategia, drenaje si fue colocado y cierre por planos.'
      ],
      consentSlug: 'trauma_craneal',
    }),
  },
  {
    id: 'otros_fistula_lcr',
    label: 'Fístula de LCR',
    category: 'Otros',
    sourceHints: ['Historia + Parte/Otros/Fistula de LCR'],
    terms: ['fístula de lcr', 'rinorraquia', 'licuorrea'],
    pathRx: /fistula de lcr|f[ií]stula.*lcr|licuorrea|rinorraquia/i,
    mother: profile({
      indication: 'fístula de líquido cefalorraquídeo con indicación de reparación por pérdida persistente o riesgo infeccioso.',
      symptoms: ['salida de líquido cefalorraquídeo por herida, nariz u oído según caso', 'cefalea ortostática si fue informada', 'riesgo infeccioso'],
      exam: 'evaluación local y neurológica concordante con sitio de fuga.',
      studies: 'TC/RM/cisternografía o evaluación de herida compatible con fístula de LCR.',
      diagnosis: 'fístula de líquido cefalorraquídeo.',
      procedure: 'reparación quirúrgica de fístula de LCR según localización',
      risks: ['recidiva de fístula', 'meningitis', 'infección', 'sangrado', 'déficit neurológico', 'necesidad de drenaje lumbar o reintervención'],
      requiredFacts: ['sitio de fuga', 'técnica de reparación', 'material de refuerzo si se usó'],
      technique: [
        'Abordaje del sitio de fístula, identificación de defecto y tejido viable.',
        'Reparación con sutura, injerto, parche o sellador según técnica informada.',
        'Prueba de cierre si fue realizada, hemostasia y cierre por planos.'
      ],
      consentSlug: 'fistula_lcr',
    }),
  },
  {
    id: 'otros_neuralgia_trigemino',
    label: 'Neuralgia del trigémino',
    category: 'Otros',
    sourceHints: ['Historia + Parte/Otros/Trigéminos'],
    terms: ['trigémino', 'neuralgia trigeminal', 'termocoagulación', 'microdescompresión'],
    pathRx: /trig[eé]mino|neuralgia trigeminal|termocoagul|microdescomp/i,
    mother: profile({
      indication: 'neuralgia trigeminal refractaria a tratamiento médico, con dolor paroxístico en territorio trigeminal.',
      symptoms: ['dolor facial paroxístico', 'territorio trigeminal afectado', 'gatillos dolorosos si fueron informados'],
      exam: 'evaluación de pares craneales y territorio trigeminal.',
      studies: 'RM/angioRM si fue realizada para descartar lesión secundaria o conflicto neurovascular.',
      diagnosis: 'neuralgia del trigémino.',
      procedure: 'procedimiento percutáneo o microquirúrgico para neuralgia trigeminal según estrategia',
      risks: ['hipoestesia facial', 'anestesia dolorosa', 'recurrencia', 'lesión corneal', 'sangrado', 'infección', 'déficit de pares craneales'],
      requiredFacts: ['rama afectada', 'lado', 'técnica'],
      technique: [
        'Posicionamiento y abordaje percutáneo o retrosigmoideo según técnica.',
        'Identificación del objetivo trigeminal o conflicto neurovascular.',
        'Lesión controlada/descompresión según procedimiento informado.',
        'Control hemostático y cierre/curación.'
      ],
      consentSlug: 'neuralgia_trigemino',
    }),
  },
  {
    id: 'otros_tunel_carpiano_periferico',
    label: 'Túnel carpiano / nervio periférico',
    category: 'Sistema nervioso periférico',
    sourceHints: ['Historia + Parte/Otros/Túnel Carpiano-Periférico'],
    terms: ['túnel carpiano', 'nervio periférico', 'neurolysis'],
    pathRx: /t[uú]nel carpiano|perif[eé]rico|nervio perif/i,
    mother: profile({
      indication: 'síndrome de túnel carpiano o compresión de nervio periférico refractaria, con correlación clínica y electromiográfica si fue realizada.',
      symptoms: ['parestesias nocturnas', 'dolor o adormecimiento en territorio del nervio afectado', 'debilidad o atrofia si fue informada'],
      exam: 'Tinel/Phalen o semiología del nervio afectado según caso, sin déficit no declarado.',
      studies: 'EMG/VCN compatible con atrapamiento nervioso si fue informado.',
      diagnosis: 'síndrome compresivo de nervio periférico.',
      procedure: 'liberación quirúrgica del nervio afectado',
      risks: ['dolor residual', 'cicatriz dolorosa', 'lesión nerviosa', 'persistencia de parestesias', 'infección', 'sangrado', 'recidiva'],
      requiredFacts: ['lado', 'nervio/procedimiento'],
      technique: [
        'Incisión sobre trayecto anatómico del nervio afectado.',
        'Disección por planos, identificación y protección del nervio.',
        'Liberación del ligamento o estructuras compresivas.',
        'Hemostasia, cierre por planos y curación.'
      ],
      consentSlug: 'tunel_carpiano_nervio_periferico',
    }),
  },
  {
    id: 'otros_bloqueo_epidural',
    label: 'Bloqueo epidural',
    category: 'Dolor',
    sourceHints: ['Historia + Parte/Otros/BLOQUEO EPIDURAL'],
    terms: ['bloqueo epidural', 'infiltración epidural'],
    pathRx: /bloqueo epidural|infiltraci[oó]n epidural/i,
    mother: profile({
      indication: 'dolor lumbar o radicular con indicación de bloqueo epidural diagnóstico/terapéutico.',
      symptoms: ['dolor lumbar', 'dolor radicular', 'limitación funcional'],
      exam: 'evaluación lumbar/radicular concordante con el nivel a infiltrar.',
      studies: 'RM o estudios concordantes con la indicación del bloqueo si fueron informados.',
      diagnosis: 'síndrome doloroso lumbar/radicular.',
      procedure: 'bloqueo epidural del nivel indicado guiado por imágenes',
      risks: ['dolor transitorio', 'punción dural', 'infección', 'sangrado', 'reacción medicamentosa', 'falta de respuesta', 'déficit neurológico excepcional'],
      requiredFacts: ['nivel', 'lado si aplica', 'medicación si se informa'],
      technique: [
        'Posicionamiento, antisepsia y control radioscópico del nivel.',
        'Punción epidural guiada por reparos anatómicos/imágenes.',
        'Administración de medicación informada, retiro de aguja, compresión local y observación.'
      ],
      consentSlug: 'bloqueo_epidural',
    }),
  },
  {
    id: 'otros_bloqueo_facetario',
    label: 'Bloqueo facetario',
    category: 'Dolor',
    sourceHints: ['Historia + Parte/Otros/BLOQUEO FACETARIO'],
    terms: ['bloqueo facetario', 'facetario'],
    pathRx: /bloqueo facetario|facetario/i,
    mother: profile({
      indication: 'dolor lumbar facetario con indicación de bloqueo diagnóstico/terapéutico.',
      symptoms: ['dolor lumbar mecánico', 'dolor facetario', 'limitación funcional'],
      exam: 'dolor a extensión/rotación lumbar y semiología concordante si fue informada.',
      studies: 'imágenes con artrosis facetaria o degeneración segmentaria si fueron informadas.',
      diagnosis: 'síndrome facetario lumbar.',
      procedure: 'bloqueo facetario del nivel y lado indicados guiado por imágenes',
      risks: ['dolor local', 'falta de respuesta', 'infección', 'sangrado', 'reacción medicamentosa', 'lesión neural excepcional'],
      requiredFacts: ['nivel', 'lado', 'medicación si se informa'],
      technique: [
        'Control radioscópico del nivel, antisepsia y punción dirigida a articulaciones facetarias o ramas mediales.',
        'Administración de medicación indicada, retiro de aguja y curación.'
      ],
      consentSlug: 'bloqueo_facetario',
    }),
  },
  {
    id: 'otros_bloqueo_sacroiliaco',
    label: 'Bloqueo sacroilíaco',
    category: 'Dolor',
    sourceHints: ['Historia + Parte/Otros/bloqueo sacroiliaco'],
    terms: ['sacroilíaco', 'bloqueo sacroiliaco'],
    pathRx: /sacroiliac/i,
    mother: profile({
      indication: 'dolor sacroilíaco con indicación de bloqueo diagnóstico/terapéutico.',
      symptoms: ['dolor sacroilíaco', 'dolor glúteo', 'limitación funcional'],
      exam: 'maniobras provocativas sacroilíacas positivas si fueron informadas.',
      studies: 'imágenes o evaluación clínica concordante con origen sacroilíaco.',
      diagnosis: 'síndrome doloroso sacroilíaco.',
      procedure: 'bloqueo sacroilíaco guiado por imágenes',
      risks: ['dolor local', 'falta de respuesta', 'infección', 'sangrado', 'reacción medicamentosa'],
      requiredFacts: ['lado', 'medicación si se informa'],
      technique: [
        'Control de imágenes, antisepsia y punción dirigida a articulación sacroilíaca.',
        'Administración de medicación indicada, retiro de aguja y curación.'
      ],
      consentSlug: 'bloqueo_sacroiliaco',
    }),
  },
  {
    id: 'otros_absceso_cerebral',
    label: 'Absceso cerebral',
    category: 'Infecciones',
    sourceHints: ['Historia + Parte/Otros/ABSCESO CEREBRAL'],
    terms: ['absceso cerebral', 'drenaje de absceso'],
    pathRx: /absceso cerebral|absceso/i,
    mother: profile({
      indication: 'absceso cerebral con indicación de drenaje, toma de muestra o evacuación por clínica, imágenes y riesgo infeccioso.',
      symptoms: ['cefalea', 'fiebre o síndrome infeccioso si fue informado', 'déficit neurológico', 'convulsiones'],
      exam: 'examen neurológico y estado infeccioso documentados.',
      studies: 'RM/TC con lesión compatible con absceso cerebral.',
      diagnosis: 'absceso cerebral.',
      procedure: 'drenaje, aspiración o evacuación quirúrgica de absceso cerebral',
      risks: ['recurrencia', 'sepsis', 'déficit neurológico', 'sangrado', 'convulsiones', 'infección persistente', 'muerte'],
      requiredFacts: ['localización', 'lado', 'muestras/cultivos'],
      technique: [
        'Abordaje guiado por localización, punción o craneotomía según tamaño y ubicación.',
        'Aspiración/drenaje de material purulento y envío a cultivo.',
        'Lavado de cavidad si fue realizado, hemostasia y cierre.'
      ],
      consentSlug: 'absceso_cerebral',
    }),
  },
  {
    id: 'otros_craneoplastia',
    label: 'Craneoplastia',
    category: 'Reconstructiva',
    sourceHints: ['Historia + Parte/Otros/Craneoplastia'],
    terms: ['craneoplastia', 'defecto óseo', 'plaqueta', 'craneal'],
    pathRx: /craneoplast/i,
    mother: profile({
      indication: 'defecto óseo craneal con indicación reconstructiva por protección cerebral, estética o síndrome del trepanado.',
      symptoms: ['defecto craneal', 'dolor o molestias locales si fueron informadas', 'síntomas por síndrome del trepanado si fueron informados'],
      exam: 'evaluación local de defecto y estado neurológico.',
      studies: 'TC de cráneo con defecto óseo y planificación de reconstrucción.',
      diagnosis: 'defecto óseo craneal postquirúrgico o postraumático.',
      procedure: 'craneoplastia con material autólogo o protésico según disponibilidad',
      risks: ['infección', 'rechazo/exposición de material', 'hematoma', 'convulsiones', 'dolor local', 'necesidad de retiro o reintervención'],
      requiredFacts: ['localización', 'material utilizado', 'lado'],
      technique: [
        'Reapertura o abordaje sobre defecto, disección de colgajos y exposición de bordes óseos.',
        'Colocación y fijación de plaqueta o material protésico/autólogo.',
        'Hemostasia, drenaje si fue colocado, cierre por planos y curación.'
      ],
      consentSlug: 'craneoplastia',
    }),
  },
  {
    id: 'otros_monitoreo_pic',
    label: 'Monitoreo de presión intracraneana',
    category: 'UCI/Trauma',
    sourceHints: ['Historia + Parte/Otros/MONITOREO DE PIC'],
    terms: ['monitoreo de pic', 'presión intracraneana', 'catéter pic'],
    pathRx: /monitoreo de pic|presi[oó]n intracraneana|cat[eé]ter pic/i,
    mother: profile({
      indication: 'necesidad de monitorización de presión intracraneana por trauma, edema, hidrocefalia o patología intracraneana grave.',
      symptoms: ['compromiso neurológico', 'riesgo de hipertensión intracraneana', 'deterioro del sensorio'],
      exam: 'estado neurológico, Glasgow y pupilas documentados según caso.',
      studies: 'TC/RM con hallazgos que justifican monitoreo de presión intracraneana.',
      diagnosis: 'riesgo de hipertensión intracraneana.',
      procedure: 'colocación de sensor/catéter de presión intracraneana',
      risks: ['sangrado', 'infección', 'malfunción del sensor', 'lesión cerebral', 'necesidad de recolocación'],
      requiredFacts: ['lado/sitio', 'tipo de sensor si informado'],
      technique: [
        'Preparación estéril, incisión y trepanación en sitio planificado.',
        'Colocación del sensor/catéter, conexión al sistema de monitoreo y verificación de lectura.',
        'Fijación, cierre y curación.'
      ],
      consentSlug: 'monitoreo_pic',
    }),
  },
  {
    id: 'otros_valvulas_hidrocefalia',
    label: 'Hidrocefalia / válvulas / DVP-DVE',
    category: 'Hidrocefalia',
    sourceHints: ['Historia + Parte/Otros/Valvulas', 'Historia + Parte/Pediatría'],
    terms: ['válvula', 'dvp', 'dve', 'hidrocefalia', 'derivación'],
    pathRx: /v[aá]lvula|dvp|dve|hidrocef|derivaci[oó]n/i,
    mother: profile({
      indication: 'hidrocefalia con indicación de derivación, revisión valvular o drenaje ventricular por clínica e imágenes.',
      symptoms: ['cefalea', 'vómitos', 'trastorno de la marcha', 'deterioro cognitivo', 'síntomas de hipertensión endocraneana según caso'],
      exam: 'examen neurológico y estado de conciencia concordantes con hidrocefalia o disfunción valvular.',
      studies: 'TC/RM con ventriculomegalia, signos de hidrocefalia o disfunción de sistema derivativo.',
      diagnosis: 'hidrocefalia o disfunción valvular.',
      procedure: 'colocación, revisión o retiro de derivación ventricular según indicación',
      risks: ['infección', 'obstrucción', 'malfunción valvular', 'hemorragia', 'sobredrenaje/subdrenaje', 'reintervención', 'déficit neurológico'],
      requiredFacts: ['tipo DVP/DVE/revisión', 'lado', 'válvula/catéter si informado'],
      technique: [
        'Posicionamiento, antisepsia amplia y planificación de trayecto.',
        'Trepanación, acceso ventricular y colocación/revisión de catéter proximal.',
        'Tunelización y colocación de válvula/catéter distal si corresponde al procedimiento informado.',
        'Verificación de flujo, fijación, cierre por planos y curación.'
      ],
      consentSlug: 'hidrocefalia_valvula',
    }),
  },
  {
    id: 'neurofisiologia_monitorizacion',
    label: 'Neurofisiología / monitorización',
    category: 'Neurofisiología',
    sourceHints: ['Historia + Parte/neurofisiologia'],
    terms: ['neurofisiología', 'monitorización', 'potenciales evocados'],
    pathRx: /neurofisiologia|monitorizaci[oó]n|potenciales evocados/i,
    mother: profile({
      indication: 'procedimiento neuroquirúrgico con necesidad de monitorización neurofisiológica o implante funcional según patología.',
      symptoms: ['síntomas neurológicos de la patología de base'],
      exam: 'examen neurológico de base previo al procedimiento.',
      studies: 'estudios de planificación según patología y objetivo funcional.',
      diagnosis: 'patología neuroquirúrgica con necesidad de apoyo neurofisiológico.',
      procedure: 'monitorización neurofisiológica o procedimiento funcional indicado',
      risks: ['falla técnica', 'déficit neurológico propio del procedimiento de base', 'infección', 'sangrado', 'reintervención'],
      requiredFacts: ['procedimiento principal', 'modalidad de monitoreo'],
      technique: [
        'Preparación y colocación de electrodos/sensores según modalidad.',
        'Registro basal y monitoreo durante pasos críticos del procedimiento.',
        'Comunicación de cambios relevantes al equipo quirúrgico y registro final.'
      ],
      consentSlug: 'neurofisiologia_monitorizacion',
    }),
  },
  {
    id: 'otros_neurocirugia',
    label: 'Otros procedimientos neuroquirúrgicos',
    category: 'Otros',
    sourceHints: ['Historia + Parte/Otros'],
    terms: ['neurocirugía', 'procedimiento neuroquirúrgico'],
    pathRx: /.*/,
    mother: profile({
      indication: 'cuadro neuroquirúrgico con indicación fundada por clínica, examen e imágenes.',
      symptoms: ['síntomas neurológicos compatibles con la patología indicada'],
      exam: 'examen neurológico útil y orientado a la patología consignada.',
      studies: 'estudios complementarios concordantes con el diagnóstico y la conducta.',
      diagnosis: 'patología neuroquirúrgica consignada.',
      procedure: 'procedimiento neuroquirúrgico indicado',
      risks: ['infección', 'sangrado', 'déficit neurológico', 'dolor residual', 'necesidad de reoperación'],
      requiredFacts: ['diagnóstico', 'procedimiento', 'sitio/lado/nivel si aplica'],
      technique: [
        'Posicionamiento y antisepsia según el procedimiento.',
        'Abordaje anatómico al sitio indicado.',
        'Realización del procedimiento informado con protección de estructuras neurales y vasculares.',
        'Hemostasia, cierre por planos, curación y destino postoperatorio.'
      ],
      consentSlug: null,
    }),
  },
];

function ensureDirs() {
  for (const dir of [OUT_DIR, TEMPLATE_DIR, QA_DIR]) fs.mkdirSync(dir, { recursive: true });
}

function normalize(value) {
  return String(value || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

function sha256(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function walk(dir, files = []) {
  if (!fs.existsSync(dir)) return files;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (SKIP_NAME.test(entry.name)) continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      if (/^(fotos|cd copiados|bibliografia|cursos|balado|recibos|cv)$/i.test(entry.name)) continue;
      walk(full, files);
    } else {
      const ext = path.extname(entry.name).toLowerCase();
      if (SUPPORTED_EXT.has(ext)) files.push(full);
    }
  }
  return files;
}

function safeRel(abs) {
  return abs.startsWith(`${NEURO_ROOT}/`) ? abs.slice(NEURO_ROOT.length + 1) : abs;
}

function scanFiles() {
  const out = [];
  const seen = new Set();
  for (const [rootType, relRoot] of SCAN_ROOTS) {
    const absRoot = path.join(NEURO_ROOT, relRoot);
    for (const abs of walk(absRoot)) {
      if (seen.has(abs)) continue;
      seen.add(abs);
      out.push({
        abs,
        rel: safeRel(abs),
        rootType,
        ext: path.extname(abs).toLowerCase(),
        size: fs.statSync(abs).size,
      });
    }
  }
  return out;
}

function classify(item) {
  const value = normalize(item.rel);
  for (const spec of FAMILY_SPECS) {
    if (spec.pathRx.test(value)) return spec;
  }
  return FAMILY_SPECS[FAMILY_SPECS.length - 1];
}

function extractText(filePath, ext) {
  if (ext === '.txt') return fs.readFileSync(filePath, 'utf8');
  if (ext === '.htm' || ext === '.html') {
    return fs.readFileSync(filePath, 'utf8')
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<[^>]+>/g, '\n');
  }
  return execFileSync('textutil', ['-convert', 'txt', '-stdout', filePath], {
    encoding: 'utf8',
    timeout: 20000,
    maxBuffer: 3 * 1024 * 1024,
  });
}

function documentType(text) {
  const n = normalize(text);
  const hasParte = /(parte quirurgico|protocolo quirurgico|tecnica quirurgica|operacion|cirujano|anestesia|decubito|incision)/.test(n);
  const hasHc = /(historia clinica|enfermedad actual|motivo de ingreso|examen fisico|antecedentes|estudios)/.test(n);
  if (hasParte && hasHc) return 'historia_y_parte';
  if (hasParte) return 'parte_quirurgico';
  if (hasHc) return 'historia_clinica';
  return 'documento_clinico';
}

function sectionSignals(text) {
  const n = normalize(text);
  const signals = {
    identificacion: /(paciente|dni|edad|obra social|historia clinica)/.test(n),
    clinica: /(motivo de ingreso|enfermedad actual|dolor|deficit|parestes|marcha|cefalea|convuls|mielopatia|radicular)/.test(n),
    examen: /(examen fisico|fuerza|sensibilidad|reflejo|glasgow|pupilas|lasegue|pares craneales)/.test(n),
    estudios: /(rmn|resonancia|tomografia|tc|rx|radiografia|angiografia|emg|laboratorio)/.test(n),
    consentimiento: /(consentimiento|riesgos|alternativas|autorizo|informado)/.test(n),
    anestesia_posicion: /(anestesia|decubito|posicion|prono|dorsal|fijacion cefalica)/.test(n),
    antisepsia: /(antisepsia|asepsia|campos esteriles|profilaxis antibiotica)/.test(n),
    control_imagenes: /(radioscop|fluoroscop|neuronaveg|control de imagenes|angio)/.test(n),
    implantes: /(tornillo|barra|cage|celda|placa|protesis|valvula|cateter|cemento|pmma)/.test(n),
    tecnica: /(incision|abordaje|diseccion|laminectomia|flavectomia|craneotomia|reseccion|descompresion|biopsia)/.test(n),
    hemostasia_cierre: /(hemostasia|cierre|sutura|curacion|drenaje)/.test(n),
    incidentes_destino: /(complicacion|incidente|sin complicaciones|recuperacion|uti|sala|egresa)/.test(n),
  };
  return Object.fromEntries(Object.entries(signals).filter(([, present]) => present).map(([key]) => [key, true]));
}

function addCount(obj, key, amount = 1) {
  obj[key] = (obj[key] || 0) + amount;
}

function buildRegistry(files) {
  const buckets = {};
  for (const spec of FAMILY_SPECS) {
    buckets[spec.id] = {
      id: spec.id,
      label: spec.label,
      category: spec.category,
      candidate_count: 0,
      sampled_count: 0,
      source_groups: spec.sourceHints,
      classifier_terms: spec.terms,
      document_type_counts: {},
      signal_counts: {},
      sampled_hashes: [],
      mother_template: {
        approval_status: 'template_ready_reviewable',
        privacy_mode: 'derived_template_no_patient_text',
        source_basis: 'Documentos locales de Neurocirugía + corpus médico-legal interno.',
        ...spec.mother,
      },
    };
  }

  const classified = files.map((item) => ({ ...item, spec: classify(item) }));
  for (const item of classified) buckets[item.spec.id].candidate_count += 1;

  const byFamily = new Map();
  for (const item of classified) {
    if (!byFamily.has(item.spec.id)) byFamily.set(item.spec.id, []);
    byFamily.get(item.spec.id).push(item);
  }

  const extractionErrors = [];
  for (const [id, items] of byFamily) {
    const bucket = buckets[id];
    const sample = items
      .sort((a, b) => {
        const rootCmp = a.rootType.localeCompare(b.rootType);
        if (rootCmp) return rootCmp;
        return a.rel.localeCompare(b.rel);
      })
      .slice(0, MAX_PER_FAMILY);
    for (const item of sample) {
      try {
        const raw = fs.readFileSync(item.abs);
        const fileHash = sha256(raw).slice(0, 16);
        const text = extractText(item.abs, item.ext);
        bucket.sampled_count += 1;
        bucket.sampled_hashes.push(fileHash);
        addCount(bucket.document_type_counts, documentType(text));
        for (const signal of Object.keys(sectionSignals(text))) addCount(bucket.signal_counts, signal);
      } catch (error) {
        extractionErrors.push({
          family: id,
          root_type: item.rootType,
          ext: item.ext,
          file_hash: sha256(`${item.rel}:${item.size}`).slice(0, 16),
          error: String(error.message || error).slice(0, 220),
        });
      }
    }
    bucket.sampled_hashes = [...new Set(bucket.sampled_hashes)].slice(0, 12);
  }

  const activeFamilies = Object.fromEntries(
    Object.entries(buckets)
      .filter(([, value]) => value.candidate_count > 0 || value.id === 'otros_neurocirugia')
      .map(([id, value]) => [id, value])
  );

  return {
    generated_at: GENERATED_AT,
    run_id: `pathology_template_bank_neurocirugia_${DATE_ID}`,
    source_root: NEURO_ROOT,
    privacy_mode: 'derived_templates_and_counts_only_no_patient_text_no_file_names',
    scan_roots: SCAN_ROOTS.map(([rootType, rel]) => ({ rootType, rel })),
    supported_extensions: [...SUPPORTED_EXT].sort(),
    candidate_total: files.length,
    sampled_total: Object.values(activeFamilies).reduce((sum, family) => sum + family.sampled_count, 0),
    max_per_family: MAX_PER_FAMILY,
    family_count: Object.keys(activeFamilies).length,
    families: activeFamilies,
    medico_legal_sources: [
      'docs/corpus_medicolegal_argentino.md',
      'docs/matriz_impacto_redaccional_hc_partes.md',
      'docs/reglas_internas_redaccion_medicolegal.md',
      'docs/criterios_estilo_hc_zanardi_2026-05-19.md',
      'data/derived/medicolegal_tamiz/medicolegal_tamiz_pack_2026-05-19.json',
    ],
    extraction_errors: extractionErrors,
    activation_status: 'ready_for_app_template_selection_with_flexible_medicolegal_gate',
  };
}

function writeOutputs(registry) {
  const bankPath = path.join(OUT_DIR, `pathology_template_bank_${DATE_ID}.json`);
  const stylePath = path.join(OUT_DIR, `pathology_template_style_guide_${DATE_ID}.md`);
  const qaPath = path.join(QA_DIR, `pathology_template_bank_${DATE_ID}_summary.json`);
  const legacyPath = path.join(TEMPLATE_DIR, 'template_mother_registry_2026-05-19.json');
  const datedTemplatePath = path.join(TEMPLATE_DIR, `template_mother_registry_${DATE_ID}.json`);

  fs.writeFileSync(bankPath, JSON.stringify(registry, null, 2));
  fs.writeFileSync(legacyPath, JSON.stringify(registry, null, 2));
  fs.writeFileSync(datedTemplatePath, JSON.stringify(registry, null, 2));

  const families = Object.values(registry.families).sort((a, b) => b.candidate_count - a.candidate_count);
  const md = [
    '# Banco de plantillas por patología neuroquirúrgica',
    '',
    `Generado: ${registry.generated_at}`,
    '',
    'Modo de privacidad: plantillas derivadas, conteos y hashes cortos; sin textos completos, nombres de pacientes ni nombres de archivos.',
    '',
    `Documentos candidatos: ${registry.candidate_total}`,
    `Muestras extraídas: ${registry.sampled_total}`,
    `Familias con plantilla: ${registry.family_count}`,
    '',
    '## Reglas transversales incorporadas',
    '',
    ...COMMON_STYLE_RULES.map((rule) => `- ${rule}`),
    '',
    '## Familias',
    '',
    ...families.map((family) => [
      `### ${family.label}`,
      '',
      `ID: \`${family.id}\` · Categoría: ${family.category} · Candidatos: ${family.candidate_count} · Muestra: ${family.sampled_count}`,
      `Términos de clasificación: ${family.classifier_terms.join(', ')}`,
      `Señales detectadas: ${Object.entries(family.signal_counts).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k, v]) => `${k} (${v})`).join(', ') || 'sin señales por texto'}`,
      `Motivo/indicación madre: ${family.mother_template.clinical_profile.indication}`,
      `Procedimiento madre: ${family.mother_template.clinical_profile.procedure}`,
      '',
    ].join('\n')),
    '## Tamiz médico-legal común',
    '',
    ...COMMON_TAMIZ.map((rule) => `- ${rule}`),
    '',
  ].join('\n');
  fs.writeFileSync(stylePath, md);

  const qa = {
    generated_at: registry.generated_at,
    ok: true,
    bank_path: bankPath,
    legacy_registry_path: legacyPath,
    dated_registry_path: datedTemplatePath,
    style_guide_path: stylePath,
    candidate_total: registry.candidate_total,
    sampled_total: registry.sampled_total,
    family_count: registry.family_count,
    largest_families: families.slice(0, 12).map((family) => ({
      id: family.id,
      label: family.label,
      candidate_count: family.candidate_count,
      sampled_count: family.sampled_count,
    })),
    extraction_errors_count: registry.extraction_errors.length,
    extraction_errors_sample: registry.extraction_errors.slice(0, 8),
    privacy_check: 'no_patient_text_no_file_names_in_registry',
  };
  fs.writeFileSync(qaPath, JSON.stringify(qa, null, 2));
  return qa;
}

function main() {
  ensureDirs();
  const files = scanFiles();
  const registry = buildRegistry(files);
  const qa = writeOutputs(registry);
  console.log(JSON.stringify(qa, null, 2));
}

main();
