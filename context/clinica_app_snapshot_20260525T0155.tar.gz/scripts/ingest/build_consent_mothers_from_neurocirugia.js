const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = path.resolve(__dirname, '..', '..');
const sourceRoots = [
  '/Users/jarvis/Desktop/NEUROCIRUGIA/Consentimientos',
  '/Users/jarvis/Desktop/NEUROCIRUGIA/NEUROCIRUGIA DE QUIROFANO/consentimientos',
  '/Users/jarvis/Desktop/NEUROCIRUGIA/INFORMED CONSENT'
];

const familyRules = [
  ['columna_vertebroplastia_cifoplastia', /cifo|cifoplast|vertebro|cement/i],
  ['columna_fijacion_transpedicular', /transpedicular|artrodesis|360|fijaci[oó]n|instrument/i],
  ['columna_microdiscectomia_tubular', /disco|hernia|microdiscect|tubular/i],
  ['columna_canal_estrecho_laminoplastia', /canal|laminoplast|laminect|recalibraje|compresi[oó]n medular/i],
  ['columna_disco_cervical', /cervical|artroplastia|foraminotomia|hangman|c2/i],
  ['vascular_aneurismas_tvt', /aneurisma|mav|vascular|endovascular|hsa|tvt|cavernoma|silviano|comunicante|fistula/i],
  ['tumores_intracraneales', /tumor|meningioma|glioma|met[aá]sta|mts|cerebel|ventricular|frontal|temporal/i],
  ['hidrocefalia_valvulas_dvp', /hidrocef|v[aá]lvula|hakim|lumboperitoneal|dandy|dvp|dve/i],
  ['chiari_malformaciones', /chiari/i],
  ['trauma_craneal_columna', /hsd|hed|hematoma|tec|hundim|fractura|craniectom/i],
  ['periferico_tunel_carpiano', /snp|t[uú]nel|cubital|perif[eé]rico|tapia|porfilio|chiavassa/i],
  ['biopsia_infeccion_revision', /biopsia|infecci[oó]n|absceso|discitis|reoperaci[oó]n|revisi[oó]n|craneoplast/i]
];

const familyDefaults = {
  columna_microdiscectomia_tubular: {
    indication: 'lumbalgia con dolor radicular persistente con correlación clínico-radiológica por hernia discal y respuesta insuficiente al tratamiento conservador.',
    symptoms: ['dolor lumbar irradiado al miembro inferior', 'parestesias o hipoestesia en territorio radicular', 'limitación funcional', 'signos de irritación radicular'],
    procedure: 'microdiscectomía lumbar con descompresión radicular del nivel afectado',
    risks: ['persistencia o recurrencia del dolor', 'recidiva herniaria', 'fibrosis epidural', 'durotomía y pérdida de LCR', 'déficit sensitivo o motor', 'infección', 'sangrado', 'necesidad de reoperación']
  },
  columna_fijacion_transpedicular: {
    indication: 'dolor lumbar mecánico y dolor radicular por inestabilidad asociada a patología degenerativa, con correlación clínico-radiológica e indicación de descompresión y estabilización.',
    symptoms: ['lumbalgia mecánica', 'dolor radicular', 'claudicación neurógena si corresponde', 'limitación para marcha y actividades habituales'],
    procedure: 'descompresión, artrodesis e instrumentación transpedicular del segmento indicado',
    risks: ['dolor residual', 'pseudoartrosis', 'falla o malposición de implantes', 'lesión radicular', 'durotomía y pérdida de LCR', 'infección', 'sangrado', 'trombosis', 'necesidad de cirugía adicional']
  },
  columna_canal_estrecho_laminoplastia: {
    indication: 'mielopatía o compromiso neurológico por estenosis de canal con correlación clínica e imagenológica.',
    symptoms: ['trastorno de la marcha', 'torpeza manual', 'parestesias', 'déficit motor o sensitivo', 'signos piramidales si corresponden'],
    procedure: 'descompresión posterior mediante laminoplastia o laminectomía según anatomía y plan quirúrgico',
    risks: ['déficit neurológico transitorio o permanente', 'dolor axial', 'inestabilidad', 'infección', 'sangrado', 'lesión dural', 'necesidad de reintervención']
  },
  columna_disco_cervical: {
    indication: 'radiculopatía o mielopatía cervical con correlación clínico-radiológica y respuesta insuficiente a tratamiento no quirúrgico o déficit progresivo.',
    symptoms: ['cervicobraquialgia', 'parestesias', 'déficit motor o sensitivo', 'limitación funcional', 'mielopatía si corresponde'],
    procedure: 'abordaje cervical y tratamiento discal/foraminal con descompresión y artrodesis o artroplastia según indicación',
    risks: ['disfonía o disfagia', 'lesión radicular o medular', 'hematoma cervical', 'infección', 'falla de implante', 'dolor residual', 'necesidad de reoperación']
  },
  columna_vertebroplastia_cifoplastia: {
    indication: 'fractura vertebral dolorosa, aplastamiento o lesión vertebral con dolor persistente y correlación imagenológica.',
    symptoms: ['dolor axial localizado', 'limitación funcional', 'dolor a la bipedestación o movilización'],
    procedure: 'vertebroplastia/cifoplastia del nivel indicado con cementación vertebral bajo control de imágenes',
    risks: ['extravasación de cemento', 'dolor residual', 'fractura de nivel adyacente', 'embolismo', 'infección', 'sangrado', 'déficit neurológico excepcional']
  },
  vascular_aneurismas_tvt: {
    indication: 'patología vascular neuroquirúrgica con riesgo hemorrágico o efecto clínico documentado según angiografía/imágenes y criterio terapéutico.',
    symptoms: ['cefalea', 'déficit neurológico focal si corresponde', 'hemorragia subaracnoidea o hallazgo vascular incidental según caso'],
    procedure: 'tratamiento microquirúrgico o endovascular de la lesión vascular según anatomía, localización y estrategia definida',
    risks: ['sangrado intraoperatorio', 'isquemia', 'vasoespasmo', 'déficit neurológico', 'convulsiones', 'infección', 'hidrocefalia', 'muerte']
  },
  tumores_intracraneales: {
    indication: 'lesión expansiva intracraneal con síntomas, efecto de masa, crecimiento o necesidad diagnóstica/terapéutica.',
    symptoms: ['cefalea', 'crisis convulsivas', 'déficit neurológico focal', 'síndrome de hipertensión endocraneana o alteración cognitiva según localización'],
    procedure: 'craneotomía y resección/biopsia de lesión intracraneal con técnica adaptada a localización y elocuencia',
    risks: ['déficit neurológico', 'sangrado', 'edema', 'convulsiones', 'infección', 'fístula de LCR', 'resección subtotal', 'recidiva o progresión', 'muerte']
  },
  hidrocefalia_valvulas_dvp: {
    indication: 'hidrocefalia o trastorno de circulación de LCR con clínica e imágenes compatibles.',
    symptoms: ['cefalea', 'vómitos', 'trastorno de marcha', 'deterioro cognitivo', 'somnolencia o hipertensión endocraneana según caso'],
    procedure: 'derivación valvular o procedimiento de LCR indicado según etiología y anatomía',
    risks: ['infección valvular', 'obstrucción o disfunción', 'hiper/hipodrenaje', 'hemorragia', 'necesidad de recambio o revisión', 'déficit neurológico']
  },
  chiari_malformaciones: {
    indication: 'malformación de Chiari sintomática o asociada a alteración de flujo de LCR/siringomielia.',
    symptoms: ['cefalea occipital', 'dolor cervical', 'síntomas sensitivos o motores', 'trastornos de equilibrio o deglución si corresponden'],
    procedure: 'descompresión de fosa posterior y unión cráneo-cervical según técnica planificada',
    risks: ['fístula de LCR', 'pseudomeningocele', 'infección', 'sangrado', 'déficit neurológico', 'persistencia de síntomas', 'reoperación']
  },
  trauma_craneal_columna: {
    indication: 'lesión traumática craneal o vertebral con indicación de evacuación, descompresión, estabilización o monitoreo.',
    symptoms: ['cefalea', 'deterioro del sensorio', 'déficit neurológico', 'dolor axial o signos de compresión según caso'],
    procedure: 'tratamiento quirúrgico del trauma según lesión, localización y urgencia',
    risks: ['resangrado', 'edema', 'infección', 'convulsiones', 'déficit neurológico', 'necesidad de reintervención', 'muerte']
  },
  periferico_tunel_carpiano: {
    indication: 'neuropatía compresiva periférica con clínica y estudios compatibles.',
    symptoms: ['dolor o parestesias', 'hipoestesia', 'debilidad o torpeza manual', 'síntomas nocturnos si corresponden'],
    procedure: 'neurolisis o liberación del nervio periférico comprometido',
    risks: ['dolor residual', 'cicatriz dolorosa', 'lesión nerviosa', 'infección', 'hematoma', 'persistencia o recurrencia de síntomas']
  },
  biopsia_infeccion_revision: {
    indication: 'necesidad diagnóstica, infecciosa o revisión quirúrgica con objetivo definido por evolución clínica e imágenes.',
    symptoms: ['dolor', 'signos infecciosos o inflamatorios', 'déficit o falla de tratamiento previo según caso'],
    procedure: 'biopsia, toilette, desbridamiento, retiro/revisión o procedimiento indicado según hallazgo',
    risks: ['persistencia infecciosa', 'sangrado', 'déficit neurológico', 'necesidad de nuevos procedimientos', 'dolor residual', 'complicaciones anestésicas']
  }
};

const commonRequirements = [
  'estado de salud y diagnostico probable',
  'procedimiento propuesto con objetivos',
  'beneficios esperados',
  'riesgos, molestias y efectos adversos previsibles',
  'alternativas razonables y sus riesgos/beneficios',
  'consecuencias de no realizar el procedimiento',
  'posibilidad de rechazar o revocar',
  'oportunidad de preguntas y comprension',
  'firma, aclaracion, documento, fecha, institucion y profesional',
  'archivo en historia clinica y disponibilidad de copia'
];

const operatingRoutines = [
  'identificacion activa del paciente, procedimiento, nivel/lateralidad y sitio quirurgico cuando corresponda',
  'posicionamiento adecuado y acolchado de puntos de apoyo',
  'proteccion ocular en decubitos o posiciones con riesgo de presion ocular',
  'antisepsia amplia, colocacion de campos esteriles y tecnica aseptica',
  'profilaxis antibiotica conforme protocolo institucional si no hay contraindicacion',
  'control radioscopico o de imagen para nivel/material cuando el procedimiento lo requiere',
  'hemostasia por planos y control de sangrado',
  'recuento de gasas, agujas e instrumental segun protocolo de quirofano',
  'verificacion final de estabilidad clinica, herida/cierre y destino postoperatorio',
  'ausencia de incidentes evidentes solo si efectivamente no ocurrieron'
];

function walk(dir, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name.startsWith('.~') || entry.name.startsWith('~$') || entry.name === 'Thumbs.db') continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full, out);
    else if (/\.(docx?|odt|rtf|txt)$/i.test(entry.name)) out.push(full);
  }
  return out;
}

function classify(file) {
  const rel = file.toLowerCase();
  for (const [family, rx] of familyRules) {
    if (rx.test(rel)) return family;
  }
  return 'otros_consentimientos';
}

function hash(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

const files = sourceRoots.flatMap((dir) => walk(dir));
const families = {};
for (const file of files) {
  const family = classify(file);
  families[family] ||= {
    consent_count: 0,
    sample_files_redacted: [],
    defaults: familyDefaults[family] || {
      indication: 'indicación neuroquirúrgica a completar según diagnóstico, clínica e imágenes.',
      symptoms: ['síntomas y signos compatibles con la patología indicada'],
      procedure: 'procedimiento neuroquirúrgico indicado',
      risks: ['infección', 'sangrado', 'déficit neurológico', 'dolor residual', 'necesidad de reoperación']
    }
  };
  families[family].consent_count += 1;
  if (families[family].sample_files_redacted.length < 8) {
    families[family].sample_files_redacted.push({
      file_hint: path.basename(file).replace(/\s+/g, ' '),
      path_hash: hash(file).slice(0, 16)
    });
  }
}

const registry = {
  generated_at: new Date().toISOString(),
  source_roots: sourceRoots,
  total_files: files.length,
  privacy_note: 'Registro derivado de rutas/nombres y reglas medico-legales; no vuelca texto completo ni datos de pacientes de consentimientos historicos.',
  legal_basis: [
    'Ley 26.529 arts. 5 a 7: consentimiento informado, contenido material y exigencia escrita para intervenciones quirurgicas.',
    'Decreto 1089/2012 art. 5: consentimiento como proceso con comprension de plan diagnostico, terapeutico o quirurgico.',
    'Ley 26.529 arts. 12 a 15 y Decreto 1089/2012 arts. 12 a 13: historia clinica completa, cronologica, con autor, soporte e integridad.',
    'CCCN art. 59: consentimiento informado para actos medicos.'
  ],
  common_requirements: commonRequirements,
  operating_routines: operatingRoutines,
  families
};

const outDir = path.join(root, 'data', 'derived', 'consent_mothers');
fs.mkdirSync(outDir, { recursive: true });
const outPath = path.join(outDir, 'consent_mother_registry_2026-05-19.json');
fs.writeFileSync(outPath, JSON.stringify(registry, null, 2) + '\n');

const summaryDir = path.join(root, 'qa', 'approval_gates');
fs.mkdirSync(summaryDir, { recursive: true });
fs.writeFileSync(path.join(summaryDir, 'consent_mother_registry_2026-05-19_summary.json'), JSON.stringify({
  generated_at: registry.generated_at,
  source_roots: registry.source_roots,
  total_files: registry.total_files,
  families_count: Object.keys(registry.families).length,
  top_families: Object.entries(registry.families)
    .sort((a, b) => b[1].consent_count - a[1].consent_count)
    .slice(0, 10)
    .map(([family, item]) => ({ family, consent_count: item.consent_count })),
  status: 'ok_redacted_registry'
}, null, 2) + '\n');

console.log(JSON.stringify({ outPath, total_files: files.length, families: Object.keys(families).length }, null, 2));
