#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const root = path.resolve(__dirname, '..', '..');
const manifestPath = path.join(root, 'data', 'processed', 'doctor', 'cli_app_neuro_ingest_priority_2026_05_18.manifest.json');
const outDir = path.join(root, 'data', 'derived', 'template_mothers');
const qaDir = path.join(root, 'qa', 'approval_gates');
const generatedAt = new Date().toISOString();
const runId = `template_mothers_neurocirugia_${generatedAt.slice(0, 10)}`;
const maxPerFamily = Number(process.env.MAX_PER_FAMILY || 18);
const totalLimit = Number(process.env.TOTAL_LIMIT || 360);

for (const dir of [outDir, qaDir]) fs.mkdirSync(dir, { recursive: true });

if (!fs.existsSync(manifestPath)) {
  throw new Error(`No existe manifest de ingesta clinica: ${manifestPath}`);
}

const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));
const allItems = manifest.items || [];

const supportedExt = new Set(['.doc', '.docx', '.odt', '.rtf', '.txt', '.htm', '.html']);
const sourceNeedle = 'NEUROCIRUGIA DE QUIROFANO/Historia + Parte';
const skipPattern = /(^|\/)(~\$|\.~lock|Thumbs\.db)|\.(jpg|jpeg|png|gif|db|tmp|lnk|mpg|thm|onetoc2|ods|pdf|dot)$/i;

const familySpecs = [
  ['columna_vertebroplastia_cifoplastia', /vertebroplast|cifoplast|cement/i],
  ['columna_fijacion_transpedicular', /transpedicular|artrodesis|fijaci[oó]n|instrumentaci[oó]n|tornillos/i],
  ['columna_microdiscectomia_tubular', /tubular|microdiscect|discectom/i],
  ['columna_disco_cervical', /disco cervical|cervical.*(cage|celda|discect|artrodesis)|c[3-7][- ]?c[3-7]/i],
  ['columna_disco_lumbar', /disco lumbar|hernia.*lumbar|l[1-5][- ]?s?1|lumbociatal/i],
  ['columna_canal_estrecho_laminoplastia', /canal estrecho|laminoplast|mielopat/i],
  ['chiari_malformaciones', /chiari|malformaci/i],
  ['hidrocefalia_valvulas_dvp', /v[aá]lvula|dvp|dve|hidrocef/i],
  ['tumores_intracraneales', /tumor|glioma|meningioma|mts|met[aá]sta|fosa posterior/i],
  ['vascular_aneurismas_tvt', /aneurisma|vascular|tvt|malformaci[oó]n arteriovenosa|mav/i],
  ['trauma_craneal_columna', /trauma|hematoma|hundimiento|extradural|subdural|fractura/i],
  ['periferico_tunel_carpiano', /t[uú]nel carpiano|perif[eé]rico/i],
  ['biopsia_infeccion_revision', /biopsia|infecci[oó]n|desbrid|retiro|revisi[oó]n|craneoplast/i],
  ['otros_neurocirugia', /.*/]
];

const canonicalSections = [
  ['identificacion', /^(nombre|paciente|edad|os|obra social|dni|hc|historia clinica)/i],
  ['fechas_y_contexto', /^(fecha|ingreso|egreso|internaci|cirug)/i],
  ['diagnosticos', /^(diagn[oó]stico|dx|motivo)/i],
  ['antecedentes_y_clinica', /^(antecedentes|enfermedad actual|cl[ií]nica|ingreso|examen)/i],
  ['imagenes_y_estudios', /^(rmn|resonancia|tc|tomograf|rx|radiograf|estudios)/i],
  ['indicacion_y_consentimiento', /^(indicaci[oó]n|consentimiento|plan)/i],
  ['tratamiento', /^(tratamiento|procedimiento|operaci[oó]n)/i],
  ['tecnica_quirurgica', /^(t[eé]cnica|parte quir[uú]rgico|descripci[oó]n)/i],
  ['hallazgos', /^(hallazgos|hallazgo)/i],
  ['implantes_y_materiales', /^(implantes|materiales|pr[oó]tesis|tornillos|cage|celda|v[aá]lvula)/i],
  ['complicaciones', /^(complicaciones|incidentes)/i],
  ['evolucion', /^(evoluci[oó]n|postoperatorio|externaci[oó]n|alta)/i],
  ['indicaciones_alta', /^(indicaciones|pautas|control|alarma)/i],
  ['firma', /^(firma|sello|servicio)/i]
];

function normalize(text) {
  return String(text || '')
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase();
}

function sha256(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function familyFor(item) {
  const rel = item.rel_path || item.abs_path || '';
  for (const [id, rx] of familySpecs) {
    if (rx.test(rel)) return id;
  }
  return 'otros_neurocirugia';
}

function extractText(filePath, ext) {
  if (ext === '.txt') return fs.readFileSync(filePath, 'utf8');
  if (ext === '.htm' || ext === '.html') {
    return fs.readFileSync(filePath, 'utf8')
      .replace(/<script[\s\S]*?<\/script>/gi, ' ')
      .replace(/<style[\s\S]*?<\/style>/gi, ' ')
      .replace(/<[^>]+>/g, '\n');
  }
  return execFileSync('textutil', ['-convert', 'txt', '-stdout', filePath], {
    encoding: 'utf8',
    timeout: 20000,
    maxBuffer: 2 * 1024 * 1024
  });
}

function extractHeadings(text) {
  const seen = [];
  const lines = String(text || '').split(/\r?\n/);
  for (const raw of lines) {
    const line = raw.trim().replace(/\s+/g, ' ');
    if (!line || line.length > 95) continue;
    const looksLikeHeading = /^[A-ZÁÉÍÓÚÑÜ0-9][A-ZÁÉÍÓÚÑÜ0-9\s/().,-]{2,}:?$/.test(line)
      || /^[A-ZÁÉÍÓÚÑÜ][A-Za-zÁÉÍÓÚÑÜáéíóúñü\s/().,-]{2,}:$/.test(line);
    if (!looksLikeHeading) continue;
    const clean = line.replace(/:$/, '').trim();
    if (clean.length >= 3 && !seen.includes(clean)) seen.push(clean);
  }
  return seen.slice(0, 80);
}

function canonicalFor(heading) {
  const h = normalize(heading).replace(/:$/, '').trim();
  for (const [id, rx] of canonicalSections) {
    if (rx.test(h)) return id;
  }
  return 'otros';
}

function safeRel(absPath) {
  const rootPath = '/Users/jarvis/Desktop/NEUROCIRUGIA/';
  return absPath && absPath.startsWith(rootPath) ? absPath.slice(rootPath.length) : absPath;
}

const candidates = allItems
  .filter((item) => {
    const abs = item.abs_path || '';
    const rel = item.rel_path || '';
    const ext = String(item.ext || path.extname(abs)).toLowerCase();
    return (abs.includes(sourceNeedle) || rel.includes(sourceNeedle))
      && supportedExt.has(ext)
      && !skipPattern.test(abs)
      && fs.existsSync(abs);
  })
  .map((item) => ({ ...item, family: familyFor(item), ext: String(item.ext || path.extname(item.abs_path)).toLowerCase() }));

const familyBuckets = new Map();
for (const item of candidates) {
  if (!familyBuckets.has(item.family)) familyBuckets.set(item.family, []);
  familyBuckets.get(item.family).push(item);
}

const selected = [];
for (const [family, items] of familyBuckets) {
  const stable = items
    .sort((a, b) => String(a.rel_path).localeCompare(String(b.rel_path)))
    .slice(0, maxPerFamily);
  selected.push(...stable);
}

const selectedLimited = selected.slice(0, totalLimit);
const families = {};
const extractionErrors = [];

for (const item of selectedLimited) {
  const family = item.family;
  if (!families[family]) {
    families[family] = {
      family,
      candidate_count: (familyBuckets.get(family) || []).length,
      sampled_count: 0,
      source_subtrees: {},
      section_counts: {},
      observed_heading_examples: [],
      source_hashes_sample: []
    };
  }
  const bucket = families[family];
  try {
    const text = extractText(item.abs_path, item.ext);
    const headings = extractHeadings(text);
    bucket.sampled_count += 1;
    bucket.source_subtrees[path.dirname(safeRel(item.abs_path)).split('/').slice(0, 4).join('/')] = true;
    bucket.source_hashes_sample.push(item.sha256 || sha256(fs.readFileSync(item.abs_path)));
    for (const heading of headings) {
      const canonical = canonicalFor(heading);
      bucket.section_counts[canonical] = (bucket.section_counts[canonical] || 0) + 1;
      if (bucket.observed_heading_examples.length < 24 && !bucket.observed_heading_examples.includes(heading)) {
        bucket.observed_heading_examples.push(heading);
      }
    }
  } catch (error) {
    extractionErrors.push({
      family,
      rel_path: safeRel(item.abs_path),
      error: String(error.message || error).slice(0, 220)
    });
  }
}

const tamizBase = [
  'Identificacion y fechas completas antes de uso real.',
  'Diagnostico e indicacion vinculados a clinica, estudios y lateralidad/nivel.',
  'Consentimiento/informacion previa mencionado como control documental, sin inventar.',
  'Tecnica quirurgica con abordaje, nivel/lado, hallazgos, maniobras principales, implantes/materiales si corresponde.',
  'Complicaciones: consignar solo dato real; si falta, marcar faltante sensible, no afirmar.',
  'Evolucion y destino postoperatorio separados del parte tecnico.',
  'Pautas de alarma/control y firma/sello como cierre documental.'
];

function motherTemplateFor(id, data) {
  const title = id.replace(/_/g, ' ');
  const common = Object.entries(data.section_counts)
    .sort((a, b) => b[1] - a[1])
    .map(([name]) => name)
    .filter((name) => name !== 'otros')
    .slice(0, 10);
  return {
    title,
    derived_from: 'Estructura local Historia + Parte, sin copiar texto sensible.',
    historia_clinica_sections: [
      'Identificacion y cobertura',
      'Fecha de ingreso / contexto',
      'Diagnostico principal y secundarios',
      'Antecedentes y enfermedad actual',
      'Examen clinico-neurologico pertinente',
      'Estudios complementarios relevantes',
      'Indicacion quirurgica',
      'Plan y consentimiento/documentacion',
      'Evolucion inmediata / indicaciones'
    ],
    parte_quirurgico_sections: [
      'Fecha, institucion, cirujano y equipo',
      'Diagnostico preoperatorio',
      'Procedimiento realizado',
      'Anestesia y posicion',
      'Abordaje, nivel/lado y control anatomico',
      'Hallazgos',
      'Tecnica quirurgica secuencial',
      'Implantes/materiales/lotes si corresponde',
      'Hemostasia, cierre, drenaje',
      'Complicaciones/incidentes segun dato real',
      'Destino postoperatorio'
    ],
    local_style_signals: common,
    medico_legal_tamiz: tamizBase,
    product_rule: 'La app debe generar documento clinico limpio; el tamiz corre en panel lateral y solo transforma el documento cuando hay dato clinico suficiente.'
  };
}

const registryFamilies = {};
for (const [id, data] of Object.entries(families)) {
  data.source_subtrees = Object.keys(data.source_subtrees).sort();
  data.source_hashes_sample = data.source_hashes_sample.slice(0, 10);
  data.mother_template = motherTemplateFor(id, data);
  registryFamilies[id] = data;
}

const registry = {
  generated_at: generatedAt,
  run_id: runId,
  source_root: '/Users/jarvis/Desktop/NEUROCIRUGIA/NEUROCIRUGIA DE QUIROFANO/Historia + Parte',
  privacy_mode: 'derived_structure_only_no_full_patient_text',
  candidate_total: candidates.length,
  selected_for_extraction: selectedLimited.length,
  max_per_family: maxPerFamily,
  total_limit: totalLimit,
  families: registryFamilies,
  extraction_errors: extractionErrors,
  activation_status: 'review_only_pending_human_and_codex_guard',
  app_requirement: 'Integrar estas plantillas madre al modo producto antes de cualquier PDF o entrega final.'
};

const registryPath = path.join(outDir, 'template_mother_registry_2026-05-19.json');
const styleGuidePath = path.join(outDir, 'template_mother_style_guide_2026-05-19.md');
const qaPath = path.join(qaDir, 'template_mother_registry_2026-05-19_summary.json');

fs.writeFileSync(registryPath, JSON.stringify(registry, null, 2));

const md = [
  '# Plantillas madre derivadas del corpus local',
  '',
  `Generado: ${generatedAt}`,
  '',
  'Modo: estructura derivada sin volcar texto completo ni datos personales.',
  '',
  `Candidatos Historia + Parte: ${candidates.length}`,
  `Extraidos para analisis: ${selectedLimited.length}`,
  '',
  '## Regla de producto',
  '',
  'La app debe comportarse como un generador/revisor documental clinico: recibe relato del medico, detecta familia, carga una plantilla madre, completa con datos disponibles, marca faltantes sensibles y aplica correcciones del medico al documento. No debe responder como chat ni entregar PDFs sueltos fuera del flujo.',
  '',
  '## Familias',
  '',
  ...Object.entries(registryFamilies).map(([id, data]) => [
    `### ${id}`,
    `Candidatos: ${data.candidate_count}. Muestra extraida: ${data.sampled_count}.`,
    `Secciones dominantes: ${Object.entries(data.section_counts).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([name, count]) => `${name} (${count})`).join(', ') || 'sin datos'}.`,
    `Subarboles: ${data.source_subtrees.slice(0, 4).join('; ') || 'sin datos'}.`,
    ''
  ].join('\n')),
  '## Tamiz medico legal comun',
  '',
  ...tamizBase.map((item) => `- ${item}`),
  '',
  '## Prohibiciones operativas',
  '',
  '- No copiar pacientes reales al producto final de prueba.',
  '- No afirmar ausencia de complicaciones, consentimiento, lateralidad, implantes o evolucion si el dato no fue dado.',
  '- No mezclar citas legales dentro del texto clinico final; el tamiz debe quedar como control lateral o validacion interna.',
  '- No enviar PDF final hasta tener candidato de app validado y APTO_PARA_ENTREGAR.'
].join('\n');

fs.writeFileSync(styleGuidePath, md);

const qa = {
  generated_at: generatedAt,
  registry_path: registryPath,
  style_guide_path: styleGuidePath,
  candidate_total: candidates.length,
  selected_for_extraction: selectedLimited.length,
  families: Object.fromEntries(Object.entries(registryFamilies).map(([id, data]) => [id, {
    candidate_count: data.candidate_count,
    sampled_count: data.sampled_count,
    section_kinds: Object.keys(data.section_counts).length
  }])),
  extraction_errors_count: extractionErrors.length,
  extraction_errors_sample: extractionErrors.slice(0, 8),
  status: extractionErrors.length > selectedLimited.length * 0.2 ? 'review_needed_extraction_errors' : 'ok_review_only'
};
fs.writeFileSync(qaPath, JSON.stringify(qa, null, 2));

console.log(JSON.stringify(qa, null, 2));
