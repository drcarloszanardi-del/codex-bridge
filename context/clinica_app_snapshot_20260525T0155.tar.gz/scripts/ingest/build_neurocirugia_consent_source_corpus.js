const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execFileSync } = require('child_process');

const appRoot = path.resolve(__dirname, '..', '..');
const outDir = path.join(appRoot, 'data', 'derived', 'consent_source_corpus');
const qaDir = path.join(appRoot, 'qa', 'approval_gates');
const docsDir = path.join(appRoot, 'docs');

const sourceRoots = [
  {
    id: 'neurocirugia_consentimientos',
    path: '/Users/jarvis/Desktop/NEUROCIRUGIA/Consentimientos',
    role: 'clinical_forms'
  },
  {
    id: 'neurocirugia_quirofano_consentimientos',
    path: '/Users/jarvis/Desktop/NEUROCIRUGIA/NEUROCIRUGIA DE QUIROFANO/consentimientos',
    role: 'clinical_forms_historical'
  },
  {
    id: 'neurocirugia_informed_consent_doctrine',
    path: '/Users/jarvis/Desktop/NEUROCIRUGIA/INFORMED CONSENT',
    role: 'doctrine_support'
  }
];

const allowedExtensions = new Set(['.doc', '.docx', '.odt', '.rtf', '.txt', '.htm', '.html', '.pdf']);
const python = process.env.CLINICA_PYTHON || '/Users/jarvis/.cache/codex-runtimes/codex-primary-runtime/dependencies/python/bin/python3';

const familyRules = [
  ['hernia_disco_lumbar', /(hernia|disco lumbar|microdiscect|discectom|di[aá]m|coflex disco)/i],
  ['canal_estrecho_lumbar_con_fijacion', /(canal lumbar|estenosis lumbar|recalibraje|artrosis).*?(fijaci[oó]n|artrodesis|transpedicular|implante|tornillo|caja)|artrodesis l[0-9]|espondilolistesis|listesis/i],
  ['canal_estrecho_lumbar_sin_fijacion', /(canal lumbar|estenosis lumbar|recalibraje|laminectom[íi]a lumbar|descompresi[oó]n lumbar)(?![\s\S]{0,80}(fijaci[oó]n|artrodesis|transpedicular|implante|tornillo|caja))/i],
  ['coflex_diam_interespinoso', /(coflex|di[aá]m|interespinoso)/i],
  ['columna_cervical_anterior_artrodesis_artroplastia', /(columna cervical|cervicobraqui|disco cervical|artrodesis cervical|artroplastia cervical|foraminotom|luxaci[oó]n cervical|hangman|c2)/i],
  ['laminoplastia_cervical_canal_cervical', /(laminoplast|canal cervical|mielopat|estenosis cervical|compresi[oó]n medular cervical)/i],
  ['vertebroplastia_cifoplastia', /(vertebroplast|cifoplast|cemento|aplastamiento|fractura osteopor)/i],
  ['biopsia_vertebral_mts_infeccion', /(biopsia|punci[oó]n vertebral|mts vertebral|met[aá]stasis vertebral|espondilodiscitis|discitis|absceso vertebral)/i],
  ['tumor_medular_intrarraquideo', /(tumor medular|meningioma dorsal|tumor dorsal|tumor sacro|intrarraqu|cola de caballo)/i],
  ['trauma_columna', /(fractura lumbar|fractura dorsal|trauma|retiro de pr[oó]tesis|reop|reoperaci[oó]n)/i],
  ['hidrocefalia_derivaciones', /(hidrocefalia|v[aá]lvula|hakim|dvp|dve|lumboperitoneal|dandy walker)/i],
  ['chiari', /(chiari|fosa posterior|cr[aá]neo[- ]?cervical)/i],
  ['hematoma_subdural_epidural', /(hsd|hed|hematoma subdural|hematoma epidural|cr[oó]nico|subagudo|agudo)/i],
  ['tumor_intracraneal_absceso', /(tumor|meningioma|glioma|met[aá]sta|absceso|craneotom|lesi[oó]n expansiva|cerebel|ventricular|frontal|temporal)(?![\s\S]{0,40}(medular|dorsal|vertebral))/i],
  ['craneoplastia_hundimiento', /(craneoplast|hundim|fractura hundimiento|craniectom)/i],
  ['vascular_neuroquirurgico', /(aneurisma|mav|malformaci[oó]n arteriovenosa|cavernoma|vascular|endovascular|hsa|f[ií]stula|tvt)/i],
  ['tunel_carpiano_cubital_periferico', /(t[uú]nel carpiano|cubital|snp|nervio perif[eé]rico|tapia|porfilio|chiavassa|neurolisis)/i],
  ['neurolisis_trigeminal_transoval', /(transoval|trig[eé]mino|neuralgia trigeminal)/i],
  ['mielomeningocele_pediatrico', /(mielomeningocele|pediatr)/i],
  ['anexo_itaes_general', /(itaes|anexo consentimiento|testigo de jehova|mural|familiar)/i]
];

const sectionRules = {
  patient_identity: /(yo,|paciente|dni|documento|aclaraci[oó]n)/i,
  diagnosis_indication: /(diagn[oó]stico|intervenirme quir[uú]rgicamente|padezco|por presentar|me produce|indicaci[oó]n)/i,
  procedure: /(procedimiento|cirug[ií]a|objetivo|se realizar[aá]|autorizo.*intervenir|tratamiento quir[uú]rgico)/i,
  benefits: /(beneficio|objetivo|mejor[ií]a|alivio|descomprimir|estabilizar|resolver|reducir)/i,
  risks: /(riesgo|complicaci[oó]n|infecci[oó]n|hemorragia|sangrado|d[eé]ficit|muerte|lcr|reoperaci[oó]n)/i,
  alternatives: /(alternativa|tratamiento conservador|tratamiento m[eé]dico|kinesiolog|bloqueo|no oper)/i,
  no_treatment: /(si no|no realizar|no efectuar|rechazo|sin tratamiento|de no oper|persistir|agravar)/i,
  autonomy_questions_revocation: /(preguntas|segunda opini[oó]n|revocar|rechazar|aceptar|comprendido|he sido informado)/i,
  anesthesia_blood: /(anestesia|anestesi[oó]logo|transfusi[oó]n|hemoderivado|sangre)/i,
  signatures: /(firma|aclaraci[oó]n|d\\.??n\\.??i|dni|fecha|jun[ií]n)/i,
  hc_copy_access: /(historia cl[ií]nica|copia|archivo|documentaci[oó]n cl[ií]nica)/i
};

const riskRules = {
  dolor_residual: /dolor residual|persistencia.*dolor|reca[ií]da.*dolor|dolor/i,
  infeccion: /infecci[oó]n|discitis|absceso|sepsis/i,
  sangrado_hematoma: /sangrado|hemorrag|hematoma/i,
  lcr_dural: /l[ií]quido cefalorraqu[ií]deo|lcr|dura|durotom|f[ií]stula|pseudomeningocele/i,
  deficit_neurologico: /d[eé]ficit|par[aá]lisis|paresia|sensitivo|motriz|motor|medular|radicular/i,
  reoperacion: /reoperaci[oó]n|reintervenci[oó]n|nueva cirug/i,
  muerte: /muerte|vida del enfermo|riesgo de vida/i,
  implantes: /implante|tornillo|barra|caja|pr[oó]tesis|malposici[oó]n|pseudoartrosis|falla/i,
  cemento: /cemento|extravasaci[oó]n|embolismo/i,
  valvula: /v[aá]lvula|obstrucci[oó]n|hiperdrenaje|hipodrenaje|recambio/i,
  convulsiones: /convulsi[oó]n|crisis/i,
  esfinteres: /esf[ií]nter|vejiga|intestino/i
};

function sha256(value) {
  return crypto.createHash('sha256').update(value).digest('hex');
}

function walk(dir, out = []) {
  if (!fs.existsSync(dir)) return out;
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    if (entry.name.startsWith('.~') || entry.name.startsWith('~$') || entry.name === 'Thumbs.db') continue;
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) walk(full, out);
    else if (allowedExtensions.has(path.extname(entry.name).toLowerCase())) out.push(full);
  }
  return out;
}

function normalizeText(value) {
  return String(value || '')
    .replace(/\r/g, '\n')
    .replace(/[ \t]+/g, ' ')
    .replace(/\n[ \t]+/g, '\n')
    .replace(/\n{3,}/g, '\n\n')
    .trim();
}

function compactText(value) {
  return normalizeText(value)
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/\b\d{1,2}[\/.-]\d{1,2}[\/.-]\d{2,4}\b/g, '<date>')
    .replace(/\b\d{1,2}\s+de\s+[a-z]+\s+de\s+\d{4}\b/g, '<date>')
    .replace(/\b\d{7,9}\b/g, '<dni>')
    .replace(/[^\p{L}\p{N}<>\s]/gu, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

function htmlToText(raw) {
  return normalizeText(String(raw || '')
    .replace(/<script[\s\S]*?<\/script>/gi, ' ')
    .replace(/<style[\s\S]*?<\/style>/gi, ' ')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/(p|div|li|h[1-6]|tr)>/gi, '\n')
    .replace(/<[^>]+>/g, ' ')
    .replace(/&nbsp;/g, ' ')
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"'));
}

function extractPdf(file) {
  const py = [
    'import sys',
    'from pypdf import PdfReader',
    'reader = PdfReader(sys.argv[1])',
    'parts = []',
    'for page in reader.pages:',
    '    try:',
    '        parts.append(page.extract_text() or "")',
    '    except Exception:',
    '        parts.append("")',
    'print("\\n".join(parts))'
  ].join('\n');
  return execFileSync(python, ['-c', py, file], { encoding: 'utf8', timeout: 20000, maxBuffer: 1024 * 1024 * 16 });
}

function extractText(file) {
  const ext = path.extname(file).toLowerCase();
  try {
    if (ext === '.txt') return fs.readFileSync(file, 'utf8');
    if (ext === '.htm' || ext === '.html') return htmlToText(fs.readFileSync(file, 'utf8'));
    if (ext === '.pdf') return extractPdf(file);
    return execFileSync('/usr/bin/textutil', ['-convert', 'txt', '-stdout', file], {
      encoding: 'utf8',
      timeout: 20000,
      maxBuffer: 1024 * 1024 * 16
    });
  } catch (error) {
    return '';
  }
}

function detectInstitution(pathAndText) {
  if (/peque[nñ]a familia|lpf/i.test(pathAndText)) return 'la_pequena_familia';
  if (/higa|hospital interzonal|pi[nñ]eyro/i.test(pathAndText)) return 'higa_junin';
  if (/cl[ií]nica centro/i.test(pathAndText)) return 'clinica_centro';
  if (/itaes/i.test(pathAndText)) return 'itaes_anexo';
  return 'no_determinada';
}

function classifyFamily(file, text) {
  const beforeRisks = String(text || '').split(/\b(riesgos?|complicaciones?)\b/i)[0].slice(0, 2600);
  const pathAndText = `${file}\n${beforeRisks}`;
  for (const [family, rx] of familyRules) {
    if (rx.test(pathAndText)) return family;
  }
  return 'neurocirugia_general_otras_patologias';
}

function sourceRootFor(file) {
  return sourceRoots.find((root) => file.startsWith(root.path));
}

function classifyBucket(file, text, family) {
  const root = sourceRootFor(file);
  const pathAndText = `${file}\n${text}`;
  if (/colocaci[oó]n diu/i.test(pathAndText)) return 'excluded_non_neuro';
  if (/consentimiento de anestesia/i.test(pathAndText)) return 'excluded_anesthesia_only';
  if (root?.role === 'doctrine_support') return 'doctrine_support';
  if (!/consent/i.test(file) && !/consentimiento informado|autorizo|he sido informado/i.test(text)) return 'excluded_not_consent';
  if (family === 'anexo_itaes_general') return 'institutional_general_anexo';
  return 'clinical_neuro_consent';
}

function countWords(text) {
  const compact = compactText(text);
  return compact ? compact.split(/\s+/).length : 0;
}

function qualityScore(sections) {
  const weights = {
    patient_identity: 1,
    diagnosis_indication: 2,
    procedure: 2,
    benefits: 1,
    risks: 2,
    alternatives: 2,
    no_treatment: 2,
    autonomy_questions_revocation: 2,
    anesthesia_blood: 1,
    signatures: 1,
    hc_copy_access: 1
  };
  return Object.entries(weights).reduce((sum, [key, weight]) => sum + (sections[key] ? weight : 0), 0);
}

function addToSetMap(map, key, values) {
  map[key] ||= new Set();
  for (const value of values) map[key].add(value);
}

function sortedSet(values) {
  return Array.from(values || []).sort();
}

function summarizeProcedureTerms(text) {
  const terms = [];
  const patterns = {
    microdiscectomia: /microdiscect|discectom|hernia discal|fragmento herniado/i,
    descompresion_recalibraje: /descompresi[oó]n|recalibraje|laminectom|foraminotom/i,
    fijacion_artrodesis: /fijaci[oó]n|artrodesis|tornillo|barra|caja|implante/i,
    laminoplastia: /laminoplast/i,
    artroplastia_artrodesis_cervical: /artroplastia cervical|artrodesis cervical|abordaje cervical/i,
    cementacion: /vertebroplast|cifoplast|cement/i,
    derivacion_lcr: /derivaci[oó]n|v[aá]lvula|lumboperitoneal|dvp|dve/i,
    craneotomia: /craneotom|craniectom|craneoplast/i,
    evacuacion_hematoma: /evacuaci[oó]n|hematoma|drenaje/i,
    neurolisis: /neurolisis|liberaci[oó]n|t[uú]nel carpiano|cubital/i,
    biopsia_desbridamiento: /biopsia|punci[oó]n|toilette|desbridamiento/i
  };
  for (const [term, rx] of Object.entries(patterns)) {
    if (rx.test(text)) terms.push(term);
  }
  return terms;
}

function build() {
  const files = sourceRoots.flatMap((root) => walk(root.path));
  const entries = [];
  const duplicatesByText = new Map();
  let extractionFailures = 0;

  for (const file of files) {
    const rawText = normalizeText(extractText(file));
    if (!rawText) extractionFailures += 1;
    const pathAndText = `${file}\n${rawText}`;
    const family = classifyFamily(file, rawText);
    const bucket = classifyBucket(file, rawText, family);
    const institution = detectInstitution(pathAndText);
    const textHash = sha256(compactText(rawText) || file);
    const duplicateOf = duplicatesByText.get(textHash) || null;
    if (!duplicateOf) duplicatesByText.set(textHash, textHash);
    const sections = Object.fromEntries(Object.entries(sectionRules).map(([key, rx]) => [key, rx.test(rawText)]));
    const risks = Object.entries(riskRules).filter(([, rx]) => rx.test(rawText)).map(([key]) => key);
    const missingCore = Object.entries(sectionRules)
      .filter(([key, present]) => ['diagnosis_indication', 'procedure', 'risks', 'alternatives', 'no_treatment', 'autonomy_questions_revocation', 'signatures'].includes(key) && !sections[key])
      .map(([key]) => key);

    entries.push({
      source_hash: sha256(file).slice(0, 20),
      text_hash: textHash.slice(0, 20),
      duplicate: Boolean(duplicateOf),
      duplicate_group: textHash.slice(0, 20),
      source_root_id: sourceRootFor(file)?.id || 'unknown',
      extension: path.extname(file).toLowerCase().replace('.', ''),
      bucket,
      canonical_family: family,
      institution,
      word_count: countWords(rawText),
      extraction_ok: Boolean(rawText),
      quality_score: qualityScore(sections),
      sections,
      missing_core_requirements: missingCore,
      risk_terms: risks,
      procedure_terms: summarizeProcedureTerms(rawText)
    });
  }

  const uniqueClinical = entries.filter((entry) => entry.bucket === 'clinical_neuro_consent' && !entry.duplicate);
  const familyMap = {};
  for (const entry of uniqueClinical) {
    familyMap[entry.canonical_family] ||= {
      unique_sources: 0,
      institutions: new Set(),
      risk_terms: new Set(),
      procedure_terms: new Set(),
      missing_core_counter: {},
      quality_scores: [],
      source_hashes: []
    };
    const item = familyMap[entry.canonical_family];
    item.unique_sources += 1;
    item.institutions.add(entry.institution);
    entry.risk_terms.forEach((term) => item.risk_terms.add(term));
    entry.procedure_terms.forEach((term) => item.procedure_terms.add(term));
    item.quality_scores.push(entry.quality_score);
    item.source_hashes.push(entry.source_hash);
    for (const missing of entry.missing_core_requirements) {
      item.missing_core_counter[missing] = (item.missing_core_counter[missing] || 0) + 1;
    }
  }

  const families = Object.fromEntries(Object.entries(familyMap)
    .sort((a, b) => b[1].unique_sources - a[1].unique_sources)
    .map(([family, item]) => {
      const scores = item.quality_scores.slice().sort((a, b) => a - b);
      return [family, {
        unique_sources: item.unique_sources,
        institutions: sortedSet(item.institutions),
        risk_terms: sortedSet(item.risk_terms),
        procedure_terms: sortedSet(item.procedure_terms),
        median_quality_score: scores.length ? scores[Math.floor(scores.length / 2)] : 0,
        missing_core_counter: item.missing_core_counter,
        representative_source_hashes: item.source_hashes.slice(0, 12)
      }];
    }));

  const bucketCounts = {};
  const familyCountsAll = {};
  for (const entry of entries) {
    bucketCounts[entry.bucket] = (bucketCounts[entry.bucket] || 0) + 1;
    familyCountsAll[entry.canonical_family] = (familyCountsAll[entry.canonical_family] || 0) + 1;
  }

  const corpus = {
    generated_at: new Date().toISOString(),
    corpus_id: 'neurocirugia_consent_source_corpus_2026-05-20',
    source_roots: sourceRoots,
    privacy_mode: 'derived_features_only_no_full_text_no_patient_names_no_source_paths',
    total_files_seen: files.length,
    extraction_failures: extractionFailures,
    unique_text_groups: duplicatesByText.size,
    bucket_counts: bucketCounts,
    all_family_counts: familyCountsAll,
    filtered_for_consent_corpus: {
      rule: 'clinical_neuro_consent unique by normalized text hash',
      unique_sources: uniqueClinical.length,
      families_count: Object.keys(families).length
    },
    medico_legal_requirements_checked: Object.keys(sectionRules),
    risk_taxonomy: Object.keys(riskRules),
    families,
    entries
  };

  fs.mkdirSync(outDir, { recursive: true });
  fs.mkdirSync(qaDir, { recursive: true });
  fs.mkdirSync(docsDir, { recursive: true });

  const outPath = path.join(outDir, 'neurocirugia_consent_source_corpus_2026-05-20.json');
  const latestPath = path.join(outDir, 'neurocirugia_consent_source_corpus_latest.json');
  fs.writeFileSync(outPath, JSON.stringify(corpus, null, 2) + '\n');
  fs.writeFileSync(latestPath, JSON.stringify(corpus, null, 2) + '\n');

  const qa = {
    generated_at: corpus.generated_at,
    ok: extractionFailures < Math.ceil(files.length * 0.1) && uniqueClinical.length > 20 && Object.keys(families).length >= 10,
    out_path: outPath,
    latest_path: latestPath,
    total_files_seen: files.length,
    extraction_failures: extractionFailures,
    unique_text_groups: duplicatesByText.size,
    bucket_counts: bucketCounts,
    unique_clinical_sources: uniqueClinical.length,
    families_count: Object.keys(families).length,
    top_families: Object.entries(families).slice(0, 14).map(([family, item]) => ({
      family,
      unique_sources: item.unique_sources,
      institutions: item.institutions,
      median_quality_score: item.median_quality_score,
      risk_terms_count: item.risk_terms.length
    }))
  };
  fs.writeFileSync(path.join(qaDir, 'neurocirugia_consent_source_corpus_2026-05-20.json'), JSON.stringify(qa, null, 2) + '\n');

  const md = [
    '# Ingesta Consentimientos Neurocirugia - 2026-05-20',
    '',
    `Estado: ${qa.ok ? 'OK' : 'REVISAR'}.`,
    '',
    `Archivos revisados: ${files.length}.`,
    `Textos únicos detectados: ${duplicatesByText.size}.`,
    `Consentimientos neuroquirúrgicos únicos filtrados: ${uniqueClinical.length}.`,
    `Familias incorporadas al corpus: ${Object.keys(families).length}.`,
    `Fallos de extracción: ${extractionFailures}.`,
    '',
    'Privacidad: el corpus guarda rasgos derivados, hashes y conteos; no vuelca texto completo, nombres de pacientes ni rutas fuente completas.',
    '',
    '## Familias principales',
    '',
    ...Object.entries(families).slice(0, 20).map(([family, item]) => (
      `- ${family}: ${item.unique_sources} fuentes únicas; instituciones ${item.institutions.join(', ')}; riesgos ${item.risk_terms.join(', ')}.`
    )),
    '',
    '## Uso operativo',
    '',
    '- El corpus fuente complementa `consent_body_pack_2026-05-19.json` como respaldo de variabilidad histórica.',
    '- No habilita entrega automática de una nueva patología por sí solo: primero debe pasar matriz R1-R8 y formato visual aprobado.',
    '- Sirve para enriquecer riesgos, alternativas y consecuencias de no tratar por familia, sin copiar formularios viejos de manera literal.',
    ''
  ].join('\n');
  fs.writeFileSync(path.join(docsDir, 'consentimientos_neurocirugia_ingesta_2026-05-20.md'), md);

  console.log(JSON.stringify(qa, null, 2));
}

build();
