#!/usr/bin/env python3
import argparse
import json
import re
import tempfile
from html.parser import HTMLParser
from pathlib import Path

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

APP_ROOT = Path(__file__).resolve().parents[2]
PACK_PATH = APP_ROOT / "data" / "derived" / "consent_canonicals" / "consent_body_pack_2026-05-19.json"


class BlockParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.blocks = []
        self.current = []
        self.tag_stack = []
        self.current_tag = None

    def handle_starttag(self, tag, attrs):
        if tag in {"p", "h1", "h2", "h3", "li"}:
            self.current = []
            self.current_tag = tag
        if tag in {"strong", "b"} and self.current_tag:
            self.current.append("<b>")

    def handle_endtag(self, tag):
        if tag in {"strong", "b"} and self.current_tag:
            self.current.append("</b>")
        if tag in {"p", "h1", "h2", "h3", "li"}:
            text = re.sub(r"\s+", " ", "".join(self.current)).strip()
            if text:
                self.blocks.append({"tag": tag, "text": text})
            self.current = []
            self.current_tag = None

    def handle_data(self, data):
        if self.current_tag:
            self.current.append(data)


def load_pack():
    if not PACK_PATH.exists():
        return {}
    with PACK_PATH.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def logo_path(pack, institution_key):
    item = pack.get("institutions", {}).get(institution_key, {})
    logo = item.get("logo") or item.get("approved_visual_logo")
    return Path(logo) if logo else None


def prepared_logo_for_pdf(logo):
    if not logo or not logo.exists():
        return None
    try:
        from PIL import Image as PILImage
    except Exception:
        return logo

    image = PILImage.open(logo).convert("RGBA")
    pixels = image.load()
    width, height = image.size
    foreground = []
    for y in range(height):
        for x in range(width):
            r, g, b, a = pixels[x, y]
            if a and min(r, g, b) < 242:
                foreground.append((x, y))
            elif a and min(r, g, b) >= 242:
                pixels[x, y] = (255, 255, 255, 0)
    if foreground:
        xs = [xy[0] for xy in foreground]
        ys = [xy[1] for xy in foreground]
        pad = 5
        box = (
            max(min(xs) - pad, 0),
            max(min(ys) - pad, 0),
            min(max(xs) + pad + 1, width),
            min(max(ys) + pad + 1, height),
        )
        image = image.crop(box)
    temp = tempfile.NamedTemporaryFile(prefix="clinica_doc_logo_", suffix=".png", delete=False)
    temp.close()
    image.save(temp.name)
    return Path(temp.name)


def logo_image_for_pdf(logo, max_width, max_height, h_align="LEFT"):
    if not logo or not logo.exists():
        return None
    try:
        from PIL import Image as PILImage

        with PILImage.open(logo) as image:
            width, height = image.size
        if width <= 0 or height <= 0:
            raise ValueError("invalid logo size")
        scale = min(max_width / width, max_height / height)
        image_width = width * scale
        image_height = height * scale
        logo_image = Image(str(logo), width=image_width, height=image_height, mask="auto")
    except Exception:
        logo_image = Image(
            str(logo),
            width=max_width,
            height=max_height,
            kind="proportional",
            mask="auto",
        )
    logo_image.hAlign = h_align
    return logo_image


def blocks_from_html(html):
    parser = BlockParser()
    parser.feed(html)
    return parser.blocks


def strip_inline_markup(text):
    return re.sub(r"</?b>", "", text or "")


def escape_reportlab(text):
    text = str(text or "")
    text = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    text = text.replace("&lt;b&gt;", "<b>").replace("&lt;/b&gt;", "</b>")
    return text


def is_title_block(tag, text):
    plain = strip_inline_markup(text).strip()
    letters = re.sub(r"[^A-ZÁÉÍÓÚÜÑ]", "", plain)
    return tag in {"h1", "h2", "h3"} or (plain.isupper() and len(letters) > 14)


def signature_table(lines, body_style, width):
    patient_lines = []
    doctor_lines = []
    target = patient_lines
    for item in lines:
        plain = strip_inline_markup(item).strip()
        lower = plain.lower()
        if lower.startswith(("firma del médico", "firma del medico", "aclaración y sello", "aclaracion y sello", "matrícula", "matricula")):
            target = doctor_lines
        target.append(escape_reportlab(plain))
    if not doctor_lines:
        return None
    table = Table(
        [[Paragraph("<br/>".join(patient_lines), body_style), Paragraph("<br/>".join(doctor_lines), body_style)]],
        colWidths=[width * 0.49, width * 0.49],
        hAlign="CENTER",
    )
    table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
    ]))
    return table


def looks_like_signature(text):
    plain = strip_inline_markup(text).strip().lower()
    return plain.startswith((
        "firma del paciente",
        "firma del paciente/representante",
        "firma del paciente o representante",
        "aclaración:",
        "aclaracion:",
        "dni:",
        "dni / vínculo",
        "dni / vinculo",
        "firma del médico",
        "firma del medico",
        "aclaración y sello",
        "aclaracion y sello",
        "matrícula",
        "matricula",
    ))


def build_pdf(payload, output_path):
    pack = load_pack()
    institution_key = payload.get("institution_key") or "clinica_centro"
    logo = logo_path(pack, institution_key)
    prepared_logo = prepared_logo_for_pdf(logo)

    styles = getSampleStyleSheet()
    body = ParagraphStyle(
        "ClinicalBody",
        parent=styles["BodyText"],
        fontName="Helvetica",
        fontSize=10.2,
        leading=13.6,
        spaceAfter=6.2,
        alignment=TA_JUSTIFY,
    )
    small = ParagraphStyle(
        "ClinicalSmall",
        parent=body,
        fontSize=8.7,
        leading=11,
        textColor=colors.HexColor("#475569"),
        spaceAfter=3,
    )
    title = ParagraphStyle(
        "ClinicalTitle",
        parent=styles["Heading2"],
        fontName="Helvetica-Bold",
        fontSize=13,
        leading=16,
        alignment=TA_CENTER,
        spaceAfter=10,
        textColor=colors.HexColor("#102f45"),
    )
    subtitle = ParagraphStyle(
        "ClinicalSubtitle",
        parent=styles["Heading3"],
        fontName="Helvetica-Bold",
        fontSize=10.4,
        leading=13,
        alignment=TA_CENTER,
        spaceAfter=5,
        textColor=colors.HexColor("#102f45"),
    )
    bullet = ParagraphStyle(
        "ClinicalBullet",
        parent=body,
        leftIndent=15,
        firstLineIndent=-9,
    )

    output_path.parent.mkdir(parents=True, exist_ok=True)
    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        leftMargin=1.65 * cm,
        rightMargin=1.65 * cm,
        topMargin=1.15 * cm,
        bottomMargin=1.25 * cm,
    )
    story = []
    if prepared_logo and prepared_logo.exists():
        image = logo_image_for_pdf(prepared_logo, max_width=4.0 * cm, max_height=1.25 * cm, h_align="LEFT")
        header_left = [image]
    else:
        header_left = [Paragraph(escape_reportlab(payload.get("institution_label", "")), subtitle)]
    header_right = [
        Paragraph(escape_reportlab(payload.get("family_label", "")), small),
        Paragraph(escape_reportlab(f"Dr. {payload.get('surgeon', 'Carlos Zanardi')}"), small),
    ]
    header = Table([[header_left, header_right]], colWidths=[doc.width * 0.58, doc.width * 0.40])
    header.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 7),
        ("LINEBELOW", (0, 0), (-1, -1), 0.5, colors.HexColor("#cbd5e1")),
    ]))
    story.append(header)
    story.append(Spacer(1, 11))
    story.append(Paragraph(escape_reportlab(payload.get("title", "Documento clínico")), title))

    signature_lines = []
    for block in blocks_from_html(payload.get("body_html", "")):
        text = block["text"]
        if looks_like_signature(text):
            signature_lines.append(text)
            continue
        escaped = escape_reportlab(text)
        if is_title_block(block["tag"], text):
            story.append(Paragraph(escaped, subtitle))
        elif block["tag"] == "li":
            story.append(Paragraph(f"- {escaped}", bullet))
        else:
            story.append(Paragraph(escaped, body))

    table = signature_table(signature_lines, body, doc.width)
    if table:
        story.append(Spacer(1, 10))
        story.append(table)

    try:
        doc.build(story)
    finally:
        if prepared_logo and prepared_logo != logo:
            try:
                prepared_logo.unlink()
            except OSError:
                pass


def main():
    parser = argparse.ArgumentParser(description="Exporta documentos clinicos generados por la app a PDF.")
    parser.add_argument("--payload", required=True)
    parser.add_argument("--output", required=True)
    args = parser.parse_args()
    with Path(args.payload).open("r", encoding="utf-8") as handle:
        payload = json.load(handle)
    build_pdf(payload, Path(args.output))
    print(args.output)


if __name__ == "__main__":
    main()
