#!/usr/bin/env python3
import argparse
import json
import re
import tempfile
from html.parser import HTMLParser
from pathlib import Path

from docx import Document
from docx.shared import Inches, Pt
from docx.enum.text import WD_ALIGN_PARAGRAPH
from reportlab.lib.enums import TA_CENTER, TA_JUSTIFY
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm
from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

APP_ROOT = Path(__file__).resolve().parents[2]
PACK_PATH = APP_ROOT / "data" / "derived" / "consent_canonicals" / "consent_body_pack_2026-05-19.json"
OUT_DIR = APP_ROOT / "exports" / "consentimientos"
DEFAULT_SURGEON_LICENSE = "MP 63905 MN 116564"
VISUAL_STANDARD_ID = "consentimiento_sobrio_institucional_v1"
VISUAL_STANDARD_SUMMARY = (
    "A4 sobrio, logo institucional unico, sin repetir nombre institucional si el logo ya lo contiene, "
    "titulo centrado, cuerpo juridico-clinico justificado y firmas paralelas."
)
CONTENT_STANDARD_ID = "consentimiento_medicolegal_arg_v1"
CONTENT_STANDARD_SUMMARY = (
    "Matriz R1-R8 Argentina: identificacion del paciente y acto, diagnostico e indicacion, "
    "procedimiento, riesgos especificos, beneficios/alternativas/no tratamiento, autonomia, "
    "firmas con matricula e integracion a historia clinica con copia/acceso."
)


def with_level(text, args):
    return text.format(level=args.level)


def canonical_content_override(slug, args):
    level = args.level
    overrides = {
        "artrodesis_cervical": {
            "title": "CONSENTIMIENTO INFORMADO PARA ARTRODESIS CERVICAL",
            "diagnosis": f"patología discal o degenerativa cervical en {level}",
            "procedure": f"discectomía cervical anterior, descompresión y artrodesis intersomática en {level}",
            "bullets": [
                "que el objetivo es descomprimir estructuras neurales, estabilizar la columna y tratar el dolor radicular o compromiso neurológico vinculado al diagnóstico;",
                "que la mejoría puede ser parcial y que no se garantiza un resultado exacto;",
                "que existen alternativas terapéuticas razonables, incluyendo tratamiento médico, rehabilitación, inmovilización, observación, otras técnicas quirúrgicas y la posibilidad de no operarme, con sus riesgos y beneficios;",
                "que, si no realizo el tratamiento indicado, pueden persistir o progresar el dolor cervical o radicular, los trastornos sensitivos, la compresión neural, la limitación funcional y el deterioro neurológico;",
                "que los riesgos incluyen lesión neurológica, disfonía, disfagia, lesión vascular, lesión esofágica o traqueal, infección, sangrado, hematoma, falla de implantes, pseudoartrosis, dolor persistente, necesidad de nueva cirugía y complicaciones anestésicas;",
                "que durante el procedimiento pueden requerirse modificaciones técnicas o conductas adicionales por hallazgos intraoperatorios.",
            ],
        },
        "artroplastia_cervical": {
            "title": "CONSENTIMIENTO INFORMADO PARA ARTROPLASTIA CERVICAL",
            "diagnosis": f"patología discal cervical en {level}",
            "procedure": f"discectomía cervical anterior, descompresión y artroplastia cervical en {level}",
            "bullets": [
                "que el objetivo es descomprimir estructuras neurales y conservar movilidad segmentaria mediante prótesis cervical;",
                "que la mejoría puede ser parcial y que no se garantiza un resultado exacto;",
                "que existen alternativas terapéuticas razonables, incluyendo tratamiento médico, rehabilitación, observación, artrodesis cervical u otras técnicas quirúrgicas y la posibilidad de no operarme, con sus riesgos y beneficios;",
                "que, si no realizo el tratamiento indicado, pueden persistir o progresar el dolor cervical o radicular, los trastornos sensitivos, la compresión neural y la limitación funcional;",
                "que los riesgos incluyen lesión neurológica, disfonía, disfagia, lesión vascular, lesión esofágica o traqueal, infección, sangrado, hematoma, migración o falla de prótesis, dolor persistente, necesidad de nueva cirugía y complicaciones anestésicas;",
                "que durante el procedimiento pueden requerirse modificaciones técnicas o conversión a otra estrategia quirúrgica por hallazgos intraoperatorios.",
            ],
        },
        "laminoplastia_cervical": {
            "title": "CONSENTIMIENTO INFORMADO PARA LAMINOPLASTIA CERVICAL",
            "diagnosis": f"mielopatía cervical por estenosis de canal en {level}",
            "procedure": f"laminoplastia cervical descompresiva en {level}",
            "bullets": [
                "que el objetivo es descomprimir la médula espinal cervical y frenar la progresión del compromiso neurológico;",
                "que la recuperación puede ser parcial, especialmente ante compromiso neurológico previo de larga evolución, y que no se garantiza un resultado exacto;",
                "que existen alternativas terapéuticas razonables, incluyendo tratamiento médico, rehabilitación, observación, otras técnicas de descompresión o fijación y la posibilidad de no operarme, con sus riesgos y beneficios;",
                "que, si no realizo el tratamiento indicado, pueden persistir o progresar el trastorno de la marcha, la torpeza manual, los trastornos sensitivos, la debilidad y el compromiso medular;",
                "que los riesgos incluyen déficit neurológico, dolor axial, parálisis C5, lesión dural o fístula de LCR, infección, sangrado, hematoma, falla de implantes, inestabilidad, necesidad de nueva cirugía y complicaciones anestésicas;",
                "que durante el procedimiento pueden requerirse modificaciones técnicas o conductas adicionales por hallazgos intraoperatorios.",
            ],
        },
        "cifoplastia_vertebroplastia": {
            "title": "CONSENTIMIENTO INFORMADO PARA CIFOPLASTIA / VERTEBROPLASTIA",
            "diagnosis": f"fractura o aplastamiento vertebral doloroso en {level}",
            "procedure": f"cifoplastia o vertebroplastia percutánea en {level}",
            "bullets": [
                "que el objetivo es estabilizar la vértebra comprometida y disminuir el dolor vinculado a la fractura;",
                "que el alivio puede ser parcial o transitorio y que no se garantiza un resultado exacto;",
                "que existen alternativas terapéuticas razonables, incluyendo tratamiento médico, analgesia, ortesis, rehabilitación, observación, otras técnicas quirúrgicas y la posibilidad de no operarme, con sus riesgos y beneficios;",
                "que, si no realizo el tratamiento indicado, pueden persistir o agravarse el dolor, el colapso vertebral, la deformidad, la limitación funcional y el riesgo de progresión de la lesión;",
                "que los riesgos incluyen fuga de cemento, embolia, lesión neurológica, infección, sangrado, hematoma, fracturas adyacentes, dolor persistente, necesidad de nueva cirugía y complicaciones anestésicas;",
                "que durante el procedimiento pueden requerirse modificaciones técnicas o toma de muestra si los hallazgos intraoperatorios lo indican.",
            ],
        },
        "biopsia_vertebral_mas_cifoplastia_vertebroplastia": {
            "title": "CONSENTIMIENTO INFORMADO PARA BIOPSIA VERTEBRAL Y CEMENTACIÓN",
            "diagnosis": f"lesión vertebral o fractura patológica en {level}",
            "procedure": f"biopsia vertebral percutánea asociada a cifoplastia o vertebroplastia en {level}",
            "bullets": [
                "que la biopsia busca obtener material para diagnóstico anatomopatológico o microbiológico y la cementación procura estabilizar la vértebra y disminuir el dolor;",
                "que el diagnóstico o alivio puede ser parcial y que no se garantiza un resultado exacto;",
                "que existen alternativas terapéuticas razonables, incluyendo tratamiento médico, inmovilización, tratamiento oncológico o infectológico, observación, otras técnicas quirúrgicas y la posibilidad de no operarme, con sus riesgos y beneficios;",
                "que, si no realizo el tratamiento indicado, puede persistir la incertidumbre diagnóstica, el dolor, el colapso vertebral, la deformidad o la progresión de la lesión;",
                "que los riesgos incluyen muestra no diagnóstica, sangrado, infección, fuga de cemento, lesión neurológica, embolia, dolor persistente, necesidad de nueva cirugía y complicaciones anestésicas;",
                "que durante el procedimiento pueden requerirse modificaciones técnicas por hallazgos intraoperatorios.",
            ],
        },
        "descompresion_dorsal_parcial_biopsia_y_fijacion": {
            "title": "CONSENTIMIENTO INFORMADO PARA DESCOMPRESIÓN DORSAL, BIOPSIA Y FIJACIÓN",
            "diagnosis": f"patología dorsal compresiva o infecciosa en {level}",
            "procedure": f"descompresión dorsal, toma de muestra, biopsia y fijación instrumentada en {level}",
            "bullets": [
                "que el objetivo es descomprimir estructuras neurales, obtener muestras diagnósticas y estabilizar el segmento comprometido;",
                "que la mejoría puede ser parcial y que no se garantiza un resultado exacto;",
                "que existen alternativas terapéuticas razonables, incluyendo tratamiento médico o infectológico, inmovilización, observación, drenaje o técnicas quirúrgicas alternativas y la posibilidad de no operarme, con sus riesgos y beneficios;",
                "que, si no realizo el tratamiento indicado, pueden persistir o agravarse el dolor, la infección, la inestabilidad, la compresión neural y el deterioro neurológico;",
                "que los riesgos incluyen lesión neurológica, lesión dural o fístula de LCR, sangrado, infección persistente, falla de implantes, dolor residual, necesidad de nueva cirugía y complicaciones anestésicas;",
                "que durante el procedimiento pueden requerirse modificaciones técnicas por hallazgos intraoperatorios.",
            ],
        },
        "espondilodiscitis_dorsal_higa_junin": {
            "title": "CONSENTIMIENTO INFORMADO PARA ESPONDILODISCITIS DORSAL",
            "diagnosis": f"espondilodiscitis dorsal en {level}",
            "procedure": f"descompresión, toma de muestra, desbridamiento y estabilización dorsal en {level}",
            "bullets": [
                "que el objetivo es tratar el compromiso infeccioso, obtener muestras, descomprimir estructuras neurales y estabilizar el segmento comprometido;",
                "que la mejoría puede ser parcial y que no se garantiza un resultado exacto;",
                "que existen alternativas terapéuticas razonables, incluyendo tratamiento antibiótico, inmovilización, drenaje, observación, otras técnicas quirúrgicas y la posibilidad de no operarme, con sus riesgos y beneficios;",
                "que, si no realizo el tratamiento indicado, pueden persistir o agravarse el dolor, la infección, la inestabilidad, la deformidad, la compresión neural y el deterioro neurológico;",
                "que los riesgos incluyen lesión neurológica, lesión dural o fístula de LCR, sangrado, infección persistente, falla de implantes, pseudoartrosis, dolor residual, necesidad de nueva cirugía y complicaciones anestésicas;",
                "que durante el procedimiento pueden requerirse modificaciones técnicas por hallazgos intraoperatorios.",
            ],
        },
        "exeresis_quiste_facetario_lumbar_sin_fijacion": {
            "title": "CONSENTIMIENTO INFORMADO PARA EXÉRESIS DE QUISTE FACETARIO LUMBAR",
            "diagnosis": f"quiste facetario lumbar sintomático en {level}",
            "procedure": f"descompresión lumbar y exéresis de quiste facetario en {level}",
            "bullets": [
                "que el objetivo es descomprimir la raíz comprometida y resecar el quiste facetario responsable de los síntomas;",
                "que la mejoría puede ser parcial y que no se garantiza un resultado exacto;",
                "que existen alternativas terapéuticas razonables, incluyendo tratamiento médico, analgesia, rehabilitación, infiltraciones, observación, fijación instrumentada u otras técnicas quirúrgicas y la posibilidad de no operarme, con sus riesgos y beneficios;",
                "que, si no realizo el tratamiento indicado, pueden persistir o agravarse el dolor radicular, la limitación funcional, el déficit neurológico y la compresión neural;",
                "que los riesgos incluyen lesión radicular, lesión dural o fístula de LCR, inestabilidad, recidiva del quiste, infección, sangrado, dolor persistente, necesidad de nueva cirugía y complicaciones anestésicas;",
                "que durante el procedimiento pueden requerirse modificaciones técnicas por hallazgos intraoperatorios.",
            ],
        },
        "hidrocefalia_derivaciones": {
            "title": "CONSENTIMIENTO INFORMADO PARA DERIVACIÓN DE HIDROCEFALIA",
            "diagnosis": f"hidrocefalia sintomática con indicación de derivación en trayecto {level}",
            "procedure": f"colocación de válvula de derivación de líquido cefalorraquídeo en trayecto {level}",
            "bullets": [
                "que el objetivo es drenar líquido cefalorraquídeo, controlar la hidrocefalia y reducir el riesgo de deterioro neurológico;",
                "que la mejoría puede ser parcial y que no se garantiza un resultado exacto;",
                "que existen alternativas terapéuticas razonables, incluyendo observación, tratamiento médico, ventriculostomía endoscópica, otras derivaciones y la posibilidad de no operarme, con sus riesgos y beneficios;",
                "que, si no realizo el tratamiento indicado, pueden persistir o agravarse la cefalea, el deterioro cognitivo, el trastorno de la marcha, la hipertensión intracraneana y el compromiso neurológico;",
                "que los riesgos incluyen infección, obstrucción o disfunción valvular, sobredrenaje o subdrenaje, sangrado, hematoma, lesión neurológica, lesión abdominal, necesidad de recambio o nueva cirugía y complicaciones anestésicas;",
                "que durante el procedimiento pueden requerirse modificaciones técnicas por hallazgos intraoperatorios.",
            ],
        },
        "chiari": {
            "title": "CONSENTIMIENTO INFORMADO PARA CIRUGÍA DE MALFORMACIÓN DE CHIARI",
            "diagnosis": f"malformación de Chiari con compromiso cráneo-cervical en {level}",
            "procedure": f"descompresión de fosa posterior y unión cráneo-cervical en {level}",
            "bullets": [
                "que el objetivo es descomprimir la unión cráneo-cervical, mejorar la circulación de líquido cefalorraquídeo y reducir el riesgo de progresión neurológica;",
                "que la mejoría puede ser parcial y que no se garantiza un resultado exacto;",
                "que existen alternativas terapéuticas razonables, incluyendo observación, tratamiento médico sintomático, rehabilitación, otros procedimientos y la posibilidad de no operarme, con sus riesgos y beneficios;",
                "que, si no realizo el tratamiento indicado, pueden persistir o agravarse la cefalea, los trastornos sensitivos, el compromiso de la médula, la siringomielia y las alteraciones funcionales asociadas;",
                "que los riesgos incluyen lesión neurológica, fístula de LCR, pseudomeningocele, infección, sangrado, inestabilidad cráneo-cervical, dolor persistente, necesidad de nueva cirugía y complicaciones anestésicas;",
                "que durante el procedimiento pueden requerirse modificaciones técnicas por hallazgos intraoperatorios.",
            ],
        },
    }
    return overrides.get(slug)


class BlockParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.blocks = []
        self.current = []
        self.current_tag = None
        self.list_stack = []

    def handle_starttag(self, tag, attrs):
        if tag in {"p", "h1", "h2", "h3", "li"}:
            self.current = []
            self.current_tag = tag
        if tag in {"strong", "b"}:
            self.current.append("**")

    def handle_endtag(self, tag):
        if tag in {"strong", "b"}:
            self.current.append("**")
        if tag in {"p", "h1", "h2", "h3", "li"}:
            text = re.sub(r"\s+", " ", "".join(self.current)).strip()
            if text:
                self.blocks.append({"tag": tag, "text": text})
            self.current = []
            self.current_tag = None

    def handle_data(self, data):
        if self.current_tag:
            self.current.append(data)


def load_pack():
    with PACK_PATH.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def fill(label):
    return f"[{label}]"


DOTTED_LINE = "........................................"


def is_default_team(value):
    cleaned = re.sub(r"\s+", " ", str(value or "").strip().lower())
    return cleaned in {
        "dr. zanardi y equipo",
        "dr zanardi y equipo",
        "dr. carlos zanardi y equipo",
        "dr carlos zanardi y equipo",
        "carlos zanardi y equipo",
    }


def authorization_sentence(args, procedure):
    surgeon = escape_html(args.surgeon)
    procedure = escape_html(procedure)
    if is_default_team(args.team):
        return (
            f"Autorizo al Dr. <strong>{surgeon}</strong> y equipo a realizar "
            f"<strong>{procedure}</strong>, pudiendo ampliarse, modificarse o complementarse "
            "el procedimiento si el criterio médico lo indicara."
        )
    team = escape_html(args.team)
    return (
        f"Autorizo a los Dres. <strong>{surgeon}</strong> y <strong>{team}</strong> a realizar "
        f"<strong>{procedure}</strong>, pudiendo ampliarse, modificarse o complementarse "
        "el procedimiento si el criterio médico lo indicara."
    )


def hydrate_html(html, args):
    values = {
        "paciente": args.patient,
        "Nombre y apellido del paciente": args.patient,
        "nombre y apellido": args.patient,
        "fecha": args.date,
        "dni": args.dni,
        "DNI": args.dni,
        "institucion": args.institution_label,
        "nivel": args.level,
        "nivel/es": args.level,
        "nivel/es y lado si aplica": args.level,
        "nivel/es y lado": args.level,
        "nivel y lateralidad": args.level,
        "nivel y lado": args.level,
        "Completar": fill("completar"),
        "equipo/segundo cirujano si corresponde": args.team,
        "equipo/segundo cirujano": args.team,
        "general / otra": "general",
    }
    text = html
    text = re.sub(r"(Lugar y fecha:</strong>\s*)\[Completar\]", rf"\g<1>{args.date}", text, flags=re.I)
    text = re.sub(r"(DNI\s*(?:<strong>)?)\[Completar\]((?:</strong>)?)", rf"\g<1>{args.dni}\g<2>", text, flags=re.I)
    text = re.sub(r"(nivel(?:es)?\s*(?:<strong>)?)\[Completar\]((?:</strong>)?)", rf"\g<1>{args.level}\g<2>", text, flags=re.I)
    text = re.sub(r"(anestesia\s*(?:prevista\s*)?(?:será\s*)?(?:<strong>)?)\[Completar\]((?:</strong>)?)", rf"\g<1>general\g<2>", text, flags=re.I)
    text = re.sub(r"\[congénito/degenerativo/multisegmentario\]", "degenerativo", text, flags=re.I)
    text = re.sub(r"\by/o\b", "o", text, flags=re.I)
    text = re.sub(r"\s*,?\s*\bsi correspond(?:e|en|iera|iese)\b", "", text, flags=re.I)
    text = re.sub(r"\s*,?\s*\bcuando correspond(?:a|ía|ia)\b", "", text, flags=re.I)
    text = re.sub(r"\s*,?\s*\bsegún corresponda\b", "", text, flags=re.I)
    text = re.sub(r"\s*,?\s*\bsi aplica\b", "", text, flags=re.I)
    text = re.sub(r"\s*,?\s*\beventual(?:mente)?\b", "", text, flags=re.I)
    if getattr(args, "surgeon_license", None):
        text = re.sub(
            r"(Matr[ií]cula:\s*</strong>\s*)(?:_{3,}|\[Completar\])",
            rf"\g<1>{args.surgeon_license}",
            text,
            flags=re.I,
        )
        text = re.sub(
            r"(Matr[ií]cula:\s*)(?:_{3,}|\[Completar\])",
            rf"\g<1>{args.surgeon_license}",
            text,
            flags=re.I,
        )
    text = re.sub(r"\s+([,.])", r"\1", text)
    for key, value in values.items():
        text = text.replace(f"[{key}]", value)
        text = text.replace(f"{{{{{key}}}}}", value)
    return text


def blocks_from_html(html):
    parser = BlockParser()
    parser.feed(html)
    return parser.blocks


def strip_marks(text):
    return text.replace("**", "")


def escape_html(text):
    return (
        str(text or "")
        .replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
    )


def is_title_block(tag, text):
    letters = re.sub(r"[^A-ZÁÉÍÓÚÜÑ]", "", text)
    return tag in {"h1", "h2", "h3"} or (text.isupper() and len(letters) > 18)


def first_match(pattern, text, default=""):
    match = re.search(pattern, text, flags=re.I | re.S)
    return re.sub(r"\s+", " ", match.group(1)).strip(" .,:;") if match else default


def proforma_html_from_blocks(entry, html, blocks, args):
    plain_blocks = [{"tag": block["tag"], "text": strip_marks(block["text"])} for block in blocks]
    title = plain_blocks[0]["text"] if plain_blocks else entry.get("title", "CONSENTIMIENTO INFORMADO")
    paragraph_text = "\n".join(block["text"] for block in plain_blocks if block["tag"] != "li")
    diagnosis = first_match(
        r"con diagn[oó]stico de\s+(.+?)(?:,\s*(?:dejo|declaro)|\s*,\s*se me|\.)",
        paragraph_text,
        entry.get("title", "patología neuroquirúrgica con indicación quirúrgica"),
    )
    procedure = first_match(
        r"a realizar(?:\s+un procedimiento de|\s+una|\s+un)?\s+(.+?)(?:,\s*pudiendo|\s+en el nivel|\.)",
        paragraph_text,
        args.procedure or "procedimiento neuroquirúrgico indicado",
    )
    if args.diagnosis:
        diagnosis = args.diagnosis
    if args.procedure:
        procedure = args.procedure
    bullets = [block["text"] for block in plain_blocks if block["tag"] == "li"]
    override = canonical_content_override(entry.get("slug"), args)
    if override:
        title = override["title"]
        diagnosis = args.diagnosis or override["diagnosis"]
        procedure = args.procedure or override["procedure"]
        bullets = override["bullets"]
    if not bullets:
        bullets = [
            "que el objetivo es tratar la causa anatómica o funcional del cuadro, procurando alivio sintomático, descompresión, estabilización, diagnóstico o control de la lesión vinculada al diagnóstico;",
            "que la mejoría puede ser parcial y que no se garantiza un resultado exacto;",
            "que existen alternativas terapéuticas razonables, incluyendo tratamiento médico, rehabilitación, observación, otras técnicas quirúrgicas y la posibilidad de no operarme, con sus riesgos y beneficios;",
            "que, si no realizo el tratamiento indicado, pueden persistir o agravarse los síntomas, la limitación funcional y el compromiso neurológico propio del diagnóstico;",
            "que entre los riesgos y complicaciones se incluyen infección, hematoma, sangrado, lesión neurológica, dolor persistente, necesidad de nueva cirugía y complicaciones anestésicas;",
            "que durante la cirugía pueden surgir hallazgos que obliguen a ajustar la técnica según criterio médico.",
        ]
    diagnosis = re.sub(r"\[[^\]]+\]", args.level, diagnosis)
    procedure = re.sub(r"\[[^\]]+\]", args.level, procedure)
    procedure = procedure.replace("nivel/es", args.level).replace("nivel", args.level)
    bullets = bullets[:7]
    title = escape_html(title)
    diagnosis = escape_html(diagnosis)
    procedure = escape_html(procedure)
    patient = escape_html(args.patient)
    dni = escape_html(args.dni)
    date = escape_html(args.date)
    surgeon = escape_html(args.surgeon)
    surgeon_license = escape_html(args.surgeon_license)
    bullet_html = "".join(f"<li>{escape_html(item)}</li>" for item in bullets)
    authorization = authorization_sentence(args, procedure)
    return f"""
<p><strong>{title}</strong></p>
<p><strong>Lugar y fecha:</strong> Junín, {date}</p>
<p>Yo, <strong>{patient}</strong>, DNI <strong>{dni}</strong>, con diagnóstico de <strong>{diagnosis}</strong>, dejo constancia de haber recibido información clara, suficiente y comprensible sobre la enfermedad, las alternativas terapéuticas y la cirugía propuesta.</p>
<p>{authorization}</p>
<p><strong>Se me informó especialmente:</strong></p>
<ul>{bullet_html}</ul>
<p>Autorizo transfusión de sangre o hemoderivados si fuera necesario.</p>
<p>Se me informó que en el procedimiento intervendrá un médico anestesiólogo y que se utilizará anestesia general, con sus riesgos inherentes.</p>
<p>Declaro haber podido realizar preguntas, haber recibido respuestas comprensibles y saber que puedo solicitar segunda opinión, aceptar, rechazar o revocar el consentimiento antes del procedimiento.</p>
<p>Declaro comprender que la medicina y la cirugía no constituyen una ciencia exacta y que no se me ha garantizado un resultado determinado.</p>
<p>Me comprometo a cumplir el seguimiento y las indicaciones postoperatorias.</p>
<p>Autorizo el uso de la documentación clínica y del registro del procedimiento con fines asistenciales y académicos, preservando mi identidad. Este consentimiento se incorporará a mi historia clínica y se me informó que puedo solicitar copia o acceso conforme normativa vigente.</p>
<p>Habiendo leído y comprendido este documento, presto conformidad para la cirugía propuesta.</p>
<p><strong>Firma del paciente/representante:</strong> ____________________</p>
<p><strong>Aclaración:</strong> ____________________</p>
<p><strong>DNI / vínculo con el paciente:</strong> ____________________</p>
<p><strong>Firma del médico:</strong> ____________________</p>
<p><strong>Aclaración y sello:</strong> Dr. {surgeon}</p>
<p><strong>Matrícula:</strong> {surgeon_license}</p>
"""


def logo_path(pack, institution_key):
    item = pack.get("institutions", {}).get(institution_key, {})
    logo = item.get("logo") or item.get("approved_visual_logo")
    return Path(logo) if logo else None


def institution_label(pack, institution_key):
    return pack.get("institutions", {}).get(institution_key, {}).get("label", institution_key)


def prepared_logo_for_pdf(logo):
    if not logo or not logo.exists():
        return None
    try:
        from PIL import Image as PILImage
    except Exception:
        return logo

    image = PILImage.open(logo).convert("RGBA")
    pixels = image.load()
    width, height = image.size
    foreground = []
    for y in range(height):
        for x in range(width):
            r, g, b, a = pixels[x, y]
            if a and min(r, g, b) < 242:
                foreground.append((x, y))
            elif a and min(r, g, b) >= 242:
                pixels[x, y] = (255, 255, 255, 0)
    if foreground:
        xs = [xy[0] for xy in foreground]
        ys = [xy[1] for xy in foreground]
        pad = 5
        box = (
            max(min(xs) - pad, 0),
            max(min(ys) - pad, 0),
            min(max(xs) + pad + 1, width),
            min(max(ys) + pad + 1, height),
        )
        image = image.crop(box)
    temp = tempfile.NamedTemporaryFile(prefix="clinica_logo_", suffix=".png", delete=False)
    temp.close()
    image.save(temp.name)
    return Path(temp.name)


def logo_image_for_pdf(logo, max_width, max_height, h_align="CENTER"):
    if not logo or not logo.exists():
        return None
    try:
        from PIL import Image as PILImage

        with PILImage.open(logo) as image:
            width, height = image.size
        if width <= 0 or height <= 0:
            raise ValueError("invalid logo size")
        scale = min(max_width / width, max_height / height)
        image_width = width * scale
        image_height = height * scale
        logo_image = Image(str(logo), width=image_width, height=image_height, mask="auto")
    except Exception:
        logo_image = Image(
            str(logo),
            width=max_width,
            height=max_height,
            kind="proportional",
            mask="auto",
        )
    logo_image.hAlign = h_align
    return logo_image


def is_signature_line(text):
    normalized = strip_marks(text).strip().lower()
    return normalized.startswith((
        "firma del paciente:",
        "firma del paciente/representante:",
        "firma del paciente o representante:",
        "aclaración:",
        "aclaracion:",
        "dni:",
        "dni / vínculo",
        "dni / vinculo",
        "firma del médico:",
        "firma del medico:",
        "aclaración y sello:",
        "aclaracion y sello:",
        "matrícula:",
        "matricula:",
    ))


def signature_table(signature_texts, body_style, width):
    patient_lines = []
    doctor_lines = []
    target = patient_lines
    for item in signature_texts:
        text = strip_marks(item).strip()
        lower = text.lower()
        if lower.startswith((
            "firma del médico:",
            "firma del medico:",
            "aclaración y sello:",
            "aclaracion y sello:",
            "matrícula:",
            "matricula:",
        )):
            target = doctor_lines
        target.append(escape_html(text))

    def cell(lines):
        return [Paragraph("<br/>".join(lines), body_style)]

    table = Table(
        [[cell(patient_lines), cell(doctor_lines)]],
        colWidths=[width * 0.49, width * 0.49],
        hAlign="CENTER",
    )
    table.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("LEFTPADDING", (0, 0), (-1, -1), 0),
        ("RIGHTPADDING", (0, 0), (-1, -1), 0),
        ("TOPPADDING", (0, 0), (-1, -1), 0),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 0),
    ]))
    return table


def build_docx(blocks, output_path, logo, institution):
    doc = Document()
    section = doc.sections[0]
    section.top_margin = Inches(0.65)
    section.bottom_margin = Inches(0.65)
    section.left_margin = Inches(0.75)
    section.right_margin = Inches(0.75)
    styles = doc.styles
    styles["Normal"].font.name = "Arial"
    styles["Normal"].font.size = Pt(10)

    header = doc.add_paragraph()
    header.alignment = WD_ALIGN_PARAGRAPH.CENTER
    if logo and logo.exists():
      run = header.add_run()
      run.add_picture(str(logo), width=Inches(1.6))
    else:
      inst = doc.add_paragraph(institution)
      inst.alignment = WD_ALIGN_PARAGRAPH.CENTER

    for block in blocks:
        tag = block["tag"]
        text = strip_marks(block["text"])
        if is_title_block(tag, text):
            para = doc.add_paragraph()
            para.alignment = WD_ALIGN_PARAGRAPH.CENTER
            run = para.add_run(text)
            run.bold = True
            run.font.size = Pt(12)
        elif tag == "li":
            para = doc.add_paragraph(style="List Bullet")
            para.add_run(text)
        else:
            para = doc.add_paragraph()
            para.paragraph_format.space_after = Pt(5)
            para.add_run(text)
    doc.save(output_path)


def build_pdf(blocks, output_path, logo, institution, compact=False):
    styles = getSampleStyleSheet()
    font_size = 9.3 if compact else 10.0
    leading = 10.8 if compact else 13.0
    space_after = 4.8 if compact else 6.4
    title_size = 11.8 if compact else 12.8
    margin_x = 1.05 * cm if compact else 1.8 * cm
    margin_y = 0.75 * cm if compact else 1.4 * cm
    body = ParagraphStyle(
        "ConsentBody",
        parent=styles["BodyText"],
        fontName="Helvetica",
        fontSize=font_size,
        leading=leading,
        spaceAfter=space_after,
        alignment=TA_JUSTIFY,
    )
    title = ParagraphStyle(
        "ConsentTitle",
        parent=styles["Heading2"],
        fontName="Helvetica-Bold",
        fontSize=title_size,
        leading=title_size + 2,
        alignment=TA_CENTER,
        spaceAfter=6 if compact else 10,
    )
    bullet = ParagraphStyle(
        "ConsentBullet",
        parent=body,
        leftIndent=15,
        firstLineIndent=-9,
        alignment=TA_JUSTIFY,
    )
    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        leftMargin=margin_x,
        rightMargin=margin_x,
        topMargin=margin_y,
        bottomMargin=margin_y,
    )
    story = []
    prepared_logo = prepared_logo_for_pdf(logo)
    if prepared_logo and prepared_logo.exists():
        logo_image = logo_image_for_pdf(
            prepared_logo,
            max_width=7.2 * cm if compact else 8.2 * cm,
            max_height=1.72 * cm if compact else 1.95 * cm,
            h_align="CENTER",
        )
        if logo_image:
            story.append(logo_image)
        story.append(Spacer(1, 5 if compact else 7))
    else:
        story.append(Paragraph(institution, title))
    signature_texts = []
    for block in blocks:
        text = strip_marks(block["text"])
        if is_signature_line(text):
            signature_texts.append(text)
            continue
        escaped = (
            text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
        )
        if is_title_block(block["tag"], text):
            story.append(Paragraph(escaped, title))
        elif block["tag"] == "li":
            story.append(Paragraph(f"- {escaped}", bullet))
        else:
            story.append(Paragraph(escaped, body))
    if signature_texts:
        story.append(Spacer(1, 8 if compact else 12))
        story.append(signature_table(signature_texts, body, doc.width))
    try:
        doc.build(story)
    finally:
        if prepared_logo and prepared_logo != logo:
            try:
                prepared_logo.unlink()
            except OSError:
                pass


def pdf_page_count(output_path):
    try:
        from pypdf import PdfReader
        return len(PdfReader(str(output_path)).pages)
    except Exception:
        data = Path(output_path).read_bytes()
        return len(re.findall(rb"/Type\s*/Page\b", data))


def write_html(html, output_path, logo, institution):
    logo_tag = f'<img src="{logo}" alt="logo" style="max-height:72px;max-width:220px;">' if logo and logo.exists() else ""
    institution_tag = "" if logo_tag else f"<div><strong>{institution}</strong></div>"
    page = f"""<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <title>Consentimiento informado</title>
  <style>
    body {{ font-family: Arial, sans-serif; color:#111827; line-height:1.42; max-width:760px; margin:32px auto; }}
    header {{ text-align:center; border-bottom:1px solid #d1d5db; padding-bottom:14px; margin-bottom:20px; }}
    p {{ margin:0 0 10px; }}
    li {{ margin-bottom:6px; }}
  </style>
</head>
<body>
  <header>{logo_tag}{institution_tag}</header>
  <main>{html}</main>
</body>
</html>
"""
    output_path.write_text(page, encoding="utf-8")


def main():
    parser = argparse.ArgumentParser(description="Exporta consentimiento canónico con logo institucional.")
    parser.add_argument("--slug", required=True)
    parser.add_argument("--institution", default="clinica_centro", choices=["clinica_centro", "higa_junin", "la_pequena_familia"])
    parser.add_argument("--patient", default=DOTTED_LINE)
    parser.add_argument("--dni", default=DOTTED_LINE)
    parser.add_argument("--date", default="[fecha]")
    parser.add_argument("--level", default="[nivel/lateralidad]")
    parser.add_argument("--team", default="Dr. Zanardi y equipo")
    parser.add_argument("--surgeon", default="Carlos Zanardi")
    parser.add_argument("--surgeon-license", default=DEFAULT_SURGEON_LICENSE)
    parser.add_argument("--diagnosis")
    parser.add_argument("--procedure")
    parser.add_argument("--proforma", choices=["source", "hernia"], default="hernia")
    parser.add_argument("--one-page", action="store_true")
    parser.add_argument("--format", choices=["html", "docx", "pdf"], default="docx")
    parser.add_argument("--output")
    args = parser.parse_args()

    pack = load_pack()
    entry = pack["by_slug"].get(args.slug)
    if not entry:
        override = canonical_content_override(args.slug, args)
        if not override:
            raise SystemExit(f"Slug no encontrado: {args.slug}")
        entry = {
            "slug": args.slug,
            "title": override["title"],
            "body_html": f"<p><strong>{override['title']}</strong></p>",
        }

    args.institution_label = institution_label(pack, args.institution)
    html = hydrate_html(entry["body_html"], args)
    source_blocks = blocks_from_html(html)
    if args.proforma == "hernia":
        html = hydrate_html(proforma_html_from_blocks(entry, html, source_blocks, args), args)
    blocks = blocks_from_html(html)
    logo = logo_path(pack, args.institution)
    OUT_DIR.mkdir(parents=True, exist_ok=True)
    output_path = Path(args.output) if args.output else OUT_DIR / f"{args.slug}_{args.institution}.{args.format}"

    if args.format == "html":
        write_html(html, output_path, logo, args.institution_label)
    elif args.format == "docx":
        build_docx(blocks, output_path, logo, args.institution_label)
    else:
        build_pdf(blocks, output_path, logo, args.institution_label, compact=args.one_page)
        if args.one_page:
            pages = pdf_page_count(output_path)
            if pages != 1:
                raise SystemExit(f"PDF no cumple una carilla: {pages} paginas ({output_path})")
    print(output_path)


if __name__ == "__main__":
    main()
