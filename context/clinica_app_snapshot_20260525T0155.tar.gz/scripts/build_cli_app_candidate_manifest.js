const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const root = path.resolve(__dirname, '..');
const workspace = path.resolve(root, '..', '..');

const files = [
  'app/product.html',
  'app/index.html',
  'app/app.js',
  'data/derived/template_mothers/template_mother_registry_2026-05-19.json',
  'data/derived/consent_mothers/consent_mother_registry_2026-05-19.json',
  'data/derived/consent_canonicals/consent_canonical_index_2026-05-19.json',
  'data/derived/consent_canonicals/consent_body_pack_2026-05-19.json',
  'data/derived/consent_source_corpus/neurocirugia_consent_source_corpus_latest.json',
  'data/derived/medicolegal_tamiz/medicolegal_tamiz_pack_2026-05-19.json',
  'data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_corpus_latest.json',
  'data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_impact_matrix_latest.md',
  'data/derived/pathology_templates/pathology_template_bank_2026-05-20.json',
  'data/derived/pathology_templates/pathology_template_style_guide_2026-05-20.md',
  'data/derived/medicolegal_updates/update_watchlist_2026-05-19.json',
  'scripts/ingest/build_consent_mothers_from_neurocirugia.js',
  'scripts/ingest/build_neurocirugia_consent_source_corpus.js',
  'scripts/ingest/build_pathology_template_bank_from_neurocirugia.js',
  'scripts/consents/build_consent_body_pack.js',
  'scripts/serve_review_only_mvp.js',
  'scripts/abrir_app_clinica_pc.sh',
  'scripts/launchd/ai.clinica.app-local.plist',
  'scripts/legal_corpus/build_neuro_spine_jurisprudence_corpus.js',
  'scripts/legal_corpus/build_medicolegal_tamiz_pack.js',
  'scripts/legal_corpus/run_detect_only_update_cycle.js',
  'scripts/exports/export_consent_artifact.py',
  'scripts/jarvis/consent_telegram_handoff.js',
  'scripts/jarvis/clinical_document_handoff.js',
  'scripts/qa/run_clinica_core_qa.js',
  'scripts/qa/validate_consent_handoff.js',
  'scripts/qa/validate_product_mode.js',
  'scripts/qa/validate_medicolegal_redaction_shield.js',
  'scripts/qa/validate_clinical_handoff.js',
  'scripts/qa/validate_clinical_send_gate.js',
  'scripts/qa/validate_latest_artifacts_freshness.js',
  'scripts/qa/validate_pathology_template_bank.js',
  'scripts/qa/validate_neuro_spine_jurisprudence_corpus.js',
  'scripts/qa/validate_neurocirugia_consent_source_corpus.js',
  'scripts/qa/visual_product_cdp_check.js',
  'docs/corpus_medicolegal_argentino.md',
  'docs/fuentes_actualizacion_medicolegal.md',
  'docs/cola_revision_jurisprudencial_medicolegal.md',
  'docs/contrato_blindaje_redaccion_medicolegal_2026-05-24.md',
  'docs/radar_fuentes_normativas_jurisprudencia_neuro_columna_5_3_2026-05-24.md',
  'qa/approval_gates/consent_mother_registry_2026-05-19_summary.json',
  'qa/approval_gates/neurocirugia_consent_source_corpus_2026-05-20.json',
  'qa/approval_gates/neurocirugia_consent_source_corpus_validation_2026-05-20.json',
  'qa/approval_gates/cli_app_product_mode_validation_2026-05-19.json',
  'qa/approval_gates/neuro_spine_jurisprudence_corpus_2026-05-20_summary.json',
  'qa/approval_gates/neuro_spine_jurisprudence_validation_2026-05-20.json',
  'qa/approval_gates/cli_app_product_visual_cdp_2026-05-19.json',
  'qa/approval_gates/medicolegal_detect_only_update_cycle_latest.json',
  'qa/approval_gates/medicolegal_detect_only_update_cycle_latest.md',
  'qa/approval_gates/latest_artifacts_freshness_2026-05-21.json',
  'qa/approval_gates/README.md',
  'exports/2026-05-19/mock_producto_final_l4l5_circunferencial_tamiz_medicolegal.html',
  'docs/PRODUCTO_OBJETIVO_2026-05-19.md'
];

function sha256(filePath) {
  return crypto.createHash('sha256').update(fs.readFileSync(filePath)).digest('hex');
}

function statIso(filePath) {
  return fs.statSync(filePath).mtime.toISOString();
}

const entries = files.map((relPath) => {
  const absPath = path.join(root, relPath);
  if (!fs.existsSync(absPath)) {
    throw new Error(`Missing required candidate file: ${absPath}`);
  }
  return {
    rel_path: relPath,
    abs_path: absPath,
    sha256: sha256(absPath),
    mtime: statIso(absPath),
    size_bytes: fs.statSync(absPath).size
  };
});

const output = {
  generated_at: new Date().toISOString(),
  candidate: 'CLI-APP-001-MEDICOLEGAL-HC-PARTES-20260517',
  status: 'local_candidate_ready_for_user_test',
  product_rule: 'Lista para prueba local. Los documentos generados requieren revision medica antes de uso asistencial real.',
  flow_claims: [
    'texto coloquial -> historia clinica base',
    'mismo input -> parte quirurgico base',
    'evolucion postoperatoria inmediata base',
    'faltantes criticos visibles',
    'tamiz medico-legal lateral detect-only',
    'hechos confirmados separados del borrador estandar',
    'historia clinica + parte quirurgico + consentimiento informado desde un relato breve'
  ],
  files: entries,
  workspace_root: workspace,
  app_root: root
};

const outDir = path.join(root, 'qa', 'approval_gates');
fs.mkdirSync(outDir, { recursive: true });
const generatedDate = output.generated_at.slice(0, 10);
const datedOutPath = path.join(outDir, `cli_app_candidate_manifest_${generatedDate}.json`);
const latestOutPath = path.join(outDir, 'cli_app_candidate_manifest_latest.json');
const payload = JSON.stringify(output, null, 2);
fs.writeFileSync(datedOutPath, payload);
fs.writeFileSync(latestOutPath, payload);
console.log(JSON.stringify({ dated: datedOutPath, latest: latestOutPath }, null, 2));
