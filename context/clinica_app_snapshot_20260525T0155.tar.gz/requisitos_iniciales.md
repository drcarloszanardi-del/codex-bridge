# Requisitos iniciales validados con el Dr. Zanardi

## Alcance inicial
- Uso personal del Dr. Zanardi.
- Asistente de redacción + almacenamiento local de pacientes.
- Foco inicial: neurocirugía y cirugía de columna.
- Integración prioritaria con Word.
- Posible integración futura con sistema sanatorial.
- Plantillas cerradas para reducir alucinaciones y omisiones.
- Almacenamiento de datos en la computadora local de Jarvis.
- La base legal no debe citarse dentro del texto final de historia clínica ni parte quirúrgico.
- Objetivo: redactar como lo haría el Dr. Zanardi, pero incorporando resguardos medicolegales y prevención de riesgo litigioso según normativa y jurisprudencia argentina.
- Debe existir un sistema de actualización periódica de leyes y jurisprudencia.
- Se acepta involucrar otro motor de IA si mejora robustez y auditoría.

## Restricciones explícitas
- No prometer blindaje legal absoluto.
- No usar redacción abierta sin estructura; preferir plantillas cerradas.
- No depender de memoria conversacional: el objetivo debe persistir en base durable.
- No exponer en el documento final la fundamentación jurídica interna.
