## Guardia nocturna — suite QA clínica medicolegal

- Fecha/hora local: 2026-05-20 02:41:26 -0300
- Fecha/hora UTC: 2026-05-20T054126Z
- Resultado general: **VERDE (0 fallas)**
- Envíos externos: **no** (solo validación de `send_command`/manifests)

### Comandos ejecutados
- `node scripts/qa/validate_jarvis_overnight_requests.js` ✅
  - Gate: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/jarvis_overnight_requests_2026-05-20.json`
- `node scripts/qa/validate_20_pathology_scenarios.js` ✅
  - Gate: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/clinical_20_pathology_scenarios_2026-05-20.json`
- `node scripts/qa/validate_jarvis_wrapper.js` ✅
  - Evidencia (exports): `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/` (PDFs generados en modo wrapper; sin envío)
- `node scripts/qa/validate_clinical_handoff.js` ✅
  - Evidencia (manifests): `/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/` (solo validación)
- `node scripts/qa/validate_consent_handoff.js` ✅
  - Evidencia (consent export): `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/` (1 página requerido OK; sin envío)
- `node scripts/qa/validate_neurocirugia_consent_source_corpus.js` ✅
  - Gate: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/neurocirugia_consent_source_corpus_validation_2026-05-20.json`
  - Corpus: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/neurocirugia_consent_source_corpus_2026-05-20.json`
- `node scripts/qa/validate_product_mode.js` ✅
  - Gate existente (último): `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/cli_app_product_mode_validation_2026-05-19.json`
- `node scripts/qa/validate_neuro_spine_jurisprudence_corpus.js` ✅
  - Gate: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/neuro_spine_jurisprudence_validation_2026-05-20.json`
  - Corpus latest: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_corpus_latest.json`
- `node scripts/qa/validate_pathology_template_bank.js` ✅
  - Gate: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/pathology_template_bank_validation_2026-05-20.json`
  - Bank: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/pathology_templates/pathology_template_bank_2026-05-20.json`

### Cambios realizados
- Código/plantillas/corpus: **sin cambios** (no se detectaron fallas)

