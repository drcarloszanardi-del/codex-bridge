# CLI-APP-001 Reconciliación Opus vs NEUROCIRUGIA

- estado: revisable_ready
- publication_activation_allowed: false
- zip_opus: `/Users/jarvis/.openclaw/media/inbound/medilegal-base-v7---dca2e052-81d0-4212-82ad-4bf852f1552e.zip`
- manifest_neuro: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/processed/doctor/cli_app_neuro_ingest_priority_2026_05_18.manifest.json`

## QA rápido
- opus_skill_present: ok
- mandatory_fields_present: ok
- forbidden_phrases_present: ok
- neuro_style_corpus_present: ok
- publication_activation_allowed_false: ok
- patient_identifiable_content_publication_block: ok

## Reglas candidatas
### R1_patient_data_minimum
- fuente: SKILL-generacion.md + parte-campos.md
- regla: No generar parte final sin nombre completo, diagnostico/patologia, fecha del acto y bloque de cirugia disponible; marcar faltantes en semaforo.
- cruce con corpus real: El corpus real contiene HC/epicrisis con fuerte presencia de identificacion, fechas de ingreso/egreso y diagnosticos principales/secundarios, por lo que el gate de faltantes es consistente.

### R2_spine_level_and_laterality
- fuente: frases-prohibidas.md + columna-lumbar.md
- regla: Exigir nivel y lateralidad especificos en hernia/listesis/canal estrecho. Prohibir diagnosticos genericos.
- cruce con corpus real: Archivos reales muestran variantes como "L4-5", "L5-S1", "izquierda", "derecha", "canal estrecho lumbar" y "extrusion discal".

### R3_radiologic_level_verification
- fuente: parte-campos.md + frases-prohibidas.md + estilo-zanardi-fijacion.md
- regla: En columna, mencionar verificacion radioscopica intraoperatoria del nivel como campo critico obligatorio.
- cruce con corpus real: Compatible con casos reales de fijacion/transpedicular/canal estrecho donde el nombre del archivo ya codifica nivel y tecnica.

### R4_complications_never_blank
- fuente: parte-campos.md + frases-prohibidas.md
- regla: Nunca dejar complicaciones vacio; usar formula expandida y no la version minima ambigua.
- cruce con corpus real: El corpus real hoy usa con frecuencia "COMPLICACIONES: No." y "Evolucion favorable", que requieren endurecimiento medico-legal.

### R5_implants_and_consumables_traceability
- fuente: parte-campos.md + estilo-zanardi-fijacion.md
- regla: Si hay implantes/hemostaticos/parches, registrar marca, lote, serie, cantidad e indicacion.
- cruce con corpus real: Especialmente alineado con fijaciones MISS, artrodesis y revisiones protésicas abundantes en el corpus local.

### R6_publication_guard
- fuente: PLAN_ACTIVO + guardrails locales
- regla: Mantener publication_activation_allowed=false y dejar todo en modo revisable, sin PDF ni publicacion automatica.
- cruce con corpus real: Es consistente con el estado actual de ingesta local y reconciliacion QA.

## Plantillas candidatas
### lumbar_fusion_miss
- base opus: estilo-zanardi-fijacion.md
- uso: listesis, inestabilidad degenerativa, fijacion circunferencial MISS
- evidencia real:
  - `EPICRISIS/COLUMNA/TRANSPEDICULAR L4-5 GRECO.docx`
  - `EPICRISIS/COLUMNA/TRANSPEDICULAR L4-5 Marchetto..docx`
  - `EPICRISIS/COLUMNA/TRANSPEDICULAR L4-5 Martin`
  - `EPICRISIS/COLUMNA/TRANSPEDICULAR L4-5-sS1 Obredor..docx`
  - `EPICRISIS/COLUMNA/TRANSPEDICULAR L5-S1.docx`
  - `NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Infecciones, desbridamientos y retiros/REMOCION DE IMPLANTE TRANSPEDICULAR Gonzalez.doc`
  - `EPICRISIS/COLUMNA/ESPONDILOLISTESIS L5-S1 COLETTA reoperacion.docx`
  - `EPICRISIS/COLUMNA/ESPONDILOLISTESIS L5-S1 COLETTA.docx`

### hdl_microdiscectomy
- base opus: columna-lumbar.md + estilo-zanardi-HDL.md
- uso: hernia de disco lumbar, microdiscectomia tubular, radiculopatia
- evidencia real:
  - `EPICRISIS/COLUMNA/Actis Juan Manuel HDL.doc`
  - `EPICRISIS/COLUMNA/Higueras HDL.docx`
  - `EPICRISIS/COLUMNA/Pacientes/Chalu Sergio HDL.doc`
  - `NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/TUBULAR/Martin Mendiburo HDL L3-4.doc`
  - `NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/TUBULAR/Rodriguez Vanesa. HDL.doc`
  - `EPICRISIS/COLUMNA/DISCO LUMBAR 2-3.docx`
  - `EPICRISIS/COLUMNA/DISCO LUMBAR L4-5 EXTRUIDO RUARO.docx`
  - `EPICRISIS/COLUMNA/DISCO LUMBAR L4-5 EXTRUIDO Vecchi.docx`

### laminoplasty_cervical
- base opus: estilo-zanardi-laminoplastia.md
- uso: canal estrecho cervical, mielopatia, laminoplastia expansiva
- evidencia real:
  - `EPICRISIS/COLUMNA/LAMINOPLASTIA CERVICAL ACERBO.docx`
  - `EPICRISIS/COLUMNA/LAMINOPLASTIA CERVICAL CALVET+.docx`
  - `EPICRISIS/COLUMNA/LAMINOPLASTIA CERVICAL ambrosetti.docx`
  - `EPICRISIS/COLUMNA/LAMINOPLASTIA CERVICAL contreras.docx`
  - `NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Laminoplastia/Acerbo C3-6 izquierda.doc`
  - `NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Laminoplastia/Alfaro Claudia laminoplastia.doc`

### revision_or_hardware_removal
- base opus: estilo-zanardi-revisiones.md
- uso: reoperaciones, retiro de implantes, discitis, pull-out, toilette
- evidencia real:
  - `EPICRISIS/COLUMNA/AMAYA CLAUDIA REVISION.docx`
  - `NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Canal estrecho/Farre Robero. Revision lumbar.doc`
  - `NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Infecciones, desbridamientos y retiros/Oberti revision.doc`
  - `NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Transpedicular/360/REVISION HUICHA 360 L5-S1.doc`
  - `NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Transpedicular/360/Revision. Sole L4-5.doc`
  - `NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Transpedicular/PULL-OUT CRISTINI REVISION.doc`

### special_cases_dural_tumor_fracture
- base opus: estilo-zanardi-especiales.md + columna-lumbar.md
- uso: lesion dural, tumor espinal, fractura, cifoplastia, complicaciones especiales
- evidencia real:
  - `EPICRISIS/COLUMNA/TUMOR ESPINAL.docx`
  - `EPICRISIS/COLUMNA/Tumor oseo S1.docx`
  - `EPICRISIS/COLUMNA/tumor intradural extramedular.docx`
  - `EPICRISIS/CRANEO/TUMOR Balcazza.docx`
  - `EPICRISIS/CRANEO/TUMOR CEREBRAL Echave.doc`
  - `EPICRISIS/CRANEO/TUMOR CEREBRAL OTERO.doc`
  - `EPICRISIS/COLUMNA/FRACTURA C2.docx`
  - `EPICRISIS/COLUMNA/FRACTURA L1. RIVERO CARLOS.docx`

## Alertas legales / de consistencia
- El corpus real de estilo contiene expresiones utiles clinicamente pero flojas medico-legalmente, por ejemplo "Evolucion: favorable" y "Complicaciones: No."; deben degradarse a alerta amarilla si pasan sin expansion.
- El ZIP Opus pide marca/lote/serie de implantes y hemostaticos, pero la muestra local visible no expone sistematicamente esa trazabilidad, asi que el motor debe abrir campos faltantes en lugar de inventarlos.
- Hay PHI en 3762/3762 archivos prioritarios; la reconciliacion debe usar solo nombres de archivos, patrones y extractos revisables, sin publicar contenido sensible.
- Existe una entrada extrana de empaquetado en el ZIP con llaves literales; debe ignorarse como ruido de origen y no importarse como conocimiento.
- La skill Opus asume consulta posterior a Codex Guard y aprobacion humana antes de PDF. Eso coincide con el guardrail actual y no debe relajarse.

## Memoria de estilo usable
- Servicio de Neurocirugia y Cirugia de Columna como encabezado recurrente en epicrisis.
- Diagnostico principal/secundario y tratamiento en formato breve, con fuerte orientacion posoperatoria.
- Alta frecuencia de columna lumbar y cervical, con subfamilias claras: HDL, canal estrecho, listesis, artrodesis, laminoplastia, fracturas, tumores.
- El corpus real sirve mejor como memoria de nomenclatura y agrupacion por tecnica/patologia que como plantilla medico-legal final lista para publicar.

### Muestras por familia
- listesis_examples:
  - `EPICRISIS/COLUMNA/ESPONDILOLISTESIS L5-S1 COLETTA reoperacion.docx`
  - `EPICRISIS/COLUMNA/ESPONDILOLISTESIS L5-S1 COLETTA.docx`
  - `EPICRISIS/COLUMNA/LISTESIS L4-5 Margiotta.docx`
  - `EPICRISIS/COLUMNA/Vercellino. Listesis L5-S1 grado 2.docx`
  - `EPICRISIS/COLUMNA/discopatia l4-5 y lisis con listesis l5-s1. Cejas alfredo.docx`
  - `EPICRISIS/COLUMNA/espondilolistesis.docx`
- transpedicular_examples:
  - `EPICRISIS/COLUMNA/TRANSPEDICULAR L4-5 GRECO.docx`
  - `EPICRISIS/COLUMNA/TRANSPEDICULAR L4-5 Marchetto..docx`
  - `EPICRISIS/COLUMNA/TRANSPEDICULAR L4-5 Martin`
  - `EPICRISIS/COLUMNA/TRANSPEDICULAR L4-5-sS1 Obredor..docx`
  - `EPICRISIS/COLUMNA/TRANSPEDICULAR L5-S1.docx`
  - `NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Infecciones, desbridamientos y retiros/REMOCION DE IMPLANTE TRANSPEDICULAR Gonzalez.doc`
- laminoplastia_examples:
  - `EPICRISIS/COLUMNA/LAMINOPLASTIA CERVICAL ACERBO.docx`
  - `EPICRISIS/COLUMNA/LAMINOPLASTIA CERVICAL CALVET+.docx`
  - `EPICRISIS/COLUMNA/LAMINOPLASTIA CERVICAL ambrosetti.docx`
  - `EPICRISIS/COLUMNA/LAMINOPLASTIA CERVICAL contreras.docx`
  - `NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Laminoplastia/Acerbo C3-6 izquierda.doc`
  - `NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/Laminoplastia/Alfaro Claudia laminoplastia.doc`
- hdl_examples:
  - `EPICRISIS/COLUMNA/Actis Juan Manuel HDL.doc`
  - `EPICRISIS/COLUMNA/Higueras HDL.docx`
  - `EPICRISIS/COLUMNA/Pacientes/Chalu Sergio HDL.doc`
  - `NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/TUBULAR/Martin Mendiburo HDL L3-4.doc`
  - `NEUROCIRUGIA DE QUIROFANO/Historia + Parte/Columna/TUBULAR/Rodriguez Vanesa. HDL.doc`

## Gaps antes de activar
- Trazabilidad de implantes/lotes/series no aparece garantizada por la muestra real visible.
- Las formulas reales de alta/epicrisis no bastan por si solas para parte quirurgico medico-legal cerrado.
- Se requiere siguiente capa de mapeo a JSON estructurado antes de cualquier activacion.

## Decisión
- El ZIP Opus y el corpus NEUROCIRUGIA ya pueden convivir como base revisable.
- La siguiente capa segura es mapear esto a JSON estructurado de generación, manteniendo semáforo, alertas y publication_activation_allowed=false.