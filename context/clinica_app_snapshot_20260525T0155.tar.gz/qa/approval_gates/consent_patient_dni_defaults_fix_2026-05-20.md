# Fix Consentimientos: paciente, DNI y equipo

Fecha: 2026-05-20.

## Problema

Jarvis podía generar o enviar consentimientos con datos de prueba como `Paciente QA`, `QA2` o `Ayudante QA` cuando el pedido real no traía paciente, DNI o equipo.

## Corrección

- Si no hay paciente real, el PDF imprime `........................................`.
- Si no hay DNI real, el PDF imprime `........................................`.
- Si no hay equipo real, el PDF imprime `Dr. Carlos Zanardi y equipo`.
- Valores de prueba (`Paciente QA`, `QA2`, `Paciente prueba`, `Paciente Wrapper`, `Ayudante QA`) se tratan como no reales antes de exportar.
- La regla quedó en la ruta única de Jarvis y en el contrato operativo.

## Validaciones

- `validate_consent_handoff.js`: OK. Incluye prueba específica sin paciente/DNI y anti-QA.
- `validate_jarvis_wrapper.js`: OK.
- `validate_product_mode.js`: OK.
- `validate_jarvis_overnight_requests.js`: OK, 24 pedidos, 0 fallas.
- `validate_20_pathology_scenarios.js`: OK, 20 casos, 56 documentos, 0 fallas.

