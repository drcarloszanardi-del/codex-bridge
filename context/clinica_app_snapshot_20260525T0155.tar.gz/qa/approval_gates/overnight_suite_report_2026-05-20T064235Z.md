# Overnight QA suite report — 2026-05-20T064235Z

## Preflight (CLI-001)
- Decision: `NO_SAFE_STEP` (reason: `lane_status_blocks_repeat`)
- Nota: suite QA ejecutada igual en modo local/read-only (sin envíos Telegram), para evidencia nocturna.

## Results (all green)
- `scripts/qa/validate_jarvis_overnight_requests.js`
  - ok: `true` | failures: `0` | out: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/jarvis_overnight_requests_2026-05-20.json`
- `scripts/qa/validate_20_pathology_scenarios.js`
  - ok: `true` | failures: `0` | out: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/clinical_20_pathology_scenarios_2026-05-20.json`
- `scripts/qa/validate_jarvis_wrapper.js`
  - ok: `true` | blocked_status: `BLOQUEADO_NO_ENVIAR`
  - pdfs:
    - `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/historia_clinica_lumbar_hdl_clinica_centro_paciente_wrapper_20260520T064145Z.pdf`
    - `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/consentimiento_hernia_disco_lumbar_clinica_centro_paciente_wrapper_20260520T064146Z.pdf`
- `scripts/qa/validate_clinical_handoff.js`
  - ok: `true` | blocked_status: `BLOQUEADO_NO_ENVIAR`
  - pdfs:
    - `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/historia_clinica_lumbar_hdl_clinica_centro_paciente_qa_20260520T064151Z.pdf`
    - `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/protocolo_quirurgico_lumbar_hdl_clinica_centro_paciente_qa_20260520T064151Z.pdf`
    - `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/consentimiento_hernia_disco_lumbar_clinica_centro_paciente_qa_20260520T064152Z.pdf`
  - manifests:
    - `/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/historia_clinica_lumbar_hdl_clinica_centro_paciente_qa_20260520T064151Z.json`
    - `/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/protocolo_quirurgico_lumbar_hdl_clinica_centro_paciente_qa_20260520T064151Z.json`
    - `/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/consentimiento_hernia_disco_lumbar_clinica_centro_paciente_qa_20260520T064152Z.json`
- `scripts/qa/validate_consent_handoff.js`
  - ok: `true`
  - manifest: `/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/consentimiento_canal_estrecho_lumbar_con_fijacion_clinica_centro_paciente_qa_centro_20260520T064156Z.json`
  - pdf: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/consentimiento_canal_estrecho_lumbar_con_fijacion_clinica_centro_paciente_qa_centro_20260520T064156Z.pdf`
- `scripts/qa/validate_neurocirugia_consent_source_corpus.js`
  - ok: `true` | corpus: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/consent_source_corpus/neurocirugia_consent_source_corpus_latest.json`
  - pack: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/consent_canonicals/consent_body_pack_2026-05-19.json`
  - extraction_failures: `3` (sin failures hard en `failures[]`)
- `scripts/qa/validate_product_mode.js`
  - status: `ok` | product_html: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/app/product.html`
- `scripts/qa/validate_neuro_spine_jurisprudence_corpus.js`
  - ok: `true` | corpus: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_corpus_latest.json`
- `scripts/qa/validate_pathology_template_bank.js`
  - ok: `true` | bank: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/pathology_templates/pathology_template_bank_2026-05-20.json`

## Notes
- No se envió nada por Telegram (solo generación y validación de manifests/PDF en modo `BLOQUEADO_NO_ENVIAR`).
- No se modificó código fuente en este run.
