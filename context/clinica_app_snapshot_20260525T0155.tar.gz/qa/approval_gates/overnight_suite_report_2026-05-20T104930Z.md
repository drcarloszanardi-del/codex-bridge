# Overnight QA suite report
- Timestamp (UTC): 2026-05-20T104930Z
- Repo: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal

## validate_jarvis_overnight_requests
```
> node scripts/qa/validate_jarvis_overnight_requests.js
```
- Result: PASS (147s)

## validate_20_pathology_scenarios
```
> node scripts/qa/validate_20_pathology_scenarios.js
```
- Result: PASS (197s)

## validate_jarvis_wrapper
```
> node scripts/qa/validate_jarvis_wrapper.js
```
- Result: PASS (6s)

## validate_clinical_handoff
```
> node scripts/qa/validate_clinical_handoff.js
```
- Result: PASS (5s)

## validate_consent_handoff
```
> node scripts/qa/validate_consent_handoff.js
```
- Result: PASS (13s)

## validate_neurocirugia_consent_source_corpus
```
> node scripts/qa/validate_neurocirugia_consent_source_corpus.js
```
- Result: PASS (0s)

## validate_product_mode
```
> node scripts/qa/validate_product_mode.js
```
- Result: PASS (1s)

## validate_neuro_spine_jurisprudence_corpus
```
> node scripts/qa/validate_neuro_spine_jurisprudence_corpus.js
```
- Result: PASS (0s)

## validate_pathology_template_bank
```
> node scripts/qa/validate_pathology_template_bank.js
```
- Result: PASS (0s)

## Summary
- Overall: PASS
## Consentimientos (verificación especial)
- Validación automática: `scripts/qa/validate_consent_handoff.js` OK (incluye `content_no_qa_leak`, `content_blank_patient_dni_lines`, `content_blank_default_team`).
- Scan extra (PDF recientes): sin hallazgos de `Paciente QA`, `QA2`, `Paciente prueba`, `Paciente Wrapper`, `Ayudante QA`.
