# MEDICOLEGAL_RULES_INTEGRATION_PLAN - 2026-05-20

Estado: `integration_plan_no_code_changes`  
Alcance: convertir el refresh de Bacon en un plan seguro de integracion para tamiz activo de HC, parte quirurgico, consentimiento y evolucion/alta.  
Nota de alcance: este plan no certifica cumplimiento legal, no reemplaza revision profesional humana y no modifica `product.html` ni scripts productivos.

## Insumos revisados

- `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/medicolegal_neuro_spine_research_refresh_2026-05-20.json`
- `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/medicolegal_neuro_spine_research_refresh_2026-05-20.md`
- `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinical_document_handoff.js`
- `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/app/product.html`
- `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/consent_telegram_handoff.js`

## Lectura del sistema actual

El handoff clinico ya opera con `tamiz_medicolegal_flexible_obligatorio_v1`: bloquea frases prohibidas, placeholders visibles, paciente/fecha faltantes, secciones basicas de HC, deficit motor no declarado, secuencia minima del parte, nivel/lateralidad informados pero no reflejados y algunos mismatches semanticos.

El handoff de consentimientos ya tiene un hard gate separado: valida contenido por slug, evita filtraciones de patologia incorrecta, exige riesgos/alternativas/autonomia/copia/firmas y evita placeholders QA o datos ficticios.

La UI de `product.html` mantiene el tamiz normativo/jurisprudencial como `review_only_detect_only`, cargado desde el pack derivado. Ese es el lugar natural para medir falsos positivos antes de promover reglas amplias.

## Reglas listas para activar con bajo riesgo

Estas no necesitan interpretar medicina compleja; bloquean contradicciones, identidad falsa o perdida de datos explicitamente provistos:

| Regla | Documento | Modo recomendado | Check propuesto | Blocker propuesto |
|---|---|---:|---|---|
| `CLI-NSJ-RR-016` | Consentimiento | `blocker` | `nsj_rr016_consent_no_fabricated_patient_data` | `consentimiento_datos_inventados_o_placeholder_ficticio` |
| `CLI-NSJ-RR-016` | Consentimiento | `blocker` | `nsj_rr016_consent_missing_identity_uses_completion_line` | `consentimiento_identidad_extrapolada_desde_ruido` |
| `CLI-NSJ-RR-009` | Consentimiento conocido por slug | `blocker` | `nsj_rr009_consent_specific_to_slug` | `consentimiento_patologia_o_slug_incorrecto` |
| `CLI-NSJ-RR-009` | Consentimiento conocido por slug | `blocker` | `nsj_rr009_consent_material_sections` | `consentimiento_generico_o_incompleto` |
| `CLI-NSJ-RR-007` | Parte | `blocker` | `nsj_rr007_parte_reconstructible_sequence` | `parte_neuro_columna_generico_no_reconstruible` |
| `CLI-NSJ-RR-007` | Parte | `blocker` | `nsj_rr007_parte_event_template_mismatch` | `parte_evento_postoperatorio_con_template_incompatible` |
| `CLI-NSJ-RR-008` | HC + parte | `blocker` si nivel/lado fueron informados | `nsj_rr008_spine_level_reflected` | `columna_nivel_no_reflejado_en_documento` |
| `CLI-NSJ-RR-008` | HC + parte | `blocker` si nivel/lado fueron informados | `nsj_rr008_spine_side_reflected` | `columna_lateralidad_no_reflejada_en_documento` |

Partes de esas mismas reglas deben seguir en dry-run: raiz, correlacion clinico-radiologica completa, proteccion/acolchado, recuento fino y destino/receptor.

## Reglas que requieren dry-run antes de bloquear

| Regla | Motivo principal |
|---|---|
| `CLI-NSJ-RR-010` | Los disparadores de deficit, dolor radicular nuevo, hematoma, infeccion, LCR, fiebre o reintervencion pueden aparecer negados, historicos o como diagnostico diferencial. |
| `CLI-NSJ-RR-011` | No debe exigir alta cuando el documento es una evolucion ordinaria o el paciente sigue internado. |
| `CLI-NSJ-RR-012` | Los datos de implantes pueden vivir en stickers, registros de proveedor, enfermeria o politica institucional separada. |
| `CLI-NSJ-RR-014` | La cadena documental completa exige normalizar hechos entre HC, consentimiento, parte y evolucion; alto riesgo de falso positivo si se hace solo por regex. |
| `CLI-NSJ-RR-015` | La transicion quirofano-recuperacion puede pertenecer a anestesia, recuperacion o enfermeria, no siempre al parte generado. |

## Reglas que deben quedar detect-only inicialmente

| Regla | Estado inicial seguro | Criterio para promover |
|---|---|---|
| `CLI-NSJ-RR-013` | `detect-only` | Promover a blocker solo cuando exista estado explicito de documento emitido/frozen y la accion sea correccion posterior. |
| `CLI-NSJ-RR-014` | `detect-only` | Promover partes acotadas cuando haya extraccion confiable de hechos y pruebas de contradiccion cross-document. |
| `CLI-NSJ-RR-010` | `detect-only` para disparadores amplios | Promover solo eventos con alta confianza y excepciones por negacion/contexto historico. |
| `CLI-NSJ-RR-011` | `detect-only` si no hay contexto de alta/pase | Promover solo cuando el tipo documental sea alta, pase o epicrisis. |
| `CLI-NSJ-RR-012` | `detect-only` para marca/lote/sticker | Promover solo tras definir politica institucional y ubicacion del registro de trazabilidad. |
| `CLI-NSJ-RR-015` | `detect-only` para responsable receptor | Promover solo si la institucion exige ese campo en el documento generado. |

## Matriz por documento

### Historia clinica

| Regla | Control | Modo |
|---|---|---:|
| `CLI-NSJ-RR-008` | Reflejar nivel y lateralidad explicitamente informados. | `blocker` |
| `CLI-NSJ-RR-008` | Raiz en patologia radicular y correlacion clinico-radiologica. | `warning` / `detect-only` |
| `CLI-NSJ-RR-010` | Si hay evento postop neurologico/infeccioso, documentar deteccion, examen, estudios, conducta y seguimiento. | `warning` / dry-run |
| `CLI-NSJ-RR-011` | Alta/pase con condicion neurologica, herida, dolor, movilidad, indicaciones, alarmas, control y reconsulta. | `warning` si hay contexto de alta |
| `CLI-NSJ-RR-013` | Addenda con fecha, hora, autor y motivo. | `detect-only` hasta tener lifecycle |
| `CLI-NSJ-RR-014` | Cadena sintomas/signos, examen, estudios, diagnostico e indicacion. | `warning` local, `detect-only` cross-doc |

### Parte quirurgico

| Regla | Control | Modo |
|---|---|---:|
| `CLI-NSJ-RR-007` | Secuencia reconstruible: posicion/planificacion, antisepsia, abordaje, hallazgos, maniobras, hemostasia, cierre, incidentes y destino. | `blocker` para nucleo, `warning` para detalle fino |
| `CLI-NSJ-RR-007` | Hematoma/toilette/drenaje no puede salir como laminoplastia/canal estrecho/mielopatia. | `blocker` |
| `CLI-NSJ-RR-008` | Nivel y lateralidad informados deben aparecer; control de nivel/material como warning. | `blocker` + `warning` |
| `CLI-NSJ-RR-010` | Reintervencion o complicacion con motivo, hallazgo, respuesta y control. | `warning`, salvo mismatch conocido |
| `CLI-NSJ-RR-012` | Implantes/material con tipo/sistema, nivel y control, sin exigir lote salvo politica institucional. | `warning` / dry-run |
| `CLI-NSJ-RR-014` | Parte coherente con HC y consentimiento. | `detect-only` |
| `CLI-NSJ-RR-015` | Condicion final, destino, drenajes e indicaciones criticas. | `warning` / dry-run |

### Consentimiento

| Regla | Control | Modo |
|---|---|---:|
| `CLI-NSJ-RR-009` | Contenido especifico por patologia/procedimiento conocido por slug. | `blocker` |
| `CLI-NSJ-RR-009` | Diagnostico, objetivo, procedimiento, riesgos, alternativas, no tratamiento, revocacion, copia/disponibilidad y preguntas. | `blocker` |
| `CLI-NSJ-RR-012` | Si hay implantes/fijacion/artrodesis, anticipar uso de implantes/material y riesgos. | `warning` / dry-run |
| `CLI-NSJ-RR-014` | Diagnostico/procedimiento coherente con HC y parte. | `detect-only` |
| `CLI-NSJ-RR-016` | No inventar paciente, DNI, ayudantes ni identidad desde ruido del pedido. | `blocker` |
| `CLI-NSJ-RR-016` | Si faltan datos, usar lineas de completado o `Dr. Carlos Zanardi y equipo`. | `blocker` para identidad inventada, `warning` para formula de equipo |

### Evolucion / alta

| Regla | Control | Modo |
|---|---|---:|
| `CLI-NSJ-RR-010` | Evento postop con deteccion, examen, estudios, decision, respuesta, destino y seguimiento. | `warning` / dry-run |
| `CLI-NSJ-RR-011` | Alta/pase sin zona gris: condicion, herida, dolor, movilidad, indicaciones, curaciones, alarmas, control y reconsulta. | `warning` si el documento es alta/pase |
| `CLI-NSJ-RR-013` | Addenda sin reemplazo silencioso. | `detect-only` hasta lifecycle; futuro `blocker` |
| `CLI-NSJ-RR-015` | Transicion desde quirofano o recuperacion con condicion y cuidados iniciales. | `warning` / dry-run |

## Mapeo de las 10 reglas

| Regla | Documentos | Control concreto | Modo inicial |
|---|---|---|---:|
| `CLI-NSJ-RR-007` | Parte | Parte no generico, secuencia reconstruible y sin mismatch de evento/template. | `blocker` para nucleo, `warning` para detalle |
| `CLI-NSJ-RR-008` | HC, parte | Nivel/lado informados deben reflejarse; raiz/correlacion/control nivel como controles graduados. | `blocker` parcial + dry-run |
| `CLI-NSJ-RR-009` | Consentimiento | Consentimiento especifico por slug y matriz material completa. | `blocker` para slugs conocidos |
| `CLI-NSJ-RR-010` | HC, parte, evolucion/alta | Trazabilidad de evento postop neurologico/infeccioso o reintervencion. | `warning` / `detect-only`, salvo mismatch conocido |
| `CLI-NSJ-RR-011` | HC, evolucion/alta | Alta/pase con condicion, indicaciones, alarmas, control y reconsulta. | `warning` / dry-run |
| `CLI-NSJ-RR-012` | Parte, consentimiento | Implantes/material anticipados en consentimiento y trazados en parte. | `warning` / dry-run |
| `CLI-NSJ-RR-013` | HC, evolucion/alta | Addenda fechada con autor y motivo; sin reemplazo silencioso. | `detect-only`; futuro `blocker` |
| `CLI-NSJ-RR-014` | Todos | Cadena sintomas/signos, estudios, diagnostico, indicacion, consentimiento, procedimiento y seguimiento. | `detect-only` |
| `CLI-NSJ-RR-015` | Parte, evolucion | Cierre de quirofano y recuperacion: condicion, destino, drenajes/instrucciones y receptor si aplica. | `warning` / dry-run |
| `CLI-NSJ-RR-016` | Consentimiento | No completar datos inventados; usar lineas o formula de equipo. | `blocker` |

## Secuencia segura de rollout

1. Mantener este frente como reporte de aprobacion, sin cambios de codigo.
2. Si luego se aprueba implementacion, activar primero solo `RR-016`, `RR-009` en slugs conocidos, nucleo de `RR-007` y nivel/lado de `RR-008`.
3. Correr al menos 20 casos sinteticos contra `RR-010`, `RR-011`, `RR-012`, `RR-014`, `RR-015` y las partes sensibles de `RR-007`, `RR-008`, `RR-009` y `RR-013`.
4. Promover solo checks con baja tasa de falso positivo, alcance documental claro y excepciones modeladas.
5. Mantener las citas/fundamentos legales fuera de los documentos clinicos; el tamiz queda como compuerta lateral.

## Archivos generados

- `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/medicolegal_rules_integration_plan_2026-05-20.json`
- `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/medicolegal_rules_integration_plan_2026-05-20.md`
