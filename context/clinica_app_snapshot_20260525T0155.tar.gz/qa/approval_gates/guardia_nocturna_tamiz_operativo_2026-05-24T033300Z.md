# Guardia nocturna clínica medicolegal - 2026-05-24

## Resultado general
- Estado: **tamiz medicolegal operativo** (no certificación legal absoluta).
- Detect-only (`--skip-fetch`): **OK**.
- QA core: **OK** tras fix mínimo de validador de ruta clínica.
- Freshness de latest artifacts: **OK**.
- QA `--full`: **pendiente de cierre** por ejecución extensa en esta corrida (no se marca OK sin evidencia final).

## Fallo material corregido
- Suite afectada: `validate_clinica_route_guard.js`.
- Síntoma: falso rojo en `consent_via_clinical_bridge` por cambio de contrato del wrapper (ya no expone `source_bridge` en salida).
- Corrección mínima: el check ahora valida puente clínico usando el manifiesto de consentimiento (`artifact_type` + ruta canonical de `outbox/clinica_medicolegal/telegram_ready`).
- Archivo tocado: `scripts/qa/validate_clinica_route_guard.js`.

## Compuertas críticas verificadas
- Historia clínica / parte / consentimiento desde app + manifiesto: **OK**.
- Bloqueo de bypass por variable de entorno en envío clínico QA: **OK** (`guarded_send_rejects_qa_env_bypass=true`).
- Jarvis como nexo (no generador libre): **OK**.
- Sin salida real por Telegram en esta guardia: **OK** (solo validaciones locales).
- Interfaz y modo producto: **OK** (sin convertir la pantalla en landing).

## Evidencia y reportes
- Detect-only: `qa/approval_gates/medicolegal_detect_only_update_cycle_20260524T030215Z.md`
- Detect-only JSON: `qa/approval_gates/medicolegal_detect_only_update_cycle_20260524T030215Z.json`
- Core QA (verde final): `qa/approval_gates/clinica_core_qa_20260524T032803.md`
- Core QA JSON: `qa/approval_gates/clinica_core_qa_20260524T032803.json`
- Freshness: salida JSON en consola (`ok:true`, generated_at `2026-05-24T03:05:16.466Z`)
- Este reporte: `qa/approval_gates/guardia_nocturna_tamiz_operativo_2026-05-24T033300Z.md`
