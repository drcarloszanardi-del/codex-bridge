# Guardia nocturna — suite QA (clínica medicolegal)

- Run (UTC): 2026-05-21T033148Z
- Repo: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal
- Resultado general: OK (9/9 validadores)

## Validadores ejecutados

1) `node scripts/qa/validate_jarvis_overnight_requests.js`
   - OK
   - Log: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/validate_jarvis_overnight_requests_log_2026-05-21T030541Z.txt
   - Artefacto: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/jarvis_overnight_requests_2026-05-21.json

2) `node scripts/qa/validate_20_pathology_scenarios.js`
   - OK
   - Log: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/validate_20_pathology_scenarios_log_2026-05-21T031327Z.txt
   - Artefacto: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/clinical_20_pathology_scenarios_2026-05-21.json

3) `node scripts/qa/validate_jarvis_wrapper.js`
   - OK
   - Log: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/validate_jarvis_wrapper_log_2026-05-21T032711Z.txt

4) `node scripts/qa/validate_clinical_handoff.js`
   - OK
   - Log: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/validate_clinical_handoff_log_2026-05-21T032750Z.txt

5) `node scripts/qa/validate_consent_handoff.js`
   - OK
   - Log: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/validate_consent_handoff_log_2026-05-21T032918Z.txt

6) `node scripts/qa/validate_neurocirugia_consent_source_corpus.js`
   - OK
   - Log: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/validate_neurocirugia_consent_source_corpus_log_2026-05-21T032939Z.txt

7) `node scripts/qa/validate_product_mode.js`
   - OK
   - Log: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/validate_product_mode_log_2026-05-21T032944Z.txt

8) `node scripts/qa/validate_neuro_spine_jurisprudence_corpus.js`
   - OK
   - Log: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/validate_neuro_spine_jurisprudence_corpus_log_2026-05-21T032949Z.txt
   - Artefacto: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/neuro_spine_jurisprudence_validation_2026-05-21.json

9) `node scripts/qa/validate_pathology_template_bank.js`
   - OK
   - Log: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/validate_pathology_template_bank_log_2026-05-21T032953Z.txt
   - Artefacto: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/pathology_template_bank_validation_2026-05-21.json

## Consentimientos — chequeos especiales

- `validate_consent_handoff` pasó incluyendo:
  - No leaks de “Paciente QA / QA2 / Paciente prueba / Paciente Wrapper / Ayudante QA”.
  - Si falta paciente/DNI: líneas de puntos.
  - Si falta equipo: default “Dr. Carlos Zanardi y equipo”.
- Verificación adicional offline: escaneo de PDFs de consentimiento modificados en los últimos ~45 min (98 PDFs) buscando esas frases → 0 hits.

## Fallas corregidas

- Ninguna (suite completa en verde a la primera).

## Archivos tocados

- Sin cambios de código dentro de `app-clinica-medicolegal`.
- Se generaron/actualizaron artefactos de QA en `qa/approval_gates/` (logs + JSONs arriba).

