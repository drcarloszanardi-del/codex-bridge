# Guardia nocturna suite — 2026-05-21T040716Z

- node scripts/qa/validate_jarvis_overnight_requests.js: exit 0 (2026-05-21T04:07:16Z -> 2026-05-21T04:10:21Z)
- node scripts/qa/validate_20_pathology_scenarios.js: exit 1 (2026-05-21T04:10:21Z -> 2026-05-21T04:29:55Z)
- node scripts/qa/validate_jarvis_wrapper.js: exit 0 (2026-05-21T04:29:55Z -> 2026-05-21T04:30:31Z)
- node scripts/qa/validate_clinical_handoff.js: exit 0 (2026-05-21T04:30:31Z -> 2026-05-21T04:31:30Z)
- node scripts/qa/validate_consent_handoff.js: exit 0 (2026-05-21T04:31:30Z -> 2026-05-21T04:32:36Z)
- node scripts/qa/validate_neurocirugia_consent_source_corpus.js: exit 0 (2026-05-21T04:32:36Z -> 2026-05-21T04:32:36Z)
- node scripts/qa/validate_product_mode.js: exit 0 (2026-05-21T04:32:36Z -> 2026-05-21T04:32:38Z)
- node scripts/qa/validate_neuro_spine_jurisprudence_corpus.js: exit 0 (2026-05-21T04:32:38Z -> 2026-05-21T04:32:38Z)
- node scripts/qa/validate_pathology_template_bank.js: exit 0 (2026-05-21T04:32:38Z -> 2026-05-21T04:32:39Z)
