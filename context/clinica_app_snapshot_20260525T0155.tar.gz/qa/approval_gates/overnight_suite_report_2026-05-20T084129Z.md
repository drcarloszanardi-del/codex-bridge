# Overnight QA suite report

- start_utc: 2026-05-20T084129Z
- repo: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal
- result: GREEN (0 failures)
- log: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/overnight_suite_2026-05-20T084129Z.log

## Commands
- node scripts/qa/validate_jarvis_overnight_requests.js
- node scripts/qa/validate_20_pathology_scenarios.js
- node scripts/qa/validate_jarvis_wrapper.js
- node scripts/qa/validate_clinical_handoff.js
- node scripts/qa/validate_consent_handoff.js
- node scripts/qa/validate_neurocirugia_consent_source_corpus.js
- node scripts/qa/validate_product_mode.js
- node scripts/qa/validate_neuro_spine_jurisprudence_corpus.js
- node scripts/qa/validate_pathology_template_bank.js

## Gate artifacts (updated this run)
- /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/jarvis_overnight_requests_2026-05-20.json
- /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/clinical_20_pathology_scenarios_2026-05-20.json
- /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/neurocirugia_consent_source_corpus_validation_2026-05-20.json
- /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/neuro_spine_jurisprudence_validation_2026-05-20.json
- /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/pathology_template_bank_validation_2026-05-20.json

## Notes
- No repair actions required (suite green).
- Derived corpora refreshed:
  - /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/consent_source_corpus/neurocirugia_consent_source_corpus_latest.json
  - /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_corpus_latest.json
