# Medicolegal gap pack - 2026-05-20

Estado: `review_only_detect_only`  
Base observada: `BASE_AVANZADA_REVIEW_ONLY`  
Alcance: paquete interno de QA para robustecer corpus medico-legal. No certifica cumplimiento legal ni sustituye revision profesional humana.

## Insumos locales usados

- `docs/corpus_medicolegal_argentino.md`: estado general, cobertura normativa, jurisprudencia base y advertencias de alcance.
- `docs/matriz_impacto_redaccional_hc_partes.md`: matriz de riesgos y controles por historia clinica, consentimiento y parte quirurgico.
- `docs/reglas_internas_redaccion_medicolegal.md`: reglas candidatas `CLI-R001` a `CLI-R015`.
- `docs/cola_revision_jurisprudencial_medicolegal.md`: cola de lectura jurisprudencial y prioridades.
- `data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_corpus_latest.json`: corpus neuro/columna con 16 registros y confiabilidad separada.
- `data/derived/medicolegal_tamiz/medicolegal_tamiz_pack_2026-05-19.json`: 19 gates detect-only, frases inseguras y politica documental.

## Estado

El corpus ya tiene una base avanzada para tamiz interno de historias clinicas, consentimientos y partes quirurgicos. La cobertura principal incluye identificacion completa del acto, consentimiento con contenido material, parte quirurgico completo y cronologico, addendas sin borrado, confidencialidad/minima exposicion e integridad/autenticidad/auditoria del registro electronico.

El estado operativo sigue siendo `BASE_AVANZADA_REVIEW_ONLY`. El uso razonable hoy es QA local, `review_only`, `detect-only`, dry run y redaccion prudente interna. No corresponde declarar cierre definitivo, cumplimiento legal total, certificacion ni activacion productiva de reglas.

## Integracion posterior 2026-05-20T15:20Z

- `GAP-001` baja de bloqueo alto a control pendiente: se incorporo texto primario oficial de Ley 27.706 desde InfoLEG id `380710` y Decreto 393/2023 desde InfoLEG id `387475`.
- Se agrego capa bonaerense relevante para HIGA Junin: Ley PBA 14.494 y Decreto PBA 1600/2024.
- Se agregaron complementarias de firma/datos/indicaciones digitales: Decreto 182/2019, Decreto 1558/2001 y Ley 27.553.
- Se sincronizo `data/db/medicolegal.sqlite` con manifiestos reales: 28 fuentes, 28 raw documents y 28 indices en `pending_review`.
- Se incorporaron tres fuentes judiciales oficiales adicionales al corpus neuro/columna: Avendaño (Rio Negro), JUBA 180817 y JUBA 30512.

## Gaps

| ID | Area | Severidad | Brecha | Impacto |
|---|---|---:|---|---|
| `GAP-001` | Ley 27706 / Decreto 393/2023 | Baja | Texto primario oficial capturado desde InfoLEG; queda revision de control de cambios y articulacion fina. | Ya puede alimentar dry-run detect-only; no habilita certificacion legal total. |
| `GAP-002` | Ley 5669 CABA | Media | Referencia secundaria detectada, primer intento SAIJ bloqueado por 403. | Mantener como pista local pendiente, no como fundamento operativo nacional. |
| `GAP-003` | Jurisprudencia HC/consentimiento/parte | Alta | Varios candidatos SAIJ tienen busqueda estructurada, fecha o friendly URL, pero no todos tienen ficha/texto completo revisado. | Las reglas son utiles para dry_run, pero no deben presentarse como doctrina cerrada. |
| `GAP-004` | Neuro/columna con fuentes secundarias | Alta | `NSJ-005`, `NSJ-006`, `NSJ-007` y `NSJ-008` siguen como secundarios pendientes de copia oficial. | Usar solo en tamiz interno hasta obtener fuente judicial oficial. |
| `GAP-005` | Alcance federal/provincial | Media | Ya se sumo capa Buenos Aires; siguen posibles ajustes por institucion, colegio profesional o politica sanitaria local. | El flujo HIGA queda mejor cubierto, pero no se declara exhaustividad provincial absoluta. |
| `GAP-006` | Validacion de implementacion | Alta | El pack detect-only existe, pero este paquete no verifica aplicacion real en app ni falsos positivos/negativos. | Antes de activar nada, hace falta dry_run con casos sinteticos y revision humana. |

## Fuentes Pendientes

- Control de cambios de Ley 27706 y Decreto 393/2023 ya capturadas desde InfoLEG.
- Fuentes institucionales locales de HIGA Junin, Clinica Centro y La Pequena Familia sobre firma, auditoria, entrega de copias, custodia y acceso.
- Ley 5669 CABA desde normativa CABA, Boletin Oficial u otra ruta primaria estable.
- Fichas o textos completos SAIJ sobre historia clinica, autenticidad, falta de prueba e impugnacion documental.
- Fichas o textos completos sobre consentimiento informado, acceso material, copia, lectura y preguntas.
- Fichas o textos completos sobre oblito, lesiones culposas, recuentos, control final y transicion quirofano-recuperacion.
- Copias oficiales de `NSJ-005`, `NSJ-006`, `NSJ-007` y `NSJ-008`.
- Oficializacion o descarte final de las cuatro fuentes secundarias neuro/columna restantes.

## Candidatos De Reglas Para Dry Run

| Dry run | Reglas fuente | Proposito | Cuidado principal |
|---|---|---|---|
| `DRY-R001` | `CLI-R001` | Identificacion completa de paciente, edad, fecha, hora, institucion y autor. | Evitar falsos positivos en anexos o notas que heredan contexto. |
| `DRY-R002` | `CLI-R002`, `CLI-R011`, `CLI-R015`, `CLI-NSJ004` | Consentimiento material, riesgos, beneficios, alternativas, preguntas, rechazo/revocacion y copia/disponibilidad. | No penalizar urgencias con imposibilidad documentada de consentimiento ordinario. |
| `DRY-R003` | `CLI-R003`, `CLI-R008`, `CLI-NSJ001`, `CLI-NSJ002` | Indicacion neuro/columna con clinica, examen, estudio, nivel/lateralidad/raiz y razon de conducta. | Separar conductas invasivas de controles evolutivos o estudios pendientes. |
| `DRY-R004` | `CLI-R004`, `CLI-R012`, `CLI-NSJ003` | Parte quirurgico no generico, con abordaje, hallazgos, maniobras, secuencia y cierre. | Adaptar a procedimientos menores donde una plantilla abreviada sea suficiente. |
| `DRY-R005` | `CLI-R005`, `CLI-R009`, `CLI-R014`, `CLI-NSJ003` | Seguridad intraoperatoria, hemostasia, recuento/verificacion, estado final, destino y receptor. | Recuento o registro anestesico pueden depender del tipo de acto y de documento separado. |
| `DRY-R006` | `CLI-R006` | Addendas con autor, fecha, hora y motivo; sin reemplazo silencioso. | Diferenciar borrador no emitido de registro ya firmado/emitido. |
| `DRY-R007` | `CLI-R007`, `CLI-R013` | Minima exposicion de datos sensibles, imagenes y finalidad de circulacion. | No bloquear imagenes asistenciales con finalidad tecnica clara. |
| `DRY-R008` | `CLI-R010`, `CLI-NSJ005` | Alta, continuidad asistencial, urgencia neurologica, horarios, comunicaciones, derivacion y receptor. | No exigir alta cuando el paciente sigue internado o el pase aun no fue emitido. |

## Riesgos

- Riesgo critico: convertir el estado `review_only_detect_only` en afirmacion de cumplimiento o certificacion. Mitigacion: mantener etiquetas prudentes y prohibir lenguaje de cierre legal.
- Riesgo alto: mezclar fuentes oficiales y secundarias sin confiabilidad separada. Mitigacion: preservar `reliability_policy` y no citar secundarios en documentos clinicos.
- Riesgo alto: automatizar alertas sin dry_run suficiente. Mitigacion: probar con casos sinteticos, medir falsos positivos/negativos y revisar salida humana.
- Riesgo medio: sobrerredaccion defensiva que degrade la calidad clinica. Mitigacion: alertas sobrias, clinicas y sin citas legales dentro del texto asistencial.
- Riesgo medio: falta de ajuste jurisdiccional/institucional. Mitigacion: agregar bucket local antes de cualquier activacion por institucion.

## Proximos Pasos

1. Completar fuentes pendientes de prioridad alta, con ruta, confiabilidad, fecha, tribunal o fundamento visible y resumen trazable.
2. Ejecutar `DRY-R001` a `DRY-R008` contra casos sinteticos de HC, consentimiento, parte quirurgico, urgencia neuro, alta, addenda e imagen clinica.
3. Revisar severidades y lenguaje de alertas con criterio clinico/legal humano, manteniendo el estado `approved_for_dry_run` como maximo siguiente hito.
4. Si luego se decide implementar, hacerlo en rama separada, con gates detect-only primero y sin citas legales ni promesas de blindaje en documentos clinicos.

## Nota De Alcance

Este gap pack sirve para orientar revision y robustecimiento del corpus. No afirma aptitud legal, no certifica cumplimiento y no modifica plantillas, datos derivados, scripts ni fuentes principales del producto.
