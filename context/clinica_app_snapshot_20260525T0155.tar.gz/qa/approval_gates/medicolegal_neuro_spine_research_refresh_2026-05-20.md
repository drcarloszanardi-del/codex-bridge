# Refresh medico-legal neuro/columna - 2026-05-20

Estado: `research_refresh_detect_only`  
Alcance: refuerzo del corpus medico-legal argentino para tamiz interno de HC, partes quirurgicos y consentimientos en neurocirugia y cirugia de columna.  
Advertencia: este paquete robustece el corpus, pero no certifica cumplimiento legal total, no reemplaza revision profesional humana y no declara blindaje absoluto.

## Que se agrego

Se relevaron 18 fuentes oficiales o primarias argentinas, con predominio de JUBA/SCBA, SAIJ, CIJ/Poder Judicial de la Nacion, InfoLEG y Poder Judicial de Rio Negro. No se incorporaron fuentes secundarias nuevas como fundamento; las secundarias previas del corpus siguen en cola de oficializacion o descarte.

El foco del barrido fue: mala praxis en neurocirugia y columna, lesion neurologica postoperatoria, consentimiento informado, historia clinica incompleta, parte quirurgico insuficiente, alta/seguimiento, complicaciones postoperatorias, infeccion/hematoma, implantes/material y controles finales.

Artefacto estructurado asociado:

- `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/medicolegal_neuro_spine_research_refresh_2026-05-20.json`

## Utilidad para historia clinica

La historia clinica debe preservar una cadena clinica defendible: sintomas y signos relevantes, examen neurologico util, estudio concordante, diagnostico, indicacion, alternativas, consentimiento y seguimiento. Para columna, el tamiz debe ser mas exigente en nivel, lateralidad, raiz comprometida cuando corresponda, correlacion clinico-radiologica y razon de la conducta.

Cuando hay deficit neurologico, dolor radicular nuevo, infeccion, hematoma, LCR o necesidad de reintervencion, la evolucion debe documentar deteccion, examen, estudios pedidos, conducta, respuesta, destino y seguimiento. En alta o pase debe quedar condicion neurologica, herida, dolor, movilidad, indicaciones, curaciones, signos de alarma y via de reconsulta.

## Utilidad para parte quirurgico

El parte quirurgico no debe ser una formula generica. Debe permitir reconstruir posicion, proteccion ocular y acolchado, antisepsia, profilaxis, abordaje, nivel/lateralidad si aplica, hallazgos, maniobras criticas, uso de implantes/material cuando corresponda, control de nivel/material, hemostasia, recuento/verificacion, cierre, incidentes o ausencia de incidentes visibles, destino inmediato y condicion de egreso.

Para eventos postoperatorios como hematoma en lodge, infeccion, toilette, drenaje o reintervencion, el parte debe narrar el motivo real del acto y no caer por palabra clave en plantillas de otra patologia. La regla practica es bloquear contradicciones semanticas: un pedido de hematoma/toilette/drenaje cervical no puede producir un parte de laminoplastia, canal estrecho o mielopatia.

## Utilidad para consentimiento

La proforma visual puede ser uniforme, pero el contenido debe ser especifico por patologia y procedimiento. El consentimiento debe incluir diagnostico, procedimiento propuesto, objetivo, riesgos propios, alternativas, no tratamiento, posibilidad de rechazo/revocacion, anestesia, transfusion cuando corresponda, copia/disponibilidad, lectura/preguntas y firmantes reales.

Debe quedar prohibido completar datos inventados. Si el usuario no informa paciente, DNI, fecha, ayudantes o datos del equipo, la salida debe usar lineas de completado o una formula sobria del tipo `Dr. Carlos Zanardi y equipo`, segun corresponda. Nunca se deben extrapolar nombres, DNI ni ayudantes desde ruido del pedido.

## Reglas que deben convertirse en tamiz

1. `CLI-NSJ-RR-007` - Parte neuro/columna no generico y reconstruible.
2. `CLI-NSJ-RR-008` - Columna con nivel, lateralidad, raiz y correlacion.
3. `CLI-NSJ-RR-009` - Consentimiento especifico por patologia y procedimiento.
4. `CLI-NSJ-RR-010` - Postoperatorio neurologico con trazabilidad de deteccion y respuesta.
5. `CLI-NSJ-RR-014` - Cadena documental completa de indicacion quirurgica.

Reglas adicionales candidatas:

- `CLI-NSJ-RR-011` - Alta y seguimiento sin zona gris.
- `CLI-NSJ-RR-012` - Implantes y material con identificacion suficiente.
- `CLI-NSJ-RR-013` - Addendas sin reemplazo silencioso.
- `CLI-NSJ-RR-015` - Transicion quirofano-recuperacion documentada.
- `CLI-NSJ-RR-016` - Consentimiento sin datos inventados.

## Fuentes principales relevadas

- SAIJ, dossier oficial de mala praxis medica: `https://www.saij.gob.ar/docs-f/dossier-f/mala_praxis_medica.pdf`
- JUBA/SCBA, historia clinica y mala praxis: `https://juba.scba.gov.ar/VerTextoCompleto.aspx?idFallo=25519`
- JUBA/SCBA, consentimiento/historia clinica: `https://juba.scba.gov.ar/VerTextoCompleto.aspx?idFallo=161074`
- JUBA/SCBA, cronologia quirurgica/anestesica: `https://juba.scba.gov.ar/VerTextoCompleto.aspx?idFallo=192025`
- JUBA/SCBA, parte/registro escueto y evento temporal: `https://juba.scba.gov.ar/VerTextoCompleto.aspx?idFallo=174803`
- JUBA/SCBA, lesion neurologica y seguimiento: `https://juba.scba.gov.ar/VerTextoCompleto.aspx?idFallo=180817`
- CIJ/PJN, sentencia en hernia discal/columna: `https://www.cij.gov.ar/informacion.html/387453545/d/sentencia-SGU-bbc33715-031b-4475-96cf-b7da0455eea1.pdf`
- CIJ/PJN, mala praxis en multiples cirugias: `https://www.cij.gov.ar/nota-105696-Ratifican-un-fallo-que-condeno-a-un-medico-por-la-mala-praxis-cometida-en-ocho-cirugias-realizadas-entre-2008-y-2015.html`
- Poder Judicial de Rio Negro, hernia discal/alta/seguimiento: `https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=1a1e6e9e-e827-4382-b44c-b177e4aa5148&option_text=0&usarSearch=1`
- Poder Judicial de Rio Negro, recidiva/hematoma postoperatorio: `https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=cd12a9ba-dfa7-4ea6-a51f-462c92fb2878&option_text=0&usarSearch=1`
- Poder Judicial de Rio Negro, paraparesia/interconsulta neuroquirurgica: `https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=a264eeb6-c144-4d24-a028-34b8194c022d&option_text=0&usarSearch=1`
- Poder Judicial de Rio Negro, implantes/material/consentimiento: `https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=f7f1eec9-d181-4a68-ae13-35769d05177a&option_text=0&usarSearch=1`
- Poder Judicial de Rio Negro, consentimiento/familia/postoperatorio/addenda: `https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=7c0fa4b6-76d0-4f29-bff4-a10c00dd49d9&option_text=0&usarSearch=1`
- Poder Judicial de Rio Negro, cadena diagnostico-tratamiento-consentimiento-seguimiento: `https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=739d3bc6-e8c5-4966-b69e-e99666d5f0a0&option_text=0&usarSearch=1`
- Poder Judicial de Rio Negro, consentimiento especifico: `https://fallos.jusrionegro.gov.ar/protocoloweb/protocolo/protocolo?id_protocolo=df6130bc-e7e6-402f-a61f-321cd943a2fb&option_text=0&usarSearch=1`
- InfoLEG, Ley 26.529 texto actualizado: `https://www.argentina.gob.ar/normativa/nacional/ley-26529-160432/texto`
- InfoLEG, Decreto 1089/2012: `https://servicios.infoleg.gob.ar/infolegInternet/anexos/195000-199999/199296/norma.htm`
- CIJ/PJN, consentimiento informado/deber de informacion: `https://www.cij.gov.ar/sentencia.html?id=74005`

## Que falta

- Reemplazar o descartar las fuentes secundarias previas `NSJ-005`, `NSJ-006`, `NSJ-007` y `NSJ-008`.
- Separar en reglas futuras las que se apoyan en texto completo oficial de las que se apoyan en sumario oficial.
- Agregar protocolos institucionales locales de Clinica Centro, La Pequena Familia y HIGA Junin si existen.
- Crear una tarea periodica detect-only de actualizacion jurisprudencial por jurisdiccion.
- Correr al menos 20 casos sinteticos contra las reglas candidatas para medir falsos positivos y falsos negativos antes de activar bloqueos nuevos.

## Conclusiones

El corpus queda mas robusto, especialmente para documentacion de indicacion quirurgica, consentimiento especifico, parte no generico, postoperatorio complicado y seguimiento. Sigue siendo un corpus de apoyo y tamiz interno: no es exhaustivo, no esta certificado y no debe usarse para prometer blindaje medico-legal absoluto.
