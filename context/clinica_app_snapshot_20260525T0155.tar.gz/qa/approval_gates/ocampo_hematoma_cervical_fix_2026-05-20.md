# Fix Ocampo hematoma cervical posterior

Fecha: 2026-05-20.

## Problema confirmado

Jarvis entregó para Ocampo Roberto un protocolo de laminoplastia/canal estrecho cervical cuando el pedido decía hematoma tardío en lodge operatoria cervical posterior, con reapertura, evacuación de hematoma, toilette, hemostasia y drenaje.

Artefactos previos incorrectos:

- `/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/protocolo_quirurgico_cervical_clinica_centro_ocampo_roberto_20260520T193605Z.json`
- `/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/protocolo_quirurgico_cervical_clinica_centro_ocampo_roberto_20260520T193641Z.json`
- `/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/protocolo_quirurgico_auto_clinica_centro_ocampo_roberto_20260520T194409Z.json`

## Causa

La inferencia del puente Jarvis-app tomaba cualquier pedido con la palabra "cervical" como familia `cervical`, que en la app equivale a "Canal estrecho cervical / laminoplastia". La validación médico-legal controlaba forma y placeholders, pero no bloqueaba contradicción semántica entre "hematoma/reapertura/toilette/drenaje" y "laminoplastia/canal estrecho/mielopatía".

## Corrección permanente

Archivos modificados:

- `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinical_document_handoff.js`
- `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_request_guard.js`
- `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/app/product.html`
- `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/qa/validate_jarvis_wrapper.js`

Cambios:

- Se agregó detección prioritaria de casos de herida/lodge postoperatoria de columna: hematoma, colección, reapertura, toilette, lavado, drenaje, evacuación y revisión de lecho.
- Esos pedidos se enrutan a `columna_infeccion_desbridamiento_retiro`, no a laminoplastia.
- Para partes quirúrgicos de hematoma cervical posterior postoperatorio se usa una plantilla específica: diagnóstico, operación, posicionamiento, protección ocular, acolchado, antisepsia, profilaxis, reapertura, evacuación, toilette/lavado, revisión del lecho, hemostasia, drenaje, cierre, recuento e incidentes.
- El tamiz bloquea si un caso de hematoma/lodge postoperatorio vuelve a contener `laminoplastia`, `canal estrecho cervical` o `mielopatía`.
- El guard de pedidos reconoce hematoma/lodge/toilette/reapertura/drenaje aunque el médico pida "preparame/haceme lo de..." sin decir explícitamente "parte quirúrgico".
- El test del wrapper ahora incluye un caso tipo Ocampo y falla si vuelve a mezclarse con laminoplastia.

## Prueba Ocampo corregida

Generado sin envío:

- PDF: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/protocolo_quirurgico_columna_infeccion_desbridamiento_retiro_clinica_centro_ocampo_roberto_20260520T200039Z.pdf`
- Manifest: `/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/protocolo_quirurgico_columna_infeccion_desbridamiento_retiro_clinica_centro_ocampo_roberto_20260520T200039Z.json`

Resultado:

- `APTO_CON_OBSERVACIONES`
- Sin blockers.
- Observaciones no bloqueantes: hora de inicio, hora de fin y ayudantes no informados.
- Checks clave OK: `no_laminoplasty_for_postoperative_wound`, `postoperative_wound_core_terms`, `parte_core_sequence`, `no_visible_placeholders`.

## Suite

Comando:

`/Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/qa/validate_jarvis_wrapper.js`

Resultado:

- `ok: true`
- `ocampo_hematoma_not_laminoplasty: true`

Guard de pedidos:

`node scripts/jarvis/clinica_request_guard.js --request 'Preparame lo de Ocampo por hematoma en lodge cervical posterior con toilette y drenaje'`

Resultado: `clinical_document_request: true`, `direct_answer_allowed: false`.
