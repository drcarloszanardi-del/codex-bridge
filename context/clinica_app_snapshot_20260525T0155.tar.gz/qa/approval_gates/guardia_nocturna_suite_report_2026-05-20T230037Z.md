# Guardia nocturna — suite QA

- Run (UTC): 2026-05-20T230037Z
- Repo: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal

## Preflight

- Preflight lane gate (CLI-001):
  {
    "decision": "NEXT_STEP",
    "lane": "CLI-001",
    "next_step": "Usar siempre `clinica_request_guard.js --request` y luego `clinica_generar_y_enviar.sh --request ... --send`; validar localmente cada HC/parte/consentimiento con manifiesto y chequeo medico-legal; no enviar PDF/ZIP/mail/Telegram ni declarar final hasta `APTO_PARA_ENTREGAR` + `codex_guard_delivery_gate.js` OK",
    "status": "active",
    "last_action": "url_validation",
    "last_artifact": "/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/protocolo_quirurgico_lumbar_fijacion_clinica_centro_paciente_20260520T225911Z.json",
    "needs_human": false,
    "terminal_state": null
  }

## Validators

=== validate_jarvis_overnight_requests ===
CMD: node scripts/qa/validate_jarvis_overnight_requests.js
LOG: qa/approval_gates/validate_jarvis_overnight_requests_log_2026-05-20T230037Z.txt

- validate_jarvis_overnight_requests: exit=0 log=qa/approval_gates/validate_jarvis_overnight_requests_log_2026-05-20T230037Z.txt
=== validate_20_pathology_scenarios ===
CMD: node scripts/qa/validate_20_pathology_scenarios.js
LOG: qa/approval_gates/validate_20_pathology_scenarios_log_2026-05-20T230037Z.txt

- validate_20_pathology_scenarios: exit=0 log=qa/approval_gates/validate_20_pathology_scenarios_log_2026-05-20T230037Z.txt
=== validate_jarvis_wrapper ===
CMD: node scripts/qa/validate_jarvis_wrapper.js
LOG: qa/approval_gates/validate_jarvis_wrapper_log_2026-05-20T230037Z.txt

- validate_jarvis_wrapper: exit=0 log=qa/approval_gates/validate_jarvis_wrapper_log_2026-05-20T230037Z.txt
=== validate_clinical_handoff ===
CMD: node scripts/qa/validate_clinical_handoff.js
LOG: qa/approval_gates/validate_clinical_handoff_log_2026-05-20T230037Z.txt

- validate_clinical_handoff: exit=0 log=qa/approval_gates/validate_clinical_handoff_log_2026-05-20T230037Z.txt
=== validate_consent_handoff ===
CMD: node scripts/qa/validate_consent_handoff.js
LOG: qa/approval_gates/validate_consent_handoff_log_2026-05-20T230037Z.txt

- validate_consent_handoff: exit=0 log=qa/approval_gates/validate_consent_handoff_log_2026-05-20T230037Z.txt
=== validate_neurocirugia_consent_source_corpus ===
CMD: node scripts/qa/validate_neurocirugia_consent_source_corpus.js
LOG: qa/approval_gates/validate_neurocirugia_consent_source_corpus_log_2026-05-20T230037Z.txt

- validate_neurocirugia_consent_source_corpus: exit=0 log=qa/approval_gates/validate_neurocirugia_consent_source_corpus_log_2026-05-20T230037Z.txt
=== validate_product_mode ===
CMD: node scripts/qa/validate_product_mode.js
LOG: qa/approval_gates/validate_product_mode_log_2026-05-20T230037Z.txt

- validate_product_mode: exit=0 log=qa/approval_gates/validate_product_mode_log_2026-05-20T230037Z.txt
=== validate_neuro_spine_jurisprudence_corpus ===
CMD: node scripts/qa/validate_neuro_spine_jurisprudence_corpus.js
LOG: qa/approval_gates/validate_neuro_spine_jurisprudence_corpus_log_2026-05-20T230037Z.txt

- validate_neuro_spine_jurisprudence_corpus: exit=0 log=qa/approval_gates/validate_neuro_spine_jurisprudence_corpus_log_2026-05-20T230037Z.txt
=== validate_pathology_template_bank ===
CMD: node scripts/qa/validate_pathology_template_bank.js
LOG: qa/approval_gates/validate_pathology_template_bank_log_2026-05-20T230037Z.txt

- validate_pathology_template_bank: exit=0 log=qa/approval_gates/validate_pathology_template_bank_log_2026-05-20T230037Z.txt

## Result

- Suite: OK (9/9)
