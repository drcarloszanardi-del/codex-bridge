# Guardia nocturna clínica — Suite QA

- Fecha (UTC): 2026-05-20T175352Z
- Repo: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal
- Contrato operativo: /Users/jarvis/.openclaw/workspace/state/clinica_medicolegal/jarvis_clinica_contract.json

## Resultado
- Estado: **OK (9/9 validadores)**
- Log suite: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/guardia_nocturna_suite_log_2026-05-20T175352Z.txt

## Validadores ejecutados (todos OK)
1) node scripts/qa/validate_jarvis_overnight_requests.js
   - Out: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/jarvis_overnight_requests_2026-05-20.json
   - Summary: ok=true, requests_count=24, failures_count=0

2) node scripts/qa/validate_20_pathology_scenarios.js
   - Out: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/clinical_20_pathology_scenarios_2026-05-20.json
   - Summary: ok=true, cases_count=20, failures_count=0

3) node scripts/qa/validate_jarvis_wrapper.js
   - Summary: ok=true, wrapper_exists=true, blocked_status=BLOQUEADO_NO_ENVIAR

4) node scripts/qa/validate_clinical_handoff.js
   - Summary: ok=true, manifests_exist=true, blocked_status=BLOQUEADO_NO_ENVIAR

5) node scripts/qa/validate_consent_handoff.js
   - Summary: ok=true

6) node scripts/qa/validate_neurocirugia_consent_source_corpus.js
   - Summary: ok=true, total_files_seen=1339, extraction_failures=3 (tolerado), failures=[]
   - Corpus latest: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/consent_source_corpus/neurocirugia_consent_source_corpus_latest.json

7) node scripts/qa/validate_product_mode.js
   - Summary: status=ok

8) node scripts/qa/validate_neuro_spine_jurisprudence_corpus.js
   - Summary: ok=true, records_count=19, failures=[]
   - Corpus latest: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_corpus_latest.json

9) node scripts/qa/validate_pathology_template_bank.js
   - Summary: ok=true, failures=[]
   - Bank: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/pathology_templates/pathology_template_bank_2026-05-20.json

## Checks solicitados (consentimientos)
- No leaks de paciente QA/QA2/Prueba/Wrapper/Ayudante en consentimiento: **OK** (validate_consent_handoff: content_no_qa_leak=true)
- Si falta paciente/DNI: **líneas punteadas**: **OK** (content_blank_patient_dni_lines=true)
- Si falta equipo: **default “Dr. Carlos Zanardi y equipo”**: **OK** (content_blank_default_team=true)

## Cambios realizados
- Ninguno (no se tocaron archivos de código).
