# Clinica full QA

Fecha: 2026-05-24T18:44:15.225Z
Estado: OK
Modo: full
Node: /Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node

## Suites

- OK route/validate_clinica_route_guard.js (5761 ms)
- OK jarvis/validate_jarvis_wrapper.js (5887 ms)
- OK documents/validate_clinical_handoff.js (25804 ms)
- OK documents/validate_consent_handoff.js (11514 ms)
- OK product/validate_product_mode.js (538 ms)
- OK medicolegal/validate_medicolegal_redaction_shield.js (92 ms)
- OK product/validate_clinical_inconsistency_audit.js (1221 ms)
- OK telegram_gate/validate_clinical_send_gate.js (27815 ms)
- OK corpus/validate_pathology_template_bank.js (112 ms)
- OK corpus/validate_neurocirugia_consent_source_corpus.js (122 ms)
- OK medicolegal/validate_neuro_spine_jurisprudence_corpus.js (93 ms)
- OK clinical_scenarios/validate_20_pathology_scenarios.js (152429 ms)
- OK clinical_matrix/validate_40_pathology_family_matrix.js (194469 ms)
- OK jarvis_synthetic_requests/validate_jarvis_overnight_requests.js (74980 ms)
- OK baseline/build_clinica_operational_baseline.js (249 ms)
- OK freshness/validate_latest_artifacts_freshness.js (140 ms)

## Politica

- Esto valida ruta local/app/Jarvis para prueba controlada.
- No convierte el tamiz medicolegal en certificacion legal terminal.
- Jarvis sigue obligado a usar wrapper unico y manifiesto apto.
- La corrida completa agrega corpus, jurisprudencia, matriz de 40 familias, 20 escenarios y pedidos sintéticos de Jarvis.
- Se verifica frescura de artefactos latest para detectar estado stale.
