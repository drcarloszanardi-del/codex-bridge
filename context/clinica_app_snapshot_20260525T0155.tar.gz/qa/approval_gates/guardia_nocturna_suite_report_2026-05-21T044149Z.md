# Guardia nocturna — app clínica medicolegal (suite QA)

- Suite TS (UTC): 2026-05-21T044149Z
- Resultado: **OK (9/9)**

## Evidencia
- Resumen: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/guardia_nocturna_suite_summary_2026-05-21T044149Z.md
- Log completo: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/guardia_nocturna_suite_log_2026-05-21T044149Z.txt
- Gate 20 patologías: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/clinical_20_pathology_scenarios_2026-05-21.json
- Requests overnight: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/jarvis_overnight_requests_2026-05-21.json

## Consentimientos (chequeo pedido)
- `validate_consent_handoff.js` pasó con:
  - `content_no_qa_leak=true` (sin "Paciente QA/QA2/Paciente prueba/Paciente Wrapper/Ayudante QA" en el contenido)
  - `content_blank_patient_dni_lines=true` (si faltan paciente/DNI quedan líneas punteadas)
  - `content_blank_default_team=true` (si falta equipo queda "Dr. Carlos Zanardi y equipo")

## Falla detectada y corrección
- Falla original (suite previa): `validate_20_pathology_scenarios.js` → `pdf_text_extract_failed:ETIMEDOUT` (extracción de texto PDF con timeout, intermitente).
- Fix aplicado: robustecí `pdfText()` en `scripts/qa/validate_20_pathology_scenarios.js`:
  - timeout default más alto (60s)
  - espera breve a archivo estable antes de extraer
  - retry automático si el extractor devuelve `ETIMEDOUT`

## Archivos tocados
- /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/qa/validate_20_pathology_scenarios.js

## Restricciones respetadas
- Sin envío por Telegram, sin cambios en tokens/chat_ids/secrets, sin tocar gateway core.
- Sin cambios en el contrato: /Users/jarvis/.openclaw/workspace/state/clinica_medicolegal/jarvis_clinica_contract.json
