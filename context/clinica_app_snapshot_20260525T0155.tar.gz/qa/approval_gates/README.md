# Approval gates

Este directorio guarda salidas de QA del bootstrap detect-only medicolegal.

- `bootstrap_detect_only_summary.json`: resumen estructurado de la corrida local.
- `clinica_core_qa_latest.json|md`: último resultado de la suite core (route guard, wrapper, handoff, send gate).
- `clinica_full_qa_latest.json|md`: último resultado de la suite full (incluye corpus, matriz 40 familias y escenarios).
- `medicolegal_detect_only_update_cycle_latest.json|md`: último ciclo detect-only con compuerta de seguridad.
- `clinica_operational_baseline_latest.json|md`: baseline operativo con hashes de artefactos críticos.
- `latest_artifacts_freshness_YYYY-MM-DD.json`: control de frescura y completitud de artefactos `latest` para detectar estado stale.
