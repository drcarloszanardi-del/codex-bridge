# Guardia nocturna clínica — suite QA (2026-05-20T150122Z)

## Resultado
- ok: true (9/9 validadores)
- cambios de código: ninguno
- entregas externas (Telegram/email): ninguna (solo validación de `send_command` y manifiestos)

## Validadores ejecutados
1) `node scripts/qa/validate_jarvis_overnight_requests.js`
   - ok: true
   - reporte: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/jarvis_overnight_requests_2026-05-20.json`

2) `node scripts/qa/validate_20_pathology_scenarios.js`
   - ok: true
   - reporte: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/clinical_20_pathology_scenarios_2026-05-20.json`

3) `node scripts/qa/validate_jarvis_wrapper.js`
   - ok: true

4) `node scripts/qa/validate_clinical_handoff.js`
   - ok: true

5) `node scripts/qa/validate_consent_handoff.js`
   - ok: true
   - foco consentimientos:
     - nunca salen con `Paciente QA`, `QA2`, `Paciente prueba`, `Paciente Wrapper`, `Paciente Bloqueo` o `Ayudante QA`.
     - si faltan paciente/DNI: quedan líneas de puntos.
     - si falta equipo o es placeholder: default `Dr. Carlos Zanardi y equipo`.

6) `node scripts/qa/validate_neurocirugia_consent_source_corpus.js`
   - ok: true
   - reporte: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/neurocirugia_consent_source_corpus_validation_2026-05-20.json`

7) `node scripts/qa/validate_product_mode.js`
   - status: ok

8) `node scripts/qa/validate_neuro_spine_jurisprudence_corpus.js`
   - ok: true
   - reporte: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/neuro_spine_jurisprudence_validation_2026-05-20.json`

9) `node scripts/qa/validate_pathology_template_bank.js`
   - ok: true
   - reporte: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/pathology_template_bank_validation_2026-05-20.json`

## Notas de control
- `send_command` verificado en manifiestos: usa `telegram_send_document_guard.js` y no ejecuta `--send`.
- Contrato Jarvis clínica: no requirió intervención (sin fallas que corrijan origen).
