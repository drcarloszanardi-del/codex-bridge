# Guardia nocturna suite — 2026-05-21T020417Z

- Resultado: OK (9/9) — `fails=0`
- Log suite: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/guardia_nocturna_suite_log_2026-05-21T020417Z.txt

## Artefactos principales (qa/approval_gates)
- Overnight requests (24): /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/jarvis_overnight_requests_2026-05-21.json
- 20 escenarios patología (56 docs / 16 consents): /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/clinical_20_pathology_scenarios_2026-05-21.json
- Jurisprudencia neuro-spine: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/neuro_spine_jurisprudence_validation_2026-05-21.json
- Banco de plantillas: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/pathology_template_bank_validation_2026-05-21.json

## Consentimientos — guardrails verificados
- Sin leaks de QA: no aparecen `Paciente QA`, `QA2`, `Paciente prueba`, `Paciente Wrapper`, `Ayudante QA`.
- Si faltan `paciente`/`DNI`: quedan líneas de puntos (no se inventan datos).
- Si falta equipo: queda default `Dr. Carlos Zanardi y equipo`.
- 1 carilla + estándar visual/contenido vigente + manifest con `send_command` validado (sin `--send`).

## Cambios / fixes
- Fallas corregidas: ninguna (suite completa en verde).
- Archivos tocados: ninguno.

## Validadores ejecutados
- validate_jarvis_overnight_requests
- validate_20_pathology_scenarios
- validate_jarvis_wrapper
- validate_clinical_handoff
- validate_consent_handoff (QA-leak guard + dots/team defaults)
- validate_neurocirugia_consent_source_corpus
- validate_product_mode
- validate_neuro_spine_jurisprudence_corpus
- validate_pathology_template_bank
