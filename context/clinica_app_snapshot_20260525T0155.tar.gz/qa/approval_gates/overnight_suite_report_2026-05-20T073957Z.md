# Overnight QA suite report

- run_ts_utc: 2026-05-20T073957Z
- host_tz: America/Argentina/Buenos_Aires
- cwd: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal

## Commands

1. node scripts/qa/validate_jarvis_overnight_requests.js
2. node scripts/qa/validate_20_pathology_scenarios.js
3. node scripts/qa/validate_jarvis_wrapper.js
4. node scripts/qa/validate_clinical_handoff.js
5. node scripts/qa/validate_consent_handoff.js
6. node scripts/qa/validate_neurocirugia_consent_source_corpus.js
7. node scripts/qa/validate_product_mode.js
8. node scripts/qa/validate_neuro_spine_jurisprudence_corpus.js
9. node scripts/qa/validate_pathology_template_bank.js


## Output
{
  "ok": true,
  "requests_count": 24,
  "files_generated_count": 24,
  "failures_count": 0,
  "outPath": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/jarvis_overnight_requests_2026-05-20.json",
  "failures": []
}
{
  "ok": true,
  "cases_count": 20,
  "documents_count": 56,
  "consent_documents_count": 16,
  "failures_count": 0,
  "outPath": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/clinical_20_pathology_scenarios_2026-05-20.json",
  "failures": []
}
{
  "ok": true,
  "checks": {
    "wrapper_exists": true,
    "hc_pdf_created": true,
    "hc_validated": true,
    "consent_pdf_created": true,
    "consent_validated": true,
    "blocked_without_pdf_send": true,
    "no_external_converter_needed": true
  },
  "hc": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/historia_clinica_lumbar_hdl_clinica_centro_paciente_wrapper_20260520T074232Z.pdf",
  "consent": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/consentimiento_hernia_disco_lumbar_clinica_centro_paciente_wrapper_20260520T074233Z.pdf",
  "blocked_status": "BLOQUEADO_NO_ENVIAR"
}
{
  "ok": true,
  "checks": {
    "hc_ok": true,
    "parte_ok": true,
    "consent_delegated_hard_gate_ok": true,
    "manifests_exist": true,
    "app_source_locked": true,
    "generated_by_app_not_free_text": true,
    "medico_legal_check_required": true,
    "red_blocks_delivery": true,
    "hc_root_side_level_ok": true,
    "hc_no_unsolicited_motor": true,
    "hc_no_forbidden": true,
    "parte_has_sequence": true,
    "parte_no_forbidden": true,
    "consent_text_ok": true,
    "incomplete_case_blocked": true
  },
  "files": {
    "hc": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/historia_clinica_lumbar_hdl_clinica_centro_paciente_qa_20260520T074235Z.pdf",
    "parte": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/protocolo_quirurgico_lumbar_hdl_clinica_centro_paciente_qa_20260520T074235Z.pdf",
    "consent": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/consentimiento_hernia_disco_lumbar_clinica_centro_paciente_qa_20260520T074236Z.pdf"
  },
  "manifests": {
    "hc": "/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/historia_clinica_lumbar_hdl_clinica_centro_paciente_qa_20260520T074235Z.json",
    "parte": "/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/protocolo_quirurgico_lumbar_hdl_clinica_centro_paciente_qa_20260520T074235Z.json",
    "consent": "/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/consentimiento_hernia_disco_lumbar_clinica_centro_paciente_qa_20260520T074236Z.json"
  },
  "blocked_status": "BLOQUEADO_NO_ENVIAR"
}
{
  "ok": true,
  "checks": {
    "pdf_exists": true,
    "pdf_one_page": true,
    "visual_standard_id_ok": true,
    "visual_standard_rule_ok": true,
    "visual_all_institution_pdfs_exist": true,
    "visual_all_institution_one_page": true,
    "visual_all_institution_standard_id": true,
    "visual_no_institution_labels_in_text": true,
    "visual_no_duplicate_institution_text": true,
    "content_standard_id_ok": true,
    "content_standard_rule_ok": true,
    "content_guard_manifest_ok": true,
    "hard_validation_before_send_ok": true,
    "manifest_validation_ok": true,
    "manifest_format_not_content": true,
    "manifest_content_slug_ok": true,
    "content_mentions_requested_pathology": true,
    "content_not_hernia": true,
    "content_r1_patient_act": true,
    "content_r2_diagnosis_indication": true,
    "content_r3_procedure_specific": true,
    "content_r4_specific_risks": true,
    "content_r5_alternatives_no_treat": true,
    "content_r6_autonomy_questions_revocation": true,
    "content_r7_signatures_license": true,
    "content_r8_hc_copy_access": true,
    "content_anesthesia_blood_no_guarantee": true,
    "content_no_placeholders": true,
    "content_no_forbidden_open_phrases": true
  },
  "manifest": "/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/consentimiento_canal_estrecho_lumbar_con_fijacion_clinica_centro_paciente_qa_centro_20260520T074238Z.json",
  "file": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/consentimiento_canal_estrecho_lumbar_con_fijacion_clinica_centro_paciente_qa_centro_20260520T074238Z.pdf",
  "visual_files": [
    "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/consentimiento_canal_estrecho_lumbar_con_fijacion_clinica_centro_paciente_qa_centro_20260520T074238Z.pdf",
    "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/consentimiento_canal_estrecho_lumbar_con_fijacion_la_pequena_familia_paciente_qa_familia_20260520T074239Z.pdf",
    "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/consentimiento_canal_estrecho_lumbar_con_fijacion_higa_junin_paciente_qa_hospital_20260520T074242Z.pdf"
  ]
}
{
  "generated_at": "2026-05-20T07:42:45.862Z",
  "ok": true,
  "corpus_path": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/consent_source_corpus/neurocirugia_consent_source_corpus_latest.json",
  "pack_path": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/consent_canonicals/consent_body_pack_2026-05-19.json",
  "total_files_seen": 1339,
  "extraction_failures": 3,
  "unique_sources": 934,
  "families_count": 19,
  "pack_enriched": true,
  "failures": []
}
{
  "product_html": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/app/product.html",
  "family_options": 44,
  "manual_family_status_ok": true,
  "document_uses_template_mother": true,
  "legal_gate_items": 8,
  "legal_score_review_only": true,
  "correction_logged": true,
  "export_manifest_summary_visible": true,
  "export_detect_only_sources_visible": true,
  "no_forbidden_visible_phrases": true,
  "lumbar_hdl_root_side_level_ok": true,
  "no_unsolicited_motor_deficit_hc": true,
  "cervical_hc_style_ok": true,
  "consent_hernia_format_reused": true,
  "registry_loaded": true,
  "consent_supported": true,
  "dual_output_hc_parte_evolucion": true,
  "same_input_flow_visible": true,
  "medico_legal_gate_visible": true,
  "legal_update_supported": true,
  "quick_exceptions_visible": true,
  "review_queue_priority_visible": true,
  "status": "ok"
}
{
  "generated_at": "2026-05-20T07:42:46.171Z",
  "ok": true,
  "corpus_path": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_corpus_latest.json",
  "tamiz_path": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/medicolegal_tamiz/medicolegal_tamiz_pack_2026-05-19.json",
  "records_count": 16,
  "official_records_count": 12,
  "secondary_records_count": 4,
  "doctrine_count": 1,
  "impact_rules_count": 6,
  "neuro_gates_count": 5,
  "failures": []
}
{
  "ok": true,
  "bank_path": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/pathology_templates/pathology_template_bank_2026-05-20.json",
  "legacy_registry": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/template_mothers/template_mother_registry_2026-05-19.json",
  "candidate_total": 3635,
  "sampled_total": 883,
  "family_count": 40,
  "required_present": 12,
  "privacy_mode": "derived_templates_and_counts_only_no_patient_text_no_file_names",
  "failures": []
}

## Summary
All commands completed (exit 0).
