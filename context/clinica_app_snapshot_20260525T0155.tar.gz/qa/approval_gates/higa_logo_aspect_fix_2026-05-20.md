# Corrección logo HIGA Junín / Hospital Piñeyro

Fecha: 2026-05-20

## Hallazgo

El logo HIGA usado por la ruta canónica de consentimientos apuntaba a `clinica/logos/hospital_junin_logo.svg.png`, un PNG de 1200x1200 con el logo real dentro de un lienzo cuadrado. En algunos flujos esto podía renderizarse con proporción visual incorrecta o con exceso de aire.

## Corrección aplicada

- Se generó `clinica/logos/hospital_junin_logo_limpio.png`, recortado al contenido real y con fondo blanco transparente.
- Se actualizó el índice y pack canónico de consentimientos para `higa_junin`.
- Se actualizó la app para usar el logo limpio en HIGA.
- Se reforzaron `export_consent_artifact.py` y `export_clinical_document_pdf.py` para insertar logos por caja máxima preservando proporción real.
- Se fijó la regla permanente en `docs/consentimiento_visual_standard.md`, `docs/jarvis_telegram_consent_handoff.md`, `docs/JARVIS_CONTRATO_OPERATIVO_CLINICA_2026-05-20.md`, `docs/RUTA_UNICA_JARVIS_CLINICA.md` y `/Users/jarvis/.openclaw/workspace/state/clinica_medicolegal/jarvis_clinica_contract.json`.

## Prueba

- Consentimiento HIGA generado por la ruta Jarvis:
  - `exports/telegram_ready/consentimiento_canal_estrecho_lumbar_con_fijacion_higa_junin_paciente_20260520T102608Z.pdf`
  - Estado: `APTO_PARA_ENVIO`
  - Una carilla: OK
  - Matrícula: `MP 63905 MN 116564`
  - Paciente/DNI no informados: líneas de puntos, sin datos QA.
- Render visual revisado: logo HIGA proporcionado, no deformado.
- Historia clínica HIGA y protocolo HIGA generados con validación `APTO_PARA_ENVIO`.

## Validaciones

- `node scripts/qa/validate_consent_handoff.js`: OK
- `node scripts/qa/validate_jarvis_wrapper.js`: OK
- `node scripts/qa/validate_jarvis_overnight_requests.js`: OK, 24 pedidos, 0 fallas
- `node scripts/build_cli_app_candidate_manifest.js`: OK
