# Guardia nocturna — resumen

- Run (UTC): 2026-05-20T230037Z
- Suite: OK (9/9)
- Reporte: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/guardia_nocturna_suite_report_2026-05-20T230037Z.md
- Log suite: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/guardia_nocturna_suite_log_2026-05-20T230037Z.txt
