# Guardia Nocturna Jarvis - Bootstrap 2026-05-20

Estado inicial: APTO.

## Validaciones corridas

- `validate_jarvis_overnight_requests.js`: OK, 24 pedidos, 24 archivos, 0 fallas.
- `validate_20_pathology_scenarios.js`: OK, 20 casos, 56 documentos, 16 consentimientos, 0 fallas.
- `validate_jarvis_wrapper.js`: OK.
- `validate_clinical_handoff.js`: OK.
- `validate_consent_handoff.js`: OK.
- `validate_neurocirugia_consent_source_corpus.js`: OK, 1339 archivos revisados, 934 fuentes clínicas únicas, 19 familias, 3 fallos de extracción, pack canónico enriquecido.
- `validate_product_mode.js`: OK.
- `validate_consent_handoff.js`: incluye regla anti-QA y caso sin paciente/DNI, OK.
- `validate_neuro_spine_jurisprudence_corpus.js`: OK, 16 registros, 12 oficiales, 6 reglas de impacto, 5 gates neuro.
- `validate_pathology_template_bank.js`: OK, 3635 candidatos, 883 muestreados, 40 familias.
- `build_cli_app_candidate_manifest.js`: OK.

## Ajustes operativos fijados

- Contrato humano: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/docs/JARVIS_CONTRATO_OPERATIVO_CLINICA_2026-05-20.md`
- Contrato legible por maquina: `/Users/jarvis/.openclaw/workspace/state/clinica_medicolegal/jarvis_clinica_contract.json`
- Ruta unica actualizada: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/docs/RUTA_UNICA_JARVIS_CLINICA.md`
- Corpus fuente de consentimientos Neurocirugia: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/consent_source_corpus/neurocirugia_consent_source_corpus_latest.json`
- Fix de defaults paciente/DNI/equipo: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/consent_patient_dni_defaults_fix_2026-05-20.md`

## Automatizacion

- `guardia-nocturna-clinica-jarvis`: activa.
- Frecuencia: una vez por hora durante 8 corridas.
- Politica: corregir fallas dentro de la app/puente, no enviar Telegram salvo pedido humano explicito.
