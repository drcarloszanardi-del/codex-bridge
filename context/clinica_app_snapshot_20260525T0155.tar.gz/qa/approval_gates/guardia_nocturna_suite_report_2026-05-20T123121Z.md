# Guardia nocturna — suite QA (2026-05-20)

Fecha/hora (UTC): `2026-05-20T123121Z`

## Resultado
- **VERDE**: todos los validadores pedidos finalizaron `ok:true`.
- **Fix aplicado**: ajuste de timeout/robustez en `scripts/qa/validate_20_pathology_scenarios.js` para evitar falso negativo en casos lentos (T20 `otros_valvulas_hidrocefalia` / `parte`).
- **Telegram**: no se envió nada; solo manifests y `send_command` verificados.

## Evidencia (salidas en `qa/approval_gates`)
- `jarvis_overnight_requests_2026-05-20.json` (24 requests, 0 fallas)
- `clinical_20_pathology_scenarios_2026-05-20.json` (20 casos, 56 docs, 0 fallas)
- `pathology_template_bank_validation_2026-05-20.json` (ok)
- `neuro_spine_jurisprudence_validation_2026-05-20.json` (ok)
- `neurocirugia_consent_source_corpus_validation_2026-05-20.json` (ok)

## Suite ejecutada (orden)
1) `node scripts/qa/validate_jarvis_overnight_requests.js` → OK (`outPath` en `jarvis_overnight_requests_2026-05-20.json`)
2) `node scripts/qa/validate_20_pathology_scenarios.js` → OK (`outPath` en `clinical_20_pathology_scenarios_2026-05-20.json`)
3) `node scripts/qa/validate_jarvis_wrapper.js` → OK
4) `node scripts/qa/validate_clinical_handoff.js` → OK
5) `node scripts/qa/validate_consent_handoff.js` → OK
6) `node scripts/qa/validate_neurocirugia_consent_source_corpus.js` → OK
7) `node scripts/qa/validate_product_mode.js` → OK
8) `node scripts/qa/validate_neuro_spine_jurisprudence_corpus.js` → OK
9) `node scripts/qa/validate_pathology_template_bank.js` → OK

## Chequeo específico: consentimientos (QA leaks / defaults)
Validado por `validate_consent_handoff.js`:
- No aparece `Paciente QA`, `QA2`, `Paciente prueba`, `Paciente Wrapper` ni `Ayudante QA` en el cuerpo del consentimiento (`content_no_qa_leak`).
- Si faltan `paciente/DNI`, quedan líneas punteadas (`content_blank_patient_dni_lines`).
- Si falta equipo, queda `Dr. Carlos Zanardi y equipo` (`content_blank_default_team`).

## Archivos tocados
- `scripts/qa/validate_20_pathology_scenarios.js` (timeout por defecto y manejo de timeouts/errores para evitar bloqueos/falsos negativos).

