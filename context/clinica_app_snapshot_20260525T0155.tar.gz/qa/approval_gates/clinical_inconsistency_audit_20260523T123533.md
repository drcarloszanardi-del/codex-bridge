# Clinical Inconsistency Audit

Fecha: 2026-05-23T12:35:28.309Z
Estado: OK
Escenarios: 12
Documentos renderizados: 19
Ollama local: no disponible

## Fallas

- Sin fallas detectadas.

## Alcance

- Auditor local determinístico, sin API tokens.
- Detecta inconsistencias de redacción clínica, inferencias no soportadas y secuencia operatoria básica.
- Ollama se informa como disponible solo para prechequeos baratos; no es autoridad médico-legal final.
