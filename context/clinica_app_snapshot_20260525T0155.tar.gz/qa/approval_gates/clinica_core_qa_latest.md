# Clinica core QA

Fecha: 2026-05-25T03:08:09.998Z
Estado: OK
Modo: core
Node: /Users/jarvis/.openclaw/tools/node-v22.22.0/bin/node

## Suites

- OK route/validate_clinica_route_guard.js (24614 ms)
- OK jarvis/validate_jarvis_wrapper.js (34943 ms)
- OK documents/validate_clinical_handoff.js (152080 ms)
- OK documents/validate_consent_handoff.js (29064 ms)
- OK product/validate_product_mode.js (2086 ms)
- OK medicolegal/validate_medicolegal_redaction_shield.js (223 ms)
- OK product/validate_clinical_inconsistency_audit.js (2112 ms)
- OK telegram_gate/validate_clinical_send_gate.js (116477 ms)

## Politica

- Esto valida ruta local/app/Jarvis para prueba controlada.
- No convierte el tamiz medicolegal en certificacion legal terminal.
- Jarvis sigue obligado a usar wrapper unico y manifiesto apto.
