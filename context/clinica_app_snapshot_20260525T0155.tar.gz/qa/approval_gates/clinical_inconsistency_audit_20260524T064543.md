# Clinical Inconsistency Audit

Fecha: 2026-05-24T06:45:43.225Z
Estado: OK
Escenarios: 12
Documentos renderizados: 19
Ollama local: disponible (qwen2.5:0.5b, smollm2:135m)

## Fallas

- Sin fallas detectadas.

## Alcance

- Auditor local determinístico, sin API tokens.
- Detecta inconsistencias de redacción clínica, inferencias no soportadas y secuencia operatoria básica.
- Ollama se informa como disponible solo para prechequeos baratos; no es autoridad médico-legal final.
