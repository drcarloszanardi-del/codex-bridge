# CLI-APP-001 · circuito sintético local contra gate de 6 controles

Fecha de corte: 2026-05-19
Estado prudente: review_only_candidate_pending_codex_guard
Objetivo: dejar archivada evidencia local y trazable de un circuito sintético completo de historia clínica + parte quirúrgico + evolución POI, validado contra el gate formal de 6 controles antes de la auditoría Codex Guard.

## Artefactos del circuito
- Manifest auditable: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/cli_app_candidate_manifest_2026-05-19.json`
- Producto candidato local: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/app/product.html`
- Mock HTML exportado del circuito: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/2026-05-19/mock_producto_final_l4l5_circunferencial_tamiz_medicolegal.html`
- Plantillas madre: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/template_mothers/template_mother_registry_2026-05-19.json`
- Tamiz médico-legal: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/medicolegal_tamiz/medicolegal_tamiz_pack_2026-05-19.json`
- Producto objetivo: `/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/docs/PRODUCTO_OBJETIVO_2026-05-19.md`

## Cobertura del circuito sintético archivado
1. Entrada coloquial única del médico.
2. Historia clínica base generada.
3. Parte quirúrgico base generado.
4. Evolución postoperatoria inmediata base generada.
5. Separación visible entre dato confirmado, redacción estándar defensiva permitida y dato crítico no inventable.
6. Lista explícita de faltantes críticos y alertas prudentes.

## Gate formal de 6 controles, validación local
1. **Identificación completa del acto**: PARCIAL.
   - Evidencia: en el mock se exponen paciente, institución y cirujano, pero edad/fecha/hora siguen marcados para completar.
   - Fuente: mock exportado, secciones de HC/parte/evolución.
2. **Consentimiento con contenido material**: PARCIAL.
   - Evidencia: la historia clínica deja la constancia narrativa de información, riesgos, beneficios y alternativas; no adjunta consentimiento auditado en este circuito sintético.
   - Fuente: mock exportado, bloque “Se informaron al paciente...”.
3. **Parte quirúrgico completo y cronológico**: PARCIAL.
   - Evidencia: técnica base y secuencia operatoria narradas; horarios, hallazgos definitivos, implantes/lotes y destino siguen abiertos.
   - Fuente: mock exportado, parte quirúrgico + faltantes críticos.
4. **Addendas sin borrado**: PARCIAL.
   - Evidencia: `product.html` incluye panel “Correcciones aplicadas” y aplicación dirigida por documento/caso, pero el mock estático no prueba una addenda consolidada final con fecha/hora de corrección.
   - Fuente: `/app/product.html` y flujo local de correcciones.
5. **Confidencialidad y acceso mínimo**: OK en entorno de prueba.
   - Evidencia: circuito armado con “Paciente prueba” y sin datos reales del paciente; uso local review_only.
   - Fuente: mock exportado y estado review_only del candidato.
6. **Integridad, autenticidad y auditoría**: PARCIAL.
   - Evidencia: existe manifest con hashes y mtimes de archivos críticos; todavía falta veredicto Codex Guard `APTO_PARA_ENTREGAR` y gate local final.
   - Fuente: manifest auditable + estado pending_codex_guard.

## Conclusión operativa
- El circuito sintético completo ya existe como evidencia local trazable.
- El candidato demuestra el flujo único pedido: audio/texto coloquial -> historia clínica base + parte quirúrgico base + evolución POI base.
- El cuello de botella actual ya no es “si existe circuito sintético”, sino la auditoría final de Codex Guard y el cierre de compuerta local.
- Estado prudente correcto: **NO entregar** y mantener `review_only_candidate_pending_codex_guard`.

## Huellas del candidato al momento del archivo
- `app/product.html` sha256 `814f809b805476b958f92294f8ad772a785c6a9ab30837dd78f4982fc15e435a`
- `app/index.html` sha256 `e882a6d126ff03d978468e1306ff8d865ee3965065ea24d3025840a3293bf40e`
- `app/app.js` sha256 `cdf2b1391289cf60bd1b00736865e85d4a565be389d974e5518fc1b08c8de613`
- `template_mother_registry_2026-05-19.json` sha256 `cb568451e1122ba5991b5274facbc6f618a41b9fb89bf651d1ec3c04022e2f05`
- `medicolegal_tamiz_pack_2026-05-19.json` sha256 `9015d88c76c63c11d20ff527fe8ffedabd217a2b2581343ef68fafa09c3f062b`
- `mock_producto_final_l4l5_circunferencial_tamiz_medicolegal.html` sha256 `054a675393100e1d37c84d0f558d052fa1a0197c9052f91b07b9b7ea5a8a999f`

## Siguiente paso permitido
Preparar/solicitar auditoría Codex Guard sobre este candidato congelado. No enviar PDF/ZIP/Telegram/mail final hasta `APTO_PARA_ENTREGAR` + `codex_guard_delivery_gate.js` OK.
