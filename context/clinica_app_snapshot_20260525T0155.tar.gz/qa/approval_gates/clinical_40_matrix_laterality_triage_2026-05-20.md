# CLINICA_MATRIX_QA - Laterality triage

Source: `clinical_40_family_matrix_2026-05-20.json`  
Validator reviewed: `scripts/qa/validate_40_pathology_family_matrix.js`  
Scope: classify the 44 failed documents, especially `lateralidad_no_presente`, without changing the app or production scripts.

## Executive finding

`clinical_40_family_matrix_2026-05-20.json` is `ok:false` because it records 44 failed documents out of 80. The dominant signal is `lateralidad_no_presente` (39 entries), but this triage did not find a direct real laterality blocker among those 39 entries.

Most lateralidad failures are rule-level false positives. Two mechanisms explain the bulk:

- The family/procedure is central, bilateral, midline, non-lateralized, or too generic to require a side by family alone.
- The PDF contains the side as `derecho` or `izquierdo`, while the stale matrix failure expected the feminine token `derecha` or `izquierda`.

The validator currently on disk already includes `sideVariants()` for `derecha/derecho` and `izquierda/izquierdo`, plus exemptions for families such as canal estrecho, laminoplastia, vertebroplastia, cifoplastia, biopsia vertebral, columna tumor, infeccion, Chiari, neurofisiologia and otros_neurocirugia. That suggests the existing JSON is stale relative to the current validator logic or was produced before those safeguards were present.

## Counts

Document-level categories:

| Category | Count |
|---|---:|
| `real_blocker` | 1 |
| `false_positive_rule` | 37 |
| `needs_context` | 4 |
| `template_gap` | 2 |

Lateralidad-only categories:

| Category | Count |
|---|---:|
| `real_blocker` | 0 |
| `false_positive_rule` | 35 |
| `needs_context` | 4 |
| `template_gap` | 0 |

Remaining blockers after laterality triage:

- `otros_tunel_carpiano_periferico` HC: `deficit_motor_no_declarado_en_el_caso`, real blocker. Manifest says `side_respected:true`, but `no_unsolicited_motor_deficit:false`.
- `otros_tunel_carpiano_periferico` parte: `parte_sin_secuencia_quirurgica_suficiente`, template gap. Manifest says `parte_core_sequence:false`, `side_respected:true`.
- `otros_monitoreo_pic` parte: `parte_sin_secuencia_quirurgica_suficiente`, template gap. Manifest says `parte_core_sequence:false`, `side_respected:true`.

## Practical criteria

Require laterality when the actual case is side-dependent:

- Hernia de disco, microdiscectomia, foramen/extraforaminal pathology, unilateral root compression or unilateral radiculopathy.
- Cervical/lumbar procedures when a root, foramen, side of symptoms, compression side, or unilateral approach is stated.
- Unilateral approaches: Wiltse unilateral decompression, TLIF/OLIF/XLIF access side, hemilaminectomy, foraminotomy, pterional/retrosigmoid/temporal/frontal craniotomy when approach side matters.
- Lateralized lesions: cranial tumors, abscesses, MAV/vascular lesions, quiste aracnoideo, CPA/fosa posterior lateral lesions when source text states side.
- Quiste facetario, sacroiliac block, trigeminal neuralgia, peripheral nerve/carpal tunnel, PIC sensor, DVP/DVE when affected/insertion side is known.

Do not require laterality by family alone when the procedure is central, midline, bilateral, or not lateralized:

- Central lumbar canal stenosis and central decompression/recalibraje.
- Multilevel cervical laminoplasty for central canal myelopathy.
- Bilateral fixation or stabilization when no unilateral access side is specified.
- Central vertebroplasty/cyphoplasty and vertebral body cementation without stated unipedicular side.
- Tumors, spinal lesions and infections when the source does not state a side.
- Chiari/fosa posterior midline decompression, neurophysiology monitoring and generic other-neurosurgery families without case detail.

Use context-sensitive rules for:

- Biopsia vertebral: side only if transpedicular/unipedicular approach, lateralized lesion, or needle entry side is stated.
- Bloqueo epidural: side for transforaminal/selective-root blocks; no side for interlaminar/caudal midline blocks.
- Artrodesis 360/MISS fixation: side only if route is unilateral; not for generic bilateral fixation in HC.
- Cranial tumors/vascular lesions: require side when lesion or craniotomy side is known; do not invent side for midline/unstated lesions.
- `otros_neurocirugia`: derive the requirement from extracted anatomy/procedure metadata, not from the bucket name.

## Classification table

| # | Family | Type | Failure(s) | Category | Rationale |
|---:|---|---|---|---|---|
| 1 | `columna_lumbar_canal_estrecho` | hc | `lateralidad_no_presente` | `false_positive_rule` | Central canal stenosis/recalibraje is not lateral by family alone. |
| 2 | `columna_lumbar_canal_estrecho` | parte | `lateralidad_no_presente` | `false_positive_rule` | Central decompression can be midline/bilateral without explicit side. |
| 3 | `columna_lumbar_fijacion_transpedicular` | hc | `lateralidad_no_presente` | `false_positive_rule` | Fixation HC does not need side for a bilateral/non-lateralized construct. |
| 4 | `columna_lumbar_espondilolistesis` | hc | `lateralidad_no_presente` | `false_positive_rule` | Espondilolistesis/fixation is not side-specific by family alone. |
| 5 | `columna_lumbar_360_circunferencial` | hc | `lateralidad_no_presente` | `false_positive_rule` | PDF contains `compromiso izquierdo`; approach side should be conditional. |
| 6 | `columna_interespinoso_coflex_diam` | hc | `lateralidad_no_presente` | `false_positive_rule` | Interspinous device is central/midline by default. |
| 7 | `columna_interespinoso_coflex_diam` | parte | `lateralidad_no_presente` | `false_positive_rule` | Family is not inherently lateralized. |
| 8 | `columna_cervical_disco_fusion` | hc | `lateralidad_no_presente` | `false_positive_rule` | PDF contains `compromiso derecho`; side is present as masculine variant. |
| 9 | `columna_cervical_artroplastia` | hc | `lateralidad_no_presente` | `false_positive_rule` | PDF contains `compromiso derecho`. |
| 10 | `columna_cervical_laminoplastia` | hc | `lateralidad_no_presente` | `false_positive_rule` | Multilevel laminoplasty is a central canal procedure. |
| 11 | `columna_cervical_laminoplastia` | parte | `lateralidad_no_presente` | `false_positive_rule` | C3-C7 laminoplasty is not side-specific by default. |
| 12 | `columna_vertebroplastia` | hc | `lateralidad_no_presente` | `false_positive_rule` | Vertebral body cementation is central unless pedicle side is stated. |
| 13 | `columna_vertebroplastia` | parte | `lateralidad_no_presente` | `false_positive_rule` | D12 cementation target is level-based in this case. |
| 14 | `columna_cifoplastia` | hc | `lateralidad_no_presente` | `false_positive_rule` | Kyphoplasty is not lateralized by family alone. |
| 15 | `columna_cifoplastia` | parte | `lateralidad_no_presente` | `false_positive_rule` | Side depends on unipedicular approach metadata. |
| 16 | `columna_biopsia_vertebral` | hc | `lateralidad_no_presente` | `needs_context` | Side depends on lateralized lesion or transpedicular entry side. |
| 17 | `columna_biopsia_vertebral` | parte | `lateralidad_no_presente` | `needs_context` | Protocol side depends on uni/bipedicular approach. |
| 18 | `columna_tumor` | hc | `lateralidad_no_presente` | `false_positive_rule` | Broad spinal tumor family is not lateralized unless source says so. |
| 19 | `columna_tumor` | parte | `lateralidad_no_presente` | `false_positive_rule` | D8 tumor protocol is level-based in this synthetic case. |
| 20 | `columna_infeccion_desbridamiento_retiro` | hc | `lateralidad_no_presente` | `false_positive_rule` | Infection/debridement is not side-specific without lateralized source data. |
| 21 | `columna_infeccion_desbridamiento_retiro` | parte | `lateralidad_no_presente` | `false_positive_rule` | No side of collection, wound, or implant was supplied. |
| 22 | `columna_quiste_facetario` | hc | `lateralidad_no_presente` | `false_positive_rule` | Side is clinically required and PDF contains `compromiso izquierdo`. |
| 23 | `tumor_glioma` | hc | `lateralidad_no_presente` | `false_positive_rule` | PDF contains `compromiso izquierdo`. |
| 24 | `tumor_fosa_posterior` | hc | `lateralidad_no_presente` | `false_positive_rule` | PDF contains `compromiso izquierdo`; fosa posterior side is conditional. |
| 25 | `tumor_estereotaxia_biopsia` | hc | `lateralidad_no_presente` | `false_positive_rule` | PDF contains `compromiso izquierdo`. |
| 26 | `tumor_angulo_pontocerebeloso` | hc | `lateralidad_no_presente` | `false_positive_rule` | PDF contains `compromiso izquierdo`. |
| 27 | `vascular_tvt_mav` | hc | `lateralidad_no_presente` | `false_positive_rule` | PDF contains `compromiso izquierdo`. |
| 28 | `malformacion_chiari` | hc | `nivel_no_presente` | `false_positive_rule` | Chiari should not use generic spinal-level hard check. |
| 29 | `malformacion_chiari` | parte | `nivel_no_presente` | `false_positive_rule` | Fosa posterior/union craneocervical wording is acceptable. |
| 30 | `malformacion_quiste_aracnoideo` | hc | `lateralidad_no_presente` | `false_positive_rule` | PDF contains `compromiso derecho`. |
| 31 | `otros_fistula_lcr` | hc | `lateralidad_no_presente` | `false_positive_rule` | PDF contains `compromiso derecho`; side required only if leak is localized. |
| 32 | `otros_neuralgia_trigemino` | hc | `lateralidad_no_presente` | `false_positive_rule` | PDF contains `compromiso derecho`. |
| 33 | `otros_tunel_carpiano_periferico` | hc | `handoff_failed:BLOQUEADO_NO_ENVIAR`, `deficit_motor_no_declarado_en_el_caso` | `real_blocker` | Unsupported motor deficit; manifest says side is respected. |
| 34 | `otros_tunel_carpiano_periferico` | parte | `handoff_failed:BLOQUEADO_NO_ENVIAR`, `parte_sin_secuencia_quirurgica_suficiente` | `template_gap` | Operative sequence insufficient; manifest says side is respected. |
| 35 | `otros_bloqueo_epidural` | hc | `lateralidad_no_presente` | `needs_context` | Epidural side depends on transforaminal/selective-root vs interlaminar/caudal route. |
| 36 | `otros_bloqueo_sacroiliaco` | hc | `lateralidad_no_presente` | `false_positive_rule` | PDF contains `compromiso derecho`; sacroiliac side is present. |
| 37 | `otros_absceso_cerebral` | hc | `lateralidad_no_presente` | `false_positive_rule` | PDF contains `compromiso izquierdo`. |
| 38 | `otros_craneoplastia` | hc | `lateralidad_no_presente` | `false_positive_rule` | PDF contains `compromiso izquierdo`. |
| 39 | `otros_monitoreo_pic` | hc | `lateralidad_no_presente` | `false_positive_rule` | PDF contains `compromiso derecho`. |
| 40 | `otros_monitoreo_pic` | parte | `handoff_failed:BLOQUEADO_NO_ENVIAR`, `parte_sin_secuencia_quirurgica_suficiente` | `template_gap` | Operative sequence insufficient; manifest says side is respected. |
| 41 | `otros_valvulas_hidrocefalia` | hc | `lateralidad_no_presente` | `false_positive_rule` | PDF contains `compromiso derecho`. |
| 42 | `neurofisiologia_monitorizacion` | hc | `lateralidad_no_presente` | `false_positive_rule` | Monitoring is not a lateralized procedure by itself. |
| 43 | `neurofisiologia_monitorizacion` | parte | `lateralidad_no_presente` | `false_positive_rule` | Inherit side requirement from base operation, not from monitoring family. |
| 44 | `otros_neurocirugia` | hc | `lateralidad_no_presente` | `needs_context` | Generic bucket is too broad; PDF contains side text but family cannot decide requirement. |

## Integration recommendations

1. Replace family-wide side hard checks with context-aware gating: `family + procedure_route + lesion_location + root_or_foramen + approach_side`.
2. Normalize Spanish morphology before matching: `derecha/derecho` and `izquierda/izquierdo` should satisfy the same side requirement.
3. Separate HC laterality from operative-protocol laterality: HC may need symptom/lesion side; protocol may need approach/entry side.
4. Prefer handoff manifest blockers over duplicate matrix checks when manifest says `side_respected:true` but another material blocker exists.
5. Add regression fixtures for central canal, laminoplasty, vertebro/cifoplasty, lateralized quiste facetario, trigeminal/PIC/DVP, epidural route variants, biopsy vertebral route variants and `otros_neurocirugia`.

No product files were modified. This is a QA triage and does not promise absolute legal certification.
