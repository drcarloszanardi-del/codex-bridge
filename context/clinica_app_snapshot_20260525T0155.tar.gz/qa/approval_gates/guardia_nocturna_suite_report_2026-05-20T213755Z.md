# Guardia nocturna clínica — suite QA (2026-05-20T213755Z)

## Resultado
- Estado general: **OK** (9/9 validadores en verde).
- Fixes aplicados: **ninguno** (no se tocaron archivos de código).

## Validadores ejecutados (comando → log)
1) node scripts/qa/validate_jarvis_overnight_requests.js
- Log: qa/approval_gates/validate_jarvis_overnight_requests_log_2026-05-20T213527Z.txt
- Output: qa/approval_gates/jarvis_overnight_requests_2026-05-20.json

2) node scripts/qa/validate_20_pathology_scenarios.js
- Log: qa/approval_gates/validate_20_pathology_scenarios_log_2026-05-20T211751Z.txt
- Output: qa/approval_gates/clinical_20_pathology_scenarios_2026-05-20.json

3) node scripts/qa/validate_jarvis_wrapper.js
- Log: qa/approval_gates/validate_jarvis_wrapper_log_2026-05-20T213132Z.txt

4) node scripts/qa/validate_clinical_handoff.js
- Log: qa/approval_gates/validate_clinical_handoff_log_2026-05-20T213207Z.txt

5) node scripts/qa/validate_consent_handoff.js
- Log: qa/approval_gates/validate_consent_handoff_log_2026-05-20T213319Z.txt

6) node scripts/qa/validate_neurocirugia_consent_source_corpus.js
- Log: qa/approval_gates/validate_neurocirugia_consent_source_corpus_log_2026-05-20T213448Z.txt

7) node scripts/qa/validate_product_mode.js
- Log: qa/approval_gates/validate_product_mode_log_2026-05-20T213458Z.txt

8) node scripts/qa/validate_neuro_spine_jurisprudence_corpus.js
- Log: qa/approval_gates/validate_neuro_spine_jurisprudence_corpus_log_2026-05-20T213512Z.txt

9) node scripts/qa/validate_pathology_template_bank.js
- Log: qa/approval_gates/validate_pathology_template_bank_log_2026-05-20T213520Z.txt

## Control específico — consentimientos (anti-QA + defaults)
Verificado por `validate_consent_handoff.js`:
- No sale ningún consentimiento con nombres de test/QA: **OK** (check `content_no_qa_leak=true`).
- Si falta paciente/DNI: quedan líneas punteadas (no se inventa): **OK** (`content_blank_patient_dni_lines=true`).
- Si falta equipo: queda default **"Dr. Carlos Zanardi y equipo"**: **OK** (`content_blank_default_team=true`).

## Evidencia adicional
- Contrato operativo vigente (sin envío Telegram; solo validación de manifests/outputs): /Users/jarvis/.openclaw/workspace/state/clinica_medicolegal/jarvis_clinica_contract.json
