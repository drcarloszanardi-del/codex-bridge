Guardia nocturna — suite QA (Clínica medicolegal)

- Timestamp (UTC): 2026-05-20T094634Z
- Repo: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal
- Contrato: /Users/jarvis/.openclaw/workspace/state/clinica_medicolegal/jarvis_clinica_contract.json

## Comandos ejecutados
1) node scripts/qa/validate_jarvis_overnight_requests.js
2) node scripts/qa/validate_20_pathology_scenarios.js
3) node scripts/qa/validate_jarvis_wrapper.js
4) node scripts/qa/validate_clinical_handoff.js
5) node scripts/qa/validate_consent_handoff.js
6) node scripts/qa/validate_neurocirugia_consent_source_corpus.js
7) node scripts/qa/validate_product_mode.js
8) node scripts/qa/validate_neuro_spine_jurisprudence_corpus.js
9) node scripts/qa/validate_pathology_template_bank.js

## Resultado
- Estado: OK (0 fallas)

## Gates/artefactos generados (principales)
- qa/approval_gates/jarvis_overnight_requests_2026-05-20.json
- qa/approval_gates/clinical_20_pathology_scenarios_2026-05-20.json
- qa/approval_gates/neurocirugia_consent_source_corpus_validation_2026-05-20.json
- qa/approval_gates/neuro_spine_jurisprudence_validation_2026-05-20.json
- qa/approval_gates/pathology_template_bank_validation_2026-05-20.json

## Derivados/exports (referencia)
- data/derived/consent_source_corpus/neurocirugia_consent_source_corpus_latest.json
- data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_corpus_latest.json
- data/derived/pathology_templates/pathology_template_bank_2026-05-20.json
- exports/telegram_ready/* (PDFs QA)
- /Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/* (manifests QA)

## Cambios en código/app
- Ninguno (solo outputs/gates/exports).
