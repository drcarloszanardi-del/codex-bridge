# CLI app short suite 2026-05-20T070807Z

## validate_clinical_handoff.js
```json
{
  "ok": true,
  "checks": {
    "hc_ok": true,
    "parte_ok": true,
    "consent_delegated_hard_gate_ok": true,
    "manifests_exist": true,
    "app_source_locked": true,
    "generated_by_app_not_free_text": true,
    "medico_legal_check_required": true,
    "red_blocks_delivery": true,
    "hc_root_side_level_ok": true,
    "hc_no_unsolicited_motor": true,
    "hc_no_forbidden": true,
    "parte_has_sequence": true,
    "parte_no_forbidden": true,
    "consent_text_ok": true,
    "incomplete_case_blocked": true
  },
  "files": {
    "hc": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/historia_clinica_lumbar_hdl_clinica_centro_paciente_qa_20260520T070807Z.pdf",
    "parte": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/protocolo_quirurgico_lumbar_hdl_clinica_centro_paciente_qa_20260520T070808Z.pdf",
    "consent": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/exports/telegram_ready/consentimiento_hernia_disco_lumbar_clinica_centro_paciente_qa_20260520T070809Z.pdf"
  },
  "manifests": {
    "hc": "/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/historia_clinica_lumbar_hdl_clinica_centro_paciente_qa_20260520T070807Z.json",
    "parte": "/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/protocolo_quirurgico_lumbar_hdl_clinica_centro_paciente_qa_20260520T070808Z.json",
    "consent": "/Users/jarvis/.openclaw/workspace/outbox/clinica_medicolegal/telegram_ready/consentimiento_hernia_disco_lumbar_clinica_centro_paciente_qa_20260520T070809Z.json"
  },
  "blocked_status": "BLOQUEADO_NO_ENVIAR"
}
```

## validate_product_mode.js
```json
{
  "product_html": "/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/app/product.html",
  "family_options": 44,
  "manual_family_status_ok": true,
  "document_uses_template_mother": true,
  "legal_gate_items": 8,
  "legal_score_review_only": true,
  "correction_logged": true,
  "export_manifest_summary_visible": true,
  "export_detect_only_sources_visible": true,
  "no_forbidden_visible_phrases": true,
  "lumbar_hdl_root_side_level_ok": true,
  "no_unsolicited_motor_deficit_hc": true,
  "cervical_hc_style_ok": true,
  "consent_hernia_format_reused": true,
  "registry_loaded": true,
  "consent_supported": true,
  "dual_output_hc_parte_evolucion": true,
  "same_input_flow_visible": true,
  "medico_legal_gate_visible": true,
  "legal_update_supported": true,
  "quick_exceptions_visible": true,
  "review_queue_priority_visible": true,
  "status": "ok"
}
```
