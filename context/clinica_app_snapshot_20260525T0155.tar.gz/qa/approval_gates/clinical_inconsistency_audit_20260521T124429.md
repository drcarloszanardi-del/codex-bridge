# Clinical Inconsistency Audit

Fecha: 2026-05-21T12:44:28.988Z
Estado: FALLA
Escenarios: 11
Documentos renderizados: 17
Ollama local: disponible (qwen2.5:0.5b, smollm2:135m)

## Fallas

- lumbar_radiculopatia_l5_derecha_sin_hernia/parte: global:placeholder_generico
  - entes intraoperatorios evidentes. Complicaciones: sin complicaciones evidentes. validar hallazgos y eventos reales
- lumbar_hernia_posterolateral_explicita/parte: global:placeholder_generico
  - entes intraoperatorios evidentes. Complicaciones: sin complicaciones evidentes. validar hallazgos y eventos reales
- laminoplastia_cervical_sin_formula_vaga/parte: global:placeholder_generico
  - orios evidentes. Complicaciones: sin complicaciones evidentes intraoperatorias. validar eventos reales

## Alcance

- Auditor local determinístico, sin API tokens.
- Detecta inconsistencias de redacción clínica, inferencias no soportadas y secuencia operatoria básica.
- Ollama se informa como disponible solo para prechequeos baratos; no es autoridad médico-legal final.
