# Clinica Operational Baseline

Fecha: 2026-05-24T14:34:04.223Z
Estado: OK
Producto: local_candidate_ready_for_user_test
Tamiz medico-legal: BASE_AVANZADA_REVIEW_ONLY

## Archivos Requeridos

- OK product_html: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/app/product.html
- OK product_logic: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/app/app.js
- OK jarvis_request_guard: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_request_guard.js
- OK jarvis_wrapper: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinica_generar_y_enviar.sh
- OK clinical_handoff: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/clinical_document_handoff.js
- OK consent_handoff: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/scripts/jarvis/consent_telegram_handoff.js
- OK telegram_text_guard: /Users/jarvis/.openclaw/workspace/scripts/send_telegram_message.js
- OK telegram_raw_document_guard: /Users/jarvis/.openclaw/workspace/scripts/send_telegram_document.js
- OK telegram_manifest_guard: /Users/jarvis/.openclaw/workspace/scripts/telegram_send_document_guard.js
- OK pathology_bank: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/pathology_templates/pathology_template_bank_2026-05-20.json
- OK template_mothers: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/template_mothers/template_mother_registry_2026-05-20.json
- OK consent_mothers: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/consent_mothers/consent_mother_registry_2026-05-19.json
- OK consent_source_corpus: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/consent_source_corpus/neurocirugia_consent_source_corpus_latest.json
- OK consent_canonical_index: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/consent_canonicals/consent_canonical_index_2026-05-19.json
- OK consent_body_pack: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/consent_canonicals/consent_body_pack_2026-05-19.json
- OK medicolegal_tamiz_pack: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/medicolegal_tamiz/medicolegal_tamiz_pack_2026-05-19.json
- OK jurisprudence_corpus: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_corpus_latest.json
- OK jurisprudence_impact_matrix: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/derived/jurisprudence_neuro_spine/jurisprudence_neuro_spine_impact_matrix_latest.md
- OK corpus_doc: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/docs/corpus_medicolegal_argentino.md
- OK impact_matrix_doc: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/docs/matriz_impacto_redaccional_hc_partes.md
- OK rules_doc: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/docs/reglas_internas_redaccion_medicolegal.md
- OK jarvis_contract_doc: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/docs/JARVIS_CONTRATO_OPERATIVO_CLINICA_2026-05-20.md
- OK core_qa_latest: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/clinica_core_qa_latest.json

## Archivos Opcionales

- OK full_qa_latest: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/clinica_full_qa_latest.json
- OK jarvis_overnight_requests: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/jarvis_overnight_requests_2026-05-20.json
- OK clinical_20_scenarios: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/clinical_20_pathology_scenarios_2026-05-20.json
- OK pathology_validation: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/pathology_template_bank_validation_2026-05-20.json
- OK consent_source_validation: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/neurocirugia_consent_source_corpus_validation_2026-05-20.json
- OK jurisprudence_validation: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/qa/approval_gates/neuro_spine_jurisprudence_validation_2026-05-20.json

## Metricas

- Familias de patologias: 40
- Candidatos de plantillas: 3635
- Fuentes unicas de consentimientos: 934
- Familias de consentimientos fuente: 19
- Core QA: OK
- Full QA: OK

## Limites

- Este baseline fija artefactos y hashes; no certifica juridicamente el contenido.
- Jarvis sigue sin permiso para redactar documentos clinicos por fuera del wrapper.
