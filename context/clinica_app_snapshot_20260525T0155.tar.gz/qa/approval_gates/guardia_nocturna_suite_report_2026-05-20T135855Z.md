# Guardia nocturna — Suite QA (clínica medicolegal)

- run_utc: 2026-05-20T135855Z
- repo: /Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal
- git_head: 82cd455

## Comandos ejecutados (en orden) — todos OK
1) node scripts/qa/validate_jarvis_overnight_requests.js
2) node scripts/qa/validate_20_pathology_scenarios.js
3) node scripts/qa/validate_jarvis_wrapper.js
4) node scripts/qa/validate_clinical_handoff.js
5) node scripts/qa/validate_consent_handoff.js
6) node scripts/qa/validate_neurocirugia_consent_source_corpus.js
7) node scripts/qa/validate_product_mode.js
8) node scripts/qa/validate_neuro_spine_jurisprudence_corpus.js
9) node scripts/qa/validate_pathology_template_bank.js

## Evidencia / outputs principales
- qa/approval_gates/bootstrap_detect_only_summary.json
- qa/approval_gates/cli_app_candidate_manifest_2026-05-19.json
- qa/approval_gates/cli_app_candidate_manifest_2026-05-20.json
- qa/approval_gates/cli_app_candidate_manifest_latest.json
- qa/approval_gates/cli_app_missing_fields_dry_run_2026_05_18.json
- qa/approval_gates/cli_app_neuro_ingest_priority_2026_05_18_summary.json
- qa/approval_gates/cli_app_opus_neuro_reconciliation_2026_05_18.json
- qa/approval_gates/cli_app_product_mode_validation_2026-05-19.json
- qa/approval_gates/cli_app_product_visual_cdp_2026-05-19.json
- qa/approval_gates/cli_app_review_only_integration_gate_2026_05_18.json
- qa/approval_gates/cli_app_taxonomy_extractor_qa_2026_05_18.json
- qa/approval_gates/clinical_20_pathology_scenarios_2026-05-20.json
- qa/approval_gates/clinical_dry_run_summary.json
- qa/approval_gates/consent_mother_registry_2026-05-19_summary.json
- qa/approval_gates/jarvis_overnight_requests_2026-05-20.json
- qa/approval_gates/medicolegal_corpus_background_summary.json
- qa/approval_gates/medicolegal_tamiz_pack_2026-05-19_summary.json
- qa/approval_gates/medicolegal_update_detect_only_summary.json
- qa/approval_gates/neuro_spine_jurisprudence_corpus_2026-05-20_summary.json
- qa/approval_gates/neuro_spine_jurisprudence_validation_2026-05-20.json
- qa/approval_gates/neurocirugia_consent_source_corpus_2026-05-20.json
- qa/approval_gates/neurocirugia_consent_source_corpus_validation_2026-05-20.json
- qa/approval_gates/pathology_template_bank_2026-05-20_summary.json
- qa/approval_gates/pathology_template_bank_validation_2026-05-20.json
- qa/approval_gates/template_mother_registry_2026-05-19_summary.json

## Chequeo especial consentimientos (requerimiento)
- No leaks de valores de QA en texto: PASA (validator `validate_consent_handoff.js`: `content_no_qa_leak:true`)
- Si falta paciente/DNI: deja líneas punteadas: PASA (`content_blank_patient_dni_lines:true`)
- Si falta equipo: default "Dr. Carlos Zanardi y equipo": PASA (`content_blank_default_team:true`)

## Falla encontrada y corrección aplicada
- Falla (run previo): `validate_20_pathology_scenarios` bloqueaba `T05` (HC espondilolistesis) por `hc_inestabilidad_no_debe_default_canal_estrecho` con `validation_status:BLOQUEADO_NO_ENVIAR`.
- Fix: `scripts/jarvis/clinical_document_handoff.js` ahora aplica el post-procesado lumbar-fijación también cuando la familia es `columna_lumbar_*`/`columna_interespinoso_*` (no solo `lumbar_fijacion`).
- Re-ejecución completa: suite OK (este reporte).

## Archivos tocados en este ciclo
- scripts/jarvis/clinical_document_handoff.js
- qa/approval_gates/guardia_nocturna_suite_report_2026-05-20T135855Z.md
