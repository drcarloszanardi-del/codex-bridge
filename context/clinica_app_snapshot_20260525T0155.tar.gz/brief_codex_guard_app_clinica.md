# Brief para Codex Guard

## Proyecto
Diseñar una app clínica de uso personal para el Dr. Zanardi que genere historias clínicas y partes quirúrgicos a partir de instrucciones simples del médico, con foco en reducción de omisiones, consistencia redaccional y resguardo medicolegal conforme a normativa y jurisprudencia argentina.

## Requisitos ya definidos
- uso personal
- asistente de redacción + almacenamiento local de pacientes
- foco inicial: neurocirugía y cirugía de columna
- integración Word
- posible integración futura con sistema sanatorial
- plantillas cerradas para evitar alucinaciones/olvidos
- almacenamiento local en la computadora de Jarvis
- la base legal interna no debe aparecer citada en la historia clínica ni en el parte
- objetivo: redactar como lo haría el Dr. Zanardi, pero cubriendo riesgos legales que el médico podría no advertir
- actualización periódica de leyes y jurisprudencia
- se puede involucrar otro motor de IA si mejora la robustez

## Lo que necesito ahora
Proponer una hoja de ruta inicial seria para aprobar con el doctor, con:
1. arquitectura funcional recomendada
2. módulos del sistema
3. estructura de base de conocimiento permanente
4. campos mínimos obligatorios para historia clínica y parte quirúrgico en este contexto
5. flujo de auditoría legal y redaccional por documento
6. esquema de actualización normativa/jurisprudencial periódica
7. criterios para decidir si conviene incorporar un segundo motor de IA y para qué rol exacto
8. primer entregable ideal de alto valor
9. preguntas críticas adicionales que todavía falten

## Restricciones
- no prometer riesgo legal cero
- no proponer texto abierto sin plantillas cerradas
- no citar base legal dentro del documento final clínico
- responder en español, claro y operativo
