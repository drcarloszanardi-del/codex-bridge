const ACTIVE_REVIEW_KEY = 'cli_app_review_state::active';

const state = {
  payload: null,
  selectedCaseId: null,
  manualOverride: false,
  lastSuggestion: null,
  activeSampleKey: null,
  activeFreeCase: null,
  institutionKey: 'clinica_centro',
  surgeonName: 'Carlos Zanardi',
  profileDefaults: {
    surgeonLicense: '',
    usualAssistant: 'Maximiliano Giménez'
  },
  sectionReview: {
    confirmed: 'pending',
    suggested: 'pending',
    missing: 'pending'
  },
  reviewNote: '',
  persistence: {
    available: true,
    restoredAt: null,
    savedAt: null,
    key: null
  }
};

const el = (id) => document.getElementById(id);

const INSTITUTIONS = {
  clinica_centro: {
    label: 'Clínica Centro',
    cityLine: 'Junín, Buenos Aires',
    logo: '../../logos/clinica_centro_logo_limpio.png',
    headerLine: 'Servicio de Neurocirugía y Cirugía de Columna'
  },
  la_pequena_familia: {
    label: 'Clínica La Pequeña Familia',
    cityLine: 'Junín, Buenos Aires',
    logo: '../../logos/la_pequena_familia_logo.png',
    headerLine: 'Servicio de Neurocirugía'
  },
  hospital_pineyro: {
    label: 'HIGA Dr. Abraham Piñeyro',
    cityLine: 'Junín, Buenos Aires',
    logo: '../../logos/hospital_junin_logo_limpio.png',
    headerLine: 'Servicio de Neurocirugía'
  }
};

const STYLE_GUIDES = {
  lumbar_fijacion_miss_artrodesis: {
    label: 'Fijación lumbar MISS',
    path: '/Users/jarvis/.openclaw/workspace/clinica/app-clinica-medicolegal/data/processed/doctor/cli_001_medilegal_base_v7_extracted_2026-05-18/medilegal/patologias/estilo-zanardi-fijacion.md',
    operationName: 'Fijación circunferencial L4/5 MISS',
    mandatoryPhrases: [
      'Bajo guía radioscópica...',
      'Las raíces pasantes y salientes del segmento quedan libres y pulsátiles.',
      'Procedimiento sin complicaciones.'
    ],
    moduleHeader: 'Módulo C/D AANC',
    defaultAssistant: 'Dr. Maximiliano Giménez'
  }
};

const MEDICOLEGAL_FOUNDATIONS = [
  {
    key: 'identificacion_autoria',
    shortLabel: 'Identificación y autoría del acto',
    basis: 'Ley 26.529, Ley 17.132 y criterios de integridad documental del registro clínico.',
    appliesTo: ['Historia clínica', 'Parte quirúrgico'],
    text: 'Se prioriza consignar identificación suficiente del episodio, autoría, fecha y hora del acto, porque la trazabilidad documental pesa en la defensa médica.'
  },
  {
    key: 'consentimiento_material',
    shortLabel: 'Consentimiento con contenido material',
    basis: 'Ley 26.529 y doctrina sobre información adecuada al paciente.',
    appliesTo: ['Historia clínica'],
    text: 'Se incluye constancia de información sobre objetivos, riesgos, beneficios y alternativas terapéuticas como núcleo defensivo básico del registro.'
  },
  {
    key: 'correlacion_clinico_radiologica',
    shortLabel: 'Correlación clínico-radiológica e indicación',
    basis: 'Buena práctica documental y criterio defensivo de indicación fundada.',
    appliesTo: ['Historia clínica', 'Parte quirúrgico'],
    text: 'Se refuerza la relación entre cuadro clínico, estudios e indicación quirúrgica para mostrar razonabilidad médica del acto.'
  },
  {
    key: 'cronologia_tecnica',
    shortLabel: 'Cronología y técnica operatoria',
    basis: 'Valor probatorio del parte quirúrgico completo y control del acto.',
    appliesTo: ['Parte quirúrgico'],
    text: 'Se privilegia dejar documentadas técnica, control radioscópico, hallazgos, complicaciones y cierre del procedimiento, marcando lo no confirmado.'
  },
  {
    key: 'evolucion_destino',
    shortLabel: 'Evolución inmediata y destino',
    basis: 'Continuidad asistencial y defensa sobre seguimiento postoperatorio.',
    appliesTo: ['Historia clínica', 'Parte quirúrgico'],
    text: 'Se agrega una evolución postoperatoria inmediata base, pero se obliga revisión si faltan examen neurológico, destino o indicaciones nominales.'
  }
];

const SAMPLE_CASES = {
  hdl_l4_l5: {
    label: 'HDL L4-L5 izquierda, parte quirúrgico',
    documentType: 'Parte quirúrgico',
    familyCode: 'lumbar_microdiscectomia_hdl',
    instruction: 'Microdiscectomía tubular L4-L5 izquierda por hernia de disco lumbar con dolor radicular. Revisar parte quirúrgico y semáforo.',
    expected: {
      semaforo: 'yellow',
      familyContains: 'Hernia de disco lumbar',
      confidence: 'alta',
      mustIncludeMissing: ['hora_inicio', 'hora_fin', 'hallazgos_intraoperatorios'],
      note: 'Debe sugerir la familia HDL lumbar y dejar horas, hallazgos y materiales como revisión manual.'
    }
  },
  cervical_canal_estrecho: {
    label: 'Canal estrecho cervical, historia clínica',
    documentType: 'Historia clínica',
    familyCode: 'cervical_laminoplastia_descompresion',
    instruction: 'Laminoplastia cervical por mielopatía cervical y canal estrecho cervical. Revisar historia clínica.',
    expected: {
      semaforo: 'green',
      familyContains: 'Laminoplastia cervical',
      confidence: 'alta',
      mustIncludeMissing: [],
      note: 'Debe reconocer el caso cervical y mostrar semáforo verde sin faltantes críticos para historia clínica.'
    }
  },
  miss_listesis: {
    label: 'Fijación lumbar MISS, historia clínica',
    documentType: 'Historia clínica',
    familyCode: 'lumbar_fijacion_miss_artrodesis',
    instruction: 'Artrodesis lumbar MISS con fijación pedicular por espondilolistesis. Revisar historia clínica.',
    expected: {
      semaforo: 'red',
      familyContains: 'Fijacion lumbar MISS',
      confidence: 'alta',
      mustIncludeMissing: ['diagnostico_postoperatorio'],
      note: 'Debe reconocer la familia de fijación lumbar MISS y dejar al menos el diagnóstico postoperatorio como revisión manual.'
    }
  },
  paciente_prueba_l4_l5_circunferencial: {
    label: 'Paciente prueba, fijación L4-L5 circunferencial',
    documentType: 'Parte quirúrgico',
    familyCode: 'lumbar_fijacion_miss_artrodesis',
    instruction: 'Paciente prueba operado de fijación L4-L5 circunferencial. Generar historia clínica y parte quirúrgico de producto final de la aplicación, completando aun los puntos no seguros como borrador de prueba.',
    expected: {
      semaforo: 'red',
      familyContains: 'Fijacion lumbar MISS',
      confidence: 'alta',
      mustIncludeMissing: ['diagnostico_preoperatorio', 'tecnica_quirurgica', 'hora_inicio', 'hora_fin'],
      note: 'Debe llevar el caso a la familia de fijación lumbar y exhibir que los campos críticos siguen siendo de completado manual aunque el borrador de prueba los narre.'
    }
  }
};

const KEYWORD_RULES = [
  {
    familyCode: 'lumbar_microdiscectomia_hdl',
    confidence: 'alta',
    terms: ['microdiscectomia', 'microdiscectomía', 'hernia de disco', 'hdl', 'radicular', 'discectomia', 'discectomía', 'l4-l5', 'l5-s1'],
    strongCombos: [
      ['microdiscectomia', 'hernia de disco'],
      ['microdiscectomía', 'hernia de disco'],
      ['hdl', 'radicular']
    ]
  },
  {
    familyCode: 'cervical_laminoplastia_descompresion',
    confidence: 'alta',
    terms: ['laminoplastia cervical', 'laminectomia cervical', 'laminectomía cervical', 'mielopatia cervical', 'mielopatía cervical', 'descompresion cervical', 'descompresión cervical', 'cervical', 'cuadriparesia', 'cuadriparesia leve', 'c3/7', 'c3-7'],
    strongCombos: [
      ['laminoplastia cervical', 'mielopatía cervical'],
      ['laminoplastia cervical', 'canal estrecho cervical'],
      ['descompresión cervical', 'mielopatía cervical'],
      ['laminoplastia cervical', 'cuadriparesia'],
      ['c3/7', 'cuadriparesia'],
      ['c3-7', 'cuadriparesia']
    ]
  },
  {
    familyCode: 'craneo_tumor_fractura_derivacion',
    confidence: 'alta',
    terms: ['hematoma subdural', 'subdural', 'trepanacion', 'trepanación', 'craneotomia', 'craneotomía', 'tumor cerebral', 'hidrocefalia', 'derivacion', 'derivación', 'dvp', 'fractura craneal', 'lesion dural', 'lesión dural'],
    strongCombos: [
      ['hematoma subdural', 'craneotomía'],
      ['hidrocefalia', 'derivación'],
      ['lesión dural', 'fractura craneal']
    ]
  },
  {
    familyCode: 'lumbar_fijacion_miss_artrodesis',
    confidence: 'media',
    terms: ['artrodesis', 'fijacion', 'fijación', 'tornillos pediculares', 'espondilolistesis', 'instrumentacion', 'instrumentación', 'miss', 'circunferencial', 'fijación l4-l5', 'fijacion l4-l5'],
    strongCombos: [
      ['artrodesis', 'miss'],
      ['fijación', 'espondilolistesis'],
      ['fijacion', 'espondilolistesis'],
      ['artrodesis', 'tornillos pediculares'],
      ['fijación', 'circunferencial'],
      ['fijacion', 'circunferencial'],
      ['circunferencial', 'l4-l5']
    ]
  },
  {
    familyCode: 'revision_retiro_implantes_discitis',
    confidence: 'media',
    terms: ['discitis', 'retiro de implantes', 'revision de herida', 'revisión de herida', 'toilette quirurgica', 'toilette quirúrgica', 'infeccion', 'infección'],
    strongCombos: [
      ['discitis', 'retiro de implantes'],
      ['discitis', 'toilette quirúrgica'],
      ['infección', 'revisión de herida']
    ]
  },
  {
    familyCode: 'periferico_bloqueos_descompresiones',
    confidence: 'media',
    terms: ['tunel carpiano', 'túnel carpiano', 'cubital', 'neurolisis', 'neurolisis', 'periferico', 'periférico', 'bloqueo periferico', 'bloqueo periférico'],
    strongCombos: [
      ['túnel carpiano', 'neurolisis'],
      ['cubital', 'neurolisis'],
      ['bloqueo periférico', 'cubital']
    ]
  }
];

const FORMAL_REVIEW_SOURCES = [
  {
    key: 'corpus',
    title: 'Corpus medicolegal argentino base',
    status: 'base_avanzada_review_only',
    path: 'docs/corpus_medicolegal_argentino.md',
    note: 'Base normativa y jurisprudencial avanzada, congelada como baseline interno review_only y sin cierre terminal apto para declarar cumplimiento total.'
  },
  {
    key: 'matriz',
    title: 'Matriz de impacto redaccional HC/partes',
    status: 'base_avanzada_review_only',
    path: 'docs/matriz_impacto_redaccional_hc_partes.md',
    note: 'Checklist útil para escritura prudente, congelado como baseline interno review_only con cierre formal pendiente.'
  },
  {
    key: 'reglas',
    title: 'Reglas internas candidatas',
    status: 'base_avanzada_review_only',
    path: 'docs/reglas_internas_redaccion_medicolegal.md',
    note: 'Reglas candidatas congeladas para QA/dry run, no activas para uso legal definitivo.'
  }
];

const MEDICOLEGAL_UPDATE_AXES = [
  {
    key: 'normativa_base',
    title: 'Normativa base del acto y del registro',
    basis: 'Ley 26.529 + Ley 17.132',
    nextAction: 'Confirmar episodio, fecha/hora, autoría y trazabilidad mínima antes de congelar candidato auditable.',
    when: () => true,
    detail: 'Mantener chequeo detect-only sobre Ley 26.529, Ley 17.132, identificación del episodio, autoría y trazabilidad mínima del documento.'
  },
  {
    key: 'consentimiento_reforzado',
    title: 'Consentimiento material y constancia de información',
    basis: 'Ley 26.529, información adecuada al paciente',
    nextAction: 'Marcar como pendiente si faltan objetivo, riesgos, beneficios, alternativas o aceptación informada explícita.',
    when: (_reviewCase, expectedMissing, documentType) => documentType === 'Historia clínica' || expectedMissing.includes('diagnostico_preoperatorio'),
    detail: 'Revisar si el borrador deja explícitos objetivo, riesgos, beneficios, alternativas y aceptación informada, sin fingir conversación no documentada.'
  },
  {
    key: 'tecnica_implantes',
    title: 'Técnica, implantes y controles intraoperatorios',
    basis: 'Buena práctica documental y control intraoperatorio verificable',
    nextAction: 'Resolver con dato confirmado o dejar excepción real visible si una rutina habitual no aplicó.',
    when: (_reviewCase, expectedMissing, documentType) => documentType === 'Parte quirúrgico' || expectedMissing.some((field) => ['tecnica_quirurgica', 'implantes', 'implante_marca_lote_serie', 'verificacion_nivel_radioscopia'].includes(field)),
    detail: 'Chequeo detect-only sobre secuencia técnica, radioscopía, implantes/lotes y excepciones reales cuando una rutina habitual no aplica.'
  },
  {
    key: 'jurisprudencia_doctrina',
    title: 'Jurisprudencia/doctrina para refuerzo prudente',
    basis: 'Cola doctrinaria/jurisprudencial local review_only',
    nextAction: 'Si persisten faltantes críticos, dejar explícito que el caso debe pasar por refuerzo doctrinario antes del paquete auditable.',
    when: (_reviewCase, expectedMissing) => expectedMissing.length > 0,
    detail: 'Si persisten faltantes críticos, dejar la cola lista para revisión doctrinaria/jurisprudencial local antes de congelar candidato auditable.'
  },
  {
    key: 'poi_destino',
    title: 'Evolución inmediata, destino y continuidad asistencial',
    basis: 'Continuidad asistencial y defensa postoperatoria',
    nextAction: 'Mantener revisión manual visible si faltan examen neurológico, destino, indicaciones o responsable nominal.',
    when: (_reviewCase, expectedMissing) => expectedMissing.includes('destino') || expectedMissing.includes('hora_fin'),
    detail: 'Verificar que la evolución POI no quede tácita: examen neurológico, destino, indicaciones y responsable deben seguir visibles como revisión manual si faltan.'
  }
];

const SIX_CONTROL_GATE = [
  {
    key: 'identificacion',
    title: 'Identificación completa de paciente, episodio, fecha, hora y autor',
    docSignals: ['Identificación suficiente de paciente, episodio, fecha, hora y autor.', 'toda nota clínica y todo parte quirúrgico deben iniciar con paciente, fecha, hora, ámbito y autor del registro.'],
    appSignals: ['Persistencia local por caso y tipo documental.', 'Triage visible de instrucción, familia y caso activo.', 'Campos críticos visibles para fecha, hora y autoría documental.']
  },
  {
    key: 'consentimiento_material',
    title: 'Consentimiento informado con contenido material y acceso/copia',
    docSignals: ['consentimiento informado', 'Consentimiento con contenido material', 'Consentimiento con constancia de acceso/copia'],
    appSignals: ['Borrador bloqueado sin salida final automática.', 'Sin PDF ni publicación, exige revisión humana antes de cualquier uso real.']
  },
  {
    key: 'parte_critico',
    title: 'Parte quirúrgico con técnica, hallazgos, cronología, complicaciones y control final',
    docSignals: ['Parte quirúrgico: hallazgos y técnica', 'Parte quirúrgico: cronología intra y postevento', 'CLI-R009 Control final verificable del acto quirúrgico'],
    appSignals: ['Checklist técnico intraoperatorio visible.', 'Semáforo y faltantes críticos obligan completar horas, hallazgos, implantes y radioscopía cuando faltan.']
  },
  {
    key: 'addendas',
    title: 'Addendas sin borrado con trazabilidad de cambios, autor, fecha y hora',
    docSignals: ['Addendas sin borrado', 'Correcciones/addendas', 'CLI-R006 Addendas sin borrado'],
    appSignals: ['Persistencia local con savedAt/restoredAt.', 'Reset y revisión por caso separados del borrador bloqueado.']
  },
  {
    key: 'confidencialidad',
    title: 'Confidencialidad y acceso mínimo a datos sensibles',
    docSignals: ['Mínima exposición de datos sensibles', 'Confidencialidad y circulación de datos', 'CLI-R007 Mínima exposición de datos sensibles'],
    appSignals: ['no_literal_phi_output=true', 'rel_path_exposed=false', 'review_only sin salida productiva.']
  },
  {
    key: 'integridad',
    title: 'Integridad, autenticidad y auditoría del registro electrónico',
    docSignals: ['Autoría digital, integridad y no repudio', 'CLI-R001 Identificación completa del acto', 'CLI-R006 Addendas sin borrado'],
    appSignals: ['codex_guard_required=true', 'human_review_required=true', 'final_generation_blocked=true y publication_activation_allowed=false.']
  }
];

const DOCUMENT_CONFIG = {
  'Historia clínica': {
    code: 'hc',
    label: 'Historia clínica',
    blockedTitle: 'Borrador de historia clínica bloqueado',
    expectedFields: [
      'diagnostico_preoperatorio',
      'diagnostico_postoperatorio',
      'tecnica_quirurgica',
      'hallazgos_intraoperatorios',
      'complicaciones',
      'destino'
    ],
    optionalFields: [
      'fecha_acto_quirurgico',
      'nivel',
      'lateralidad',
      'implantes',
      'implante_marca_lote_serie',
      'hemostatico_nombre_lote_cantidad',
      'parche_duramadre_marca_lote_serie'
    ],
    alertKeywords: ['diagnostico', 'hallazgos', 'destino', 'complicaciones'],
    checklistTitle: 'Checklist narrativo mínimo',
    blockedBullets: [
      'Evolución final deshabilitada.',
      'No emitir PHI literal ni cierre automático.',
      'Requiere validación humana antes de usar en historia clínica real.'
    ]
  },
  'Parte quirúrgico': {
    code: 'parte',
    label: 'Parte quirúrgico',
    blockedTitle: 'Parte quirúrgico bloqueado',
    expectedFields: [
      'fecha_acto_quirurgico',
      'hora_inicio',
      'hora_fin',
      'tecnica_quirurgica',
      'hallazgos_intraoperatorios',
      'complicaciones',
      'implantes',
      'implante_marca_lote_serie',
      'hemostatico_nombre_lote_cantidad',
      'parche_duramadre_marca_lote_serie',
      'verificacion_nivel_radioscopia'
    ],
    optionalFields: [
      'diagnostico_preoperatorio',
      'diagnostico_postoperatorio',
      'nivel',
      'lateralidad',
      'destino'
    ],
    alertKeywords: ['hora_', 'implante', 'lote', 'hemostatico', 'parche', 'radioscopia'],
    checklistTitle: 'Checklist técnico intraoperatorio',
    blockedBullets: [
      'Redacción operatoria final deshabilitada.',
      'No inferir materiales, lotes ni tiempos.',
      'Requiere control manual del parte antes de cualquier uso clínico.'
    ]
  },
  Epicrisis: {
    code: 'epicrisis',
    label: 'Epicrisis',
    blockedTitle: 'Epicrisis bloqueada',
    expectedFields: [
      'diagnostico_preoperatorio',
      'diagnostico_postoperatorio',
      'tecnica_quirurgica',
      'complicaciones',
      'destino'
    ],
    optionalFields: [
      'fecha_acto_quirurgico',
      'hallazgos_intraoperatorios',
      'implantes',
      'nivel',
      'lateralidad'
    ],
    alertKeywords: ['destino', 'complicaciones', 'diagnostico_postoperatorio'],
    checklistTitle: 'Checklist de alta y cierre',
    blockedBullets: [
      'Epicrisis final deshabilitada.',
      'No generar indicaciones de alta ni resumen definitivo automático.',
      'Requiere revisión humana para consistencia de diagnóstico y destino.'
    ]
  }
};

function semaforoBadge(level) {
  const labels = { green: 'VERDE', yellow: 'AMARILLO', red: 'ROJO' };
  return `<span class="badge ${level}">${labels[level] || String(level).toUpperCase()}</span>`;
}

function storageKey(caseId = state.selectedCaseId, documentType = el('documentType')?.value) {
  if (!caseId || !documentType) return null;
  return `cli_app_review_state::${caseId}::${documentType}`;
}

function freeCaseKey(documentType = el('documentType')?.value || 'Historia clínica') {
  return `cli_app_free_case::${documentType}`;
}

function persistenceSnapshot() {
  return {
    selectedCaseId: state.selectedCaseId,
    documentType: el('documentType')?.value || 'Historia clínica',
    instruction: el('instruction')?.value || '',
    reviewNote: state.reviewNote,
    sectionReview: { ...state.sectionReview },
    manualOverride: state.manualOverride,
    activeSampleKey: state.activeSampleKey,
    savedAt: new Date().toISOString()
  };
}

function persistActiveSelection(snapshot = persistenceSnapshot()) {
  try {
    localStorage.setItem(ACTIVE_REVIEW_KEY, JSON.stringify({
      selectedCaseId: snapshot.selectedCaseId,
      documentType: snapshot.documentType,
      instruction: snapshot.instruction,
      activeSampleKey: snapshot.activeSampleKey,
      activeFreeCase: state.activeFreeCase,
      manualOverride: state.manualOverride,
      institutionKey: state.institutionKey,
      surgeonName: state.surgeonName,
      savedAt: snapshot.savedAt
    }));
    state.persistence.available = true;
  } catch (error) {
    state.persistence.available = false;
  }
}

function loadActiveSelection() {
  try {
    const raw = localStorage.getItem(ACTIVE_REVIEW_KEY);
    state.persistence.available = true;
    return raw ? JSON.parse(raw) : null;
  } catch (error) {
    state.persistence.available = false;
    return null;
  }
}

function renderPersistenceStatus() {
  const node = el('reviewPersistenceStatus');
  if (!node) return;
  if (!state.persistence.available) {
    node.innerHTML = '<strong>Persistencia local no disponible.</strong><div>El navegador no expone localStorage en este contexto.</div>';
    return;
  }

  const bits = [];
  if (state.persistence.restoredAt) bits.push(`restaurado ${new Date(state.persistence.restoredAt).toLocaleString('es-AR')}`);
  if (state.persistence.savedAt) bits.push(`guardado ${new Date(state.persistence.savedAt).toLocaleString('es-AR')}`);
  const key = state.persistence.key ? state.persistence.key.split('::').slice(1).join(' · ') : 'sin clave activa';
  node.innerHTML = `
    <strong>Persistencia local activa</strong>
    <div>Clave actual: ${key}</div>
    <div>${bits.length ? bits.join(' · ') : 'Sin datos restaurados todavía para este caso/tipo documental.'}</div>
  `;
}

function persistReviewState() {
  const key = storageKey();
  if (!key) return;
  const snapshot = persistenceSnapshot();
  try {
    localStorage.setItem(key, JSON.stringify(snapshot));
    persistActiveSelection(snapshot);
    state.persistence.available = true;
    state.persistence.key = key;
    state.persistence.savedAt = snapshot.savedAt;
  } catch (error) {
    state.persistence.available = false;
  }
  renderPersistenceStatus();
}

function resetReviewState({ persist = true } = {}) {
  state.sectionReview = {
    confirmed: 'pending',
    suggested: 'pending',
    missing: 'pending'
  };
  state.reviewNote = '';
  const note = el('reviewNote');
  if (note) note.value = '';
  if (persist) persistReviewState();
}

function loadPersistedReviewState(caseId = state.selectedCaseId) {
  const key = storageKey(caseId);
  state.persistence.key = key;
  if (!key) {
    renderPersistenceStatus();
    return;
  }

  try {
    const raw = localStorage.getItem(key);
    state.persistence.available = true;
    if (!raw) {
      state.persistence.restoredAt = null;
      state.persistence.savedAt = null;
      resetReviewState({ persist: false });
      renderPersistenceStatus();
      return;
    }

    const saved = JSON.parse(raw);
    state.sectionReview = {
      confirmed: saved.sectionReview?.confirmed || 'pending',
      suggested: saved.sectionReview?.suggested || 'pending',
      missing: saved.sectionReview?.missing || 'pending'
    };
    state.reviewNote = saved.reviewNote || '';
    state.activeSampleKey = saved.activeSampleKey || null;
    state.persistence.restoredAt = saved.savedAt || new Date().toISOString();
    state.persistence.savedAt = saved.savedAt || null;
  } catch (error) {
    state.persistence.available = false;
    resetReviewState({ persist: false });
  }
  renderPersistenceStatus();
}

function removePersistedReviewState() {
  const key = storageKey();
  if (!key) return;
  try {
    localStorage.removeItem(key);
    localStorage.removeItem(ACTIVE_REVIEW_KEY);
    state.persistence.available = true;
    state.persistence.key = key;
    state.persistence.restoredAt = null;
    state.persistence.savedAt = null;
  } catch (error) {
    state.persistence.available = false;
  }
  renderPersistenceStatus();
}

function ensureSuggestionNode() {
  if (el('suggestionBox')) return;
  const select = el('familySelect');
  const box = document.createElement('div');
  box.id = 'suggestionBox';
  box.className = 'warn';
  box.style.marginTop = '10px';
  select.insertAdjacentElement('afterend', box);
}

function buildFreeCaseSummary(reviewCase) {
  const triage = buildInstructionTriage(reviewCase);
  const currentInstruction = el('instruction')?.value?.trim() || 'Sin instrucción cargada';
  const family = state.lastSuggestion?.familyLabel || reviewCase.family_label;
  const confidence = state.lastSuggestion?.confidence || 'manual';
  return {
    instruction: currentInstruction,
    family,
    confidence,
    criticalMissing: triage.criticalMissing,
    suggested: triage.suggested,
    confirmed: triage.confirmed
  };
}

function persistFreeCase(reviewCase) {
  if (!reviewCase) return;
  const summary = buildFreeCaseSummary(reviewCase);
  state.activeFreeCase = {
    caseId: reviewCase.case_id,
    documentType: el('documentType')?.value || 'Historia clínica',
    ...summary,
    savedAt: new Date().toISOString()
  };
  try {
    localStorage.setItem(freeCaseKey(state.activeFreeCase.documentType), JSON.stringify(state.activeFreeCase));
    state.persistence.available = true;
  } catch (error) {
    state.persistence.available = false;
  }
}

function loadFreeCase(documentType = el('documentType')?.value || 'Historia clínica') {
  try {
    const raw = localStorage.getItem(freeCaseKey(documentType));
    state.persistence.available = true;
    return raw ? JSON.parse(raw) : null;
  } catch (error) {
    state.persistence.available = false;
    return null;
  }
}

function renderFreeCasePanel(reviewCase) {
  const node = el('freeCaseSummary');
  const checks = el('freeCaseChecks');
  if (!node || !checks || !reviewCase) return;

  const activeDocumentType = el('documentType')?.value || 'Historia clínica';
  let freeCase = state.activeFreeCase;
  if (!freeCase || freeCase.documentType !== activeDocumentType) {
    freeCase = loadFreeCase(activeDocumentType);
    state.activeFreeCase = freeCase && freeCase.documentType === activeDocumentType ? freeCase : null;
  }
  if (!freeCase || !freeCase.instruction) {
    node.innerHTML = 'Todavía no hay un caso libre armado.';
    checks.innerHTML = '<li>La revisión local se guarda por caso y tipo documental.</li>';
    return;
  }

  node.innerHTML = `
    <strong>Familia activa:</strong> ${freeCase.family}<br>
    <strong>Confianza:</strong> ${freeCase.confidence}<br>
    <strong>Instrucción:</strong> ${freeCase.instruction}<br>
    <strong>Faltantes críticos:</strong> ${freeCase.criticalMissing.length ? freeCase.criticalMissing.join(', ') : 'sin faltantes críticos'}
  `;

  const items = [
    `Caso base reutilizado: ${reviewCase.family_label}`,
    `Tipo documental: ${freeCase.documentType}`,
    `Persistido localmente: ${freeCase.savedAt ? new Date(freeCase.savedAt).toLocaleString('es-AR') : 'sí'}`,
    `Confirmados: ${freeCase.confirmed.length}`,
    `Sugerencias revisables: ${freeCase.suggested.length}`
  ];
  checks.innerHTML = items.map((item) => `<li>${item}</li>`).join('');
}

function renderStats(payload) {
  const readiness = payload.readiness_summary;
  el('stats').innerHTML = `
    <div class="stat"><strong>${readiness.families_catalogued}</strong>familias</div>
    <div class="stat"><strong>${readiness.families_with_dry_run_cases}</strong>casos test</div>
    <div class="stat"><strong>${readiness.manifest_total_items}</strong>items corpus</div>
  `;
  el('generatedAt').textContent = `Paquete ${new Date(payload.generated_at).toLocaleString('es-AR')}`;
  el('guardrails').innerHTML = [
    'publication_activation_allowed=false',
    'pdf_generation_allowed=local_preview_pipeline',
    'human_review_required=true',
    'codex_guard_required=true'
  ].join(' · ');
  renderTrialReadyPanel(payload);
}

function renderTrialReadyPanel(payload) {
  const readiness = payload.readiness_summary;
  const reviewCases = payload.review_cases || [];
  const guardrails = [
    'NO APTO_PARA_ENTREGAR sin revisión humana final',
    'Fórmula única: base medico-legal avanzada, con cierre formal pendiente',
    'PDF/Word local solo como preview exportable, no autoentrega',
    'Borrador bloqueado, revisión humana requerida',
    'Tamiz Codex Guard requerido antes de cualquier entrega'
  ];
  const instructions = [
    'Cargar un caso de prueba local.',
    'Verificar la familia sugerida y la confianza visible.',
    'Revisar confirmado vs sugerencia clínica vs faltante crítico.',
    'Chequear tamiz médico legal y dominios bloqueados.',
    'Confirmar que el borrador siga bloqueado y sin PDF/publicación.'
  ];
  const checklist = [
    `${reviewCases.length} review_cases cargados desde el paquete local.`,
    'Selector de documento, familia y caso de prueba visibles.',
    'Semáforo, alertas y faltantes críticos visibles.',
    'Panel listo para prueba interna de Jarvis principal.'
  ];

  el('trialReadinessSummary').innerHTML = `
    <strong>Estado:</strong> listo para prueba interna controlada.<br>
    <strong>Paquete:</strong> ${reviewCases.length} casos review_only, ${readiness.families_catalogued} familias catalogadas y ${readiness.manifest_total_items} items de corpus.<br>
    <strong>Uso permitido:</strong> solo revisión interna, sin salida clínica final.
  `;
  el('trialInstructions').innerHTML = instructions.map((item) => `<li>${item}</li>`).join('');
  el('trialGuardrails').innerHTML = guardrails.map((item) => `<li>${item}</li>`).join('');
  el('trialChecklist').innerHTML = checklist.map((item) => `<li>${item}</li>`).join('');
}

function inferFamilyFromInstruction(payload, rawInstruction) {
  const instruction = String(rawInstruction || '').trim().toLowerCase();
  if (!instruction) return null;

  const scored = payload.review_cases.map((reviewCase) => {
    const rule = KEYWORD_RULES.find((item) => item.familyCode === reviewCase.family_code);
    const hits = (rule?.terms || []).filter((term) => instruction.includes(term.toLowerCase()));
    const comboHits = (rule?.strongCombos || []).filter((combo) => combo.every((term) => instruction.includes(term.toLowerCase())));
    const labelTokens = reviewCase.family_label.toLowerCase().split(/[^a-záéíóúñ0-9]+/i).filter(Boolean);
    const labelHits = labelTokens.filter((token) => token.length > 3 && instruction.includes(token));
    const score = hits.length * 3 + labelHits.length + comboHits.length * 4;
    return {
      reviewCase,
      hits: [...new Set([...hits, ...labelHits, ...comboHits.flat()])],
      score,
      baseConfidence: rule?.confidence || 'baja',
      comboHits: comboHits.length
    };
  }).filter((item) => item.score > 0).sort((a, b) => b.score - a.score);

  if (!scored.length) return null;

  const best = scored[0];
  let confidence = best.score >= 6 ? 'alta' : best.score >= 3 ? 'media' : 'baja';
  if (best.baseConfidence === 'alta' && best.score >= 4) confidence = 'alta';
  if (best.comboHits > 0 && best.score >= 5) confidence = 'alta';

  return {
    caseId: best.reviewCase.case_id,
    familyLabel: best.reviewCase.family_label,
    confidence,
    reasons: best.hits.slice(0, 5)
  };
}

function renderSuggestion() {
  ensureSuggestionNode();
  const box = el('suggestionBox');
  const suggestion = state.lastSuggestion;

  if (!suggestion) {
    box.innerHTML = '<strong>Sugerencia automática</strong><div>No hay coincidencia suficiente todavía. Puede elegir la familia manualmente.</div>';
    return;
  }

  const mode = state.manualOverride ? 'Corrección manual activa' : 'Sugerencia aplicada automáticamente';
  const reasons = suggestion.reasons.length ? suggestion.reasons.join(', ') : 'sin palabras clave trazables';
  box.innerHTML = `
    <strong>${mode}</strong>
    <div>Familia sugerida: <strong>${suggestion.familyLabel}</strong></div>
    <div>Confianza: <strong>${suggestion.confidence}</strong></div>
    <div>Motivo: ${reasons}</div>
  `;
}

function getDocumentConfigByLabel(documentType = 'Historia clínica') {
  return DOCUMENT_CONFIG[documentType] || DOCUMENT_CONFIG['Historia clínica'];
}

function getDocumentConfig() {
  return getDocumentConfigByLabel(el('documentType').value);
}

function getDocumentViewForType(reviewCase, documentType = el('documentType').value) {
  const config = getDocumentConfigByLabel(documentType);
  const presentSet = new Set(reviewCase.missing_fields_map.fields_present);
  const allMissing = reviewCase.missing_fields_map.fields_missing;
  const expectedPresent = config.expectedFields.filter((field) => presentSet.has(field));
  const expectedMissing = config.expectedFields.filter((field) => !presentSet.has(field));
  const optionalPresent = config.optionalFields.filter((field) => presentSet.has(field));
  const optionalMissing = config.optionalFields.filter((field) => allMissing.includes(field));
  const relevantAlerts = reviewCase.alerts.filter((alert) => config.alertKeywords.some((keyword) => alert.field.includes(keyword)));

  return {
    config,
    expectedPresent,
    expectedMissing,
    optionalPresent,
    optionalMissing,
    relevantAlerts
  };
}

function getDocumentView(reviewCase) {
  return getDocumentViewForType(reviewCase, el('documentType').value);
}

function normalizeInstruction(text) {
  return String(text || '').toLowerCase();
}

function diagnosisOnlyText(text) {
  return String(text || '')
    .replace(/\s*,?\s*con\s+(?:criterio|indicaci[oó]n)\s+de\b.*$/gi, '')
    .replace(/\s*,?\s*con\s+indicaci[oó]n\s+(?:quir[uú]rgica|fundada)\b.*$/gi, '')
    .replace(/\s*,?\s*para\s+(?:descompresi[oó]n|instrumentaci[oó]n|estabilizaci[oó]n|artrodesis|fijaci[oó]n|microdiscectom[ií]a|recalibraje)\b.*$/gi, '')
    .replace(/\s+([,.])/g, '$1')
    .replace(/\s{2,}/g, ' ')
    .trim()
    .replace(/[.;,\s]+$/g, '');
}

function extractInstructionEntities(rawInstruction) {
  const instruction = String(rawInstruction || '').trim();
  const normalized = normalizeInstruction(instruction);
  const fallbackSurgeon = state.surgeonName || 'Carlos Zanardi';
  const fallbackAssistant = state.profileDefaults?.usualAssistant || 'Maximiliano Giménez';
  const patientMatch = instruction.match(/(?:paciente|sr\.?|sra\.?|nombre)\s*[:\-]?\s*([A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÑáéíóúñ'`. -]{2,60})/i);
  const surgeonMatch = instruction.match(/(?:cirujano|dr\.?|dra\.?)\s*[:\-]?\s*([A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÑáéíóúñ'`. -]{2,60})/i);
  const assistantMatch = instruction.match(/(?:ayudante|ayudantes|1er ayudante|primer ayudante)\s*[:\-]?\s*([A-ZÁÉÍÓÚÑ][A-Za-zÁÉÍÓÚÑáéíóúñ'`. -]{2,60})/i);
  const ageMatch = instruction.match(/(?:edad|de)\s*(\d{1,2})\s*años/i);
  const dateMatch = instruction.match(/(?:fecha|día|dia)\s*[:\-]?\s*(\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4})/i);
  const lumbarLevelMatch = normalized.match(/l\d\s*[\/-]\s*(?:l\d|s\d)/i);
  const cervicalLevelMatch = normalized.match(/c\d\s*[\/-]\s*c?\d/i);
  const lateralityMatch = normalized.match(/\b(izquierda|derecha|bilateral)\b/i);
  const startTimeMatch = instruction.match(/(?:hora\s*(?:de\s*)?inicio|inicio)\s*[:\-]?\s*(\d{1,2}:\d{2})/i);
  const endTimeMatch = instruction.match(/(?:hora\s*(?:de\s*)?fin|fin)\s*[:\-]?\s*(\d{1,2}:\d{2})/i);
  const bloodLossMatch = instruction.match(/(?:sangrado|perdida hematica|p[eé]rdida hem[aá]tica|sangrado estimado)\s*[:\-]?\s*(\d{1,4})\s*(ml|cc)/i);
  const implantDetailMatch = instruction.match(/((?:tornillos pediculares|caja(?:\s+plif)?|plif|barra(?:s)?|implante(?:s)?|injerto)[^.\n;]{0,80})/i);
  const destinationMatch = instruction.match(/(?:destino|pasa a|se traslada a|queda en)\s*[:\-]?\s*(uti|uci|terapia intensiva|sala de recuperaci[oó]n|recuperaci[oó]n|habitaci[oó]n|internaci[oó]n|guardia)/i);
  const complicationMatch = instruction.match(/(?:complicaciones?|incidentes?|eventos? intraoperatorios?)\s*[:\-]?\s*([^.\n]{3,90})/i);
  const implantMention = /(tornillos pediculares|caja(?:\s+plif)?|plif|barra(?:s)?|implante(?:s)?|injerto)/i.test(instruction);
  const quickExceptionRules = [
    { test: /(sin drenaje|no se coloc[oó] drenaje)/i, label: 'Sin drenaje postoperatorio' },
    { test: /(sin injerto|no se coloc[oó] injerto)/i, label: 'Sin injerto agregado' },
    { test: /(sin implantes|no se colocaron implantes)/i, label: 'Sin implantes adicionales' },
    { test: /(sin radioscop(?:ia|ía)|sin control radioscop(?:ico|ico))/i, label: 'Sin control radioscópico referido' },
    { test: /(sin complicaciones|no hubo complicaciones)/i, label: 'Sin complicaciones referidas' },
    { test: /(sin evento[s]?|sin incidentes|no hubo incidentes)/i, label: 'Sin incidentes intraoperatorios referidos' }
  ];

  const patientName = patientMatch?.[1]?.trim().replace(/[.,;:]$/, '') || 'Paciente prueba';
  const surgeonName = surgeonMatch?.[1]?.trim().replace(/[.,;:]$/, '') || fallbackSurgeon;
  const assistantName = assistantMatch?.[1]?.trim().replace(/[.,;:]$/, '') || fallbackAssistant;
  const ageLabel = ageMatch?.[1] ? `${ageMatch[1]} años` : '____ años';
  const surgeryDateLabel = dateMatch?.[1] || '____ de __________ de 20__';
  const lumbarLevel = lumbarLevelMatch ? lumbarLevelMatch[0].replace(/\s+/g, '').toUpperCase().replace('/', '-') : 'L4-5';
  const cervicalLevels = cervicalLevelMatch ? cervicalLevelMatch[0].replace(/\s+/g, '').toUpperCase().replace('/', '-') : 'C3-7';
  const laterality = lateralityMatch?.[1] || '';
  const quickExceptions = quickExceptionRules.filter((rule) => rule.test.test(instruction)).map((rule) => rule.label);
  const startTimeLabel = startTimeMatch?.[1] || 'sin hora de inicio referida';
  const endTimeLabel = endTimeMatch?.[1] || 'sin hora de fin referida';
  const bloodLossLabel = bloodLossMatch ? `${bloodLossMatch[1]} ${bloodLossMatch[2]}` : 'sin pérdida hemática explícita';
  const implantLabel = implantDetailMatch?.[1]
    ? implantDetailMatch[1].trim().replace(/[.;:]$/, '')
    : implantMention
      ? 'Implantes/injerto referidos en el relato'
      : 'sin implantes o injerto explícitos';
  const destinationLabel = destinationMatch?.[1]
    ? destinationMatch[1].trim().replace(/^./, (char) => char.toUpperCase())
    : 'sin destino posoperatorio explícito';
  const complicationLabel = complicationMatch?.[1]
    ? complicationMatch[1].trim().replace(/[.;:]$/, '')
    : quickExceptions.includes('Sin complicaciones referidas')
      ? 'sin complicaciones referidas'
      : 'sin complicaciones explícitas';
  const diagnosisLabel = normalized.includes('espondilolistesis')
    ? `espondilolistesis sintomática del nivel ${lumbarLevel}`
    : normalized.includes('hernia de disco') || normalized.includes('hdl')
      ? `hernia de disco lumbar ${lumbarLevel}${laterality ? ` ${laterality}` : ''}`
      : normalized.includes('mielopat') || normalized.includes('canal estrecho cervical')
        ? `canal estrecho cervical ${cervicalLevels} con mielopatía`
        : normalized.includes('artrodesis') || normalized.includes('fijación') || normalized.includes('fijacion')
          ? `patología degenerativa lumbar ${lumbarLevel} con inestabilidad y compromiso neural`
          : '';
  const anesthesiaLabel = /anestesia general/i.test(instruction)
    ? 'Anestesia general referida'
    : /raquidea|raquídea/i.test(instruction)
      ? 'Anestesia raquídea referida'
      : /sedaci[oó]n/i.test(instruction)
        ? 'Sedación referida'
        : 'sin dato anestésico referido';
  const positioningLabel = /dec[uú]bito prono|prono/i.test(instruction)
    ? 'Decúbito prono referido'
    : /dec[uú]bito supino|supino/i.test(instruction)
      ? 'Decúbito supino referido'
      : /dec[uú]bito lateral|lateral/i.test(instruction)
        ? 'Decúbito lateral referido'
        : 'sin posición referida';
  const fluoroscopyLabel = /(radioscop(?:ia|ía)|fluoroscop(?:ia|ía)|arco en c)/i.test(instruction)
    ? 'Control radioscópico referido'
    : 'sin radioscopía explícita en el relato';
  const monitoringLabel = /(monitoreo neurofisiol[oó]gico|potenciales evocados|neuromonitoreo)/i.test(instruction)
    ? 'Monitoreo neurofisiológico referido'
    : 'sin monitoreo neurofisiológico explícito';
  const drainageLabel = /(drenaje|red[oó]n|hemovac)/i.test(instruction)
    ? 'Drenaje referido'
    : 'sin drenaje explícito en el relato';
  const antibioticsLabel = /(profilaxis antibi[oó]tica|cefazolina|antibi[oó]tico profil[aá]ctico)/i.test(instruction)
    ? 'Profilaxis antibiótica referida'
    : 'sin profilaxis antibiótica explícita';

  return {
    patientName,
    surgeonName,
    assistantName,
    ageLabel,
    surgeryDateLabel,
    lumbarLevel,
    cervicalLevels,
    laterality,
    diagnosisLabel,
    quickExceptions,
    anesthesiaLabel,
    positioningLabel,
    fluoroscopyLabel,
    monitoringLabel,
    drainageLabel,
    antibioticsLabel,
    startTimeLabel,
    endTimeLabel,
    bloodLossLabel,
    implantLabel,
    destinationLabel,
    complicationLabel
  };
}

function buildInstructionTriage(reviewCase) {
  const instruction = normalizeInstruction(el('instruction').value);
  const familyTerms = {
    columna_lumbar: ['lumbar', 'l4', 'l5', 's1', 'radicular', 'hdl', 'ciatica', 'ciática'],
    columna_cervical: ['cervical', 'mielopatia', 'mielopatía', 'braquialgia', 'canal estrecho cervical'],
    craneo: ['craneo', 'cráneo', 'subdural', 'craneotomia', 'craneotomía', 'dvp', 'derivacion', 'derivación'],
    periferico: ['tunel carpiano', 'túnel carpiano', 'cubital', 'neurolisis', 'neurolisis']
  };

  const confirmed = [];
  if (instruction) confirmed.push(`Instrucción libre cargada por el médico: ${el('instruction').value.trim()}`);
  if (instruction && familyTerms[reviewCase.domain]?.some((term) => instruction.includes(term))) {
    confirmed.push(`Patología compatible con ${reviewCase.family_label}`);
  }
  if (instruction && /derech|izquierd|bilateral/.test(instruction)) confirmed.push('Lateralidad mencionada en la instrucción');
  if (instruction && /l\d[-/]l\d|l\d[-/]s\d|c\d[-/]c\d/.test(instruction)) confirmed.push('Nivel anatómico mencionado en la instrucción');

  const suggested = [];
  if (state.lastSuggestion) {
    suggested.push(`Familia sugerida: ${state.lastSuggestion.familyLabel} (${state.lastSuggestion.confidence})`);
  }
  if (reviewCase.selected_template?.template_id) {
    suggested.push(`Plantilla candidata: ${reviewCase.selected_template.template_id}`);
  }
  if (reviewCase.missing_fields_map.blocked_inference_domains.includes('hallazgos')) {
    suggested.push('Hallazgos intraoperatorios deben proponerse solo como revisión manual, no como dato confirmado');
  }

  const criticalMissing = getDocumentView(reviewCase).expectedMissing;

  return { confirmed, suggested, criticalMissing };
}

function renderSampleExpectation(reviewCase) {
  const box = el('expectedResult');
  const list = el('sampleChecklist');
  const sample = SAMPLE_CASES[state.activeSampleKey];

  if (!sample) {
    box.innerHTML = 'Todavía no cargó un caso de prueba.';
    list.innerHTML = '<li>Puede cargar un caso local para comparar sugerencia, semáforo y faltantes.</li>';
    return;
  }

  const expected = sample.expected;
  const actualMissing = getDocumentView(reviewCase).expectedMissing;
  const familyOk = reviewCase.family_label.includes(expected.familyContains);
  const semaforoOk = reviewCase.semaforo === expected.semaforo;
  const confidenceOk = (state.lastSuggestion?.confidence || 'sin sugerencia') === expected.confidence;
  const missingChecks = expected.mustIncludeMissing.map((field) => ({
    field,
    ok: actualMissing.includes(field)
  }));

  box.innerHTML = `
    <strong>${sample.label}</strong>
    <div>Esperado: familia <strong>${expected.familyContains}</strong>, semáforo <strong>${expected.semaforo.toUpperCase()}</strong>, confianza <strong>${expected.confidence}</strong>.</div>
    <div>${expected.note}</div>
  `;

  list.innerHTML = [
    `<li><strong>Familia sugerida:</strong> ${familyOk ? 'OK' : 'REVISAR'} (${reviewCase.family_label})</li>`,
    `<li><strong>Semáforo:</strong> ${semaforoOk ? 'OK' : 'REVISAR'} (${reviewCase.semaforo.toUpperCase()})</li>`,
    `<li><strong>Confianza:</strong> ${confidenceOk ? 'OK' : 'REVISAR'} (${state.lastSuggestion?.confidence || 'sin sugerencia'})</li>`,
    ...missingChecks.map((item) => `<li><strong>Faltante esperado ${item.field}:</strong> ${item.ok ? 'OK' : 'REVISAR'}</li>`)
  ].join('');
}

function renderInstructionTriage(reviewCase) {
  const triage = buildInstructionTriage(reviewCase);
  el('instructionTriage').innerHTML = [
    ...triage.confirmed.map((item) => `<li><strong>Confirmado:</strong> ${item}</li>`),
    ...triage.suggested.map((item) => `<li><strong>Sugerencia:</strong> ${item}</li>`)
  ].join('') || '<li>Sin instrucción suficiente todavía. Cargar texto libre para activar el triage.</li>';

  el('criticalMissing').innerHTML = triage.criticalMissing.length
    ? triage.criticalMissing.map((field) => `<li><strong>${field}</strong> <span class="muted">(completar antes de usar ${getDocumentConfig().label.toLowerCase()})</span></li>`).join('')
    : '<li>Sin faltantes críticos para el tipo documental actual.</li>';
}

function renderProductColloquialMap(reviewCase) {
  const node = el('colloquialMap');
  if (!node) return;
  const instruction = el('instruction')?.value || '';
  const extracted = extractInstructionEntities(instruction);
  const mapRows = [
    ['Paciente', extracted.patientName],
    ['Edad', extracted.ageLabel],
    ['Fecha', extracted.surgeryDateLabel],
    ['Cirujano', extracted.surgeonName],
    ['Ayudante', extracted.assistantName],
    ['Nivel lumbar', extracted.lumbarLevel],
    ['Nivel cervical', extracted.cervicalLevels],
    ['Lateralidad', extracted.laterality || 'no referida'],
    ['Diagnóstico sugerido', extracted.diagnosisLabel || 'sin diagnóstico trazable todavía'],
    ['Anestesia', extracted.anesthesiaLabel],
    ['Posición', extracted.positioningLabel],
    ['Radioscopía', extracted.fluoroscopyLabel],
    ['Neuromonitoreo', extracted.monitoringLabel],
    ['Drenaje', extracted.drainageLabel],
    ['Profilaxis ATB', extracted.antibioticsLabel],
    ['Hora inicio', extracted.startTimeLabel],
    ['Hora fin', extracted.endTimeLabel],
    ['Pérdida hemática', extracted.bloodLossLabel],
    ['Implantes/injerto', extracted.implantLabel],
    ['Excepciones rápidas', extracted.quickExceptions?.length ? extracted.quickExceptions.join('; ') : 'sin excepciones detectadas en el relato'],
    ['Familia activa', reviewCase.family_label]
  ];
  node.innerHTML = `<ul class="side-list">${mapRows.map(([label, value]) => `<li><strong>${escapeHtml(label)}:</strong> ${escapeHtml(value)}</li>`).join('')}</ul>`;
}

function renderProductFactBoundary(reviewCase) {
  const node = el('factBoundary');
  if (!node) return;
  const triage = buildInstructionTriage(reviewCase);
  const { expectedMissing } = getDocumentView(reviewCase);
  const confirmed = triage.confirmed.length
    ? triage.confirmed.map((item) => `<li><strong>Confirmado:</strong> ${escapeHtml(item)}</li>`).join('')
    : '<li>Sin dato confirmado trazable todavía.</li>';
  const draftOnly = [
    ...triage.suggested.map((item) => `Sugerencia revisable: ${item}`),
    ...expectedMissing.map((field) => `Completar manualmente: ${field}`)
  ];
  node.innerHTML = `
    <div class="warn" style="margin-bottom:10px;">
      <strong>Hechos confirmados</strong>
      <ul class="side-list">${confirmed}</ul>
    </div>
    <div class="warn">
      <strong>Texto estándar / completar antes de usar</strong>
      <ul class="side-list">${draftOnly.length ? draftOnly.map((item) => `<li>${escapeHtml(item)}</li>`).join('') : '<li>Sin texto estándar pendiente para este caso.</li>'}</ul>
    </div>
  `;
}

function renderProductTemplateMother(reviewCase) {
  const node = el('templateMother');
  if (!node) return;
  const template = reviewCase.selected_template || {};
  const styleGuide = getStyleGuide(reviewCase);
  node.innerHTML = `
    <ul class="side-list">
      <li><strong>Template ID:</strong> ${escapeHtml(template.template_id || 'sin template madre asignada')}</li>
      <li><strong>Template label:</strong> ${escapeHtml(template.label || reviewCase.family_label)}</li>
      <li><strong>Dominio:</strong> ${escapeHtml(reviewCase.domain || 'sin dominio')}</li>
      <li><strong>Guía de estilo:</strong> ${escapeHtml(styleGuide?.label || 'sin guía específica')}</li>
    </ul>
  `;
}

function renderSectionFlow(reviewCase) {
  const triage = buildInstructionTriage(reviewCase);
  const { config, expectedPresent, expectedMissing, optionalPresent, relevantAlerts } = getDocumentView(reviewCase);
  const sections = [
    {
      title: '1. Dato confirmado',
      tone: 'Confirmar solo lo trazable desde la instrucción o el caso base.',
      items: triage.confirmed.length ? triage.confirmed : ['Sin dato confirmado suficiente todavía.']
    },
    {
      title: '2. Sugerencia clínica revisable',
      tone: 'Proponer familia y plantilla como borrador, nunca como cierre definitivo.',
      items: [
        ...(triage.suggested.length ? triage.suggested : ['Sin sugerencia automática útil todavía.']),
        ...expectedPresent.map((field) => `Campo ya presente y reutilizable: ${field}`),
        ...optionalPresent.slice(0, 3).map((field) => `Complementario disponible: ${field}`)
      ]
    },
    {
      title: '3. Faltante crítico',
      tone: `Completar manualmente antes de usar ${config.label.toLowerCase()}.`,
      items: expectedMissing.length ? expectedMissing : ['Sin faltantes críticos para este tipo documental.']
    }
  ];

  el('sectionFlow').innerHTML = sections.map((section) => `
    <div class="warn" style="margin-bottom:10px;">
      <strong>${section.title}</strong>
      <div class="muted" style="margin:4px 0 8px;">${section.tone}</div>
      <ul>${section.items.map((item) => `<li>${item}</li>`).join('')}</ul>
    </div>
  `).join('');

  const checks = [
    `Tipo documental activo: ${config.label}`,
    `Campos confirmados/presentes: ${expectedPresent.length}`,
    `Faltantes críticos visibles: ${expectedMissing.length}`,
    `Alertas relevantes visibles: ${relevantAlerts.length}`,
    `Borrador final: bloqueado (${reviewCase.draft_contract?.final_generation_blocked ? 'OK' : 'REVISAR'})`
  ];
  el('flowChecks').innerHTML = checks.map((item) => `<li>${item}</li>`).join('');
}

function renderSectionControls(reviewCase) {
  const sections = [
    {
      key: 'confirmed',
      title: 'Dato confirmado',
      detail: 'Validar que solo queden datos trazables desde la instruccion o el caso base.'
    },
    {
      key: 'suggested',
      title: 'Sugerencia clinica revisable',
      detail: 'Confirmar que la familia y la plantilla propuestas sean corregibles manualmente.'
    },
    {
      key: 'missing',
      title: 'Faltante critico',
      detail: 'Marcar si los faltantes visibles alcanzan para frenar cualquier uso clinico.'
    }
  ];

  el('sectionControls').innerHTML = sections.map((section) => `
    <div class="warn" style="margin-bottom:10px;">
      <strong>${section.title}</strong>
      <div class="muted" style="margin:4px 0 8px;">${section.detail}</div>
      <select data-review-section="${section.key}">
        <option value="pending" ${state.sectionReview[section.key] === 'pending' ? 'selected' : ''}>Pendiente</option>
        <option value="ok" ${state.sectionReview[section.key] === 'ok' ? 'selected' : ''}>OK local</option>
        <option value="followup" ${state.sectionReview[section.key] === 'followup' ? 'selected' : ''}>Revisar antes de uso</option>
        <option value="blocked" ${state.sectionReview[section.key] === 'blocked' ? 'selected' : ''}>Bloqueado</option>
      </select>
    </div>
  `).join('');

  document.querySelectorAll('[data-review-section]').forEach((node) => {
    node.addEventListener('change', (event) => {
      state.sectionReview[event.target.dataset.reviewSection] = event.target.value;
      renderReviewSummary(reviewCase);
      el('draft').textContent = buildDraft(reviewCase);
      persistReviewState();
    });
  });
}

function renderReviewSummary(reviewCase) {
  const labels = {
    pending: 'Pendiente',
    ok: 'OK local',
    followup: 'Revisar antes de uso',
    blocked: 'Bloqueado'
  };
  const criticalMissing = getDocumentView(reviewCase).expectedMissing;
  const blockedSections = Object.entries(state.sectionReview).filter(([, value]) => value === 'blocked');
  const followupSections = Object.entries(state.sectionReview).filter(([, value]) => value === 'followup');
  const okSections = Object.entries(state.sectionReview).filter(([, value]) => value === 'ok').length;
  const note = state.reviewNote.trim();

  el('reviewSummary').innerHTML = `
    <strong>Estado local:</strong> ${okSections}/3 secciones en OK local.<br>
    <strong>Pendientes criticos:</strong> ${criticalMissing.length ? criticalMissing.join(', ') : 'sin faltantes criticos para este tipo documental'}<br>
    <strong>Secciones a revisar:</strong> ${followupSections.length ? followupSections.map(([key]) => key).join(', ') : 'ninguna marcada'}<br>
    <strong>Bloqueos locales:</strong> ${blockedSections.length ? blockedSections.map(([key]) => key).join(', ') : 'sin bloqueo local marcado'}<br>
    <strong>Nota breve:</strong> ${note || 'sin nota local'}
  `;

  renderPersistenceStatus();

  const noteEl = el('reviewNote');
  if (noteEl && noteEl.value !== state.reviewNote) noteEl.value = state.reviewNote;
}

function getStyleGuide(reviewCase) {
  return STYLE_GUIDES[reviewCase.family_code] || null;
}

function buildMissingMissDataList() {
  return [
    'Hora de inicio y hora de fin del acto quirúrgico',
    'Tornillos: marca, modelo, diámetro, longitud y lote',
    'PLIF/caja: marca, altura, lote y serie',
    'Barras: marca, diámetro y lote',
    'Hemostático: nombre y lote',
    'Parche dural si se utilizó: marca y lote',
    'Pérdida hemática estimada',
    'Lado exacto de abordaje por triángulo de Kambin',
    'Matrícula provincial y equipo final interviniente'
  ];
}

function buildEmbeddedRationale(reviewCase, documentType = el('documentType').value) {
  const { config, expectedMissing } = getDocumentViewForType(reviewCase, documentType);
  return MEDICOLEGAL_FOUNDATIONS
    .filter((item) => item.appliesTo.includes(documentType))
    .map((item) => ({
      ...item,
      detail: item.key === 'identificacion_autoria'
        ? `${item.text} ${expectedMissing.some((field) => ['fecha_acto_quirurgico', 'hora_inicio', 'hora_fin'].includes(field)) ? 'En este borrador, fecha/hora siguen como completado manual obligatorio.' : 'En este borrador no quedan faltantes críticos de fecha/hora.'}`
        : item.key === 'cronologia_tecnica'
          ? `${item.text} ${expectedMissing.length ? `Faltantes críticos visibles: ${expectedMissing.join(', ')}.` : 'Sin faltantes críticos visibles para este documento base.'}`
          : item.key === 'evolucion_destino'
            ? `${item.text} ${expectedMissing.includes('destino') ? 'Destino sigue pendiente de validación manual.' : 'Destino ya tiene base documentada en este borrador.'}`
            : item.text
    }));
}

function buildEmbeddedRationaleText(reviewCase, documentType = el('documentType').value) {
  const embeddedRationale = buildEmbeddedRationale(reviewCase, documentType);
  if (!embeddedRationale.length) return '';

  return [
    'FUNDAMENTOS MEDICOLEGALES EMBEBIDOS:',
    ...embeddedRationale.map((item) => `${item.shortLabel}: ${item.detail} Fundamento: ${item.basis}`)
  ].join('\n');
}

function buildSyntheticConsentDocument(reviewCase) {
  const instruction = el('instruction').value || 'Sin instrucción cargada';
  const institution = INSTITUTIONS[state.institutionKey] || INSTITUTIONS.clinica_centro;
  const institutionTitle = institution.label.toUpperCase();
  const serviceTitle = institution.headerLine.toUpperCase();
  const { patientName, surgeonName, ageLabel, surgeryDateLabel, lumbarLevel, cervicalLevels, diagnosisLabel } = extractInstructionEntities(instruction);
  const isCircumferentialLumbar = reviewCase.family_code === 'lumbar_fijacion_miss_artrodesis' && /circunferencial|360|plif|l\d[\/-]l\d|l\d[\/-]s\d/i.test(instruction);
  const isCervicalLaminoplasty = reviewCase.family_code === 'cervical_laminoplastia_descompresion' && /laminoplast|cervical|c\d[\/-]c?\d|cuadriparesia|mielopat/i.test(instruction);
  const isLumbarMicrodiscectomy = reviewCase.family_code === 'lumbar_microdiscectomia_hdl' && /microdiscect|hernia de disco|hdl|radicul/i.test(instruction);
  if (!isCircumferentialLumbar && !isCervicalLaminoplasty && !isLumbarMicrodiscectomy) return null;

  const procedureLabel = isCircumferentialLumbar
    ? `fijación instrumentada y artrodesis lumbar ${lumbarLevel}`
    : isCervicalLaminoplasty
      ? `laminoplastia cervical ${cervicalLevels}`
      : `microdiscectomía lumbar ${lumbarLevel}`;
  const diagnosisText = diagnosisLabel || (isCircumferentialLumbar
    ? `patología degenerativa lumbar ${lumbarLevel} con inestabilidad segmentaria`
    : isCervicalLaminoplasty
      ? `canal estrecho cervical ${cervicalLevels} con mielopatía`
      : `hernia de disco lumbar ${lumbarLevel} con radiculopatía`);
  const objectiveText = isCircumferentialLumbar
    ? `estabilizar el segmento ${lumbarLevel} para reducir dolor mecánico, recuperar función y disminuir progresión de la inestabilidad`
    : isCervicalLaminoplasty
      ? `descomprimir la médula cervical en ${cervicalLevels}, intentar frenar la progresión mielopática y preservar función neurológica`
      : `descomprimir la raíz comprometida en ${lumbarLevel}, aliviar dolor radicular y mejorar la limitación funcional`;
  const alternativesText = isCircumferentialLumbar
    ? 'Alternativas conversadas: continuar tratamiento conservador, analgesia, rehabilitación, infiltraciones o diferir el gesto quirúrgico si el balance riesgo-beneficio cambiara.'
    : isCervicalLaminoplasty
      ? 'Alternativas conversadas: observación, rehabilitación y tratamiento sintomático, asumiendo el riesgo de persistencia o progresión del compromiso mielopático.'
      : 'Alternativas conversadas: tratamiento conservador prolongado, kinesioterapia, analgesia, infiltraciones y vigilancia evolutiva si la clínica lo permitiera.';
  const familySpecificRisks = isCircumferentialLumbar
    ? 'Riesgos particularmente remarcados para este caso: malposición o aflojamiento de implantes, pseudoartrosis, lesión radicular, fístula de LCR, necesidad de ampliar la estabilización o revisar el material en un segundo tiempo.'
    : isCervicalLaminoplasty
      ? 'Riesgos particularmente remarcados para este caso: empeoramiento neurológico, paresia C5, dolor axial cervical persistente, necesidad de convertir o ampliar la descompresión y complicaciones del material de fijación si se utilizara.'
      : 'Riesgos particularmente remarcados para este caso: persistencia del dolor radicular, recurrencia herniaria, lesión dural con fístula de LCR, déficit neurológico y necesidad de reintervención por recidiva o fibrosis.';

  return [
    institutionTitle,
    serviceTitle,
    'CONSENTIMIENTO INFORMADO BASE',
    '',
    `PACIENTE: ${patientName}.        EDAD: ${ageLabel}.        FECHA: ${surgeryDateLabel}.`,
    `PROFESIONAL INFORMANTE: ${surgeonName}.`,
    '',
    `Procedimiento propuesto: ${procedureLabel}.`,
    `Diagnóstico de base: ${diagnosisText}.`,
    `Objetivo práctico comunicado: ${objectiveText}.`,
    '',
    'Se deja constancia de que se explicó en lenguaje claro el diagnóstico, el objetivo del procedimiento, los beneficios esperables, las alternativas razonables y los riesgos relevantes, incluyendo sangrado, infección, lesión neurológica, fístula de LCR, persistencia del dolor, necesidad de reintervención, complicaciones anestésicas y eventos no previsibles propios del acto quirúrgico.',
    '',
    familySpecificRisks,
    '',
    alternativesText,
    '',
    'Se informó también que el resultado no puede garantizarse y que podrían requerirse maniobras, materiales o decisiones intraoperatorias complementarias si la situación clínica lo exige.',
    '',
    'El paciente manifiesta haber comprendido la información recibida, haber podido formular preguntas y otorgar consentimiento para continuar con la estrategia propuesta.',
    '',
    '<i>Base de consentimiento para revisión interna: completar identificación formal, firmantes, testigos, riesgos particulares del caso, alternativas personalizadas y constancia de entrega/copia antes de cualquier uso real.</i>'
  ].join('\n');
}

function buildSyntheticEvolutionDocument(reviewCase) {
  const instruction = el('instruction').value || 'Sin instrucción cargada';
  const institution = INSTITUTIONS[state.institutionKey] || INSTITUTIONS.clinica_centro;
  const institutionTitle = institution.label.toUpperCase();
  const serviceTitle = institution.headerLine.toUpperCase();
  const { patientName, ageLabel, surgeryDateLabel, lumbarLevel, cervicalLevels } = extractInstructionEntities(instruction);
  const isCircumferentialLumbar = reviewCase.family_code === 'lumbar_fijacion_miss_artrodesis' && /circunferencial|360|plif|l\d[\/-]l\d|l\d[\/-]s\d/i.test(instruction);
  const isCervicalLaminoplasty = reviewCase.family_code === 'cervical_laminoplastia_descompresion' && /laminoplast|cervical|c\d[\/-]c?\d|cuadriparesia|mielopat/i.test(instruction);
  const isLumbarMicrodiscectomy = reviewCase.family_code === 'lumbar_microdiscectomia_hdl' && /microdiscect|hernia de disco|hdl|radicul/i.test(instruction);
  if (!isCircumferentialLumbar && !isCervicalLaminoplasty && !isLumbarMicrodiscectomy) return null;

  if (isCircumferentialLumbar) {
    return [
      institutionTitle,
      serviceTitle,
      'EVOLUCIÓN POSTOPERATORIA INMEDIATA',
      '',
      `PACIENTE: ${patientName}.        EDAD: ${ageLabel}.        FECHA: ${surgeryDateLabel}.`,
      '',
      `POI de fijación instrumentada y artrodesis lumbar ${lumbarLevel}. Procedimiento bien tolerado. Sin déficit motor grosero en el control inmediato. Se dejan indicaciones postoperatorias y control evolutivo.`,
      '',
      '<i>Completado por app para cierre visual de prueba: falta consignar examen neurológico posoperatorio específico, destino, drenajes, analgesia e indicaciones nominales.</i>'
    ].join('\n');
  }

  if (isLumbarMicrodiscectomy) {
    return [
      institutionTitle,
      serviceTitle,
      'EVOLUCIÓN POSTOPERATORIA INMEDIATA',
      '',
      `PACIENTE: ${patientName}.        EDAD: ${ageLabel}.        FECHA: ${surgeryDateLabel}.`,
      '',
      `POI de microdiscectomía lumbar ${lumbarLevel}. Procedimiento bien tolerado. Sin déficit motor grosero agregado en el control inmediato. Se dejan indicaciones postoperatorias y control evolutivo.`,
      '',
      '<i>Completado por app para cierre visual de prueba: falta consignar examen neurológico detallado, dolor residual inmediato, deambulación, destino y medicación nominal.</i>'
    ].join('\n');
  }

  return [
    institutionTitle,
    serviceTitle,
    'EVOLUCIÓN POSTOPERATORIA INMEDIATA',
    '',
    `PACIENTE: ${patientName}.        EDAD: <i>${ageLabel}</i>.        FECHA: <i>${surgeryDateLabel}</i>.`,
    '',
    `POI de laminoplastia cervical ${cervicalLevels} para tratamiento de canal estrecho cervical sintomático. Moviliza los 4 miembros, sin déficit agregado evidente en el control inmediato. Se dejan indicaciones postoperatorias.`,
    '',
    '<i>Completado por app para cierre visual de prueba: falta consignar destino final, examen neurológico detallado, drenajes y esquema analgésico/postoperatorio.</i>'
  ].join('\n');
}

function buildSyntheticFinalDocument(reviewCase, documentType = el('documentType').value) {
  const config = getDocumentConfigByLabel(documentType);
  const instruction = el('instruction').value || 'Sin instrucción cargada';
  const institution = INSTITUTIONS[state.institutionKey] || INSTITUTIONS.clinica_centro;
  const institutionTitle = institution.label.toUpperCase();
  const serviceTitle = institution.headerLine.toUpperCase();
  const embeddedRationaleText = buildEmbeddedRationaleText(reviewCase, documentType);
  const { patientName, surgeonName, assistantName, ageLabel, surgeryDateLabel, lumbarLevel, cervicalLevels, laterality, diagnosisLabel, quickExceptions, anesthesiaLabel, positioningLabel, fluoroscopyLabel, monitoringLabel, drainageLabel, antibioticsLabel, startTimeLabel, endTimeLabel, bloodLossLabel, implantLabel, destinationLabel, complicationLabel } = extractInstructionEntities(instruction);
  const quickExceptionsLine = quickExceptions?.length ? `EXCEPCIONES RÁPIDAS DEL RELATO: ${quickExceptions.join('; ')}. <i>Confirmar si realmente aplican al acto documentado.</i>` : '';
  const colloquialRoutineLine = `LECTURA OPERATIVA DEL RELATO: ${anesthesiaLabel}; ${positioningLabel}; ${fluoroscopyLabel}; ${monitoringLabel}; ${drainageLabel}; ${antibioticsLabel}; hora inicio ${startTimeLabel}; hora fin ${endTimeLabel}; pérdida hemática ${bloodLossLabel}; ${implantLabel}; complicaciones ${complicationLabel}; destino posoperatorio ${destinationLabel}. <i>Tomar estas marcas como señales de borrador y completar solo con dato confirmado si se fuera a usar clínicamente.</i>`;
  const isCircumferentialLumbar = reviewCase.family_code === 'lumbar_fijacion_miss_artrodesis' && /circunferencial|360|plif|l\d[\/-]l\d|l\d[\/-]s\d/i.test(instruction);
  const isCervicalLaminoplasty = reviewCase.family_code === 'cervical_laminoplastia_descompresion' && /laminoplast|cervical|c\d[\/-]c?\d|cuadriparesia|mielopat/i.test(instruction);
  const isLumbarMicrodiscectomy = reviewCase.family_code === 'lumbar_microdiscectomia_hdl' && /microdiscect|hernia de disco|hdl|radicul/i.test(instruction);
  if (!isCircumferentialLumbar && !isCervicalLaminoplasty && !isLumbarMicrodiscectomy) return null;

  if (isCircumferentialLumbar) {
    const historia = [
      institutionTitle,
      serviceTitle,
      'HISTORIA CLINICA',
      '',
      `PACIENTE: ${patientName}.        EDAD: ${ageLabel}.        FECHA: ${surgeryDateLabel}.`,
      '',
      `MOTIVO DE INGRESO: cirugía lumbar ${lumbarLevel} para descompresión neural y estabilización circunferencial del segmento.`,
      '',
      `ENFERMEDAD ACTUAL: lumbalgia y dolor radicular${laterality ? ` ${laterality}` : ''} de evolución progresiva, con limitación para la marcha y las actividades habituales, sin respuesta adecuada a tratamientos conservadores, por lo que se plantea resolución quirúrgica del nivel ${lumbarLevel}.`,
      '',
      'EXAMEN FÍSICO: lúcido/a, hemodinámicamente compensado/a. Sin déficit motor grosero al ingreso. <i>Completar hallazgos segmentarios, sensibilidad, reflejos y maniobras de tensión radicular.</i>',
      '',
      `RMN: cambios degenerativos del segmento ${lumbarLevel} con compromiso del canal y de los recesos laterales, asociados a inestabilidad segmentaria. <i>Completar descripción exacta según estudio real.</i>`,
      '',
      'EXAMENES PREQUIRURGICOS: en rango aceptable para procedimiento programado. <i>Completar ECG, Rx tórax, laboratorio y evaluación preanestésica efectivamente realizada.</i>',
      '',
      `IMPRESIÓN DIAGNOSTICA: ${diagnosisOnlyText(diagnosisLabel || `patología degenerativa lumbar ${lumbarLevel} sintomática con inestabilidad y compromiso neural`)}.`,
      '',
      `PLAN TERAPEUTICO: fijación instrumentada y artrodesis lumbar ${lumbarLevel}.`,
      '',
      'Se informaron al paciente y a sus familiares sobre los objetivos, riesgos, beneficios y alternativas del procedimiento. Se firmaron consentimientos.'
    ].join('\n');

    const parte = [
      institutionTitle,
      serviceTitle,
      'PARTE QUIRURGICO',
      '',
      `PACIENTE: ${patientName}.        EDAD: ${ageLabel}.        FECHA: ${surgeryDateLabel}.`,
      '',
      `CIRUJANO: ${surgeonName}.        AYUDANTES: ${assistantName}.`,
      '',
      `DIAGNOSTICO: ${diagnosisOnlyText(diagnosisLabel || `patología degenerativa lumbar ${lumbarLevel} con inestabilidad y compromiso neural`)}.`,
      '',
      `OPERACIÓN: fijación instrumentada y artrodesis lumbar ${lumbarLevel}.`,
      '',
      `HORARIO QUIRÚRGICO REFERIDO: inicio ${startTimeLabel}; fin ${endTimeLabel}.`,
      `PÉRDIDA HEMÁTICA REFERIDA: ${bloodLossLabel}.`,
      `MATERIAL/IMPLANTES REFERIDOS: ${implantLabel}.`,
      '',
      'Código: <i>__________________</i>.',
      '',
      colloquialRoutineLine,
      '',
      `Decúbito prono, soportes bajo tórax y tobillos. Se constatan pulsos pedios. Antisepsia rigurosa y campos. Infiltración de celular. Incisión medial por planos. Escoplado paravertebral bilateral hasta exponer puntos de entrada pedicular del nivel ${lumbarLevel}. Corroboración radioscópica de nivel. Colocación de tornillos transpediculares poliaxiales bajo control intraoperatorio. Preparación del espacio discal ${lumbarLevel} y del lecho de artrodesis según técnica. Colocación del sistema de fijación posterior y estabilización circunferencial del segmento. <i>Se dispone injerto óseo y sustituto según disponibilidad y criterio intraoperatorio.</i> Hemostasia completa. <i>Drenaje al lecho según indicación documentada.</i> Cierre por planos. Cura plana, oclusiva y compresiva. Procedimiento bien tolerado, sin complicaciones evidentes.`,
      '',
      quickExceptionsLine,
      '<i>Completado por app para cierre visual de prueba: ayudantes, código, tipo y medidas exactas de implantes, lotes, horarios, hallazgos confirmados, hemostáticos y destino postoperatorio requieren validación manual si se fuera a usar clínicamente.</i>'
    ].filter(Boolean).join('\n');

    const evolucion = [
      institutionTitle,
      serviceTitle,
      'EVOLUCIÓN',
      '',
      `PACIENTE: ${patientName}.        EDAD: ${ageLabel}.        FECHA: ${surgeryDateLabel}.`,
      '',
      `POI de fijación instrumentada y artrodesis lumbar ${lumbarLevel}. Procedimiento bien tolerado. Sin déficit motor grosero en el control inmediato. Se dejan indicaciones postoperatorias y control evolutivo.`,
      '',
      quickExceptionsLine,
      '<i>Completado por app para cierre visual de prueba: falta consignar examen neurológico posoperatorio específico, destino, drenajes, analgesia e indicaciones nominales.</i>'
    ].filter(Boolean).join('\n');

    if (config.code === 'hc') return `${historia}\n\n${evolucion}\n\n${embeddedRationaleText}`;
    if (config.code === 'parte') return `${parte}\n\n${evolucion}\n\n${embeddedRationaleText}`;
    return `${historia}\n\n${parte}\n\n${evolucion}\n\n${embeddedRationaleText}`;
  }

  const historiaCervical = [
    institutionTitle,
    serviceTitle,
    'HISTORIA CLINICA',
    '',
    `PACIENTE: ${patientName}.        EDAD: <i>${ageLabel}</i>.        FECHA: <i>${surgeryDateLabel}</i>.`,
    '',
    `MOTIVO DE INGRESO: cirugía de canal estrecho cervical sintomático ${cervicalLevels}.`,
    '',
    'ENFERMEDAD ACTUAL: cuadriparesia leve progresiva, de evolución insidiosa, asociada a dificultad funcional creciente y compromiso mielopático cervical, por lo que se indica tratamiento quirúrgico descompresivo.',
    '',
    'EXAMEN FÍSICO: lúcido/a, hemodinámicamente compensado/a. Cuadriparesia leve. <i>Completar distribución, reflejos osteotendinosos, sensibilidad, marcha y signos piramidales.</i>',
    '',
    `RMN: canal estrecho cervical ${cervicalLevels} con compresión medular. <i>Completar presencia o ausencia de mielomalacia, rectificación o cifosis, y el nivel de mayor compromiso.</i>`,
    '',
    'EXAMENES PREQUIRURGICOS: en rango quirúrgico. <i>Completar laboratorio, Rx tórax y valoración cardiológica/anestésica efectivamente realizadas.</i>',
    '',
    `IMPRESIÓN DIAGNÓSTICA: ${diagnosisLabel || `canal estrecho cervical ${cervicalLevels} con mielopatía cervical y cuadriparesia leve progresiva`}.`,
    '',
    `PLAN TERAPÉUTICO: laminoplastia ${cervicalLevels}, técnica open-door.`,
    '',
    'Se informó al paciente y sus familiares sobre los objetivos y riesgos del procedimiento. Se firmaron consentimientos.'
  ].join('\n');

  const parteCervical = [
    institutionTitle,
    serviceTitle,
    'PARTE QUIRURGICO',
    '',
    `PACIENTE: ${patientName}.        EDAD: <i>${ageLabel}</i>.        FECHA: <i>${surgeryDateLabel}</i>.`,
    '',
    `CIRUJANO: ${surgeonName}.        AYUDANTE: ${assistantName}.`,
    '',
    `DIAGNOSTICO: ${diagnosisLabel || `canal estrecho cervical ${cervicalLevels} con cuadro de cuadriparesia leve progresiva`}.`,
    '',
    `OPERACIÓN: laminoplastia ${cervicalLevels} open-door.`,
    '',
    `HORARIO QUIRÚRGICO REFERIDO: inicio ${startTimeLabel}; fin ${endTimeLabel}.`,
    `PÉRDIDA HEMÁTICA REFERIDA: ${bloodLossLabel}.`,
    `MATERIAL/IMPLANTES REFERIDOS: ${implantLabel}.`,
    '',
    'Código: <i>12.17.02 + instrumentación</i>.',
    '',
    colloquialRoutineLine,
    '',
    'Decúbito prono, soportes bajo tórax, crestas ilíacas y tobillos. Mayfield. Se constatan pulsos pedios. Antisepsia rigurosa y campos. Infiltración de celular. Incisión medial desde C1 hasta D1, por planos. Disección paravertebral bilateral respetando los ligamentos interespinoso y nucal. Expuestas bilateralmente las partes mediales de los macizos articulares de C3 a C7, se realiza laminotomía del lado de apertura y canal de bisagra contralateral en la unión lámino-articular. Apertura de las láminas en bisagra. Fijación en posición de las láminas con placas de laminoplastia. El saco dural queda descomprimido y pulsátil. Hemostasia completa. <i>Si correspondiera, colocar chips de hueso y sustituto óseo en la canaleta de bisagra.</i> Cierre de músculo, aponeurosis, celular y piel por planos. Cura plana, oclusiva y compresiva. Procedimiento bien tolerado, sin complicaciones evidentes.',
    '',
    quickExceptionsLine,
    '<i>Completado por app para cierre visual de prueba: edad, fecha, ayudante, lateralidad exacta de apertura, cantidad/tipo de placas, hallazgos medulares específicos y cualquier evento hemodinámico intraoperatorio requieren validación manual.</i>'
  ].filter(Boolean).join('\n');

  const evolucionCervical = [
    institutionTitle,
    serviceTitle,
    'EVOLUCIÓN',
    '',
    `PACIENTE: ${patientName}.        EDAD: <i>${ageLabel}</i>.        FECHA: <i>${surgeryDateLabel}</i>.`,
    '',
    `POI de laminoplastia cervical ${cervicalLevels} para tratamiento de canal estrecho cervical sintomático. Moviliza los 4 miembros, sin déficit agregado evidente en el control inmediato. Se dejan indicaciones postoperatorias.`,
    '',
    colloquialRoutineLine,
    '',
    quickExceptionsLine,
    '<i>Completado por app para cierre visual de prueba: falta consignar destino final, examen neurológico detallado, drenajes y esquema analgésico/postoperatorio.</i>'
  ].filter(Boolean).join('\n');

  if (isLumbarMicrodiscectomy) {
    const historiaLumbar = [
      institutionTitle,
      serviceTitle,
      'HISTORIA CLINICA',
      '',
      `PACIENTE: ${patientName}.        EDAD: ${ageLabel}.        FECHA: ${surgeryDateLabel}.`,
      '',
      `MOTIVO DE INGRESO: dolor lumbar y radicular por hernia de disco ${lumbarLevel} con indicación de microdiscectomía.`,
      '',
      `ENFERMEDAD ACTUAL: lumbociatalgia${laterality ? ` ${laterality}` : ''} persistente, con pobre respuesta al tratamiento conservador, correlación clínico-radiológica y criterio quirúrgico para descompresión focal del nivel ${lumbarLevel}.`,
      '',
      'EXAMEN FÍSICO: lúcido/a, hemodinámicamente compensado/a. <i>Completar déficit motor segmentario, sensibilidad, reflejos y maniobras radiculares relevantes.</i>',
      '',
      `RMN: hernia de disco ${lumbarLevel} con conflicto radicular. <i>Completar lateralidad exacta, grado de compresión y hallazgos asociados según informe real.</i>`,
      '',
      'EXAMENES PREQUIRURGICOS: en rango aceptable para cirugía programada. <i>Completar laboratorio, evaluación preanestésica y estudios complementarios efectivamente realizados.</i>',
      '',
      `IMPRESIÓN DIAGNÓSTICA: ${diagnosisLabel || `hernia de disco lumbar ${lumbarLevel} sintomática con radiculopatía`}.`,
      '',
      `PLAN TERAPÉUTICO: microdiscectomía lumbar ${lumbarLevel}.`,
      '',
      'Se informó al paciente y a sus familiares sobre objetivos, riesgos, beneficios y alternativas del procedimiento. Se firmaron consentimientos.'
    ].join('\n');

    const parteLumbar = [
      institutionTitle,
      serviceTitle,
      'PARTE QUIRURGICO',
      '',
      `PACIENTE: ${patientName}.        EDAD: ${ageLabel}.        FECHA: ${surgeryDateLabel}.`,
      '',
      `CIRUJANO: ${surgeonName}.        AYUDANTE: ${assistantName}.`,
      '',
      `DIAGNOSTICO: ${diagnosisLabel || `hernia de disco lumbar ${lumbarLevel} con radiculopatía`}.`,
      '',
      `OPERACIÓN: microdiscectomía lumbar ${lumbarLevel}${laterality ? ` ${laterality}` : ''}.`,
      '',
      `HORARIO QUIRÚRGICO REFERIDO: inicio ${startTimeLabel}; fin ${endTimeLabel}.`,
      `PÉRDIDA HEMÁTICA REFERIDA: ${bloodLossLabel}.`,
      `MATERIAL/IMPLANTES REFERIDOS: ${implantLabel}.`,
      '',
      'Código: <i>__________________</i>.',
      '',
      colloquialRoutineLine,
      '',
      `Decúbito prono, antisepsia rigurosa y campos. Control radioscópico de nivel ${lumbarLevel}. Abordaje interlaminar por planos con magnificación. Se identifica saco dural y raíz comprometida${laterality ? ` del lado ${laterality}` : ''}, se realiza flavectomía limitada, exposición del receso lateral y extracción del fragmento discal herniario. Revisión del espacio discal y liberación radicular satisfactoria. Hemostasia completa. Cierre por planos. Cura plana, oclusiva y compresiva. Procedimiento bien tolerado, sin complicaciones evidentes.`,
      '',
      quickExceptionsLine,
      '<i>Completado por app para cierre visual de prueba: horarios, hallazgos intraoperatorios específicos, lateralidad definitiva, material hemostático y destino inmediato requieren validación manual antes de cualquier uso real.</i>'
    ].filter(Boolean).join('\n');

    const evolucionLumbar = [
      institutionTitle,
      serviceTitle,
      'EVOLUCIÓN',
      '',
      `PACIENTE: ${patientName}.        EDAD: ${ageLabel}.        FECHA: ${surgeryDateLabel}.`,
      '',
      `POI de microdiscectomía lumbar ${lumbarLevel}. Procedimiento bien tolerado. Sin déficit motor grosero agregado en el control inmediato. Se dejan indicaciones postoperatorias y control evolutivo.`,
      '',
      colloquialRoutineLine,
      '',
      quickExceptionsLine,
      '<i>Completado por app para cierre visual de prueba: falta consignar examen neurológico detallado, dolor residual inmediato, deambulación, destino y medicación nominal.</i>'
    ].filter(Boolean).join('\n');

    if (config.code === 'hc') return `${historiaLumbar}\n\n${evolucionLumbar}\n\n${embeddedRationaleText}`;
    if (config.code === 'parte') return `${parteLumbar}\n\n${evolucionLumbar}\n\n${embeddedRationaleText}`;
    return `${historiaLumbar}\n\n${parteLumbar}\n\n${evolucionLumbar}\n\n${embeddedRationaleText}`;
  }

  if (config.code === 'hc') return `${historiaCervical}\n\n${evolucionCervical}\n\n${embeddedRationaleText}`;
  if (config.code === 'parte') return `${parteCervical}\n\n${evolucionCervical}\n\n${embeddedRationaleText}`;
  return `${historiaCervical}\n\n${parteCervical}\n\n${evolucionCervical}\n\n${embeddedRationaleText}`;
}

function buildDraft(reviewCase, documentType = el('documentType').value) {
  const { config, expectedPresent, expectedMissing, optionalPresent, optionalMissing, relevantAlerts } = getDocumentViewForType(reviewCase, documentType);
  const triage = buildInstructionTriage(reviewCase);
  const embeddedRationale = buildEmbeddedRationale(reviewCase, documentType);
  const suggestionLine = state.lastSuggestion
    ? `Sugerencia automática: ${state.lastSuggestion.familyLabel} (${state.lastSuggestion.confidence}; motivo: ${state.lastSuggestion.reasons.join(', ') || 'sin palabras clave trazables'})`
    : 'Sugerencia automática: sin coincidencia suficiente, requiere selección manual';
  const overrideLine = state.manualOverride
    ? 'Selección final: corregida manualmente por el médico/revisor.'
    : 'Selección final: coincide con la sugerencia automática actual.';
  const blockedDomains = reviewCase.missing_fields_map.blocked_inference_domains || [];
  const syntheticFinal = buildSyntheticFinalDocument(reviewCase, documentType);
  const institution = INSTITUTIONS[state.institutionKey] || INSTITUTIONS.clinica_centro;

  return [
    `Documento: ${config.label}`,
    `Institución seleccionada: ${institution.label}`,
    `Cirujano principal: ${state.surgeonName || 'Carlos Zanardi'}`,
    `Familia: ${reviewCase.family_label}`,
    `Instrucción médica: ${el('instruction').value || 'Sin instrucción cargada'}`,
    suggestionLine,
    overrideLine,
    `Semáforo: ${reviewCase.semaforo.toUpperCase()}`,
    `Mesa de revisión local: dato_confirmado=${state.sectionReview.confirmed}; sugerencia_clinica=${state.sectionReview.suggested}; faltante_critico=${state.sectionReview.missing}`,
    `Nota breve local: ${state.reviewNote || 'sin nota local'}`,
    '',
    `${config.blockedTitle}:`,
    ...config.blockedBullets.map((item) => `- ${item}`),
    `- Campos críticos faltantes para ${config.code}: ${expectedMissing.length}.`,
    `- Alertas relevantes para ${config.code}: ${relevantAlerts.length}.`,
    `- Dominios bloqueados para inferencia automática: ${blockedDomains.length ? blockedDomains.join(', ') : 'ninguno en este caso'}.`,
    '',
    'Triage de la instrucción libre:',
    ...(triage.confirmed.length ? triage.confirmed.map((item) => `✓ Confirmado: ${item}`) : ['• Confirmado: sin dato trazable suficiente todavía']),
    ...(triage.suggested.length ? triage.suggested.map((item) => `• Sugerencia clínica: ${item}`) : ['• Sugerencia clínica: sin sugerencia automática útil todavía']),
    ...expectedMissing.map((field) => `• Faltante crítico: ${field}`),
    '',
    `${config.checklistTitle}:`,
    ...expectedPresent.map((field) => `✓ Campo esperado presente: ${field}`),
    ...expectedMissing.map((field) => `• Completar manualmente: ${field}`),
    '',
    'Fundamentos médico-legales embebidos:',
    ...embeddedRationale.map((item) => `• ${item.shortLabel}: ${item.detail} Fundamento: ${item.basis}`),
    ...(optionalPresent.length || optionalMissing.length ? ['', 'Campos complementarios:'] : []),
    ...optionalPresent.map((field) => `✓ Complementario presente: ${field}`),
    ...optionalMissing.map((field) => `• Complementario faltante: ${field}`),
    ...(syntheticFinal ? ['', 'Borrador sintético de producto final de la aplicación:', syntheticFinal] : [])
  ].join('\n');
}

function renderDualWorkflow(reviewCase) {
  const docs = ['Historia clínica', 'Parte quirúrgico'];
  const institution = INSTITUTIONS[state.institutionKey] || INSTITUTIONS.clinica_centro;
  const consentDraft = buildSyntheticConsentDocument(reviewCase);
  const evolutionDraft = buildSyntheticEvolutionDocument(reviewCase);
  const packageStatus = docs.map((documentType) => {
    const { config, expectedMissing, expectedPresent } = getDocumentViewForType(reviewCase, documentType);
    const synthetic = buildSyntheticFinalDocument(reviewCase, documentType);
    const embeddedRationale = buildEmbeddedRationale(reviewCase, documentType);
    const draftSource = synthetic || buildDraft(reviewCase, documentType);
    const preview = draftSource
      .split('\n')
      .filter(Boolean)
      .slice(0, 5)
      .join(' · ');
    const exportBase = `${reviewCase.family_code}_${config.code}_${state.institutionKey}`;
    return {
      config,
      expectedMissing,
      expectedPresent,
      embeddedRationale,
      draftSource,
      preview,
      exportBase,
      synthetic
    };
  });

  const packageMissing = [...new Set(packageStatus.flatMap((item) => item.expectedMissing))];
  const packageSummaryCard = `
    <div class="warn" style="margin-bottom:10px;">
      <strong>Paquete clínico base desde una sola entrada</strong><br>
      <span class="muted">Relato coloquial único, salida separada para consentimiento, historia clínica, parte quirúrgico y evolución postoperatoria inmediata.</span>
      <ul>
        <li>Piezas visibles del paquete: ${consentDraft ? 5 : 4}</li>
        <li>Familia activa: ${escapeHtml(reviewCase.family_label)}</li>
        <li>Faltantes críticos agregados: ${packageMissing.length ? packageMissing.join(', ') : 'sin faltantes críticos visibles para esta base'}</li>
        <li>Gate vigente: review_only detect-only, con validación humana y Codex Guard obligatorias.</li>
        <li>Cola médico-legal activa: normas, doctrina y jurisprudencia quedan como refuerzo detect-only, no como bloqueo de generación.</li>
        <li>Siguiente uso seguro: revisar faltantes, completar datos confirmados y recién luego congelar candidato auditable.</li>
      </ul>
    </div>
  `;

  const cards = packageStatus.map(({ config, expectedMissing, expectedPresent, embeddedRationale, draftSource, preview, exportBase, synthetic }) => `
      <div class="warn" style="margin-bottom:10px;">
        <strong>${config.label}</strong><br>
        <span class="muted">Mismo relato coloquial, misma familia sugerida, salida base distinta por tipo documental.</span>
        <ul>
          <li>Campos presentes reutilizables: ${expectedPresent.length}</li>
          <li>Faltantes críticos visibles: ${expectedMissing.length ? expectedMissing.join(', ') : 'sin faltantes críticos para esta base'}</li>
          <li>Borrador base: ${synthetic ? 'listo para preview institucional' : 'modo checklist/borrador bloqueado'}</li>
          <li>Fundamento prudente principal: ${embeddedRationale[0] ? `${embeddedRationale[0].shortLabel}. ${embeddedRationale[0].detail}` : 'sin fundamento cargado'}</li>
          <li>Base sugerida para export local: <code>${exportBase}</code></li>
        </ul>
        <div class="muted">Vista rápida: ${escapeHtml(preview)}</div>
        <div class="doc-preview" style="margin-top:12px; padding:18px;">
          <div class="doc-header">
            <img class="doc-logo" src="${institution.logo}" alt="${institution.label}">
            <div class="doc-title">
              <h4>${institution.label}</h4>
              <p>${institution.headerLine}<br>${institution.cityLine}<br>${config.label} · Cirujano: ${escapeHtml(state.surgeonName || 'Carlos Zanardi')}</p>
            </div>
          </div>
          <div class="doc-body">${formatDocumentHtml(draftSource)}</div>
        </div>
      </div>
    `);

  const consentCard = consentDraft ? `
    <div class="warn" style="margin-bottom:10px;">
      <strong>Consentimiento informado base</strong><br>
      <span class="muted">Mismo relato coloquial, salida base adicional para completar el paquete clínico defensivo.</span>
      <div class="doc-preview" style="margin-top:12px; padding:18px;">
        <div class="doc-header">
          <img class="doc-logo" src="${institution.logo}" alt="${institution.label}">
          <div class="doc-title">
            <h4>${institution.label}</h4>
            <p>${institution.headerLine}<br>${institution.cityLine}<br>Consentimiento informado base · Cirujano: ${escapeHtml(state.surgeonName || 'Carlos Zanardi')}</p>
          </div>
        </div>
        <div class="doc-body">${formatDocumentHtml(consentDraft)}</div>
      </div>
    </div>
  ` : '';

  const evolutionCard = evolutionDraft ? `
    <div class="warn" style="margin-bottom:10px;">
      <strong>Evolución postoperatoria inmediata base</strong><br>
      <span class="muted">Salida separada del mismo relato coloquial para no dejar la evolución solo incrustada dentro de historia clínica o parte.</span>
      <div class="doc-preview" style="margin-top:12px; padding:18px;">
        <div class="doc-header">
          <img class="doc-logo" src="${institution.logo}" alt="${institution.label}">
          <div class="doc-title">
            <h4>${institution.label}</h4>
            <p>${institution.headerLine}<br>${institution.cityLine}<br>Evolución postoperatoria inmediata base · Cirujano: ${escapeHtml(state.surgeonName || 'Carlos Zanardi')}</p>
          </div>
        </div>
        <div class="doc-body">${formatDocumentHtml(evolutionDraft)}</div>
      </div>
    </div>
  ` : '';

  const detailedHtml = packageSummaryCard + consentCard + cards.join('') + evolutionCard + '<div class="warn"><strong>Flujo simple esperado</strong><div>1. Se carga audio/texto coloquial. 2. La app sugiere familia clínica. 3. Se revisan faltantes críticos. 4. Se obtiene consentimiento base, historia clínica base, parte quirúrgico base y evolución postoperatoria inmediata base sin liberar salida final.</div></div>';
  const simpleHtml = packageSummaryCard + '<div class="warn"><strong>Resumen ejecutivo del flujo</strong><div>Desde una sola entrada coloquial, la app ahora separa consentimiento base, historia clínica base, parte quirúrgico base y evolución postoperatoria inmediata base, deja visibles los faltantes críticos y muestra las vistas institucionales completas para revisión comparada sin salir del mismo caso.</div></div>' + consentCard + cards + evolutionCard;

  const dualWorkflowEl = el('dualWorkflow');
  if (dualWorkflowEl) dualWorkflowEl.innerHTML = detailedHtml;

  const dualWorkflowSimpleEl = el('dualWorkflowSimple');
  if (dualWorkflowSimpleEl) dualWorkflowSimpleEl.innerHTML = simpleHtml;
}

function renderFormalReviewSources() {
  el('hcParteSources').innerHTML = FORMAL_REVIEW_SOURCES.map((source) => `
    <li><strong>${source.status.toUpperCase()}</strong> · ${source.title}<br><span class="muted">${source.path} · ${source.note}</span></li>
  `).join('');

  el('hcPartePendingReview').innerHTML = 'Base médico-legal avanzada en modo detect-only/review_only. Estado vigente: NO APTO_PARA_ENTREGAR sin revisión humana final. El gate de 6 controles sirve para tamiz prudente y las tres fuentes documentales quedan congeladas como baseline interno, con cierre formal todavía pendiente.';
}

function renderReviewQueue(reviewCase) {
  const documentType = el('documentType').value;
  const { expectedMissing } = getDocumentView(reviewCase);
  const blockedDomains = reviewCase.missing_fields_map.blocked_inference_domains || [];
  const evolutionDraft = buildEvolutionDraft(reviewCase) || '';
  const poiNeedsManualReview = expectedMissing.includes('destino') || /examen neurológico|analgesia|indicaciones nominales|medicación nominal|drenajes/i.test(evolutionDraft);
  const pendingControls = SIX_CONTROL_GATE.filter((control) => {
    if (control.key === 'identificacion') return expectedMissing.some((field) => ['fecha_acto_quirurgico', 'hora_inicio', 'hora_fin'].includes(field));
    if (control.key === 'parte_critico') return expectedMissing.some((field) => ['tecnica_quirurgica', 'hallazgos_intraoperatorios', 'complicaciones', 'implantes', 'implante_marca_lote_serie', 'hemostatico_nombre_lote_cantidad', 'parche_duramadre_marca_lote_serie', 'verificacion_nivel_radioscopia'].includes(field));
    if (control.key === 'integridad') return true;
    return false;
  });
  const medicoLegalAxes = MEDICOLEGAL_UPDATE_AXES.filter((axis) => axis.when(reviewCase, expectedMissing, documentType));

  const reviewQueue = [
    ...expectedMissing.map((field) => ({
      priority: 1,
      kind: 'faltante_critico',
      title: `Completar ${field}`,
      detail: `Dato crítico todavía no confirmado para ${el('documentType').value}.`,
      source: 'caso actual'
    })),
    ...(poiNeedsManualReview ? [{
      priority: 2,
      kind: 'poi_revision',
      title: 'Cerrar POI base antes de congelar candidato auditable',
      detail: 'La evolución inmediata sigue marcando revisión manual de examen neurológico, destino, drenajes o esquema de indicaciones nominales.',
      source: 'buildEvolutionDraft'
    }] : []),
    ...blockedDomains.map((domain) => ({
      priority: 2,
      kind: 'dominio_bloqueado',
      title: `Resolver dominio ${domain}`,
      detail: 'La app preserva detect-only en este dominio. Solo corresponde completar con dato confirmado o dejar constancia de excepción real.',
      source: 'missing_fields_map.blocked_inference_domains'
    })),
    ...pendingControls.map((control) => ({
      priority: 3,
      kind: 'gate_pendiente',
      title: control.title,
      detail: `Control interno todavía no consolidado para este caso. Señales app: ${control.appSignals.join(' | ')}`,
      source: 'SIX_CONTROL_GATE'
    })),
    ...medicoLegalAxes.map((axis) => ({
      priority: 4,
      kind: 'tamiz_medicolegal',
      title: axis.title,
      detail: `${axis.detail} Acción sugerida: ${axis.nextAction}`,
      source: `MEDICOLEGAL_UPDATE_AXES · ${axis.basis}`
    })),
    ...FORMAL_REVIEW_SOURCES.map((source) => ({
      priority: 5,
      kind: 'baseline_review_only',
      title: source.title,
      detail: source.note,
      source: source.path
    }))
  ].sort((a, b) => a.priority - b.priority || a.title.localeCompare(b.title, 'es'));

  const queueHeadline = reviewQueue.length
    ? `Cola activa de revisión interna: <strong>${reviewQueue.length}</strong> ítems detect-only. Prioridad: faltantes críticos, dominios bloqueados, controles pendientes, tamiz médico-legal y recién después fuentes baseline.`
    : 'Sin ítems activos en la cola detect-only para este caso.';

  el('reviewQueueSummary').innerHTML = queueHeadline;

  el('reviewQueueList').innerHTML = reviewQueue.length
    ? reviewQueue.map((item) => `<li><strong>${item.kind.toUpperCase()}</strong> · ${escapeHtml(item.title)}<br><span class="muted">P${item.priority} · ${escapeHtml(item.detail)} · ${escapeHtml(item.source)}</span></li>`).join('')
    : '<li>Sin cola activa para este caso.</li>';
}

function escapeHtml(text) {
  return String(text || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function formatDocumentHtml(raw) {
  return String(raw || '')
    .split('\n')
    .map((line) => {
      const trimmed = line.trim();
      if (!trimmed) return '<p>&nbsp;</p>';
      const safe = escapeHtml(trimmed)
        .replace(/&lt;i&gt;(.*?)&lt;\/i&gt;/g, '<span class="app-fill">$1</span>');
      return `<p>${safe}</p>`;
    })
    .join('');
}

function renderInstitutionalPreview(reviewCase) {
  const institution = INSTITUTIONS[state.institutionKey] || INSTITUTIONS.clinica_centro;
  const config = getDocumentConfig();
  const styleGuide = getStyleGuide(reviewCase);
  const syntheticFinal = buildSyntheticFinalDocument(reviewCase);
  const draftSource = syntheticFinal || buildDraft(reviewCase);
  const surgeon = state.surgeonName || 'Carlos Zanardi';
  el('documentPreview').innerHTML = `
    <div class="doc-header">
      <img class="doc-logo" src="${institution.logo}" alt="${institution.label}">
      <div class="doc-title">
        <h4>${institution.label}</h4>
        <p>${institution.headerLine}<br>${institution.cityLine}<br>${config.label} · Cirujano: ${escapeHtml(surgeon)}${styleGuide ? `<br>Base de estilo: ${escapeHtml(styleGuide.label)}` : ''}</p>
      </div>
    </div>
    <div class="doc-body">${formatDocumentHtml(draftSource)}</div>
  `;

  const exportBase = `${reviewCase.family_code}_${config.code}_${state.institutionKey}`;
  const rationaleList = buildEmbeddedRationale(reviewCase, config.label)
    .map((item) => `<li><strong>${item.shortLabel}</strong>: ${escapeHtml(item.basis)}</li>`).join('');
  el('exportStatus').innerHTML = [
    `<strong>HTML preview listo</strong> para exportación local`,
    `Nombre base sugerido: <code>${exportBase}</code>`,
    'Pipeline actual: vista institucional en navegador -> imprimir a PDF o guardar HTML -> convertir a Word si hace falta.',
    '<span class="muted">Los fragmentos resaltados en amarillo son texto completado por app y requieren validación humana.</span>',
    rationaleList ? `<div style="margin-top:8px"><strong>Fundamentos embebidos:</strong><ul>${rationaleList}</ul></div>` : ''
  ].join('<br>');
}

function renderSixControlGate(reviewCase) {
  const criticalMissing = getDocumentView(reviewCase).expectedMissing;
  const statusByControl = {
    identificacion: criticalMissing.some((field) => ['fecha_acto_quirurgico', 'hora_inicio', 'hora_fin'].includes(field)) ? 'PENDIENTE_FORMAL' : 'BASE_OK',
    consentimiento_material: 'BASE_OK',
    parte_critico: criticalMissing.some((field) => ['tecnica_quirurgica', 'hallazgos_intraoperatorios', 'complicaciones', 'implantes', 'implante_marca_lote_serie', 'hemostatico_nombre_lote_cantidad', 'parche_duramadre_marca_lote_serie', 'verificacion_nivel_radioscopia'].includes(field)) ? 'PENDIENTE_FORMAL' : 'BASE_OK',
    addendas: 'BASE_OK',
    confidencialidad: 'BASE_OK',
    integridad: 'PENDIENTE_FORMAL'
  };

  const items = SIX_CONTROL_GATE.map((control) => {
    const status = statusByControl[control.key] || 'BASE_OK';
    const pendingDetail = status === 'PENDIENTE_FORMAL'
      ? `<br>Faltantes críticos visibles: ${criticalMissing.join(', ')}`
      : '<br>Sin faltantes críticos visibles para este control en review_only.';
    return `<li><strong>${status}</strong> · ${control.title}<br><span class="muted">Docs: ${control.docSignals.join(' | ')}<br>App review_only: ${control.appSignals.join(' | ')}${pendingDetail}</span></li>`;
  });

  const verdict = criticalMissing.length
    ? 'Base médico-legal avanzada con faltantes críticos visibles para revisión interna. Estado del gate: BASE_AVANZADA_REVIEW_ONLY, modo detect-only/review_only preservado y revisión humana/Codex Guard obligatoria antes de cualquier entrega.'
    : 'Base avanzada y gate local consistente para revisión interna. Estado del gate: BASE_AVANZADA_REVIEW_ONLY, con detect-only/review_only preservado. Igual no corresponde decir cumplimiento total ni cierre legal definitivo: sigue siendo review_only con revisión humana/Codex Guard obligatoria.';

  el('hcParteGate').innerHTML = items.join('');
  el('hcParteVerdict').innerHTML = verdict;
}

function renderMedicoLegalGate(reviewCase) {
  const sourceGuardrails = reviewCase.source_guardrails || {};
  const blockedDomains = reviewCase.missing_fields_map.blocked_inference_domains || [];
  const medicoLegalItems = [
    sourceGuardrails.no_literal_phi_output ? 'Sin salida literal de PHI en la interfaz.' : 'Revisar: posible salida PHI no bloqueada.',
    sourceGuardrails.no_pdf_generated ? 'PDF deshabilitado en modo review_only.' : 'Revisar: PDF no debería estar habilitado.',
    reviewCase.draft_contract?.final_generation_blocked ? 'Generación final bloqueada hasta revisión humana.' : 'Revisar: borrador final no debería liberarse.',
    reviewCase.draft_contract?.codex_guard_required ? 'Tamiz Codex Guard requerido antes de cualquier entrega.' : 'Revisar: falta compuerta Codex Guard.',
    'Modo detect-only preservado: sin PDF, sin publicación y sin cierre automático legal.'
  ];

  el('medicoLegalGate').innerHTML = medicoLegalItems.map((item) => `<li>${item}</li>`).join('');
  el('blockedDomains').innerHTML = blockedDomains.length
    ? blockedDomains.map((domain) => `<li><strong>${domain}</strong> <span class="muted">(completar manualmente)</span></li>`).join('')
    : '<li>Sin dominios bloqueados para este caso.</li>';
}

function renderCase(reviewCase) {
  state.selectedCaseId = reviewCase.case_id;
  loadPersistedReviewState(reviewCase.case_id);
  document.querySelectorAll('.case-card').forEach((node) => {
    node.classList.toggle('active', node.dataset.caseId === reviewCase.case_id);
  });

  el('caseTitle').textContent = reviewCase.family_label;
  el('caseMeta').textContent = `${reviewCase.domain} · case_id ${reviewCase.case_id} · ${el('documentType').value}`;
  el('semaforo').innerHTML = semaforoBadge(reviewCase.semaforo);

  const { config, expectedMissing, optionalMissing, relevantAlerts } = getDocumentView(reviewCase);
  el('missingFields').innerHTML = expectedMissing.length || optionalMissing.length
    ? [
        ...expectedMissing.map((field) => `<li><strong>${field}</strong> <span class="muted">(requerido en ${config.label})</span></li>`),
        ...optionalMissing.map((field) => `<li>${field} <span class="muted">(complementario)</span></li>`)
      ].join('')
    : `<li>Sin campos faltantes relevantes para ${config.label.toLowerCase()}.</li>`;

  el('alerts').innerHTML = relevantAlerts.length
    ? relevantAlerts.map((alert) => `<li><strong>${alert.field}</strong>: ${alert.reason}</li>`).join('')
    : `<li>Sin alertas específicas para ${config.label.toLowerCase()}.</li>`;

  renderMedicoLegalGate(reviewCase);
  renderFormalReviewSources();
  renderReviewQueue(reviewCase);
  renderSixControlGate(reviewCase);
  renderSuggestion();
  renderInstructionTriage(reviewCase);
  renderProductColloquialMap(reviewCase);
  renderProductFactBoundary(reviewCase);
  renderProductTemplateMother(reviewCase);
  renderSectionFlow(reviewCase);
  renderDualWorkflow(reviewCase);
  renderSectionControls(reviewCase);
  renderReviewSummary(reviewCase);
  renderSampleExpectation(reviewCase);
  renderFreeCasePanel(reviewCase);
  renderDualWorkflow(reviewCase);
  el('draft').textContent = buildDraft(reviewCase);
  renderInstitutionalPreview(reviewCase);
}

function applyInstructionSuggestion(payload) {
  const suggestion = inferFamilyFromInstruction(payload, el('instruction').value);
  state.lastSuggestion = suggestion;

  if (!state.manualOverride && suggestion) {
    el('familySelect').value = suggestion.caseId;
    const reviewCase = payload.review_cases.find((item) => item.case_id === suggestion.caseId);
    if (reviewCase) renderCase(reviewCase);
    return;
  }

  const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId) || payload.review_cases[0];
  if (current) renderCase(current);
}

function renderCaseList(payload) {
  const select = el('familySelect');
  const sampleSelect = el('sampleCaseSelect');
  select.innerHTML = payload.review_cases.map((reviewCase) => `<option value="${reviewCase.case_id}">${reviewCase.family_label}</option>`).join('');
  sampleSelect.innerHTML = ['<option value="">Seleccionar caso de prueba…</option>', ...Object.entries(SAMPLE_CASES).map(([key, sample]) => `<option value="${key}">${sample.label}</option>`)].join('');

  el('caseList').innerHTML = payload.review_cases.map((reviewCase) => `
    <div class="case-card" data-case-id="${reviewCase.case_id}">
      <strong>${reviewCase.family_label}</strong>
      <div class="muted">${reviewCase.domain} · ${reviewCase.missing_fields_map.missing_count} campos faltantes</div>
      <div style="margin-top:8px;">${semaforoBadge(reviewCase.semaforo)}</div>
    </div>
  `).join('');

  document.querySelectorAll('.case-card').forEach((node) => {
    node.addEventListener('click', () => {
      const reviewCase = payload.review_cases.find((item) => item.case_id === node.dataset.caseId);
      state.manualOverride = true;
      select.value = reviewCase.case_id;
      renderCase(reviewCase);
      persistReviewState();
    });
  });

  select.addEventListener('change', (event) => {
    state.manualOverride = true;
    const reviewCase = payload.review_cases.find((item) => item.case_id === event.target.value);
    renderCase(reviewCase);
    persistReviewState();
  });

  el('instruction').addEventListener('input', () => {
    state.manualOverride = false;
    applyInstructionSuggestion(payload);
    const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId);
    if (current) persistFreeCase(current);
    persistReviewState();
  });

  el('institutionSelect').addEventListener('change', (event) => {
    state.institutionKey = event.target.value;
    const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId);
    if (current) {
      renderInstitutionalPreview(current);
      el('draft').textContent = buildDraft(current);
      persistReviewState();
    }
  });

  el('surgeonName').addEventListener('input', (event) => {
    state.surgeonName = event.target.value;
    const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId);
    if (current) {
      renderInstitutionalPreview(current);
      el('draft').textContent = buildDraft(current);
      persistReviewState();
    }
  });

  el('reviewNote').addEventListener('input', (event) => {
    state.reviewNote = event.target.value;
    const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId);
    if (current) {
      renderReviewSummary(current);
      el('draft').textContent = buildDraft(current);
      persistReviewState();
    }
  });

  el('documentType').addEventListener('change', () => {
    const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId);
    state.activeFreeCase = loadFreeCase(el('documentType').value);
    if (current) {
      renderCase(current);
      persistReviewState();
    }
  });

  el('loadSampleBtn').addEventListener('click', () => {
    const sample = SAMPLE_CASES[sampleSelect.value];
    if (!sample) return;
    state.activeSampleKey = sampleSelect.value;
    state.manualOverride = false;
    el('instruction').value = sample.instruction;
    el('documentType').value = sample.documentType;
    applyInstructionSuggestion(payload);
    const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId);
    if (current) {
      persistFreeCase(current);
      renderFreeCasePanel(current);
    }
    persistReviewState();
  });

  el('newCaseBtn').addEventListener('click', () => {
    state.manualOverride = false;
    applyInstructionSuggestion(payload);
    const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId);
    if (current) {
      persistFreeCase(current);
      renderFreeCasePanel(current);
      persistReviewState();
    }
  });

  el('resetReviewBtn').addEventListener('click', () => {
    resetReviewState({ persist: false });
    removePersistedReviewState();
    const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId);
    if (current) {
      renderSectionControls(current);
      renderReviewSummary(current);
      el('draft').textContent = buildDraft(current);
    }
  });

  const activeSelection = loadActiveSelection();
  if (activeSelection?.documentType && DOCUMENT_CONFIG[activeSelection.documentType]) {
    el('documentType').value = activeSelection.documentType;
  }
  if (activeSelection?.instruction) {
    el('instruction').value = activeSelection.instruction;
  }
  if (activeSelection?.activeSampleKey && SAMPLE_CASES[activeSelection.activeSampleKey]) {
    sampleSelect.value = activeSelection.activeSampleKey;
    state.activeSampleKey = activeSelection.activeSampleKey;
  }
  if (activeSelection?.institutionKey && INSTITUTIONS[activeSelection.institutionKey]) {
    state.institutionKey = activeSelection.institutionKey;
    el('institutionSelect').value = activeSelection.institutionKey;
  }
  if (activeSelection?.surgeonName) {
    state.surgeonName = activeSelection.surgeonName;
    el('surgeonName').value = activeSelection.surgeonName;
  }

  const activeDocumentType = el('documentType')?.value || 'Historia clínica';
  const restoredFreeCase = activeSelection?.activeFreeCase;
  state.activeFreeCase = restoredFreeCase && restoredFreeCase.documentType === activeDocumentType
    ? restoredFreeCase
    : loadFreeCase(activeDocumentType);

  const initialCase = payload.review_cases.find((item) => item.case_id === activeSelection?.selectedCaseId) || payload.review_cases[0];
  state.selectedCaseId = initialCase.case_id;
  select.value = initialCase.case_id;
  state.manualOverride = Boolean(activeSelection?.manualOverride);

  if (activeSelection?.instruction) {
    const preservedCaseId = state.manualOverride ? initialCase.case_id : null;
    applyInstructionSuggestion(payload);
    if (preservedCaseId) {
      const preservedCase = payload.review_cases.find((item) => item.case_id === preservedCaseId);
      if (preservedCase) {
        state.manualOverride = true;
        el('familySelect').value = preservedCase.case_id;
        renderCase(preservedCase);
      }
    }
  } else {
    renderCase(initialCase);
  }
}

async function init() {
  const payload = window.__APP_DATA__;
  if (!payload?.review_cases?.length) throw new Error('Paquete review_only embebido ausente o inválido');
  state.payload = payload;
  renderStats(payload);
  renderCaseList(payload);
}

init().catch((error) => {
  document.body.innerHTML = `<pre style="padding:24px;">Error cargando MVP review_only:\n${error.stack}</pre>`;
});
