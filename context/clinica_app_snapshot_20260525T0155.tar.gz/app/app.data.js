const ACTIVE_REVIEW_KEY = 'cli_app_review_state::active';

const state = {
  payload: null,
  selectedCaseId: null,
  manualOverride: false,
  lastSuggestion: null,
  activeSampleKey: null,
  activeFreeCase: null,
  institutionKey: 'clinica_centro',
  surgeonName: 'Carlos Zanardi',
  profileDefaults: {
    surgeonLicense: '',
    usualAssistant: 'Maximiliano Giménez'
  },
  sectionReview: {
    confirmed: 'pending',
    suggested: 'pending',
    missing: 'pending'
  },
  reviewNote: '',
  persistence: {
    available: true,
    restoredAt: null,
    savedAt: null,
    key: null
  }
};

const el = (id) => document.getElementById(id);

const INSTITUTIONS = {
  clinica_centro: {
    label: 'Clínica Centro',
    cityLine: 'Junín, Buenos Aires',
    logo: '../../logos/clinica_centro_logo_limpio.png',
    headerLine: 'Servicio de Neurocirugía y Cirugía de Columna'
  },
  la_pequena_familia: {
    label: 'Clínica La Pequeña Familia',
    cityLine: 'Junín, Buenos Aires',
    logo: '../../logos/la_pequena_familia_logo.png',
    headerLine: 'Servicio de Neurocirugía'
  },
  hospital_pineyro: {
    label: 'HIGA Dr. Abraham Piñeyro',
    cityLine: 'Junín, Buenos Aires',
    logo: '../../logos/hospital_junin_logo_limpio.png',
    headerLine: 'Servicio de Neurocirugía'
  }
};

const MEDICOLEGAL_FOUNDATIONS = [
  {
    key: 'identificacion_autoria',
    shortLabel: 'Identificación y autoría del acto',
    basis: 'Ley 26.529, Ley 17.132 y criterios de integridad documental del registro clínico.',
    appliesTo: ['Historia clínica', 'Parte quirúrgico'],
    text: 'Se prioriza consignar identificación suficiente del episodio, autoría, fecha y hora del acto, porque la trazabilidad documental pesa en la defensa médica.'
  },
  {
    key: 'consentimiento_material',
    shortLabel: 'Consentimiento con contenido material',
    basis: 'Ley 26.529 y doctrina sobre información adecuada al paciente.',
    appliesTo: ['Historia clínica'],
    text: 'Se incluye constancia de información sobre objetivos, riesgos, beneficios y alternativas terapéuticas como núcleo defensivo básico del registro.'
  },
  {
    key: 'correlacion_clinico_radiologica',
    shortLabel: 'Correlación clínico-radiológica e indicación',
    basis: 'Buena práctica documental y criterio defensivo de indicación fundada.',
    appliesTo: ['Historia clínica', 'Parte quirúrgico'],
    text: 'Se refuerza la relación entre cuadro clínico, estudios e indicación quirúrgica para mostrar razonabilidad médica del acto.'
  },
  {
    key: 'cronologia_tecnica',
    shortLabel: 'Cronología y técnica operatoria',
    basis: 'Valor probatorio del parte quirúrgico completo y control del acto.',
    appliesTo: ['Parte quirúrgico'],
    text: 'Se privilegia dejar documentadas técnica, control radioscópico, hallazgos, complicaciones y cierre del procedimiento, marcando lo no confirmado.'
  },
  {
    key: 'evolucion_destino',
    shortLabel: 'Evolución inmediata y destino',
    basis: 'Continuidad asistencial y defensa sobre seguimiento postoperatorio.',
    appliesTo: ['Historia clínica', 'Parte quirúrgico'],
    text: 'Se agrega una evolución postoperatoria inmediata base, pero se obliga revisión si faltan examen neurológico, destino o indicaciones nominales.'
  }
];

const SAMPLE_CASES = {
  hdl_l4_l5: {
    label: 'HDL L4-L5 izquierda, parte quirúrgico',
    documentType: 'Parte quirúrgico',
    familyCode: 'lumbar_microdiscectomia_hdl',
    instruction: 'Microdiscectomía tubular L4-L5 izquierda por hernia de disco lumbar con dolor radicular. Revisar parte quirúrgico y semáforo.',
    expected: {
      semaforo: 'yellow',
      familyContains: 'Hernia de disco lumbar',
      confidence: 'alta',
      mustIncludeMissing: ['hora_inicio', 'hora_fin', 'hallazgos_intraoperatorios'],
      note: 'Debe sugerir la familia HDL lumbar y dejar horas, hallazgos y materiales como revisión manual.'
    }
  },
  cervical_canal_estrecho: {
    label: 'Canal estrecho cervical, historia clínica',
    documentType: 'Historia clínica',
    familyCode: 'cervical_laminoplastia_descompresion',
    instruction: 'Laminoplastia cervical por mielopatía cervical y canal estrecho cervical. Revisar historia clínica.',
    expected: {
      semaforo: 'green',
      familyContains: 'Laminoplastia cervical',
      confidence: 'alta',
      mustIncludeMissing: [],
      note: 'Debe reconocer el caso cervical y mostrar semáforo verde sin faltantes críticos para historia clínica.'
    }
  },
  miss_listesis: {
    label: 'Fijación lumbar MISS, historia clínica',
    documentType: 'Historia clínica',
    familyCode: 'lumbar_fijacion_miss_artrodesis',
    instruction: 'Artrodesis lumbar MISS con fijación pedicular por espondilolistesis. Revisar historia clínica.',
    expected: {
      semaforo: 'red',
      familyContains: 'Fijacion lumbar MISS',
      confidence: 'alta',
      mustIncludeMissing: ['diagnostico_postoperatorio'],
      note: 'Debe reconocer la familia de fijación lumbar MISS y dejar al menos el diagnóstico postoperatorio como revisión manual.'
    }
  },
  paciente_prueba_l4_l5_circunferencial: {
    label: 'Paciente prueba, fijación L4-L5 circunferencial',
    documentType: 'Parte quirúrgico',
    familyCode: 'lumbar_fijacion_miss_artrodesis',
    instruction: 'Paciente prueba operado de fijación L4-L5 circunferencial. Generar historia clínica y parte quirúrgico de producto final de la aplicación, completando aun los puntos no seguros como borrador de prueba.',
    expected: {
      semaforo: 'red',
      familyContains: 'Fijacion lumbar MISS',
      confidence: 'alta',
      mustIncludeMissing: ['diagnostico_preoperatorio', 'tecnica_quirurgica', 'hora_inicio', 'hora_fin'],
      note: 'Debe llevar el caso a la familia de fijación lumbar y exhibir que los campos críticos siguen siendo de completado manual aunque el borrador de prueba los narre.'
    }
  }
};

const KEYWORD_RULES = [
  {
    familyCode: 'lumbar_microdiscectomia_hdl',
    confidence: 'alta',
    terms: ['microdiscectomia', 'microdiscectomía', 'hernia de disco', 'hdl', 'radicular', 'discectomia', 'discectomía', 'l4-l5', 'l5-s1'],
    strongCombos: [
      ['microdiscectomia', 'hernia de disco'],
      ['microdiscectomía', 'hernia de disco'],
      ['hdl', 'radicular']
    ]
  },
  {
    familyCode: 'cervical_laminoplastia_descompresion',
    confidence: 'alta',
    terms: ['laminoplastia cervical', 'laminectomia cervical', 'laminectomía cervical', 'mielopatia cervical', 'mielopatía cervical', 'descompresion cervical', 'descompresión cervical', 'cervical', 'cuadriparesia', 'cuadriparesia leve', 'c3/7', 'c3-7'],
    strongCombos: [
      ['laminoplastia cervical', 'mielopatía cervical'],
      ['laminoplastia cervical', 'canal estrecho cervical'],
      ['descompresión cervical', 'mielopatía cervical'],
      ['laminoplastia cervical', 'cuadriparesia'],
      ['c3/7', 'cuadriparesia'],
      ['c3-7', 'cuadriparesia']
    ]
  },
  {
    familyCode: 'craneo_tumor_fractura_derivacion',
    confidence: 'alta',
    terms: ['hematoma subdural', 'subdural', 'trepanacion', 'trepanación', 'craneotomia', 'craneotomía', 'tumor cerebral', 'hidrocefalia', 'derivacion', 'derivación', 'dvp', 'fractura craneal', 'lesion dural', 'lesión dural'],
    strongCombos: [
      ['hematoma subdural', 'craneotomía'],
      ['hidrocefalia', 'derivación'],
      ['lesión dural', 'fractura craneal']
    ]
  },
  {
    familyCode: 'lumbar_fijacion_miss_artrodesis',
    confidence: 'media',
    terms: ['artrodesis', 'fijacion', 'fijación', 'tornillos pediculares', 'espondilolistesis', 'instrumentacion', 'instrumentación', 'miss', 'circunferencial', 'fijación l4-l5', 'fijacion l4-l5'],
    strongCombos: [
      ['artrodesis', 'miss'],
      ['fijación', 'espondilolistesis'],
      ['fijacion', 'espondilolistesis'],
      ['artrodesis', 'tornillos pediculares'],
      ['fijación', 'circunferencial'],
      ['fijacion', 'circunferencial'],
      ['circunferencial', 'l4-l5']
    ]
  },
  {
    familyCode: 'revision_retiro_implantes_discitis',
    confidence: 'media',
    terms: ['discitis', 'retiro de implantes', 'revision de herida', 'revisión de herida', 'toilette quirurgica', 'toilette quirúrgica', 'infeccion', 'infección'],
    strongCombos: [
      ['discitis', 'retiro de implantes'],
      ['discitis', 'toilette quirúrgica'],
      ['infección', 'revisión de herida']
    ]
  },
  {
    familyCode: 'periferico_bloqueos_descompresiones',
    confidence: 'media',
    terms: ['tunel carpiano', 'túnel carpiano', 'cubital', 'neurolisis', 'neurolisis', 'periferico', 'periférico', 'bloqueo periferico', 'bloqueo periférico'],
    strongCombos: [
      ['túnel carpiano', 'neurolisis'],
      ['cubital', 'neurolisis'],
      ['bloqueo periférico', 'cubital']
    ]
  }
];

const FORMAL_REVIEW_SOURCES = [
  {
    key: 'corpus',
    title: 'Corpus medicolegal argentino base',
    status: 'base_avanzada_review_only',
    path: 'docs/corpus_medicolegal_argentino.md',
    note: 'Base normativa y jurisprudencial avanzada, congelada como baseline interno review_only y sin cierre terminal apto para declarar cumplimiento total.'
  },
  {
    key: 'matriz',
    title: 'Matriz de impacto redaccional HC/partes',
    status: 'base_avanzada_review_only',
    path: 'docs/matriz_impacto_redaccional_hc_partes.md',
    note: 'Checklist útil para escritura prudente, congelado como baseline interno review_only con cierre formal pendiente.'
  },
  {
    key: 'reglas',
    title: 'Reglas internas candidatas',
    status: 'base_avanzada_review_only',
    path: 'docs/reglas_internas_redaccion_medicolegal.md',
    note: 'Reglas candidatas congeladas para QA/dry run, no activas para uso legal definitivo.'
  }
];

const SIX_CONTROL_GATE = [
  {
    key: 'identificacion',
    title: 'Identificación completa de paciente, episodio, fecha, hora y autor',
    docSignals: ['Identificación suficiente de paciente, episodio, fecha, hora y autor.', 'toda nota clínica y todo parte quirúrgico deben iniciar con paciente, fecha, hora, ámbito y autor del registro.'],
    appSignals: ['Persistencia local por caso y tipo documental.', 'Triage visible de instrucción, familia y caso activo.', 'Campos críticos visibles para fecha, hora y autoría documental.']
  },
  {
    key: 'consentimiento_material',
    title: 'Consentimiento informado con contenido material y acceso/copia',
    docSignals: ['consentimiento informado', 'Consentimiento con contenido material', 'Consentimiento con constancia de acceso/copia'],
    appSignals: ['Borrador bloqueado sin salida final automática.', 'Sin PDF ni publicación, exige revisión humana antes de cualquier uso real.']
  },
  {
    key: 'parte_critico',
    title: 'Parte quirúrgico con técnica, hallazgos, cronología, complicaciones y control final',
    docSignals: ['Parte quirúrgico: hallazgos y técnica', 'Parte quirúrgico: cronología intra y postevento', 'CLI-R009 Control final verificable del acto quirúrgico'],
    appSignals: ['Checklist técnico intraoperatorio visible.', 'Semáforo y faltantes críticos obligan completar horas, hallazgos, implantes y radioscopía cuando faltan.']
  },
  {
    key: 'addendas',
    title: 'Addendas sin borrado con trazabilidad de cambios, autor, fecha y hora',
    docSignals: ['Addendas sin borrado', 'Correcciones/addendas', 'CLI-R006 Addendas sin borrado'],
    appSignals: ['Persistencia local con savedAt/restoredAt.', 'Reset y revisión por caso separados del borrador bloqueado.']
  },
  {
    key: 'confidencialidad',
    title: 'Confidencialidad y acceso mínimo a datos sensibles',
    docSignals: ['Mínima exposición de datos sensibles', 'Confidencialidad y circulación de datos', 'CLI-R007 Mínima exposición de datos sensibles'],
    appSignals: ['no_literal_phi_output=true', 'rel_path_exposed=false', 'review_only sin salida productiva.']
  },
  {
    key: 'integridad',
    title: 'Integridad, autenticidad y auditoría del registro electrónico',
    docSignals: ['Autoría digital, integridad y no repudio', 'CLI-R001 Identificación completa del acto', 'CLI-R006 Addendas sin borrado'],
    appSignals: ['codex_guard_required=true', 'human_review_required=true', 'final_generation_blocked=true y publication_activation_allowed=false.']
  }
];

const DOCUMENT_CONFIG = {
  'Historia clínica': {
    code: 'hc',
    label: 'Historia clínica',
    blockedTitle: 'Borrador de historia clínica bloqueado',
    expectedFields: [
      'diagnostico_preoperatorio',
      'diagnostico_postoperatorio',
      'tecnica_quirurgica',
      'hallazgos_intraoperatorios',
      'complicaciones',
      'destino'
    ],
    optionalFields: [
      'fecha_acto_quirurgico',
      'nivel',
      'lateralidad',
      'implantes',
      'implante_marca_lote_serie',
      'hemostatico_nombre_lote_cantidad',
      'parche_duramadre_marca_lote_serie'
    ],
    alertKeywords: ['diagnostico', 'hallazgos', 'destino', 'complicaciones'],
    checklistTitle: 'Checklist narrativo mínimo',
    blockedBullets: [
      'Evolución final deshabilitada.',
      'No emitir PHI literal ni cierre automático.',
      'Requiere validación humana antes de usar en historia clínica real.'
    ]
  },
  'Parte quirúrgico': {
    code: 'parte',
    label: 'Parte quirúrgico',
    blockedTitle: 'Parte quirúrgico bloqueado',
    expectedFields: [
      'fecha_acto_quirurgico',
      'hora_inicio',
      'hora_fin',
      'tecnica_quirurgica',
      'hallazgos_intraoperatorios',
      'complicaciones',
      'implantes',
      'implante_marca_lote_serie',
      'hemostatico_nombre_lote_cantidad',
      'parche_duramadre_marca_lote_serie',
      'verificacion_nivel_radioscopia'
    ],
    optionalFields: [
      'diagnostico_preoperatorio',
      'diagnostico_postoperatorio',
      'nivel',
      'lateralidad',
      'destino'
    ],
    alertKeywords: ['hora_', 'implante', 'lote', 'hemostatico', 'parche', 'radioscopia'],
    checklistTitle: 'Checklist técnico intraoperatorio',
    blockedBullets: [
      'Redacción operatoria final deshabilitada.',
      'No inferir materiales, lotes ni tiempos.',
      'Requiere control manual del parte antes de cualquier uso clínico.'
    ]
  },
  Epicrisis: {
    code: 'epicrisis',
    label: 'Epicrisis',
    blockedTitle: 'Epicrisis bloqueada',
    expectedFields: [
      'diagnostico_preoperatorio',
      'diagnostico_postoperatorio',
      'tecnica_quirurgica',
      'complicaciones',
      'destino'
    ],
    optionalFields: [
      'fecha_acto_quirurgico',
      'hallazgos_intraoperatorios',
      'implantes',
      'nivel',
      'lateralidad'
    ],
    alertKeywords: ['destino', 'complicaciones', 'diagnostico_postoperatorio'],
    checklistTitle: 'Checklist de alta y cierre',
    blockedBullets: [
      'Epicrisis final deshabilitada.',
      'No generar indicaciones de alta ni resumen definitivo automático.',
      'Requiere revisión humana para consistencia de diagnóstico y destino.'
    ]
  }
};

function semaforoBadge(level) {
  const labels = { green: 'VERDE', yellow: 'AMARILLO', red: 'ROJO' };
  return `<span class="badge ${level}">${labels[level] || String(level).toUpperCase()}</span>`;
}

function storageKey(caseId = state.selectedCaseId, documentType = el('documentType')?.value) {
  if (!caseId || !documentType) return null;
  return `cli_app_review_state::${caseId}::${documentType}`;
}

function freeCaseKey(documentType = el('documentType')?.value || 'Historia clínica') {
  return `cli_app_free_case::${documentType}`;
}

function persistenceSnapshot() {
  return {
    selectedCaseId: state.selectedCaseId,
    documentType: el('documentType')?.value || 'Historia clínica',
    instruction: el('instruction')?.value || '',
    reviewNote: state.reviewNote,
    sectionReview: { ...state.sectionReview },
    manualOverride: state.manualOverride,
    activeSampleKey: state.activeSampleKey,
    savedAt: new Date().toISOString()
  };
}

function persistActiveSelection(snapshot = persistenceSnapshot()) {
  try {
    localStorage.setItem(ACTIVE_REVIEW_KEY, JSON.stringify({
      selectedCaseId: snapshot.selectedCaseId,
      documentType: snapshot.documentType,
      instruction: snapshot.instruction,
      activeSampleKey: snapshot.activeSampleKey,
      activeFreeCase: state.activeFreeCase,
      manualOverride: state.manualOverride,
      savedAt: snapshot.savedAt
    }));
    state.persistence.available = true;
  } catch (error) {
    state.persistence.available = false;
  }
}

function loadActiveSelection() {
  try {
    const raw = localStorage.getItem(ACTIVE_REVIEW_KEY);
    state.persistence.available = true;
    return raw ? JSON.parse(raw) : null;
  } catch (error) {
    state.persistence.available = false;
    return null;
  }
}

function renderPersistenceStatus() {
  const node = el('reviewPersistenceStatus');
  if (!node) return;
  if (!state.persistence.available) {
    node.innerHTML = '<strong>Persistencia local no disponible.</strong><div>El navegador no expone localStorage en este contexto.</div>';
    return;
  }

  const bits = [];
  if (state.persistence.restoredAt) bits.push(`restaurado ${new Date(state.persistence.restoredAt).toLocaleString('es-AR')}`);
  if (state.persistence.savedAt) bits.push(`guardado ${new Date(state.persistence.savedAt).toLocaleString('es-AR')}`);
  const key = state.persistence.key ? state.persistence.key.split('::').slice(1).join(' · ') : 'sin clave activa';
  node.innerHTML = `
    <strong>Persistencia local activa</strong>
    <div>Clave actual: ${key}</div>
    <div>${bits.length ? bits.join(' · ') : 'Sin datos restaurados todavía para este caso/tipo documental.'}</div>
  `;
}

function persistReviewState() {
  const key = storageKey();
  if (!key) return;
  const snapshot = persistenceSnapshot();
  try {
    localStorage.setItem(key, JSON.stringify(snapshot));
    persistActiveSelection(snapshot);
    state.persistence.available = true;
    state.persistence.key = key;
    state.persistence.savedAt = snapshot.savedAt;
  } catch (error) {
    state.persistence.available = false;
  }
  renderPersistenceStatus();
}

function resetReviewState({ persist = true } = {}) {
  state.sectionReview = {
    confirmed: 'pending',
    suggested: 'pending',
    missing: 'pending'
  };
  state.reviewNote = '';
  const note = el('reviewNote');
  if (note) note.value = '';
  if (persist) persistReviewState();
}

function loadPersistedReviewState(caseId = state.selectedCaseId) {
  const key = storageKey(caseId);
  state.persistence.key = key;
  if (!key) {
    renderPersistenceStatus();
    return;
  }

  try {
    const raw = localStorage.getItem(key);
    state.persistence.available = true;
    if (!raw) {
      state.persistence.restoredAt = null;
      state.persistence.savedAt = null;
      resetReviewState({ persist: false });
      renderPersistenceStatus();
      return;
    }

    const saved = JSON.parse(raw);
    state.sectionReview = {
      confirmed: saved.sectionReview?.confirmed || 'pending',
      suggested: saved.sectionReview?.suggested || 'pending',
      missing: saved.sectionReview?.missing || 'pending'
    };
    state.reviewNote = saved.reviewNote || '';
    state.activeSampleKey = saved.activeSampleKey || null;
    state.persistence.restoredAt = saved.savedAt || new Date().toISOString();
    state.persistence.savedAt = saved.savedAt || null;
  } catch (error) {
    state.persistence.available = false;
    resetReviewState({ persist: false });
  }
  renderPersistenceStatus();
}

function removePersistedReviewState() {
  const key = storageKey();
  if (!key) return;
  try {
    localStorage.removeItem(key);
    localStorage.removeItem(ACTIVE_REVIEW_KEY);
    state.persistence.available = true;
    state.persistence.key = key;
    state.persistence.restoredAt = null;
    state.persistence.savedAt = null;
  } catch (error) {
    state.persistence.available = false;
  }
  renderPersistenceStatus();
}

function ensureSuggestionNode() {
  if (el('suggestionBox')) return;
  const select = el('familySelect');
  const box = document.createElement('div');
  box.id = 'suggestionBox';
  box.className = 'warn';
  box.style.marginTop = '10px';
  select.insertAdjacentElement('afterend', box);
}

function buildFreeCaseSummary(reviewCase) {
  const triage = buildInstructionTriage(reviewCase);
  const currentInstruction = el('instruction')?.value?.trim() || 'Sin instrucción cargada';
  const family = state.lastSuggestion?.familyLabel || reviewCase.family_label;
  const confidence = state.lastSuggestion?.confidence || 'manual';
  return {
    instruction: currentInstruction,
    family,
    confidence,
    criticalMissing: triage.criticalMissing,
    suggested: triage.suggested,
    confirmed: triage.confirmed
  };
}

function persistFreeCase(reviewCase) {
  if (!reviewCase) return;
  const summary = buildFreeCaseSummary(reviewCase);
  state.activeFreeCase = {
    caseId: reviewCase.case_id,
    documentType: el('documentType')?.value || 'Historia clínica',
    ...summary,
    savedAt: new Date().toISOString()
  };
  try {
    localStorage.setItem(freeCaseKey(state.activeFreeCase.documentType), JSON.stringify(state.activeFreeCase));
    state.persistence.available = true;
  } catch (error) {
    state.persistence.available = false;
  }
}

function loadFreeCase(documentType = el('documentType')?.value || 'Historia clínica') {
  try {
    const raw = localStorage.getItem(freeCaseKey(documentType));
    state.persistence.available = true;
    return raw ? JSON.parse(raw) : null;
  } catch (error) {
    state.persistence.available = false;
    return null;
  }
}

function renderFreeCasePanel(reviewCase) {
  const node = el('freeCaseSummary');
  const checks = el('freeCaseChecks');
  if (!node || !checks || !reviewCase) return;

  const activeDocumentType = el('documentType')?.value || 'Historia clínica';
  let freeCase = state.activeFreeCase;
  if (!freeCase || freeCase.documentType !== activeDocumentType) {
    freeCase = loadFreeCase(activeDocumentType);
    state.activeFreeCase = freeCase && freeCase.documentType === activeDocumentType ? freeCase : null;
  }
  if (!freeCase || !freeCase.instruction) {
    node.innerHTML = 'Todavía no hay un caso libre armado.';
    checks.innerHTML = '<li>La revisión local se guarda por caso y tipo documental.</li>';
    return;
  }

  node.innerHTML = `
    <strong>Familia activa:</strong> ${freeCase.family}<br>
    <strong>Confianza:</strong> ${freeCase.confidence}<br>
    <strong>Instrucción:</strong> ${freeCase.instruction}<br>
    <strong>Faltantes críticos:</strong> ${freeCase.criticalMissing.length ? freeCase.criticalMissing.join(', ') : 'sin faltantes críticos'}
  `;

  const items = [
    `Caso base reutilizado: ${reviewCase.family_label}`,
    `Tipo documental: ${freeCase.documentType}`,
    `Persistido localmente: ${freeCase.savedAt ? new Date(freeCase.savedAt).toLocaleString('es-AR') : 'sí'}`,
    `Confirmados: ${freeCase.confirmed.length}`,
    `Sugerencias revisables: ${freeCase.suggested.length}`
  ];
  checks.innerHTML = items.map((item) => `<li>${item}</li>`).join('');
}

function renderStats(payload) {
  const readiness = payload.readiness_summary;
  el('stats').innerHTML = `
    <div class="stat"><strong>${readiness.families_catalogued}</strong>familias</div>
    <div class="stat"><strong>${readiness.families_with_dry_run_cases}</strong>casos test</div>
    <div class="stat"><strong>${readiness.manifest_total_items}</strong>items corpus</div>
  `;
  el('generatedAt').textContent = `Paquete ${new Date(payload.generated_at).toLocaleString('es-AR')}`;
  el('guardrails').innerHTML = [
    'publication_activation_allowed=false',
    'pdf_generation_allowed=local_preview_pipeline',
    'human_review_required=true',
    'codex_guard_required=true'
  ].join(' · ');
  renderTrialReadyPanel(payload);
}

function renderTrialReadyPanel(payload) {
  const readiness = payload.readiness_summary;
  const reviewCases = payload.review_cases || [];
  const guardrails = [
    'NO APTO_PARA_ENTREGAR sin revisión humana final',
    'Fórmula única: base medico-legal avanzada, con cierre formal pendiente',
    'PDF/Word local solo como preview exportable, no autoentrega',
    'Borrador bloqueado, revisión humana requerida',
    'Tamiz Codex Guard requerido antes de cualquier entrega'
  ];
  const instructions = [
    'Cargar un caso de prueba local.',
    'Verificar la familia sugerida y la confianza visible.',
    'Revisar confirmado vs sugerencia clínica vs faltante crítico.',
    'Chequear tamiz médico legal y dominios bloqueados.',
    'Confirmar que el borrador siga bloqueado y sin PDF/publicación.'
  ];
  const checklist = [
    `${reviewCases.length} review_cases cargados desde el paquete local.`,
    'Selector de documento, familia y caso de prueba visibles.',
    'Semáforo, alertas y faltantes críticos visibles.',
    'Panel listo para prueba interna de Jarvis principal.'
  ];

  el('trialReadinessSummary').innerHTML = `
    <strong>Estado:</strong> listo para prueba interna controlada.<br>
    <strong>Paquete:</strong> ${reviewCases.length} casos review_only, ${readiness.families_catalogued} familias catalogadas y ${readiness.manifest_total_items} items de corpus.<br>
    <strong>Uso permitido:</strong> solo revisión interna, sin salida clínica final.
  `;
  el('trialInstructions').innerHTML = instructions.map((item) => `<li>${item}</li>`).join('');
  el('trialGuardrails').innerHTML = guardrails.map((item) => `<li>${item}</li>`).join('');
  el('trialChecklist').innerHTML = checklist.map((item) => `<li>${item}</li>`).join('');
}

function inferFamilyFromInstruction(payload, rawInstruction) {
  const instruction = String(rawInstruction || '').trim().toLowerCase();
  if (!instruction) return null;

  const scored = payload.review_cases.map((reviewCase) => {
    const rule = KEYWORD_RULES.find((item) => item.familyCode === reviewCase.family_code);
    const hits = (rule?.terms || []).filter((term) => instruction.includes(term.toLowerCase()));
    const comboHits = (rule?.strongCombos || []).filter((combo) => combo.every((term) => instruction.includes(term.toLowerCase())));
    const labelTokens = reviewCase.family_label.toLowerCase().split(/[^a-záéíóúñ0-9]+/i).filter(Boolean);
    const labelHits = labelTokens.filter((token) => token.length > 3 && instruction.includes(token));
    const score = hits.length * 3 + labelHits.length + comboHits.length * 4;
    return {
      reviewCase,
      hits: [...new Set([...hits, ...labelHits, ...comboHits.flat()])],
      score,
      baseConfidence: rule?.confidence || 'baja',
      comboHits: comboHits.length
    };
  }).filter((item) => item.score > 0).sort((a, b) => b.score - a.score);

  if (!scored.length) return null;

  const best = scored[0];
  let confidence = best.score >= 6 ? 'alta' : best.score >= 3 ? 'media' : 'baja';
  if (best.baseConfidence === 'alta' && best.score >= 4) confidence = 'alta';
  if (best.comboHits > 0 && best.score >= 5) confidence = 'alta';

  return {
    caseId: best.reviewCase.case_id,
    familyLabel: best.reviewCase.family_label,
    confidence,
    reasons: best.hits.slice(0, 5)
  };
}

function renderSuggestion() {
  ensureSuggestionNode();
  const box = el('suggestionBox');
  const suggestion = state.lastSuggestion;

  if (!suggestion) {
    box.innerHTML = '<strong>Sugerencia automática</strong><div>No hay coincidencia suficiente todavía. Puede elegir la familia manualmente.</div>';
    return;
  }

  const mode = state.manualOverride ? 'Corrección manual activa' : 'Sugerencia aplicada automáticamente';
  const reasons = suggestion.reasons.length ? suggestion.reasons.join(', ') : 'sin palabras clave trazables';
  box.innerHTML = `
    <strong>${mode}</strong>
    <div>Familia sugerida: <strong>${suggestion.familyLabel}</strong></div>
    <div>Confianza: <strong>${suggestion.confidence}</strong></div>
    <div>Motivo: ${reasons}</div>
  `;
}

function getDocumentConfigByLabel(documentType = 'Historia clínica') {
  return DOCUMENT_CONFIG[documentType] || DOCUMENT_CONFIG['Historia clínica'];
}

function getDocumentConfig() {
  return getDocumentConfigByLabel(el('documentType').value);
}

function getDocumentViewForType(reviewCase, documentType = el('documentType').value) {
  const config = getDocumentConfigByLabel(documentType);
  const presentSet = new Set(reviewCase.missing_fields_map.fields_present);
  const allMissing = reviewCase.missing_fields_map.fields_missing;
  const expectedPresent = config.expectedFields.filter((field) => presentSet.has(field));
  const expectedMissing = config.expectedFields.filter((field) => !presentSet.has(field));
  const optionalPresent = config.optionalFields.filter((field) => presentSet.has(field));
  const optionalMissing = config.optionalFields.filter((field) => allMissing.includes(field));
  const relevantAlerts = reviewCase.alerts.filter((alert) => config.alertKeywords.some((keyword) => alert.field.includes(keyword)));

  return {
    config,
    expectedPresent,
    expectedMissing,
    optionalPresent,
    optionalMissing,
    relevantAlerts
  };
}

function getDocumentView(reviewCase) {
  return getDocumentViewForType(reviewCase, el('documentType').value);
}

function normalizeInstruction(text) {
  return String(text || '').toLowerCase();
}

function buildInstructionTriage(reviewCase) {
  const instruction = normalizeInstruction(el('instruction').value);
  const familyTerms = {
    columna_lumbar: ['lumbar', 'l4', 'l5', 's1', 'radicular', 'hdl', 'ciatica', 'ciática'],
    columna_cervical: ['cervical', 'mielopatia', 'mielopatía', 'braquialgia', 'canal estrecho cervical'],
    craneo: ['craneo', 'cráneo', 'subdural', 'craneotomia', 'craneotomía', 'dvp', 'derivacion', 'derivación'],
    periferico: ['tunel carpiano', 'túnel carpiano', 'cubital', 'neurolisis', 'neurolisis']
  };

  const confirmed = [];
  if (instruction) confirmed.push(`Instrucción libre cargada por el médico: ${el('instruction').value.trim()}`);
  if (instruction && familyTerms[reviewCase.domain]?.some((term) => instruction.includes(term))) {
    confirmed.push(`Patología compatible con ${reviewCase.family_label}`);
  }
  if (instruction && /derech|izquierd|bilateral/.test(instruction)) confirmed.push('Lateralidad mencionada en la instrucción');
  if (instruction && /l\d[-/]l\d|l\d[-/]s\d|c\d[-/]c\d/.test(instruction)) confirmed.push('Nivel anatómico mencionado en la instrucción');

  const suggested = [];
  if (state.lastSuggestion) {
    suggested.push(`Familia sugerida: ${state.lastSuggestion.familyLabel} (${state.lastSuggestion.confidence})`);
  }
  if (reviewCase.selected_template?.template_id) {
    suggested.push(`Plantilla candidata: ${reviewCase.selected_template.template_id}`);
  }
  if (reviewCase.missing_fields_map.blocked_inference_domains.includes('hallazgos')) {
    suggested.push('Hallazgos intraoperatorios deben proponerse solo como revisión manual, no como dato confirmado');
  }

  const criticalMissing = getDocumentView(reviewCase).expectedMissing;

  return { confirmed, suggested, criticalMissing };
}

function renderSampleExpectation(reviewCase) {
  const box = el('expectedResult');
  const list = el('sampleChecklist');
  const sample = SAMPLE_CASES[state.activeSampleKey];

  if (!sample) {
    box.innerHTML = 'Todavía no cargó un caso de prueba.';
    list.innerHTML = '<li>Puede cargar un caso local para comparar sugerencia, semáforo y faltantes.</li>';
    return;
  }

  const expected = sample.expected;
  const actualMissing = getDocumentView(reviewCase).expectedMissing;
  const familyOk = reviewCase.family_label.includes(expected.familyContains);
  const semaforoOk = reviewCase.semaforo === expected.semaforo;
  const confidenceOk = (state.lastSuggestion?.confidence || 'sin sugerencia') === expected.confidence;
  const missingChecks = expected.mustIncludeMissing.map((field) => ({
    field,
    ok: actualMissing.includes(field)
  }));

  box.innerHTML = `
    <strong>${sample.label}</strong>
    <div>Esperado: familia <strong>${expected.familyContains}</strong>, semáforo <strong>${expected.semaforo.toUpperCase()}</strong>, confianza <strong>${expected.confidence}</strong>.</div>
    <div>${expected.note}</div>
  `;

  list.innerHTML = [
    `<li><strong>Familia sugerida:</strong> ${familyOk ? 'OK' : 'REVISAR'} (${reviewCase.family_label})</li>`,
    `<li><strong>Semáforo:</strong> ${semaforoOk ? 'OK' : 'REVISAR'} (${reviewCase.semaforo.toUpperCase()})</li>`,
    `<li><strong>Confianza:</strong> ${confidenceOk ? 'OK' : 'REVISAR'} (${state.lastSuggestion?.confidence || 'sin sugerencia'})</li>`,
    ...missingChecks.map((item) => `<li><strong>Faltante esperado ${item.field}:</strong> ${item.ok ? 'OK' : 'REVISAR'}</li>`)
  ].join('');
}

function renderInstructionTriage(reviewCase) {
  const triage = buildInstructionTriage(reviewCase);
  el('instructionTriage').innerHTML = [
    ...triage.confirmed.map((item) => `<li><strong>Confirmado:</strong> ${item}</li>`),
    ...triage.suggested.map((item) => `<li><strong>Sugerencia:</strong> ${item}</li>`)
  ].join('') || '<li>Sin instrucción suficiente todavía. Cargar texto libre para activar el triage.</li>';

  el('criticalMissing').innerHTML = triage.criticalMissing.length
    ? triage.criticalMissing.map((field) => `<li><strong>${field}</strong> <span class="muted">(completar antes de usar ${getDocumentConfig().label.toLowerCase()})</span></li>`).join('')
    : '<li>Sin faltantes críticos para el tipo documental actual.</li>';
}

function renderSectionFlow(reviewCase) {
  const triage = buildInstructionTriage(reviewCase);
  const { config, expectedPresent, expectedMissing, optionalPresent, relevantAlerts } = getDocumentView(reviewCase);
  const sections = [
    {
      title: '1. Dato confirmado',
      tone: 'Confirmar solo lo trazable desde la instrucción o el caso base.',
      items: triage.confirmed.length ? triage.confirmed : ['Sin dato confirmado suficiente todavía.']
    },
    {
      title: '2. Sugerencia clínica revisable',
      tone: 'Proponer familia y plantilla como borrador, nunca como cierre definitivo.',
      items: [
        ...(triage.suggested.length ? triage.suggested : ['Sin sugerencia automática útil todavía.']),
        ...expectedPresent.map((field) => `Campo ya presente y reutilizable: ${field}`),
        ...optionalPresent.slice(0, 3).map((field) => `Complementario disponible: ${field}`)
      ]
    },
    {
      title: '3. Faltante crítico',
      tone: `Completar manualmente antes de usar ${config.label.toLowerCase()}.`,
      items: expectedMissing.length ? expectedMissing : ['Sin faltantes críticos para este tipo documental.']
    }
  ];

  el('sectionFlow').innerHTML = sections.map((section) => `
    <div class="warn" style="margin-bottom:10px;">
      <strong>${section.title}</strong>
      <div class="muted" style="margin:4px 0 8px;">${section.tone}</div>
      <ul>${section.items.map((item) => `<li>${item}</li>`).join('')}</ul>
    </div>
  `).join('');

  const checks = [
    `Tipo documental activo: ${config.label}`,
    `Campos confirmados/presentes: ${expectedPresent.length}`,
    `Faltantes críticos visibles: ${expectedMissing.length}`,
    `Alertas relevantes visibles: ${relevantAlerts.length}`,
    `Borrador final: bloqueado (${reviewCase.draft_contract?.final_generation_blocked ? 'OK' : 'REVISAR'})`
  ];
  el('flowChecks').innerHTML = checks.map((item) => `<li>${item}</li>`).join('');
}

function renderSectionControls(reviewCase) {
  const sections = [
    {
      key: 'confirmed',
      title: 'Dato confirmado',
      detail: 'Validar que solo queden datos trazables desde la instruccion o el caso base.'
    },
    {
      key: 'suggested',
      title: 'Sugerencia clinica revisable',
      detail: 'Confirmar que la familia y la plantilla propuestas sean corregibles manualmente.'
    },
    {
      key: 'missing',
      title: 'Faltante critico',
      detail: 'Marcar si los faltantes visibles alcanzan para frenar cualquier uso clinico.'
    }
  ];

  el('sectionControls').innerHTML = sections.map((section) => `
    <div class="warn" style="margin-bottom:10px;">
      <strong>${section.title}</strong>
      <div class="muted" style="margin:4px 0 8px;">${section.detail}</div>
      <select data-review-section="${section.key}">
        <option value="pending" ${state.sectionReview[section.key] === 'pending' ? 'selected' : ''}>Pendiente</option>
        <option value="ok" ${state.sectionReview[section.key] === 'ok' ? 'selected' : ''}>OK local</option>
        <option value="followup" ${state.sectionReview[section.key] === 'followup' ? 'selected' : ''}>Revisar antes de uso</option>
        <option value="blocked" ${state.sectionReview[section.key] === 'blocked' ? 'selected' : ''}>Bloqueado</option>
      </select>
    </div>
  `).join('');

  document.querySelectorAll('[data-review-section]').forEach((node) => {
    node.addEventListener('change', (event) => {
      state.sectionReview[event.target.dataset.reviewSection] = event.target.value;
      renderReviewSummary(reviewCase);
      el('draft').textContent = buildDraft(reviewCase);
      persistReviewState();
    });
  });
}

function renderReviewSummary(reviewCase) {
  const labels = {
    pending: 'Pendiente',
    ok: 'OK local',
    followup: 'Revisar antes de uso',
    blocked: 'Bloqueado'
  };
  const criticalMissing = getDocumentView(reviewCase).expectedMissing;
  const blockedSections = Object.entries(state.sectionReview).filter(([, value]) => value === 'blocked');
  const followupSections = Object.entries(state.sectionReview).filter(([, value]) => value === 'followup');
  const okSections = Object.entries(state.sectionReview).filter(([, value]) => value === 'ok').length;
  const note = state.reviewNote.trim();

  el('reviewSummary').innerHTML = `
    <strong>Estado local:</strong> ${okSections}/3 secciones en OK local.<br>
    <strong>Pendientes criticos:</strong> ${criticalMissing.length ? criticalMissing.join(', ') : 'sin faltantes criticos para este tipo documental'}<br>
    <strong>Secciones a revisar:</strong> ${followupSections.length ? followupSections.map(([key]) => key).join(', ') : 'ninguna marcada'}<br>
    <strong>Bloqueos locales:</strong> ${blockedSections.length ? blockedSections.map(([key]) => key).join(', ') : 'sin bloqueo local marcado'}<br>
    <strong>Nota breve:</strong> ${note || 'sin nota local'}
  `;

  renderPersistenceStatus();

  const noteEl = el('reviewNote');
  if (noteEl && noteEl.value !== state.reviewNote) noteEl.value = state.reviewNote;
}

function buildEmbeddedRationale(reviewCase, documentType = el('documentType').value) {
  const { config, expectedMissing } = getDocumentViewForType(reviewCase, documentType);
  return MEDICOLEGAL_FOUNDATIONS
    .filter((item) => item.appliesTo.includes(documentType))
    .map((item) => ({
      ...item,
      detail: item.key === 'identificacion_autoria'
        ? `${item.text} ${expectedMissing.some((field) => ['fecha_acto_quirurgico', 'hora_inicio', 'hora_fin'].includes(field)) ? 'En este borrador, fecha/hora siguen como completado manual obligatorio.' : 'En este borrador no quedan faltantes críticos de fecha/hora.'}`
        : item.key === 'cronologia_tecnica'
          ? `${item.text} ${expectedMissing.length ? `Faltantes críticos visibles: ${expectedMissing.join(', ')}.` : 'Sin faltantes críticos visibles para este documento base.'}`
          : item.key === 'evolucion_destino'
            ? `${item.text} ${expectedMissing.includes('destino') ? 'Destino sigue pendiente de validación manual.' : 'Destino ya tiene base documentada en este borrador.'}`
            : item.text
    }));
}

function buildSyntheticFinalDocument(reviewCase, documentType = el('documentType').value) {
  const config = getDocumentConfigByLabel(documentType);
  const instruction = el('instruction').value || 'Sin instrucción cargada';
  const isCircumferentialLumbar = reviewCase.family_code === 'lumbar_fijacion_miss_artrodesis' && /circunferencial|360|plif|l4-l5/i.test(instruction);
  const isCervicalLaminoplasty = reviewCase.family_code === 'cervical_laminoplastia_descompresion' && /laminoplast|cervical|c3[\/-]7|cuadriparesia|mielopat/i.test(instruction);
  if (!isCircumferentialLumbar && !isCervicalLaminoplasty) return null;

  if (isCircumferentialLumbar) {
    const historia = [
      'CLINICA LA PEQUEÑA FAMILIA',
      'SERVICIO DE NEUROCIRUGIA',
      'HISTORIA CLINICA',
      '',
      'PACIENTE: Paciente prueba.        EDAD: ____ años.        FECHA: ____ de __________ de 20__.',
      '',
      'MOTIVO DE INGRESO: cirugía lumbar L4-5 para descompresión neural y estabilización circunferencial del segmento.',
      '',
      'ENFERMEDAD ACTUAL: lumbalgia y radiculalgia de evolución progresiva, con limitación para la marcha y las actividades habituales, sin respuesta adecuada a tratamientos conservadores, por lo que se plantea resolución quirúrgica del nivel L4-5.',
      '',
      'EXAMEN FÍSICO: lúcido/a, hemodinámicamente compensado/a. Sin déficit motor grosero al ingreso. <i>Completar hallazgos segmentarios, sensibilidad, reflejos y maniobras de tensión radicular.</i>',
      '',
      'RMN: cambios degenerativos del segmento L4-5 con compromiso del canal y/o de los recesos laterales, asociados a inestabilidad segmentaria. <i>Completar descripción exacta según estudio real.</i>',
      '',
      'EXAMENES PREQUIRURGICOS: en rango aceptable para procedimiento programado. <i>Completar ECG, Rx tórax, laboratorio y evaluación preanestésica efectivamente realizada.</i>',
      '',
      'IMPRESIÓN DIAGNOSTICA: patología degenerativa lumbar L4-5 sintomática con inestabilidad y compromiso neural.',
      '',
      'PLAN TERAPEUTICO: fijación instrumentada y artrodesis lumbar L4-5.',
      '',
      'Se informaron al paciente y a sus familiares sobre los objetivos, riesgos, beneficios y alternativas del procedimiento. Se firmaron consentimientos.'
    ].join('\n');

    const parte = [
      'CLINICA LA PEQUEÑA FAMILIA',
      'SERVICIO DE NEUROCIRUGIA',
      'PARTE QUIRURGICO',
      '',
      'PACIENTE: Paciente prueba.        EDAD: ____ años.        FECHA: ____ de __________ de 20__.',
      '',
      'CIRUJANO: Carlos Zanardi.        AYUDANTES: <i>__________________</i>.',
      '',
      'DIAGNOSTICO: patología degenerativa lumbar L4-5 con inestabilidad y compromiso neural.',
      '',
      'OPERACIÓN: fijación instrumentada y artrodesis lumbar L4-5.',
      '',
      'Código: <i>__________________</i>.',
      '',
      'Decúbito prono, soportes bajo tórax y tobillos. Se constatan pulsos pedios. Antisepsia rigurosa y campos. Infiltración de celular. Incisión medial por planos. Escoplado paravertebral bilateral hasta exponer puntos de entrada pedicular del nivel L4-5. Corroboración radioscópica de nivel. Colocación de tornillos transpediculares poliaxiales en L4 y L5 bilateralmente bajo control intraoperatorio. Preparación del espacio discal L4-5 y del lecho de artrodesis según técnica. Colocación del sistema de fijación posterior y estabilización circunferencial del segmento. <i>Se dispone injerto óseo y/o sustituto según disponibilidad y criterio intraoperatorio.</i> Hemostasia completa. <i>Drenaje al lecho documentado por indicación médica.</i> Cierre por planos. Cura plana, oclusiva y compresiva. Procedimiento bien tolerado, sin complicaciones evidentes.',
      '',
      '<i>Completado por app para cierre visual de prueba: ayudantes, código, tipo y medidas exactas de implantes, lotes, horarios, hallazgos confirmados, hemostáticos y destino postoperatorio requieren validación manual si se fuera a usar clínicamente.</i>'
    ].join('\n');

    const evolucion = [
      'CLINICA LA PEQUEÑA FAMILIA',
      'SERVICIO DE NEUROCIRUGIA',
      'EVOLUCIÓN',
      '',
      'PACIENTE: Paciente prueba.        EDAD: ____ años.        FECHA: ____ de __________ de 20__.',
      '',
      'POI de fijación instrumentada y artrodesis lumbar L4-5. Procedimiento bien tolerado. Sin déficit motor grosero en el control inmediato. Se dejan indicaciones postoperatorias y control evolutivo.',
      '',
      '<i>Completado por app para cierre visual de prueba: falta consignar examen neurológico posoperatorio específico, destino, drenajes, analgesia e indicaciones nominales.</i>'
    ].join('\n');

    if (config.code === 'hc') return `${historia}\n\n${evolucion}`;
    if (config.code === 'parte') return `${parte}\n\n${evolucion}`;
    return `${historia}\n\n${parte}\n\n${evolucion}`;
  }

  const historiaCervical = [
    'CLINICA LA PEQUEÑA FAMILIA',
    'SERVICIO DE NEUROCIRUGIA',
    'HISTORIA CLINICA',
    '',
    'PACIENTE: Paciente prueba.        EDAD: <i>____ años</i>.        FECHA: <i>____ de __________ de 20__</i>.',
    '',
    'MOTIVO DE INGRESO: cirugía de canal estrecho cervical sintomático C3-7.',
    '',
    'ENFERMEDAD ACTUAL: cuadriparesia leve progresiva, de evolución insidiosa, asociada a dificultad funcional creciente y compromiso mielopático cervical, por lo que se indica tratamiento quirúrgico descompresivo.',
    '',
    'EXAMEN FÍSICO: lúcido/a, hemodinámicamente compensado/a. Cuadriparesia leve. <i>Completar distribución, reflejos osteotendinosos, sensibilidad, marcha y signos piramidales.</i>',
    '',
    'RMN: canal estrecho cervical C3-7 con compresión medular. <i>Completar si existe mielomalacia, rectificación o cifosis, y el nivel de mayor compromiso.</i>',
    '',
    'EXAMENES PREQUIRURGICOS: en rango quirúrgico. <i>Completar laboratorio, Rx tórax y valoración cardiológica/anestésica efectivamente realizadas.</i>',
    '',
    'IMPRESIÓN DIAGNÓSTICA: canal estrecho cervical sintomático con mielopatía cervical y cuadriparesia leve progresiva.',
    '',
    'PLAN TERAPÉUTICO: laminoplastia C3-7, técnica open-door.',
    '',
    'Se informó al paciente y sus familiares sobre los objetivos y riesgos del procedimiento. Se firmaron consentimientos.'
  ].join('\n');

  const parteCervical = [
    'CLINICA LA PEQUEÑA FAMILIA',
    'SERVICIO DE NEUROCIRUGIA',
    'PARTE QUIRURGICO',
    '',
    'PACIENTE: Paciente prueba.        EDAD: <i>____ años</i>.        FECHA: <i>____ de __________ de 20__</i>.',
    '',
    'CIRUJANO: Carlos Zanardi.        AYUDANTE: <i>__________________</i>.',
    '',
    'DIAGNOSTICO: canal estrecho cervical C3-7 con cuadro de cuadriparesia leve progresiva.',
    '',
    'OPERACIÓN: laminoplastia C3-7 open-door.',
    '',
    'Código: <i>12.17.02 + instrumentación</i>.',
    '',
    'Decúbito prono, soportes bajo tórax, crestas ilíacas y tobillos. Mayfield. Se constatan pulsos pedios. Antisepsia rigurosa y campos. Infiltración de celular. Incisión medial desde C1 hasta D1, por planos. Disección paravertebral bilateral respetando los ligamentos interespinoso y nucal. Expuestas bilateralmente las partes mediales de los macizos articulares de C3 a C7, se realiza laminotomía del lado de apertura y canal de bisagra contralateral en la unión lámino-articular. Apertura de las láminas en bisagra. Fijación en posición de las láminas con placas de laminoplastia. El saco dural queda descomprimido y pulsátil. Hemostasia completa. <i>Si correspondiera, colocar chips de hueso y/o sustituto óseo en la canaleta de bisagra.</i> Cierre de músculo, aponeurosis, celular y piel por planos. Cura plana, oclusiva y compresiva. Procedimiento bien tolerado, sin complicaciones evidentes.',
    '',
    '<i>Completado por app para cierre visual de prueba: edad, fecha, ayudante, lateralidad exacta de apertura, cantidad/tipo de placas, hallazgos medulares específicos y cualquier evento hemodinámico intraoperatorio requieren validación manual.</i>'
  ].join('\n');

  const evolucionCervical = [
    'CLINICA LA PEQUEÑA FAMILIA',
    'SERVICIO DE NEUROCIRUGIA',
    'EVOLUCIÓN',
    '',
    'PACIENTE: Paciente prueba.        EDAD: <i>____ años</i>.        FECHA: <i>____ de __________ de 20__</i>.',
    '',
    'POI de laminoplastia cervical C3-7 para tratamiento de canal estrecho cervical sintomático. Moviliza los 4 miembros, sin déficit agregado evidente en el control inmediato. Se dejan indicaciones postoperatorias.',
    '',
    '<i>Completado por app para cierre visual de prueba: falta consignar destino final, examen neurológico detallado, drenajes y esquema analgésico/postoperatorio.</i>'
  ].join('\n');

  if (config.code === 'hc') return `${historiaCervical}\n\n${evolucionCervical}`;
  if (config.code === 'parte') return `${parteCervical}\n\n${evolucionCervical}`;
  return `${historiaCervical}\n\n${parteCervical}\n\n${evolucionCervical}`;
}

function buildDraft(reviewCase, documentType = el('documentType').value) {
  const { config, expectedPresent, expectedMissing, optionalPresent, optionalMissing, relevantAlerts } = getDocumentViewForType(reviewCase, documentType);
  const triage = buildInstructionTriage(reviewCase);
  const embeddedRationale = buildEmbeddedRationale(reviewCase, documentType);
  const suggestionLine = state.lastSuggestion
    ? `Sugerencia automática: ${state.lastSuggestion.familyLabel} (${state.lastSuggestion.confidence}; motivo: ${state.lastSuggestion.reasons.join(', ') || 'sin palabras clave trazables'})`
    : 'Sugerencia automática: sin coincidencia suficiente, requiere selección manual';
  const overrideLine = state.manualOverride
    ? 'Selección final: corregida manualmente por el médico/revisor.'
    : 'Selección final: coincide con la sugerencia automática actual.';
  const blockedDomains = reviewCase.missing_fields_map.blocked_inference_domains || [];
  const syntheticFinal = buildSyntheticFinalDocument(reviewCase, documentType);
  const institution = INSTITUTIONS[state.institutionKey] || INSTITUTIONS.clinica_centro;

  return [
    `Documento: ${config.label}`,
    `Institución seleccionada: ${institution.label}`,
    `Cirujano principal: ${state.surgeonName || 'Carlos Zanardi'}`,
    `Familia: ${reviewCase.family_label}`,
    `Instrucción médica: ${el('instruction').value || 'Sin instrucción cargada'}`,
    suggestionLine,
    overrideLine,
    `Semáforo: ${reviewCase.semaforo.toUpperCase()}`,
    `Mesa de revisión local: dato_confirmado=${state.sectionReview.confirmed}; sugerencia_clinica=${state.sectionReview.suggested}; faltante_critico=${state.sectionReview.missing}`,
    `Nota breve local: ${state.reviewNote || 'sin nota local'}`,
    '',
    `${config.blockedTitle}:`,
    ...config.blockedBullets.map((item) => `- ${item}`),
    `- Campos críticos faltantes para ${config.code}: ${expectedMissing.length}.`,
    `- Alertas relevantes para ${config.code}: ${relevantAlerts.length}.`,
    `- Dominios bloqueados para inferencia automática: ${blockedDomains.length ? blockedDomains.join(', ') : 'ninguno en este caso'}.`,
    '',
    'Triage de la instrucción libre:',
    ...(triage.confirmed.length ? triage.confirmed.map((item) => `✓ Confirmado: ${item}`) : ['• Confirmado: sin dato trazable suficiente todavía']),
    ...(triage.suggested.length ? triage.suggested.map((item) => `• Sugerencia clínica: ${item}`) : ['• Sugerencia clínica: sin sugerencia automática útil todavía']),
    ...expectedMissing.map((field) => `• Faltante crítico: ${field}`),
    '',
    `${config.checklistTitle}:`,
    ...expectedPresent.map((field) => `✓ Campo esperado presente: ${field}`),
    ...expectedMissing.map((field) => `• Completar manualmente: ${field}`),
    '',
    'Fundamentos médico-legales embebidos:',
    ...embeddedRationale.map((item) => `• ${item.shortLabel}: ${item.detail} Fundamento: ${item.basis}`),
    ...(optionalPresent.length || optionalMissing.length ? ['', 'Campos complementarios:'] : []),
    ...optionalPresent.map((field) => `✓ Complementario presente: ${field}`),
    ...optionalMissing.map((field) => `• Complementario faltante: ${field}`),
    ...(syntheticFinal ? ['', 'Borrador sintético de producto final de la aplicación:', syntheticFinal] : [])
  ].join('\n');
}

function renderDualWorkflow(reviewCase) {
  const docs = ['Historia clínica', 'Parte quirúrgico'];
  const cards = docs.map((documentType) => {
    const { config, expectedMissing, expectedPresent } = getDocumentViewForType(reviewCase, documentType);
    const synthetic = buildSyntheticFinalDocument(reviewCase, documentType);
    const embeddedRationale = buildEmbeddedRationale(reviewCase, documentType);
    const preview = (synthetic || buildDraft(reviewCase, documentType))
      .split('\n')
      .filter(Boolean)
      .slice(0, 5)
      .join(' · ');
    return `
      <div class="warn" style="margin-bottom:10px;">
        <strong>${config.label}</strong><br>
        <span class="muted">Mismo relato coloquial, misma familia sugerida, salida base distinta por tipo documental.</span>
        <ul>
          <li>Campos presentes reutilizables: ${expectedPresent.length}</li>
          <li>Faltantes críticos visibles: ${expectedMissing.length ? expectedMissing.join(', ') : 'sin faltantes críticos para esta base'}</li>
          <li>Borrador base: ${synthetic ? 'listo para preview institucional' : 'modo checklist/borrador bloqueado'}</li>
          <li>Fundamento prudente principal: ${embeddedRationale[0] ? `${embeddedRationale[0].shortLabel}. ${embeddedRationale[0].detail}` : 'sin fundamento cargado'}</li>
        </ul>
        <div class="muted">Vista rápida: ${escapeHtml(preview)}</div>
      </div>
    `;
  });

  el('dualWorkflow').innerHTML = cards.join('') + '<div class="warn"><strong>Flujo simple esperado</strong><div>1. Se carga audio/texto coloquial. 2. La app sugiere familia clínica. 3. Se revisan faltantes críticos. 4. Se obtiene base separada para historia clínica y parte quirúrgico sin liberar salida final.</div></div>';
}

function renderFormalReviewSources() {
  el('hcParteSources').innerHTML = FORMAL_REVIEW_SOURCES.map((source) => `
    <li><strong>${source.status.toUpperCase()}</strong> · ${source.title}<br><span class="muted">${source.path} · ${source.note}</span></li>
  `).join('');

  el('hcPartePendingReview').innerHTML = 'Base médico-legal avanzada en modo detect-only/review_only. Estado vigente: NO APTO_PARA_ENTREGAR sin revisión humana final. El gate de 6 controles sirve para tamiz prudente y las tres fuentes documentales quedan congeladas como baseline interno, con cierre formal todavía pendiente.';
}

function escapeHtml(text) {
  return String(text || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function formatDocumentHtml(raw) {
  return String(raw || '')
    .split('\n')
    .map((line) => {
      const trimmed = line.trim();
      if (!trimmed) return '<p>&nbsp;</p>';
      const safe = escapeHtml(trimmed)
        .replace(/&lt;i&gt;(.*?)&lt;\/i&gt;/g, '<span class="app-fill">$1</span>');
      return `<p>${safe}</p>`;
    })
    .join('');
}

function renderInstitutionalPreview(reviewCase) {
  const institution = INSTITUTIONS[state.institutionKey] || INSTITUTIONS.clinica_centro;
  const config = getDocumentConfig();
  const syntheticFinal = buildSyntheticFinalDocument(reviewCase);
  const draftSource = syntheticFinal || buildDraft(reviewCase);
  const surgeon = state.surgeonName || 'Carlos Zanardi';
  el('documentPreview').innerHTML = `
    <div class="doc-header">
      <img class="doc-logo" src="${institution.logo}" alt="${institution.label}">
      <div class="doc-title">
        <h4>${institution.label}</h4>
        <p>${institution.headerLine}<br>${institution.cityLine}<br>${config.label} · Cirujano: ${escapeHtml(surgeon)}</p>
      </div>
    </div>
    <div class="doc-body">${formatDocumentHtml(draftSource)}</div>
  `;

  const exportBase = `${reviewCase.family_code}_${config.code}_${state.institutionKey}`;
  const rationaleList = buildEmbeddedRationale(reviewCase, config.label)
    .map((item) => `<li><strong>${item.shortLabel}</strong>: ${escapeHtml(item.basis)}</li>`).join('');
  el('exportStatus').innerHTML = [
    `<strong>HTML preview listo</strong> para exportación local`,
    `Nombre base sugerido: <code>${exportBase}</code>`,
    'Pipeline actual: vista institucional en navegador -> imprimir a PDF o guardar HTML -> convertir a Word si hace falta.',
    '<span class="muted">Los fragmentos resaltados en amarillo son texto completado por app y requieren validación humana.</span>',
    rationaleList ? `<div style="margin-top:8px"><strong>Fundamentos embebidos:</strong><ul>${rationaleList}</ul></div>` : ''
  ].join('<br>');
}

function renderSixControlGate(reviewCase) {
  const criticalMissing = getDocumentView(reviewCase).expectedMissing;
  const statusByControl = {
    identificacion: criticalMissing.some((field) => ['fecha_acto_quirurgico', 'hora_inicio', 'hora_fin'].includes(field)) ? 'PENDIENTE_FORMAL' : 'BASE_OK',
    consentimiento_material: 'BASE_OK',
    parte_critico: criticalMissing.some((field) => ['tecnica_quirurgica', 'hallazgos_intraoperatorios', 'complicaciones', 'implantes', 'implante_marca_lote_serie', 'hemostatico_nombre_lote_cantidad', 'parche_duramadre_marca_lote_serie', 'verificacion_nivel_radioscopia'].includes(field)) ? 'PENDIENTE_FORMAL' : 'BASE_OK',
    addendas: 'BASE_OK',
    confidencialidad: 'BASE_OK',
    integridad: 'PENDIENTE_FORMAL'
  };

  const items = SIX_CONTROL_GATE.map((control) => {
    const status = statusByControl[control.key] || 'BASE_OK';
    const pendingDetail = status === 'PENDIENTE_FORMAL'
      ? `<br>Faltantes críticos visibles: ${criticalMissing.join(', ')}`
      : '<br>Sin faltantes críticos visibles para este control en review_only.';
    return `<li><strong>${status}</strong> · ${control.title}<br><span class="muted">Docs: ${control.docSignals.join(' | ')}<br>App review_only: ${control.appSignals.join(' | ')}${pendingDetail}</span></li>`;
  });

  const verdict = criticalMissing.length
    ? 'Base médico-legal avanzada con faltantes críticos visibles para revisión interna. Estado del gate: BASE_AVANZADA_REVIEW_ONLY, modo detect-only/review_only preservado y revisión humana/Codex Guard obligatoria antes de cualquier entrega.'
    : 'Base avanzada y gate local consistente para revisión interna. Estado del gate: BASE_AVANZADA_REVIEW_ONLY, con detect-only/review_only preservado. Igual no corresponde decir cumplimiento total ni cierre legal definitivo: sigue siendo review_only con revisión humana/Codex Guard obligatoria.';

  el('hcParteGate').innerHTML = items.join('');
  el('hcParteVerdict').innerHTML = verdict;
}

function renderMedicoLegalGate(reviewCase) {
  const sourceGuardrails = reviewCase.source_guardrails || {};
  const blockedDomains = reviewCase.missing_fields_map.blocked_inference_domains || [];
  const medicoLegalItems = [
    sourceGuardrails.no_literal_phi_output ? 'Sin salida literal de PHI en la interfaz.' : 'Revisar: posible salida PHI no bloqueada.',
    sourceGuardrails.no_pdf_generated ? 'PDF deshabilitado en modo review_only.' : 'Revisar: PDF no debería estar habilitado.',
    reviewCase.draft_contract?.final_generation_blocked ? 'Generación final bloqueada hasta revisión humana.' : 'Revisar: borrador final no debería liberarse.',
    reviewCase.draft_contract?.codex_guard_required ? 'Tamiz Codex Guard requerido antes de cualquier entrega.' : 'Revisar: falta compuerta Codex Guard.',
    'Modo detect-only preservado: sin PDF, sin publicación y sin cierre automático legal.'
  ];

  el('medicoLegalGate').innerHTML = medicoLegalItems.map((item) => `<li>${item}</li>`).join('');
  el('blockedDomains').innerHTML = blockedDomains.length
    ? blockedDomains.map((domain) => `<li><strong>${domain}</strong> <span class="muted">(completar manualmente)</span></li>`).join('')
    : '<li>Sin dominios bloqueados para este caso.</li>';
}

function renderCase(reviewCase) {
  state.selectedCaseId = reviewCase.case_id;
  loadPersistedReviewState(reviewCase.case_id);
  document.querySelectorAll('.case-card').forEach((node) => {
    node.classList.toggle('active', node.dataset.caseId === reviewCase.case_id);
  });

  el('caseTitle').textContent = reviewCase.family_label;
  el('caseMeta').textContent = `${reviewCase.domain} · case_id ${reviewCase.case_id} · ${el('documentType').value}`;
  el('semaforo').innerHTML = semaforoBadge(reviewCase.semaforo);

  const { config, expectedMissing, optionalMissing, relevantAlerts } = getDocumentView(reviewCase);
  el('missingFields').innerHTML = expectedMissing.length || optionalMissing.length
    ? [
        ...expectedMissing.map((field) => `<li><strong>${field}</strong> <span class="muted">(requerido en ${config.label})</span></li>`),
        ...optionalMissing.map((field) => `<li>${field} <span class="muted">(complementario)</span></li>`)
      ].join('')
    : `<li>Sin campos faltantes relevantes para ${config.label.toLowerCase()}.</li>`;

  el('alerts').innerHTML = relevantAlerts.length
    ? relevantAlerts.map((alert) => `<li><strong>${alert.field}</strong>: ${alert.reason}</li>`).join('')
    : `<li>Sin alertas específicas para ${config.label.toLowerCase()}.</li>`;

  renderMedicoLegalGate(reviewCase);
  renderFormalReviewSources();
  renderSixControlGate(reviewCase);
  renderSuggestion();
  renderInstructionTriage(reviewCase);
  renderSectionFlow(reviewCase);
  renderDualWorkflow(reviewCase);
  renderSectionControls(reviewCase);
  renderReviewSummary(reviewCase);
  renderSampleExpectation(reviewCase);
  renderFreeCasePanel(reviewCase);
  renderDualWorkflow(reviewCase);
  el('draft').textContent = buildDraft(reviewCase);
  renderInstitutionalPreview(reviewCase);
}

function applyInstructionSuggestion(payload) {
  const suggestion = inferFamilyFromInstruction(payload, el('instruction').value);
  state.lastSuggestion = suggestion;

  if (!state.manualOverride && suggestion) {
    el('familySelect').value = suggestion.caseId;
    const reviewCase = payload.review_cases.find((item) => item.case_id === suggestion.caseId);
    if (reviewCase) renderCase(reviewCase);
    return;
  }

  const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId) || payload.review_cases[0];
  if (current) renderCase(current);
}

function renderCaseList(payload) {
  const select = el('familySelect');
  const sampleSelect = el('sampleCaseSelect');
  select.innerHTML = payload.review_cases.map((reviewCase) => `<option value="${reviewCase.case_id}">${reviewCase.family_label}</option>`).join('');
  sampleSelect.innerHTML = ['<option value="">Seleccionar caso de prueba…</option>', ...Object.entries(SAMPLE_CASES).map(([key, sample]) => `<option value="${key}">${sample.label}</option>`)].join('');

  el('caseList').innerHTML = payload.review_cases.map((reviewCase) => `
    <div class="case-card" data-case-id="${reviewCase.case_id}">
      <strong>${reviewCase.family_label}</strong>
      <div class="muted">${reviewCase.domain} · ${reviewCase.missing_fields_map.missing_count} campos faltantes</div>
      <div style="margin-top:8px;">${semaforoBadge(reviewCase.semaforo)}</div>
    </div>
  `).join('');

  document.querySelectorAll('.case-card').forEach((node) => {
    node.addEventListener('click', () => {
      const reviewCase = payload.review_cases.find((item) => item.case_id === node.dataset.caseId);
      state.manualOverride = true;
      select.value = reviewCase.case_id;
      renderCase(reviewCase);
      persistReviewState();
    });
  });

  select.addEventListener('change', (event) => {
    state.manualOverride = true;
    const reviewCase = payload.review_cases.find((item) => item.case_id === event.target.value);
    renderCase(reviewCase);
    persistReviewState();
  });

  el('instruction').addEventListener('input', () => {
    state.manualOverride = false;
    applyInstructionSuggestion(payload);
    const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId);
    if (current) persistFreeCase(current);
    persistReviewState();
  });

  el('institutionSelect').addEventListener('change', (event) => {
    state.institutionKey = event.target.value;
    const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId);
    if (current) {
      renderInstitutionalPreview(current);
      el('draft').textContent = buildDraft(current);
      persistReviewState();
    }
  });

  el('surgeonName').addEventListener('input', (event) => {
    state.surgeonName = event.target.value;
    const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId);
    if (current) {
      renderInstitutionalPreview(current);
      el('draft').textContent = buildDraft(current);
      persistReviewState();
    }
  });

  el('reviewNote').addEventListener('input', (event) => {
    state.reviewNote = event.target.value;
    const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId);
    if (current) {
      renderReviewSummary(current);
      el('draft').textContent = buildDraft(current);
      persistReviewState();
    }
  });

  el('documentType').addEventListener('change', () => {
    const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId);
    state.activeFreeCase = loadFreeCase(el('documentType').value);
    if (current) {
      renderCase(current);
      persistReviewState();
    }
  });

  el('loadSampleBtn').addEventListener('click', () => {
    const sample = SAMPLE_CASES[sampleSelect.value];
    if (!sample) return;
    state.activeSampleKey = sampleSelect.value;
    state.manualOverride = false;
    el('instruction').value = sample.instruction;
    el('documentType').value = sample.documentType;
    applyInstructionSuggestion(payload);
    const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId);
    if (current) {
      persistFreeCase(current);
      renderFreeCasePanel(current);
    }
    persistReviewState();
  });

  el('newCaseBtn').addEventListener('click', () => {
    state.manualOverride = false;
    applyInstructionSuggestion(payload);
    const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId);
    if (current) {
      persistFreeCase(current);
      renderFreeCasePanel(current);
      persistReviewState();
    }
  });

  el('resetReviewBtn').addEventListener('click', () => {
    resetReviewState({ persist: false });
    removePersistedReviewState();
    const current = payload.review_cases.find((item) => item.case_id === state.selectedCaseId);
    if (current) {
      renderSectionControls(current);
      renderReviewSummary(current);
      el('draft').textContent = buildDraft(current);
    }
  });

  const activeSelection = loadActiveSelection();
  if (activeSelection?.documentType && DOCUMENT_CONFIG[activeSelection.documentType]) {
    el('documentType').value = activeSelection.documentType;
  }
  if (activeSelection?.instruction) {
    el('instruction').value = activeSelection.instruction;
  }
  if (activeSelection?.activeSampleKey && SAMPLE_CASES[activeSelection.activeSampleKey]) {
    sampleSelect.value = activeSelection.activeSampleKey;
    state.activeSampleKey = activeSelection.activeSampleKey;
  }
  if (activeSelection?.institutionKey && INSTITUTIONS[activeSelection.institutionKey]) {
    state.institutionKey = activeSelection.institutionKey;
    el('institutionSelect').value = activeSelection.institutionKey;
  }
  if (activeSelection?.surgeonName) {
    state.surgeonName = activeSelection.surgeonName;
    el('surgeonName').value = activeSelection.surgeonName;
  }

  const activeDocumentType = el('documentType')?.value || 'Historia clínica';
  const restoredFreeCase = activeSelection?.activeFreeCase;
  state.activeFreeCase = restoredFreeCase && restoredFreeCase.documentType === activeDocumentType
    ? restoredFreeCase
    : loadFreeCase(activeDocumentType);

  const initialCase = payload.review_cases.find((item) => item.case_id === activeSelection?.selectedCaseId) || payload.review_cases[0];
  state.selectedCaseId = initialCase.case_id;
  select.value = initialCase.case_id;
  state.manualOverride = Boolean(activeSelection?.manualOverride);

  if (activeSelection?.instruction) {
    const preservedCaseId = state.manualOverride ? initialCase.case_id : null;
    applyInstructionSuggestion(payload);
    if (preservedCaseId) {
      const preservedCase = payload.review_cases.find((item) => item.case_id === preservedCaseId);
      if (preservedCase) {
        state.manualOverride = true;
        el('familySelect').value = preservedCase.case_id;
        renderCase(preservedCase);
      }
    }
  } else {
    renderCase(initialCase);
  }
}

async function init() {
  const payload = window.__APP_DATA__;
  if (!payload?.review_cases?.length) throw new Error('Paquete review_only embebido ausente o inválido');
  state.payload = payload;
  renderStats(payload);
  renderCaseList(payload);
}

init().catch((error) => {
  document.body.innerHTML = `<pre style="padding:24px;">Error cargando MVP review_only:\n${error.stack}</pre>`;
});
